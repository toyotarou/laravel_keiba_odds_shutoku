
    /**
     * ═══════════════════════════════════════════════════════════════════════
     * @ANCHOR-20261020-R122-NATIVE  合成試験と取消の例を「本体」へ直接通す
     * ═══════════════════════════════════════════════════════════════════════
     * 【10月20日005のご指摘6-1・11-4】
     *   これまで合成729件＋境界4件は、Command側の検証用関数
     *   （self::r122Decide／self::r122AcceptBatch）へ通していました。
     *   <b>本番が使う本体の関数へ通した試験ではありませんでした。</b>
     *   取消の配分も、11→10頭の不足移動しか試験がなく、
     *   目標数 C が変わる例（16→15・14→13・9→8・全頭取消）は
     *   コードを直したのに試験がありませんでした。
     *
     *   この試験は、本番が呼ぶ本体の関数だけを使います。
     *     BaganrikiSignals::v04Classify        mode・S・配分モード
     *     BaganrikiAllocation::v04TargetCount  目標数
     *     BaganrikiTime::acceptBatch       取得境界
     *     BaganrikiRanking::afterCancellation  取消後の引き直し
     *
     * 読むだけです。DBへは1行も書きません。
     */
    private function runR122Native(string $dir): void
    {
        self::r122Autoload();
        // AiController の v04Classify は BaganrikiSignals への薄い入口（private）です。
        // 本番が実際に計算しているのは BaganrikiSignals なので、そちらを呼びます。
        $S = \App\Http\Controllers\Api\BaganrikiSignals::class;
        $T = \App\Http\Controllers\Api\BaganrikiTime::class;
        $R = \App\Http\Controllers\Api\BaganrikiRanking::class;

        $this->info('════════════════════════════════════════════════════════');
        $this->info(' r12.2 合成試験と取消の例を「本体」へ直接通す');
        $this->info('════════════════════════════════════════════════════════');
        $this->line('  実行時刻 : ' . date('c'));
        $this->line('  対象     : ' . $dir);
        $this->warn('  ※ Command側の検証用関数は使いません。本体だけを呼びます');
        $this->line('');

        $pass = 0; $fail = 0;
        $ok = function (string $name, $got, $want, string $note = '')
              use (&$pass, &$fail) {
            if ($got === $want) {
                $pass++;
                $this->line(sprintf('  ○ %-12s %s', $name, $note));
            } else {
                $fail++;
                $this->error(sprintf('  × %-12s %s  期待=%s 実際=%s', $name, $note,
                    var_export($want, true), var_export($got, true)));
            }
        };

        // ── ① 合成729件を本体 v04Classify へ直接通す ────────────────────
        $this->info('── ① 合成729件を本体 BaganrikiSignals::v04Classify へ通す ──');
        $p1 = rtrim($dir, '/') . '/validation/mode_cases.json';
        if (!is_file($p1)) { $p1 = rtrim($dir, '/') . '/mode_cases.json'; }
        if (!is_file($p1)) {
            $this->error('  × mode_cases.json がありません: ' . $p1);
            $fail++;
        } else {
            $d = json_decode((string) file_get_contents($p1), true);
            $cases = (array) ($d['cases'] ?? []);
            // 先方の signals は true/false/null。本体は TRUE/FALSE/UNKNOWN の文字列です。
            $tri = static fn($v) => ($v === null) ? 'UNKNOWN' : ($v ? 'TRUE' : 'FALSE');
            $keys = ['mode', 'mode_status', 'allocation_mode', 'mode_policy_id',
                     'selection_enabled', 'S', 'S_min', 'S_max', 'display_rating'];
            $ng = 0; $shown = 0; $checked = 0;
            foreach ($cases as $c) {
                $sig = (array) ($c['signals'] ?? []);
                $flags = [];
                foreach (['X1', 'X2', 'X3', 'X4', 'X5', 'X6', 'Z'] as $k) {
                    $flags[$k] = $tri($sig[$k] ?? null);
                }
                $r = $S::v04Classify($flags);
                foreach ($keys as $k) {
                    if (!array_key_exists($k, (array) ($c['expected'] ?? []))) { continue; }
                    $checked++;
                    if ($c['expected'][$k] !== $r[$k]) {
                        $ng++;
                        if ($shown < 5) {
                            $shown++;
                            $this->error(sprintf('      %s %s 期待=%s 実際=%s 信号=%s',
                                (string) ($c['id'] ?? '?'), $k,
                                var_export($c['expected'][$k], true),
                                var_export($r[$k], true),
                                json_encode($sig)));
                        }
                        break;
                    }
                }
            }
            $this->line(sprintf('    %d 件（判定 %d 項目）', count($cases), $checked));
            $ok('N-01', $ng, 0, '本体 v04Classify との不一致');
            $ok('N-02', count($cases), 729, '通した件数');
        }
        $this->line('');

        // ── ② 境界4件を本体 acceptBatch へ直接通す ──────────────────────
        $this->info('── ② 取得境界4件を本体 BaganrikiTime::acceptBatch へ通す ──');
        $p2 = rtrim($dir, '/') . '/validation/acquisition_boundary_cases.json';
        if (!is_file($p2)) { $p2 = rtrim($dir, '/') . '/acquisition_boundary_cases.json'; }
        if (!is_file($p2)) {
            $this->error('  × acquisition_boundary_cases.json がありません: ' . $p2);
            $fail++;
        } else {
            $d = json_decode((string) file_get_contents($p2), true);
            $cases = (array) ($d['cases'] ?? []);
            $ng = 0;
            foreach ($cases as $c) {
                // 予定時刻は与えられていないので、情報上限から発走時刻を戻します。
                // 戻した発走時刻を渡すので、@ANCHOR-R122-ANCHORMATCH の
                // 「正本との一致検査」も一緒に通ります。
                $frz = $T::us((string) ($c['input_freeze_at'] ?? ''));
                if ($frz === null) {
                    $ng++;
                    $this->error('      ' . (string) ($c['id'] ?? '?') . ' 情報上限が読めません');
                    continue;
                }
                $anchor = $frz - $T::INPUT_FREEZE_OFFSET_SEC * 1000000;
                $r = $T::acceptBatch((int) $c['slot'], [
                    'request_started_at'   => (string) $c['request_started_at'],
                    'response_received_at' => (string) $c['response_received_at'],
                    'available_at'         => (string) $c['available_at'],
                    'input_freeze_at'      => (string) $c['input_freeze_at'],
                ], $anchor);
                $got  = ($r['ok'] ?? false) ? 'PASS' : 'FAIL';
                $want = (string) ($c['expected'] ?? '');
                if ($got !== $want) {
                    $ng++;
                    $this->error(sprintf('      %s 期待=%s 実際=%s %s',
                        (string) ($c['id'] ?? '?'), $want, $got,
                        (string) ($r['reason'] ?? '')));
                } else {
                    $this->line(sprintf('    ○ %-18s %s', (string) ($c['id'] ?? '?'), $got));
                }
            }
            $ok('N-03', $ng, 0, '本体 acceptBatch との不一致');
            $ok('N-04', count($cases), 4, '通した件数');
        }
        $this->line('');

        // ── ③ 正本の発走時刻との一致検査（新しい検査） ──────────────────
        $this->info('── ③ 申告された予定・情報上限が正本と合わないとき ──');
        $anchor = $T::us('2026-10-18T10:05:00+09:00');
        $frzOk  = $T::toJst($T::inputFreeze($anchor));
        $schOk  = $T::toJst($T::slotScheduled($anchor, 6));
        $mk = static function (array $over) use ($schOk, $frzOk) {
            return $over + ['slot_scheduled_at'    => $schOk,
                            'request_started_at'   => $schOk,
                            'response_received_at' => $schOk,
                            'available_at'         => $schOk,
                            'input_freeze_at'      => $frzOk];
        };
        $r = $T::acceptBatch(6, $mk([]), $anchor);
        $ok('N-05', $r['ok'], true, '正本と合っていれば採用');
        $r = $T::acceptBatch(6, $mk(['slot_scheduled_at' => $T::toJst($T::slotScheduled($anchor, 6) + 1000000)]), $anchor);
        $ok('N-06', $r['code'], 'SCHEDULE_MISMATCH', '予定が1秒ずれたら不採用');
        $r = $T::acceptBatch(6, $mk(['input_freeze_at' => $T::toJst($T::inputFreeze($anchor) + 1000000)]), $anchor);
        $ok('N-07', $r['code'], 'FREEZE_MISMATCH', '情報上限が1秒甘いと不採用');
        $this->line('');

        // ── ④ 日付・時刻の繰上がり ──────────────────────────────────────
        $this->info('── ④ 存在しない日付・時刻を受け取らない ──');
        $ok('N-08', $T::us('2026-02-30T10:05:00+09:00'), null, '2月30日は受け取らない');
        $ok('N-09', $T::us('2026-13-01T10:05:00+09:00'), null, '13月は受け取らない');
        $ok('N-10', $T::us('2026-10-18T25:00:00+09:00'), null, '25時は受け取らない');
        $ok('N-11', $T::us('2026-10-18T10:61:00+09:00'), null, '61分は受け取らない');
        $ok('N-12', $T::us('2025-02-29T10:05:00+09:00'), null, '平年の2月29日は受け取らない');
        $ok('N-13', ($T::us('2024-02-29T10:05:00+09:00') !== null), true, 'うるう年の2月29日は通る');
        $ok('N-14', ($T::us('2026-10-18T10:05:00.123456+09:00') !== null), true,
            'マイクロ秒つきは通る');
        $this->line('');

        // ── ⑤ 取消で目標数が変わる例を本体へ通す ────────────────────────
        $this->info('── ⑤ 取消で目標数 C が変わる例（16→15・14→13・9→8・全頭）──');
        //   凍結帯は維持したまま、最新の頭数から C と基本配分を引き直します。
        //   帯は「上位3＝A／次3＝B／残り＝D」ではなく、各例の形で作ります。
        $band = static function (int $n, int $a, int $b) {
            $m = [];
            for ($i = 1; $i <= $n; $i++) {
                $m[$i] = ($i <= $a) ? 'A' : (($i <= $a + $b) ? 'B' : 'D');
            }
            return $m;
        };
        //  N  取消後  配分モード  期待する基本配分
        $cases = [
            ['16→15', 16, [16], 'MIXED',    ['A' => 3, 'B' => 2, 'D' => 1], 6],
            ['14→13', 14, [14], 'MIXED',    ['A' => 3, 'B' => 2, 'D' => 0], 5],
            ['9→8',    9, [9],  'MIXED',    ['A' => 2, 'B' => 2, 'D' => 0], 4],
        ];
        $i = 15;
        foreach ($cases as $cs) {
            [$label, $n, $cancel, $mode, $wantBase, $wantC] = $cs;
            // A6・B6・残りD の形（帯は凍結したまま動かしません）
            $fb = $band($n, 6, 6);
            $old = $R::afterCancellation($fb, [], ['A' => 3, 'B' => 3, 'D' => 1], $mode);
            $ac  = $R::afterCancellation($fb, $cancel, ['A' => 3, 'B' => 3, 'D' => 1], $mode);
            $nm = 'N-' . str_pad((string) $i, 2, '0', STR_PAD_LEFT); $i++;
            $ok($nm, $ac['target_count'], $wantC,
                $label . ' の目標数（取消前 ' . var_export($old['target_count'], true) . '）');
            $nm = 'N-' . str_pad((string) $i, 2, '0', STR_PAD_LEFT); $i++;
            $ok($nm, $ac['base_quota'], $wantBase,
                $label . ' の基本配分 '
                . json_encode($ac['base_quota'] ?? null));
            $nm = 'N-' . str_pad((string) $i, 2, '0', STR_PAD_LEFT); $i++;
            $ok($nm, $ac['active_count'], $n - count($cancel), $label . ' の生存頭数');
        }
        // 全頭取消
        $fb = $band(16, 6, 6);
        $all = range(1, 16);
        $ac  = $R::afterCancellation($fb, $all, ['A' => 3, 'B' => 3, 'D' => 1], 'MIXED');
        $ok('N-24', $ac['all_cancelled'], true, '全頭取消は印を立てる');
        $ok('N-25', $ac['target_count'], 0, '全頭取消の目標数は0');
        $ok('N-26', $ac['live_quota'], null, '全頭取消では枠を返さない');
        $ok('N-27', $ac['active_count'], 0, '全頭取消の生存頭数は0');
        // 凍結帯を詰め直していないこと
        $ac2 = $R::afterCancellation($band(16, 6, 6), [1], ['A' => 3, 'B' => 3, 'D' => 1], 'MIXED');
        $ok('N-28', $ac2['band_alive']['A'], 5, '取消でAの生存が1減る（詰め直さない）');
        $ok('N-29', $ac2['band_alive']['B'], 6, 'Bは動かない（人気を繰り上げない）');
        // ══════════════════════════════════════════════════════════════
        // @ANCHOR-20261021-R122-PERCAND  10月21日008のご指摘4（取消の採用単位）
        // ══════════════════════════════════════════════════════════════
        //   なるが挙げた例をそのまま本体 pick へ通します。
        //     出馬表 1・2・3番
        //     A（先に利用可能）1・2番の単勝あり。3番は単勝も取消も<b>無い</b>
        //     B（後に利用可能）1・2番の単勝あり。3番の<b>正式取消</b>あり
        //     両方とも commit済み・時刻適合・hash正常
        //   合算した活動集合（1・2番）を使うと A が通ってしまいます。
        //   候補ごとに<b>自分の取消だけ</b>を引けば、A は3番の単勝が無いので
        //   落ち、B が採用されます。
        $this->info('── ⑥ 取消の採用単位（008のご指摘4）──');
        $mkB = static function (string $id, string $availAt, array $vals,
                                array $cancelled, bool $committed = true): array {
            return ['batch_id' => $id, 'slot' => 6,
                    'slot_scheduled_at'    => '2026-10-18T09:34:00+09:00',
                    'request_started_at'   => $availAt,
                    'response_received_at' => $availAt,
                    'available_at'         => $availAt,
                    'input_freeze_at'      => '2026-10-18T09:34:30+09:00',
                    'committed' => $committed, 'payload_ng' => null,
                    'values' => $vals, 'cancelled' => $cancelled];
        };
        $entry = [1, 2, 3];
        $vAB   = [1 => ['win' => '2.1'], 2 => ['win' => '4.5']];
        $vAll  = [1 => ['win' => '2.1'], 2 => ['win' => '4.5'], 3 => ['win' => '9.9']];
        $anchorUs6 = \App\Http\Controllers\Api\BaganrikiTime::us('2026-10-18T09:40:00+09:00');
        $A = $mkB('A', '2026-10-18T09:34:10+09:00', $vAB,  []);
        $B = $mkB('B', '2026-10-18T09:34:20+09:00', $vAB,  [3]);
        $pk = \App\Http\Controllers\Api\BaganrikiAcquisition::pick(6, [$A, $B], $entry, $anchorUs6);
        $ok('N-30', (string) ($pk['status'] ?? ''), 'ADOPTED',
            '採用できるバッチがある');
        $ok('N-31', (string) ($pk['batch']['batch_id'] ?? ''), 'B',
            '3番の取消を持つBを採用する（Aを選ばない）');
        $rejA = null;
        foreach ((array) $pk['rejected'] as $rj) {
            if ((string) ($rj['batch_id'] ?? '') === 'A') { $rejA = $rj; }
        }
        $ok('N-32', (string) ($rejA['code'] ?? ''), 'FREEZE_ODDS_MISSING',
            'Aは3番の単勝が無いので落ちる（別候補の取消を借りない）');
        $ok('N-33', strpos((string) ($rejA['reason'] ?? ''), '3') !== false, true,
            'その理由に馬番3が出る');

        // 未commit の取消は、ほかの候補を助けません
        $C = $mkB('C', '2026-10-18T09:34:10+09:00', $vAB, []);
        $D = $mkB('D', '2026-10-18T09:34:20+09:00', $vAB, [3], false);  // 未commit
        $pk2 = \App\Http\Controllers\Api\BaganrikiAcquisition::pick(6, [$C, $D], $entry, $anchorUs6);
        $ok('N-34', (string) ($pk2['status'] ?? ''), 'UNAVAILABLE',
            '未commitの取消では、どの候補も通らない');
        $codes2 = [];
        foreach ((array) $pk2['rejected'] as $rj) {
            $codes2[(string) $rj['batch_id']] = (string) $rj['code'];
        }
        $ok('N-35', $codes2['C'] ?? '', 'FREEZE_ODDS_MISSING',
            'Cは3番の単勝が無いので落ちる');
        $ok('N-36', $codes2['D'] ?? '', 'NOT_COMMITTED',
            'Dは未commitで落ちる');

        // 時刻不適合の取消も、ほかの候補を助けません
        $E = $mkB('E', '2026-10-18T09:34:10+09:00', $vAB, []);
        $F = $mkB('F', '2026-10-18T09:40:30+09:00', $vAB, [3]);  // 情報上限より後
        $pk3 = \App\Http\Controllers\Api\BaganrikiAcquisition::pick(6, [$E, $F], $entry, $anchorUs6);
        $codes3 = [];
        foreach ((array) $pk3['rejected'] as $rj) {
            $codes3[(string) $rj['batch_id']] = (string) $rj['code'];
        }
        $ok('N-37', (string) ($pk3['status'] ?? ''), 'UNAVAILABLE',
            '時刻不適合の取消でも、どの候補も通らない');
        $ok('N-38', $codes3['E'] ?? '', 'FREEZE_ODDS_MISSING',
            'Eは3番の単勝が無いので落ちる');
        $ok('N-39', ($codes3['F'] ?? '') !== '' && ($codes3['F'] ?? '') !== 'FREEZE_ODDS_MISSING',
            true, 'Fは時刻の理由で落ちる（' . ($codes3['F'] ?? '') . '）');

        // 自分で取消を持つ候補は、その馬を全頭検査から外せます（正しい動き）
        $G = $mkB('G', '2026-10-18T09:34:10+09:00', $vAB, [3]);
        $pk4 = \App\Http\Controllers\Api\BaganrikiAcquisition::pick(6, [$G], $entry, $anchorUs6);
        $ok('N-40', (string) ($pk4['status'] ?? ''), 'ADOPTED',
            '自分の取消なら、その馬は全頭検査から外れる');

        // 取消が無く全頭そろっていれば、これまでどおり先に来た方を採ります
        $H = $mkB('H', '2026-10-18T09:34:10+09:00', $vAll, []);
        $I = $mkB('I', '2026-10-18T09:34:20+09:00', $vAll, []);
        $pk5 = \App\Http\Controllers\Api\BaganrikiAcquisition::pick(6, [$H, $I], $entry, $anchorUs6);
        $ok('N-41', (string) ($pk5['batch']['batch_id'] ?? ''), 'H',
            '全頭そろっていれば先に利用できた方を採る（従来どおり）');
        $this->line('');

        $this->line('');

        $this->line('  判定件数 : ' . ($pass + $fail) . ' 件');
        $this->line('  合格     : ' . $pass . ' 件');
        $this->line('  不合格   : ' . $fail . ' 件');
        $this->line('');
        $this->info('════════════════════════════════════════════════════════');
        $this->info(($fail === 0)
            ? ' 本体へ直接通して契約どおりでした（書き込み0件）'
            : ' 合わない箇所があります。上の × をご確認ください');
        $this->info('════════════════════════════════════════════════════════');
    }
