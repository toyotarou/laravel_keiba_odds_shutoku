
    /**
     * ═══════════════════════════════════════════════════════════════════════
     * @ANCHOR-20261020-R122-PROMPT  同じファイルの中のクラスを読ませる一手間
     * ═══════════════════════════════════════════════════════════════════════
     * PSR-4 の自動読み込みは「クラス名＝ファイル名」で探すので、
     * AiController.php の<b>中に</b>置いた BaganrikiPrompt などは、
     * 外から名前で呼んでも見つかりません
     * （Class "App\Http\Controllers\Api\BaganrikiPrompt" not found）。
     * 先に AiController を読ませると、同じファイルにある全クラスが入ります。
     *
     * これは「新しいファイルを作らない」という決めごとの副作用です。
     * 10月19日の r122CompareWithProduction() で同じ手当てをしていましたが、
     * 今回足した入口（--r122-prompt-install / --r122-prompt-check）に
     * 入れ忘れていて、サーバで同じエラーが出ました。
     */
    private static function r122Autoload(): void
    {
        if (!class_exists(\App\Http\Controllers\Api\BaganrikiPrompt::class, false)) {
            class_exists(\App\Http\Controllers\Api\AiController::class);
        }
    }

    /**
     * ═══════════════════════════════════════════════════════════════════════
     * @ANCHOR-20261020-R122-PROMPT  配布された両AI本文を storage へ入れる
     * ═══════════════════════════════════════════════════════════════════════
     * 本文はコードへ書き写しません。配布ファイルをそのまま置き、
     * 置いた直後に中身（マーカー・版・差し込み記号）を確かめます。
     */
    private function runR122PromptInstall(string $srcDir): void
    {
        self::r122Autoload();
        $srcDir = rtrim($srcDir, '/');
        $dst = \App\Http\Controllers\Api\BaganrikiPrompt::dir();
        $this->info('══ r12.2 両AI本文の設置 ══');
        $this->line('  配布元: ' . $srcDir);
        $this->line('  置き場: ' . $dst);
        if (!is_dir($dst) && !@mkdir($dst, 0775, true) && !is_dir($dst)) {
            $this->error('  置き場を作れません: ' . $dst);
            return;
        }
        $ng = 0;
        foreach (\App\Http\Controllers\Api\BaganrikiPrompt::FILES as $role => $name) {
            $s = $srcDir . '/' . $name;
            if (!is_file($s)) {
                $this->error("  × {$name} が配布元にありません");
                $ng++;
                continue;
            }
            $body = file_get_contents($s);
            if (strncmp((string) $body, "\xEF\xBB\xBF", 3) === 0) {
                $body = substr((string) $body, 3);
                $this->line("  － {$name} の先頭のBOMを外しました（hashが変わるため）");
            }
            file_put_contents($dst . '/' . $name, $body);
            $this->line(sprintf('  ○ %-18s %7d バイト  sha256=%s',
                $name, strlen((string) $body), hash('sha256', (string) $body)));
        }
        $this->line('');
        foreach (['1st', '2nd', 'common'] as $role) {
            $b = \App\Http\Controllers\Api\BaganrikiPrompt::systemBody($role);
            if ($b['ok']) {
                $this->line(sprintf('  確認 %-7s 行数%4d  バイト%7d  sha256=%s',
                    $role, $b['lines'], $b['bytes'], $b['sha256']));
            } else {
                $this->error('  確認 ' . $role . ' × ' . $b['reason']);
                $ng++;
            }
        }
        $this->line('');
        if ($ng === 0) {
            $this->info('  設置できました。.env に BAGANRIKI_R122_PROMPT=1 を入れると'
                      . '新しい本文で送ります（既定は 0 で今までと同じ）。');
        } else {
            $this->error('  設置に失敗した項目が ' . $ng . ' 件あります。');
        }
    }

    /**
     * ═══════════════════════════════════════════════════════════════════════
     * @ANCHOR-20261020-R122-PROMPT  送信文の検査（AIへは送りません・費用0円）
     * ═══════════════════════════════════════════════════════════════════════
     * 根拠：10月20日003の確認結果①②／server_contract_r12.2.txt 5章・6章・9章
     *
     * 6つに分けて確かめます。
     *   §1 配布本文3本が、そのまま system として使える状態か
     *   §2 snapshot_hash の作り方が先方の実装と1バイト単位で同じか
     *      （先方の参照入力14本の snapshot_hash を再現できるか）
     *   §3 生の取得payloadから INPUT_JSON を組み立て、
     *      先方の参照入力と全キー一致するか（7ケース×2role）
     *   §4 組み立てた INPUT_JSON が同梱スキーマに適合するか
     *   §5 送信の一式（system＋user）の自己点検
     *   §6 本番DBの保存済みレースで組み立てられるか（--r122-prompt-real）
     */
    private function runR122PromptCheck(string $root): void
    {
        self::r122Autoload();
        $root = rtrim($root, '/');
        $pDir = is_dir($root . '/prompts')  ? $root . '/prompts'  : $root;
        $sDir = is_dir($root . '/schemas')  ? $root . '/schemas'  : $root;
        $vDir = is_dir($root . '/validation') ? $root . '/validation' : $root;
        $dump = (string) ($this->option('r122-prompt-dump') ?: '');

        $this->info('════════════════════════════════════════════════════════');
        $this->info(' r12.2 送信文の検査（AI呼び出し0回・費用0円・DB書込なし）');
        $this->info('════════════════════════════════════════════════════════');
        $this->line('  実行時刻 : ' . date('c'));
        $this->line('  資材      : ' . $root);
        $this->line('  本文置き場: ' . \App\Http\Controllers\Api\BaganrikiPrompt::dir());
        $this->line('');

        $ngTotal = 0;

        // ───────────────────────────────────────────────────────────────
        // §1 配布本文
        // ───────────────────────────────────────────────────────────────
        $this->info('── §1 配布本文3本の確認 ──');
        foreach (\App\Http\Controllers\Api\BaganrikiPrompt::FILES as $role => $name) {
            $b = \App\Http\Controllers\Api\BaganrikiPrompt::systemBody($role);
            $src = $pDir . '/' . $name;
            $same = (is_file($src) && $b['ok'])
                  ? (hash('sha256', (string) file_get_contents($src)) === $b['sha256']
                     || hash('sha256', ltrim((string) file_get_contents($src), "\xEF\xBB\xBF")) === $b['sha256'])
                  : false;
            if (!$b['ok']) {
                $this->error(sprintf('  × %-18s %s', $name, $b['reason']));
                $ngTotal++;
                continue;
            }
            $this->line(sprintf('  ○ %-18s 行%4d バイト%7d 配布と同一=%s',
                $name, $b['lines'], $b['bytes'], $same ? 'はい' : 'いいえ'));
            foreach ($b['checks'] as $k => $v) {
                if ($v !== true) { $this->error('      × ' . $k); $ngTotal++; }
            }
            if (!$same) {
                $this->error('      × 置いた本文と配布ファイルのSHA-256が違います');
                $ngTotal++;
            }
        }
        // 1st/2nd がそれぞれ共通本文を内包していること（連結してはいけない根拠）
        $b1 = \App\Http\Controllers\Api\BaganrikiPrompt::systemBody('1st');
        $b2 = \App\Http\Controllers\Api\BaganrikiPrompt::systemBody('2nd');
        $bc = \App\Http\Controllers\Api\BaganrikiPrompt::systemBody('common');
        if ($b1['ok'] && $b2['ok'] && $bc['ok']) {
            $head = mb_substr((string) $bc['body'], 0, 120);
            $in1 = (mb_strpos((string) $b1['body'], $head) !== false);
            $in2 = (mb_strpos((string) $b2['body'], $head) !== false);
            $this->line('  － 共通本文の冒頭が 1st に含まれる: ' . ($in1 ? 'はい' : 'いいえ'));
            $this->line('  － 共通本文の冒頭が 2nd に含まれる: ' . ($in2 ? 'はい' : 'いいえ'));
            $this->line('     → どちらも「はい」なので、common_prompt.txt を後ろへ'
                      . '連結しません（連結すると同じ規則が二重になります）');
            if (!$in1 || !$in2) { $ngTotal++; }
        }
        $this->line('');

        // ───────────────────────────────────────────────────────────────
        // §2 snapshot_hash の作り方
        // ───────────────────────────────────────────────────────────────
        $this->info('── §2 snapshot_hash の作り方の照合（先方の参照入力） ──');
        $refs = glob($vDir . '/normal/*_input.json') ?: [];
        sort($refs);
        if ($refs === []) {
            $this->error('  × ' . $vDir . '/normal/*_input.json が見つかりません');
            $ngTotal++;
        }
        $h2ok = 0; $h2ng = 0;
        foreach ($refs as $f) {
            $in = json_decode((string) file_get_contents($f), true);
            if (!is_array($in)) { $this->error('  × 読めません: ' . basename($f)); $ngTotal++; continue; }
            $h = \App\Http\Controllers\Api\BaganrikiPrompt::commonHash($in);
            $got = (string) ($h['hash'] ?? '');
            $exp = (string) ($in['snapshot_hash'] ?? '');
            if ($got === $exp && $exp !== '') { $h2ok++; }
            else {
                $h2ng++;
                $this->error(sprintf('  × %s 得た値 %s / 期待値 %s',
                    basename($f), substr($got, 0, 16), substr($exp, 0, 16)));
            }
        }
        $this->line(sprintf('  一致 %d 件 / 不一致 %d 件（対象 %d 件）',
            $h2ok, $h2ng, count($refs)));
        $this->line('  対象   INPUT_JSON から ai_role・role_cap・role_quota・snapshot_hash を外した残り');
        $this->line('  並び   全階層でキーを文字列として昇順');
        $this->line('  書式   区切りは "," と ":"（余白なし）／非ASCIIはエスケープしない');
        $this->line('  方式名 ' . \App\Http\Controllers\Api\BaganrikiPrompt::HASH_VERSION);
        $ngTotal += $h2ng;
        $this->line('');

        // ───────────────────────────────────────────────────────────────
        // §3 生payloadからの組み立てと参照入力との突き合わせ
        // ───────────────────────────────────────────────────────────────
        $this->info('── §3 取得payloadから INPUT_JSON を組み立てて参照入力と照合 ──');
        $this->line('  【与えたもの】発走時刻・投票締切・batch_id・coverage の文面・');
        $this->line('                スロットなしの登録（past_performance）');
        $this->line('                … これらは payload から導けない入力です');
        $this->line('  【導いたもの】N・runners・帯・signals・S・S_min・S_max・mode・');
        $this->line('                mode_status・allocation_mode・mode_policy_id・');
        $this->line('                target_count・base_quota・quota・quota_adjustments・');
        $this->line('                role_cap・role_quota・selection_enabled・display_rating・');
        $this->line('                cutoff_at・input_freeze_at・時刻契約の期限・');
        $this->line('                field_catalog・input_indices・snapshot_hash・');
        $this->line('                取得監査の payload_hash と3つの実時刻');
        $this->line('');
        $cases = [];
        foreach ($refs as $f) {
            if (!preg_match('/^(.+)_(1st|2nd)_input\.json$/', basename($f), $m)) continue;
            $cases[$m[1]][$m[2]] = $f;
        }
        $c3ok = 0; $c3ng = 0; $assembled = [];
        foreach ($cases as $case => $byRole) {
            foreach (['1st', '2nd'] as $role) {
                if (!isset($byRole[$role])) continue;
                $ref = json_decode((string) file_get_contents($byRole[$role]), true);
                $ctx = $this->r122PromptCaseContext($vDir, $case, $ref);
                if ($ctx === null) {
                    $this->error("  × {$case} {$role} 生payloadが見つかりません");
                    $c3ng++; $ngTotal++;
                    continue;
                }
                $b = \App\Http\Controllers\Api\BaganrikiPrompt::buildInput($ctx, $role);
                if (!$b['ok']) {
                    $this->error("  × {$case} {$role} 組み立て失敗 "
                               . $b['code'] . ' ' . $b['reason']);
                    $c3ng++; $ngTotal++;
                    continue;
                }
                $keys = array_unique(array_merge(array_keys($ref), array_keys($b['input'])));
                $diff = $this->r122PromptDiff($b['input'], $ref);
                if ($diff === []) {
                    $c3ok++;
                    // @ANCHOR-20261020-R122-PROMPT  件数は数えて出します（34と書いた誤りの再発防止）
                    $this->line(sprintf('  ○ %-26s %s  全%dキー一致  snapshot_hash=%s',
                        $case, $role, count($keys),
                        substr((string) $b['input']['snapshot_hash'], 0, 16)));
                } else {
                    $c3ng++; $ngTotal += count($diff);
                    $this->error(sprintf('  × %-26s %s  違い %d 件', $case, $role, count($diff)));
                    foreach (array_slice($diff, 0, 8) as $d) {
                        $this->error('      - ' . $d);
                    }
                }
                $assembled[$case . '|' . $role] = $b['input'];
            }
        }
        $this->line(sprintf('  一致 %d 件 / 不一致 %d 件', $c3ok, $c3ng));
        $this->line('');

        // ───────────────────────────────────────────────────────────────
        // §4 スキーマ適合
        // ───────────────────────────────────────────────────────────────
        $this->info('── §4 同梱スキーマへの適合 ──');
        $inSchema = @json_decode((string) @file_get_contents($sDir . '/input_schema.json'), true);
        $srSchema = @json_decode((string) @file_get_contents($sDir . '/source_registry_schema.json'), true);
        if (!is_array($inSchema) || !is_array($srSchema)) {
            $this->error('  × スキーマを読めません: ' . $sDir);
            $ngTotal++;
        } else {
            $this->line('  使うスキーマ: input_schema.json / source_registry_schema.json');
            $this->line('  （検査する語彙: type・const・enum・required・properties・items・'
                      . 'additionalProperties・minItems・maxItems・uniqueItems・'
                      . 'minimum・maximum・minLength・pattern・anyOf・oneOf・allOf・if/then）');
            $s4ng = 0;
            foreach ($assembled as $name => $in) {
                $e = self::jsCheck($in, $inSchema, '');
                $e2 = self::jsCheck($in['source_registry'], $srSchema, 'source_registry');
                $all = array_merge($e, $e2);
                if ($all === []) continue;
                $s4ng++;
                $this->error('  × ' . $name . ' 違反 ' . count($all) . ' 件');
                foreach (array_slice($all, 0, 6) as $x) $this->error('      - ' . $x);
            }
            $this->line(sprintf('  自作した入力 %d 件のうち 違反あり %d 件',
                count($assembled), $s4ng));
            $ngTotal += $s4ng;
            // 参照入力も同じ検査器で見ます（検査器そのものの確かさの目安）
            $s4r = 0;
            foreach ($refs as $f) {
                $in = json_decode((string) file_get_contents($f), true);
                $all = array_merge(self::jsCheck($in, $inSchema, ''),
                                   self::jsCheck($in['source_registry'], $srSchema, 'source_registry'));
                if ($all !== []) {
                    $s4r++;
                    $this->warn('  △ 先方の参照入力でも違反: ' . basename($f)
                              . ' ' . count($all) . ' 件（検査器側の読み違いの可能性）');
                    foreach (array_slice($all, 0, 4) as $x) $this->warn('      - ' . $x);
                }
            }
            $this->line('  先方の参照入力 ' . count($refs) . ' 件のうち 違反あり ' . $s4r . ' 件');
        }
        $this->line('');

        // ───────────────────────────────────────────────────────────────
        // §5 送信の一式
        // ───────────────────────────────────────────────────────────────
        $this->info('── §5 送信の一式（system＋INPUT_JSON）の自己点検 ──');
        $s5ng = 0;
        foreach ($cases as $case => $byRole) {
            foreach (['1st', '2nd'] as $role) {
                if (!isset($byRole[$role])) continue;
                $ref = json_decode((string) file_get_contents($byRole[$role]), true);
                $ctx = $this->r122PromptCaseContext($vDir, $case, $ref);
                if ($ctx === null) continue;
                $asm = \App\Http\Controllers\Api\BaganrikiPrompt::assemble($ctx, $role);
                if (!$asm['ok']) {
                    $s5ng++; $ngTotal++;
                    $this->error("  × {$case} {$role} " . $asm['code'] . ' ' . $asm['reason']);
                    continue;
                }
                $this->line(sprintf('  ○ %-26s %s  system %6dバイト／user %6dバイト'
                                  . '／入れ子%2d／自己点検 %d件',
                    $case, $role, strlen((string) $asm['system']), $asm['user_bytes'],
                    \App\Http\Controllers\Api\BaganrikiPrompt::depthOf($asm['input']),
                    count($asm['issues'])));
                if ($dump !== '') {
                    if (!is_dir($dump)) @mkdir($dump, 0775, true);
                    file_put_contents($dump . '/' . $case . '_' . $role . '_system.txt',
                                      (string) $asm['system']);
                    file_put_contents($dump . '/' . $case . '_' . $role . '_input.json',
                                      (string) $asm['user']);
                }
            }
        }
        if ($dump !== '') $this->line('  書き出し先: ' . $dump);
        $this->line('');

        // ───────────────────────────────────────────────────────────────
        // §6 本番DBでの組み立て
        // ───────────────────────────────────────────────────────────────
        if ((bool) $this->option('r122-prompt-real')) {
            $this->r122PromptReal($dump);
        } else {
            $this->line('── §6 本番DBでの組み立ては --r122-prompt-real を付けたときだけ行います ──');
        }
        $this->line('');

        $this->info('════════════════════════════════════════════════════════');
        if ($ngTotal === 0) {
            $this->info(' すべて一致しました（不一致 0 件）');
        } else {
            $this->error(' 不一致・違反 合計 ' . $ngTotal . ' 件');
        }
        $this->info('════════════════════════════════════════════════════════');
    }

    /**
     * @ANCHOR-20261020-R122-PROMPT  合成ケースの文脈を生payloadから作ります
     */
    private function r122PromptCaseContext(string $vDir, string $case, array $ref): ?array
    {
        self::r122Autoload();
        $files = [];
        foreach (\App\Http\Controllers\Api\BaganrikiTime::INPUT_SLOTS as $slot) {
            $f = $vDir . '/raw_payloads/' . $case . '_s' . $slot . '.json';
            if (is_file($f)) $files[$slot] = $f;
        }
        if ($files === []) return null;

        $registry = [];
        $audit = [];
        $anchorUs = \App\Http\Controllers\Api\BaganrikiTime::us(
            $ref['time_contract']['anchor_at'] ?? null);
        if ($anchorUs === null) return null;

        foreach (\App\Http\Controllers\Api\BaganrikiTime::INPUT_SLOTS as $slot) {
            if (!isset($files[$slot])) {
                $audit[(string) $slot] = ['status' => 'UNAVAILABLE',
                    'reason' => 'このスロットの取得payloadがありません'];
                continue;
            }
            $bytes = (string) file_get_contents($files[$slot]);
            $pl = json_decode($bytes, true);
            $recs = (array) ($pl['records'] ?? []);
            $obs = null; $av = null;
            foreach ($recs as $r) {
                $registry[(string) $r['source_ref']] = $r;
                $o = \App\Http\Controllers\Api\BaganrikiTime::us($r['observed_at'] ?? null);
                $a = \App\Http\Controllers\Api\BaganrikiTime::us($r['available_at'] ?? null);
                if ($o !== null && ($obs === null || $o > $obs)) $obs = $o;
                if ($a !== null && ($av  === null || $a > $av))  $av  = $a;
            }
            $sch = \App\Http\Controllers\Api\BaganrikiTime::slotScheduled($anchorUs, $slot);
            $audit[(string) $slot] = [
                'status'               => 'ADOPTED',
                'batch_id'             => (string) ($ref['collection_audit'][(string) $slot]['batch_id'] ?? ''),
                'payload_hash'         => hash('sha256', $bytes),
                'slot_scheduled_at'    => \App\Http\Controllers\Api\BaganrikiPrompt::rfc3339($sch),
                'source_updated_at'    => null,
                'request_started_at'   => \App\Http\Controllers\Api\BaganrikiPrompt::rfc3339($sch),
                'response_received_at' => ($obs === null) ? null
                                        : \App\Http\Controllers\Api\BaganrikiPrompt::rfc3339($obs),
                'available_at'         => ($av === null) ? null
                                        : \App\Http\Controllers\Api\BaganrikiPrompt::rfc3339($av),
            ];
        }
        // スロットなしの登録（過去走の指数など）は payload に入っていないので与えます
        foreach ((array) ($ref['source_registry'] ?? []) as $k => $e) {
            if (($e['slot_offset'] ?? null) === null) $registry[(string) $k] = $e;
        }

        return [
            'race_id'         => (string) ($ref['race_id'] ?? ''),
            'anchor_at'       => (string) ($ref['time_contract']['anchor_at'] ?? ''),
            'sales_close_at'  => (string) ($ref['time_contract']['sales_close_at'] ?? ''),
            'registry'        => $registry,
            'audit'           => $audit,
            'coverage'        => (array) ($ref['coverage'] ?? []),
            'entry_nums'      => array_map(static fn($r) => (int) $r['horse_no'],
                                           (array) ($ref['runners'] ?? [])),
            'cancelled'       => [],
            'legacy_gap_type' => $ref['legacy_gap_type'] ?? null,
            'similar'         => null,
        ];
    }

    /**
     * @ANCHOR-20261020-R122-PROMPT  2つの INPUT_JSON の違いを1行ずつにします
     *   値そのものの比較はキー昇順のJSONで行います（キーの並びは意味を持たない）。
     */
    private function r122PromptDiff(array $got, array $exp): array
    {
        $out = [];
        $keys = array_values(array_unique(array_merge(array_keys($exp), array_keys($got))));
        sort($keys, SORT_STRING);
        foreach ($keys as $k) {
            $a = array_key_exists($k, $got) ? $got[$k] : '(キー無し)';
            $b = array_key_exists($k, $exp) ? $exp[$k] : '(キー無し)';
            $ja = \App\Http\Controllers\Api\BaganrikiPrompt::canonical($a);
            $jb = \App\Http\Controllers\Api\BaganrikiPrompt::canonical($b);
            if ($ja === $jb) continue;
            if ($k === 'source_registry' || $k === 'input_indices'
                || $k === 'field_catalog' || $k === 'collection_audit') {
                foreach ($this->r122PromptDiffDeep((array) $a, (array) $b, $k) as $x) {
                    $out[] = $x;
                }
                continue;
            }
            $out[] = sprintf('%s 得た値 %s / 期待値 %s', $k,
                mb_strimwidth((string) $ja, 0, 160, '…'),
                mb_strimwidth((string) $jb, 0, 160, '…'));
        }
        return $out;
    }

    /** 大きな入れ物は中の要素ごとに違いを出します */
    private function r122PromptDiffDeep(array $got, array $exp, string $prefix): array
    {
        $out = [];
        $keys = array_values(array_unique(array_merge(array_keys($exp), array_keys($got))));
        sort($keys, SORT_STRING);
        foreach ($keys as $k) {
            $ja = array_key_exists($k, $got)
                ? \App\Http\Controllers\Api\BaganrikiPrompt::canonical($got[$k]) : '(キー無し)';
            $jb = array_key_exists($k, $exp)
                ? \App\Http\Controllers\Api\BaganrikiPrompt::canonical($exp[$k]) : '(キー無し)';
            if ($ja === $jb) continue;
            $out[] = sprintf('%s.%s 得た値 %s / 期待値 %s', $prefix, $k,
                mb_strimwidth((string) $ja, 0, 140, '…'),
                mb_strimwidth((string) $jb, 0, 140, '…'));
        }
        return $out;
    }

    /**
     * @ANCHOR-20261020-R122-PROMPT  本番DBの保存済みレースで組み立てを試します
     *   既定では「投票締切の正本が無い」「取得監査の実時刻が無い」で止まります。
     *   --r122-prompt-assume を付けると、その2つを仮置きして送信文の形まで出します
     *   （本番送信には使いません。どこまで出来ているかを示すためです）。
     */
    private function r122PromptReal(string $dump): void
    {
        self::r122Autoload();
        $this->info('── §6 本番DBの保存済みレースでの組み立て ──');
        $dates = array_values(array_filter(array_map('trim',
            explode(',', (string) ($this->option('date') ?: date('Y-m-d'))))));
        $assume = (bool) $this->option('r122-prompt-assume');
        $override = [];
        if ($assume) {
            $override['assume_audit'] = true;
            $this->warn('  【仮】取得監査の実時刻を予定時刻で埋めます（本番送信には使いません）');
        }
        $offset = (int) ($this->option('r122-prompt-sales-offset') ?: 0);
        if ($offset > 0) {
            $this->warn('  【仮】投票締切を「発走の' . $offset . '秒前」として扱います'
                      . '（正本ではありません。契約11.2のため本番送信はしません）');
        }
        $ctrl = app(\App\Http\Controllers\Api\AiController::class);
        $tbl = ['合計' => 0];
        $byCode = [];
        $rows = [];
        foreach ($dates as $date) {
            foreach (\DB::table('t_horse_odds_finder_races')->where('date', $date)
                        ->orderBy('basho')->orderBy('race')
                        ->get(['date', 'kaisuu', 'basho', 'day', 'race']) as $r) {
                $ov = $override;
                if ($offset > 0) {
                    $st = \DB::table('t_horse_odds_finder_races')
                            ->where('date', $r->date)->where('kaisuu', $r->kaisuu)
                            ->where('basho', $r->basho)->where('day', $r->day)
                            ->where('race', (int) $r->race)->value('start_time');
                    $us = \App\Http\Controllers\Api\BaganrikiTime::us(
                        $r->date . 'T' . (strlen((string) $st) === 5 ? $st . ':00' : $st) . '+09:00');
                    if ($us !== null) {
                        $ov['sales_close_at'] = \App\Http\Controllers\Api\BaganrikiPrompt::rfc3339(
                            $us - $offset * 1000000);
                    }
                }
                // @ANCHOR-20261020-R122-ONEBUILD  ここは「作り直す側」です。
                //   実レースの入力がどう組み上がるかを見る調査なので、
                //   固定入力を作らずに組み立てます。
                $asm = $ctrl->r122AssembleFresh($r->date, $r->kaisuu, $r->basho,
                                               $r->day, $r->race, '1st', $ov);
                $tbl['合計']++;
                $code = $asm['ok'] ? 'OK' : (string) $asm['code'];
                $byCode[$code] = ($byCode[$code] ?? 0) + 1;
                if ($asm['ok']) {
                    $rows[] = sprintf('  ○ %-22s N=%2d %-9s %-11s user%7dバイト hash=%s',
                        $asm['race_id'], (int) ($asm['input']['N'] ?? 0),
                        (string) ($asm['input']['mode'] ?? ''),
                        (string) ($asm['input']['mode_status'] ?? ''),
                        (int) $asm['user_bytes'], substr((string) $asm['snapshot_hash'], 0, 12));
                    if ($dump !== '') {
                        if (!is_dir($dump)) @mkdir($dump, 0775, true);
                        file_put_contents($dump . '/real_' . $asm['race_id'] . '_1st_input.json',
                                          (string) $asm['user']);
                    }
                }
            }
        }
        $this->line('  対象 ' . $tbl['合計'] . ' レース');
        ksort($byCode);
        foreach ($byCode as $code => $n) {
            $this->line(sprintf('    %-28s %4d レース', $code, $n));
        }
        foreach (array_slice($rows, 0, 12) as $x) $this->line($x);
        if (count($rows) > 12) $this->line('    …ほか ' . (count($rows) - 12) . ' レース');
        $this->line('');
        $this->line('  【止まる理由の意味】');
        $this->line('    SALES_CLOSE_UNRESOLVED   投票締切の正本がDBに無い（契約11.2で公開しない）');
        $this->line('    ACQUISITION_AUDIT_MISSING 取得監査の実時刻がDBに無い（お願い②A案の記録待ち）');
        $this->line('    ODDS_SERIES_INCOMPLETE   6分前の単勝がそろっていない');
        $this->line('    ENTRY_MISSING            出馬表の馬番が無い');
    }

    /**
     * ═══════════════════════════════════════════════════════════════════════
     * @ANCHOR-20261020-R122-PROMPT  JSON Schema（2020-12の必要な語彙だけ）
     * ═══════════════════════════════════════════════════════════════════════
     * 外部ライブラリを入れずに済ませるため、同梱スキーマで実際に使われている
     * 語彙だけを実装しています。知らない語彙は無視せず、warn を返します。
     * 連想配列へ復号したデータを見るので、空の {} と [] は区別しません。
     *
     * @return array 違反の説明（空なら適合）
     */
    public static function jsCheck($data, $schema, string $path): array
    {
        if ($schema === true || $schema === []) return [];
        if ($schema === false) return [self::jsAt($path) . ' ここには何も置けません'];
        if (!is_array($schema)) return [];
        $e = [];
        $at = self::jsAt($path);

        foreach (['$schema', '$id', 'title', 'description', 'format',
                  'examples', 'default', 'comment', '$comment'] as $ignore) {
            unset($schema[$ignore]);
        }

        if (array_key_exists('const', $schema)) {
            if (self::jsJson($data) !== self::jsJson($schema['const'])) {
                $e[] = $at . ' const 不一致 得た値 ' . self::jsShort($data)
                     . ' / 期待値 ' . self::jsShort($schema['const']);
            }
        }
        if (isset($schema['enum'])) {
            $ok = false;
            foreach ($schema['enum'] as $x) {
                if (self::jsJson($data) === self::jsJson($x)) { $ok = true; break; }
            }
            if (!$ok) $e[] = $at . ' enum に無い値 ' . self::jsShort($data);
        }
        if (isset($schema['type'])) {
            $types = is_array($schema['type']) ? $schema['type'] : [$schema['type']];
            $ok = false;
            foreach ($types as $t) { if (self::jsType($data, (string) $t)) { $ok = true; break; } }
            if (!$ok) {
                $e[] = $at . ' type 不一致（期待 ' . implode('|', $types)
                     . '／得た値 ' . self::jsShort($data) . '）';
            }
        }
        if (isset($schema['pattern']) && is_string($data)) {
            $re = '/' . str_replace('/', '\\/', (string) $schema['pattern']) . '/u';
            if (!preg_match($re, $data)) {
                $e[] = $at . ' pattern 不一致 ' . self::jsShort($data);
            }
        }
        if (isset($schema['minLength']) && is_string($data)
            && mb_strlen($data) < (int) $schema['minLength']) {
            $e[] = $at . ' minLength 未満';
        }
        if (isset($schema['minimum']) && (is_int($data) || is_float($data))
            && $data < $schema['minimum']) {
            $e[] = $at . ' minimum 未満 ' . self::jsShort($data);
        }
        if (isset($schema['maximum']) && (is_int($data) || is_float($data))
            && $data > $schema['maximum']) {
            $e[] = $at . ' maximum 超過 ' . self::jsShort($data);
        }
        if (is_array($data)) {
            $isList = (array_keys($data) === range(0, count($data) - 1));
            if (isset($schema['minItems']) && $isList
                && count($data) < (int) $schema['minItems']) {
                $e[] = $at . ' minItems 未満（' . count($data) . '件）';
            }
            if (isset($schema['maxItems']) && $isList
                && count($data) > (int) $schema['maxItems']) {
                $e[] = $at . ' maxItems 超過（' . count($data) . '件）';
            }
            if (!empty($schema['uniqueItems']) && $isList) {
                $seen = [];
                foreach ($data as $x) {
                    $j = self::jsJson($x);
                    if (isset($seen[$j])) { $e[] = $at . ' uniqueItems 違反'; break; }
                    $seen[$j] = true;
                }
            }
            if (isset($schema['items']) && $isList) {
                foreach ($data as $i => $x) {
                    foreach (self::jsCheck($x, $schema['items'], $path . '[' . $i . ']') as $x2) {
                        $e[] = $x2;
                    }
                }
            }
            if (isset($schema['required'])) {
                foreach ((array) $schema['required'] as $k) {
                    if (!array_key_exists($k, $data) && !array_key_exists((int) $k, $data)) {
                        $e[] = $at . ' required キーがありません: ' . $k;
                    }
                }
            }
            $props = (array) ($schema['properties'] ?? []);
            foreach ($props as $k => $sub) {
                $hit = array_key_exists($k, $data) ? $k
                     : (is_numeric($k) && array_key_exists((int) $k, $data) ? (int) $k : null);
                if ($hit === null) continue;
                foreach (self::jsCheck($data[$hit], $sub, $path . '/' . $k) as $x2) $e[] = $x2;
            }
            if (array_key_exists('additionalProperties', $schema) && !$isList) {
                $ap = $schema['additionalProperties'];
                foreach ($data as $k => $v) {
                    if (array_key_exists((string) $k, $props)) continue;
                    if ($ap === false) {
                        $e[] = $at . ' 余分なキー: ' . $k;
                        continue;
                    }
                    if (is_array($ap)) {
                        foreach (self::jsCheck($v, $ap, $path . '/' . $k) as $x2) $e[] = $x2;
                    }
                }
            }
        }
        if (isset($schema['allOf'])) {
            foreach ($schema['allOf'] as $sub) {
                foreach (self::jsCheck($data, $sub, $path) as $x2) $e[] = $x2;
            }
        }
        if (isset($schema['anyOf'])) {
            $ok = false; $first = null;
            foreach ($schema['anyOf'] as $sub) {
                $r = self::jsCheck($data, $sub, $path);
                if ($r === []) { $ok = true; break; }
                if ($first === null) $first = $r;
            }
            if (!$ok) {
                $e[] = $at . ' anyOf のどれにも合いません（最初の候補の理由: '
                     . implode('／', array_slice((array) $first, 0, 2)) . '）';
            }
        }
        if (isset($schema['oneOf'])) {
            $hit = 0; $first = null;
            foreach ($schema['oneOf'] as $sub) {
                $r = self::jsCheck($data, $sub, $path);
                if ($r === []) $hit++;
                elseif ($first === null) $first = $r;
            }
            if ($hit !== 1) {
                $e[] = $at . ' oneOf に合うのが ' . $hit . ' 個（1個でなければなりません。'
                     . '最初の候補の理由: ' . implode('／', array_slice((array) $first, 0, 2)) . '）';
            }
        }
        if (isset($schema['if'])) {
            $cond = self::jsCheck($data, $schema['if'], $path);
            if ($cond === [] && isset($schema['then'])) {
                foreach (self::jsCheck($data, $schema['then'], $path) as $x2) $e[] = $x2;
            }
            if ($cond !== [] && isset($schema['else'])) {
                foreach (self::jsCheck($data, $schema['else'], $path) as $x2) $e[] = $x2;
            }
        }
        $known = ['const', 'enum', 'type', 'pattern', 'minLength', 'minimum', 'maximum',
                  'minItems', 'maxItems', 'uniqueItems', 'items', 'required',
                  'properties', 'additionalProperties', 'allOf', 'anyOf', 'oneOf',
                  'if', 'then', 'else'];
        foreach (array_keys($schema) as $k) {
            if (!in_array((string) $k, $known, true)) {
                $e[] = $at . ' この検査器が知らない語彙があります: ' . $k;
            }
        }
        return $e;
    }

    /** 型の判定（連想配列へ復号しているので object と array は中身で見ます） */
    private static function jsType($d, string $t): bool
    {
        switch ($t) {
            case 'object':
                if (!is_array($d)) return false;
                if ($d === []) return true;                 // 空は {} と [] を区別できない
                return (array_keys($d) !== range(0, count($d) - 1));
            case 'array':
                if (!is_array($d)) return false;
                if ($d === []) return true;
                return (array_keys($d) === range(0, count($d) - 1));
            case 'string':  return is_string($d);
            case 'integer': return is_int($d) || (is_float($d) && $d == (int) $d);
            case 'number':  return is_int($d) || is_float($d);
            case 'boolean': return is_bool($d);
            case 'null':    return $d === null;
        }
        return true;
    }

    private static function jsAt(string $p): string
    {
        return ($p === '') ? '(root)' : $p;
    }

    private static function jsJson($v): string
    {
        return (string) json_encode($v, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES
                                      | JSON_PRESERVE_ZERO_FRACTION);
    }

    private static function jsShort($v): string
    {
        return mb_strimwidth(self::jsJson($v), 0, 60, '…');
    }
