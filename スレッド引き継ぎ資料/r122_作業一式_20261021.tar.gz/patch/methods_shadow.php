
    /**
     * ═══════════════════════════════════════════════════════════════════════
     * @ANCHOR-20261020-R122-SHADOW  入力だけ作って凍結する（送信は旧本文）
     * ═══════════════════════════════════════════════════════════════════════
     * BAGANRIKI_R122_PROMPT=shadow のときに呼ばれます。
     *
     * ■ やること
     *   r12.2 の入力を組み立てて、作れたら PRODUCTION として凍結保存します。
     *   <b>AIへ送る本文は触りません（旧本文のままです）。</b>
     *   キューの枠も取りません。旧本文の応答を r12.2 の原応答として
     *   保存してしまうと、ジャーナルが契約に合わない中身で汚れるためです。
     *
     * ■ 何が測れるか
     *   ・入力が作れるレースと作れないレース（理由つき）
     *   ・送信文の大きさ（実レースでの実寸）
     *   ・coverage 7区分の実際の状態
     *   ・取得監査の実時刻が入力に紐づくか
     *   ・snapshot_hash が本番の世代で残るか
     *
     * ■ 何も壊しません
     *   失敗しても例外を外に出しません。いまの商品の動きは変わりません。
     */
    public function r122ShadowRecord($date, $kaisuu, $basho, $day, $race): void
    {
        try {
            $raceId = self::r122RaceId($date, $kaisuu, $basho, $day, $race);
            // ══════════════════════════════════════════════════════════
            // @ANCHOR-20261020-R122-ONEBUILD  10月20日007のご指摘2
            // ══════════════════════════════════════════════════════════
            //   【旧】ここで組み立ててから、あとで r122Freeze を呼んで
            //     <b>もう一度</b>組み立てていました。派生の計算時刻が
            //     2回で変わるので、ログに出る hash と保存された hash が
            //     食い違います。shadow でも同じ問題が起きていました。
            //   【いま】r122AssembleSend が、固定入力が無ければ1回だけ
            //     作って固定し、<b>保存した本文を読んで返します</b>。
            //     ログに出る hash は、保存されたものと同じです。
            $asm = $this->r122AssembleSend($date, $kaisuu, $basho, $day, $race, '1st');
            if (!($asm['ok'] ?? false)) {
                \Log::error('[R122-SHADOW] 入力を作れません（旧本文で送ります）', [
                    'race_id' => $raceId,
                    'code'    => $asm['code'] ?? null,
                    'reason'  => $asm['reason'] ?? null,
                ]);
                return;
            }
            $in = (array) $asm['input'];
            $cov = [];
            foreach ((array) ($in['coverage'] ?? []) as $k => $v) {
                $cov[$k] = (string) ($v['status'] ?? '?');
            }
            \Log::error('[R122-SHADOW] 入力を作れました（旧本文で送ります）', [
                'race_id'        => $raceId,
                'N'              => $in['N'] ?? null,
                'mode'           => ($in['mode'] ?? '') . '／' . ($in['mode_status'] ?? ''),
                'snapshot_hash'  => $in['snapshot_hash'] ?? null,
                'user_bytes'     => $asm['user_bytes'] ?? strlen((string) $asm['user']),
                'registry'       => count((array) ($in['source_registry'] ?? [])),
                'coverage'       => $cov,
                'past_runs_max'  => self::r122PastRunsMax(),
            ]);

            // 凍結保存の状態を確かめます。
            //   上の r122AssembleSend で固定済みなので、ここは必ず
            //   skipped=true（既存）になります。作り直しません。
            $fz = $this->r122Freeze($date, $kaisuu, $basho, $day, $race,
                                    [], 'PRODUCTION', false);
            \Log::error('[R122-SHADOW] 凍結保存', [
                'race_id'       => $raceId,
                'ok'            => $fz['ok'] ?? false,
                'skipped'       => $fz['skipped'] ?? false,
                'code'          => $fz['code'] ?? null,
                'reason'        => $fz['reason'] ?? null,
                'snapshot_hash' => $fz['snapshot_hash'] ?? null,
                'counts'        => $fz['counts'] ?? null,
                // @ANCHOR-20261020-R122-ONEBUILD  保存物を読んだ印と、hashの一致
                'from_saved'    => $asm['from_saved'] ?? null,
                'hash_same'     => (($asm['snapshot_hash'] ?? null) !== null
                                    && ($asm['snapshot_hash'] ?? null)
                                       === ($fz['snapshot_hash'] ?? null)),
            ]);
        } catch (\Throwable $e) {
            // ここで落ちても、いまの商品は止めません
            \Log::error('[R122-SHADOW] 例外（送信は続けます）', [
                'message' => $e->getMessage(),
                'at'      => $e->getFile() . ':' . $e->getLine(),
            ]);
        }
    }
