
    /**
     * ═══════════════════════════════════════════════════════════════════════
     * @ANCHOR-20261020-R122-ACQFIX  監査行→採用→入力→凍結保存→読戻しの通し試験
     * ═══════════════════════════════════════════════════════════════════════
     * 根拠：10月20日005のご指摘2-4「この接続を通した証跡がない」
     *
     * ■ 何をするか
     *   1つのレースについて、<b>取得側と同じ形</b>の監査行を6スロットぶん作り、
     *   原ペイロードは保存済みオッズから組み立て、SHA-256も実際に計算します。
     *   そのうえで本番と同じ経路を通します。
     *     監査行の読込 → 原ペイロードのhash照合 → 採用バッチの選定
     *     → INPUT_JSON の組み立て → 凍結保存 → 読み戻し
     *
     * ■ 書き込みについて
     *   <b>全部ひとつのトランザクションで行い、最後に必ずロールバックします。</b>
     *   DBへ残る書き込みは0件です。既存テーブルには一切触りません。
     *
     * ■ 正直に書いておくこと
     *   ここで使う監査行は<b>試験用に作ったもの</b>です。実開催で取れた
     *   実時刻ではありません。実監査行での確認は10月24・25日に行います。
     *   これは「経路がつながっているか」を確かめる試験です。
     */
    private function runR122AcqTest(): void
    {
        self::r122Autoload();
        $date = (string) ($this->option('date') ?: '2026-10-18');
        $this->info('════════════════════════════════════════════════════════');
        $this->info(' r12.2 監査行→採用→入力→凍結保存→読戻し の通し試験');
        $this->info('════════════════════════════════════════════════════════');
        $this->line('  実行時刻 : ' . date('c'));
        $this->warn('  ※ 監査行は試験用に作ったものです（実開催の実時刻ではありません）');
        $this->warn('  ※ 全部ロールバックします。DBへ残る書き込みは0件です');
        $this->line('');

        $r = \DB::table('t_horse_odds_finder_races')->where('date', $date)
                ->orderBy('basho')->orderBy('race')->first();
        if ($r === null) { $this->error('  × 対象レースがありません: ' . $date); return; }
        $raceId = \App\Http\Controllers\Api\AiController::r122RaceId(
            $r->date, $r->kaisuu, $r->basho, $r->day, $r->race);
        $st = (string) $r->start_time;
        if (strlen($st) === 5) $st .= ':00';
        $anchorUs = \App\Http\Controllers\Api\BaganrikiTime::us($r->date . 'T' . $st . '+09:00');
        if ($anchorUs === null) { $this->error('  × 発走時刻を読めません'); return; }
        $this->line('  対象レース : ' . $raceId . '  発走 ' . $st);

        $slots = \App\Http\Controllers\Api\BaganrikiTime::INPUT_SLOTS;
        $rows  = [];
        $made  = 0;
        foreach ($slots as $slot) {
            // 保存済みオッズから、取得側が受け取るのと同じ形の原ペイロードを作ります
            $pl = [];
            foreach (\DB::table('t_horse_odds_finder_odds')
                        ->where('date', $r->date)->where('kaisuu', $r->kaisuu)
                        ->where('basho', $r->basho)->where('day', $r->day)
                        ->where('race', (int) $r->race)
                        ->where('minutes_before_start', $slot)
                        ->orderBy('num')->get(['num', 'odds', 'fuku_min', 'fuku_max']) as $o) {
                $pl[] = ['num' => (int) $o->num, 'tan' => (string) $o->odds,
                         'fuku_min' => (string) $o->fuku_min, 'fuku_max' => (string) $o->fuku_max];
            }
            if ($pl === []) { $this->line(sprintf('  － %2d分前 オッズが無いので監査行を作りません', $slot)); continue; }
            $raw = (string) json_encode($pl, JSON_UNESCAPED_UNICODE);
            $sch = \App\Http\Controllers\Api\BaganrikiTime::slotScheduled($anchorUs, $slot);
            $toDb = static function (int $us): string {
                return (new \DateTimeImmutable('@' . intdiv($us, 1000000)))
                    ->setTimezone(new \DateTimeZone('Asia/Tokyo'))
                    ->format('Y-m-d H:i:s') . sprintf('.%06d', $us % 1000000);
            };
            $rows[] = [
                'race_id' => $raceId, 'slot' => $slot,
                'batch_id' => 'ACQTEST-' . $raceId . '-' . $slot . '-' . substr(bin2hex(random_bytes(3)), 0, 6),
                'slot_scheduled_at'    => $toDb($sch),
                'source_updated_at'    => null,
                'request_started_at'   => $toDb($sch + 500000),          // 予定 +0.5秒
                'response_received_at' => $toDb($sch + 1500000),         // 予定 +1.5秒
                'available_at'         => $toDb($sch + 2500000),         // 予定 +2.5秒
                'raw_payload'          => $raw,
                'payload_hash'         => hash('sha256', $raw),
                'validation_result'    => 'ADOPTED',
                'rejection_reason'     => null,
                'committed'            => 1,
                'created_at'           => $toDb($sch + 2500000),
            ];
            $made++;
            $this->line(sprintf('  － %2d分前 %2d頭ぶんの原ペイロード %6d バイト  sha256=%s',
                $slot, count($pl), strlen($raw), substr(hash('sha256', $raw), 0, 12)));
        }
        if ($made === 0) { $this->error('  × 監査行を1件も作れません'); return; }
        $this->line('');

        $ok = true;
        \DB::beginTransaction();
        try {
            \DB::table('baganriki_acquisition_batches')->insert($rows);
            $this->info('── ① 監査行を入れた（' . count($rows) . ' 件・ロールバックします）──');

            $ctrl = app(\App\Http\Controllers\Api\AiController::class);

            $this->info('── ② 監査行を読んで採用バッチを選び、INPUT_JSON を作る ──');
            // @ANCHOR-20261020-R122-ONEBUILD  ここは「作り直す側」です。
            //   仮の締切を差し込んで組み立てを見る試験なので、
            //   保存物を読む送信経路（r122AssembleSend）は通しません。
            $asm = $ctrl->r122AssembleFresh($r->date, $r->kaisuu, $r->basho, $r->day, $r->race,
                                           '1st', ['sales_close_at' =>
                \App\Http\Controllers\Api\BaganrikiPrompt::rfc3339($anchorUs - 60 * 1000000)]);
            if (!$asm['ok']) {
                $ok = false;
                $this->error('  × ' . $asm['code'] . ' ' . $asm['reason']);
            } else {
                $in = $asm['input'];
                $this->line('  ○ N=' . $in['N'] . '  mode=' . $in['mode']
                          . '／' . $in['mode_status']
                          . '  snapshot_hash=' . substr((string) $in['snapshot_hash'], 0, 16));
                $this->line('  ○ source_registry ' . count($in['source_registry']) . ' 件');
                $ad = [];
                foreach ($in['collection_audit'] as $k => $v) {
                    $ad[] = $k . '=' . ($v['status'] ?? '?');
                }
                $this->line('  ○ collection_audit ' . implode(' ', $ad));
                $six = $in['collection_audit']['6'] ?? null;
                if (is_array($six) && ($six['status'] ?? '') === 'ADOPTED') {
                    $this->line('  ○ 6分前 batch_id ' . $six['batch_id']);
                    $this->line('           request '  . $six['request_started_at']);
                    $this->line('           response ' . $six['response_received_at']);
                    $this->line('           available ' . $six['available_at']);
                    $this->line('           payload_hash ' . substr((string) $six['payload_hash'], 0, 16));
                    // 採用したバッチの原値が、そのまま登録に入っているか
                    $bt = null;
                    foreach ($rows as $x) { if ($x['batch_id'] === $six['batch_id']) { $bt = $x; break; } }
                    if ($bt === null) {
                        $ok = false; $this->error('  × 採用された batch_id が試験用の行に見つかりません');
                    } else {
                        if (hash('sha256', $bt['raw_payload']) !== $six['payload_hash']) {
                            $ok = false; $this->error('  × payload_hash が原ペイロードと合いません');
                        } else {
                            $this->line('  ○ payload_hash を再計算して一致を確認');
                        }
                        $pl = json_decode($bt['raw_payload'], true);
                        $miss = 0;
                        foreach ((array) $pl as $h) {
                            $n = (int) $h['num'];
                            $t = trim((string) $h['tan']);
                            if (!\App\Http\Controllers\Api\BaganrikiAcquisition::usableDecimal($t)) continue;
                            $ref = 'h' . $n . '_win_odds_6';
                            $got = $in['source_registry'][$ref]['value'] ?? null;
                            if ((string) $got !== (string) \App\Http\Controllers\Api\AiController::r122NumValue($t)) $miss++;
                        }
                        if ($miss > 0) {
                            $ok = false;
                            $this->error('  × 採用バッチの原値と登録の値が違う馬が ' . $miss . ' 頭');
                        } else {
                            $this->line('  ○ 6分前の登録の値は、採用バッチの原値と全頭一致');
                        }
                    }
                }
            }

            if ($ok) {
                $this->info('── ③ 凍結保存して読み戻す ──');
                $fz = $ctrl->r122Freeze($r->date, $r->kaisuu, $r->basho, $r->day, $r->race,
                    ['sales_close_at' =>
                        \App\Http\Controllers\Api\BaganrikiPrompt::rfc3339($anchorUs - 60 * 1000000)],
                    'REPLAY', false);
                if (!$fz['ok']) {
                    $ok = false;
                    $this->error('  × 凍結保存できません: ' . $fz['code'] . ' ' . $fz['reason']);
                } else {
                    $c = $fz['counts'];
                    $this->line(sprintf('  ○ 保存できました 出馬%s 取得%s 凍結%s 活動%s',
                        $c['entry'] ?? '-', $c['acquired'] ?? '-',
                        $c['frozen'] ?? '-', $c['active'] ?? '-'));
                    // @ANCHOR-20261020-R122-SEP  REPLAY は別世代に保存されます
                    $gen = (int) ($fz['generation'] ?? 0);
                    $this->line('  ○ 保存先の世代 generation=' . $gen
                              . '（REPLAY は本番の0と分けています）');
                    $snap = \DB::table('baganriki_snapshots')->where('race_id', $raceId)
                               ->where('generation', $gen)->first();
                    if ($snap === null) {
                        $ok = false; $this->error('  × 読み戻せません');
                    } else {
                        $this->line('  ○ 読み戻し snapshot_hash ' . substr((string) $snap->snapshot_hash, 0, 16));
                        // ══════════════════════════════════════════════
                        // @ANCHOR-20261020-R122-DERIVEDAT  hash が違う理由
                        // ══════════════════════════════════════════════
                        //   上の行と番号が違うのは不具合ではありません。
                        //   上は<b>この試験が組み立てた</b>入力、
                        //   下は<b>凍結が組み立てて保存した</b>入力です。
                        //   派生値の computed_at に実計算時刻を入れる契約
                        //   （時刻A案）なので、組み立て直すと hash も変わります。
                        //   大事なのは「保存したものと読み戻したものが同じ」ことで、
                        //   それは次の行で確かめています。
                        $this->line('     ※ 上の hash と違うのは、組み立てが別だからです'
                                  . '（派生の計算時刻が入るため）。'
                                  . '保存と読み戻しが一致していることが要点です');
                        $this->line('           mode ' . $snap->mode . '／' . $snap->mode_status
                                  . '  frozen_at ' . $snap->frozen_at);
                        $j = json_decode((string) $snap->input_json_1st, true);
                        if (!is_array($j) || ($j['snapshot_hash'] ?? null) !== $snap->snapshot_hash) {
                            $ok = false; $this->error('  × 保存した入力と snapshot_hash が合いません');
                        } else {
                            $this->line('  ○ 保存した INPUT_JSON を読み直せて、hash も一致');
                        }
                        $run = \DB::table('baganriki_race_runs')->where('race_id', $raceId)->first();
                        if ($run !== null) {
                            $this->line('  ○ race_runs status=' . $run->status
                                      . ' run_kind=' . $run->run_kind
                                      . ' generation=' . $run->generation
                                      . ' 出馬' . $run->entry_count . ' 凍結' . $run->frozen_count);
                        }
                        // ── ④ 仮置きを本番として保存しようとしたら止まるか ──
                        $this->info('── ④ 仮置きの入力を PRODUCTION で保存しようとする ──');
                        $ng = $ctrl->r122Freeze($r->date, $r->kaisuu, $r->basho, $r->day, $r->race,
                            ['sales_close_at' =>
                                \App\Http\Controllers\Api\BaganrikiPrompt::rfc3339($anchorUs - 60 * 1000000)],
                            'PRODUCTION', false);
                        if (($ng['ok'] ?? false) === false && ($ng['code'] ?? '') === 'REPLAY_ONLY') {
                            $this->line('  ○ 止まりました: ' . $ng['reason']);
                        } else {
                            $ok = false;
                            $this->error('  × 仮置きの入力が PRODUCTION として保存できてしまいます');
                        }
                        $p0 = \DB::table('baganriki_snapshots')->where('race_id', $raceId)
                                 ->where('generation', 0)->count();
                        if ($p0 === 0) {
                            $this->line('  ○ 本番の世代（generation=0）には1件も入っていません');
                        } else {
                            $ok = false;
                            $this->error('  × 本番の世代に ' . $p0 . ' 件入ってしまいました');
                        }
                    }
                }
            }
        } catch (\Throwable $e) {
            $ok = false;
            $this->error('  × 例外: ' . $e->getMessage());
        } finally {
            \DB::rollBack();
        }

        $this->line('');
        $n1 = \DB::table('baganriki_acquisition_batches')->count();
        $n2 = \DB::table('baganriki_snapshots')->count();
        $n3 = \DB::table('baganriki_race_runs')->count();
        $this->line(sprintf('  ロールバック後の件数  監査 %d 件／snapshot %d 件／race_runs %d 件',
            $n1, $n2, $n3));
        if ($n1 !== 0 || $n2 !== 0 || $n3 !== 0) {
            $this->warn('  ※ 0件でない場合は、試験の前から入っていた行です');
        }
        $this->line('');
        $this->info('════════════════════════════════════════════════════════');
        $this->info($ok ? ' 監査行から凍結保存まで通りました（DBへ残る書き込み0件）'
                        : ' 通らなかった箇所があります。上の × をご確認ください');
        $this->info('════════════════════════════════════════════════════════');
    }
