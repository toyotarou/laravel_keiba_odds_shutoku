
    /**
     * ═══════════════════════════════════════════════════════════════════════
     * @ANCHOR-20261020-R122-FREEZE  凍結入力の保存を走らせる
     * ═══════════════════════════════════════════════════════════════════════
     * 根拠：server_contract_r12.2.txt 2章・5章／詳細設計書 4.4・7.2
     *
     *   一度固定した snapshot は上書きしません。
     *   入力を作れないレースは snapshot を作らず、baganriki_race_runs へ
     *   理由コードつきで残します（「何も起きなかった」と区別するため）。
     *   --r122-freeze-dry なら1行も書きません。
     */
    private function runR122Freeze(bool $dry): void
    {
        self::r122Autoload();
        $dates = array_values(array_filter(array_map('trim',
            explode(',', (string) ($this->option('date') ?: date('Y-m-d'))))));
        $assume = (bool) $this->option('r122-prompt-assume');
        $offset = (int) ($this->option('r122-prompt-sales-offset') ?: 0);

        $this->info('════════════════════════════════════════════════════════');
        $this->info($dry ? ' r12.2 凍結入力の保存（試すだけ・1行も書きません）'
                         : ' r12.2 凍結入力の保存');
        $this->info('════════════════════════════════════════════════════════');
        $this->line('  実行時刻 : ' . date('c'));
        $this->line('  対象日   : ' . implode(' / ', $dates));
        if ($assume) $this->warn('  【仮】取得監査の実時刻を予定時刻で埋めます（本番の凍結には使いません）');
        if ($offset > 0) $this->warn('  【仮】投票締切を「発走の' . $offset . '秒前」として扱います（正本ではありません）');
        $this->line('');

        $ctrl = app(\App\Http\Controllers\Api\AiController::class);
        $byCode = []; $okN = 0; $skipN = 0; $rows = [];
        foreach ($dates as $date) {
            foreach (\DB::table('t_horse_odds_finder_races')->where('date', $date)
                        ->orderBy('basho')->orderBy('race')
                        ->get(['date', 'kaisuu', 'basho', 'day', 'race', 'start_time']) as $r) {
                $ov = [];
                if ($assume) $ov['assume_audit'] = true;
                if ($offset > 0) {
                    $st = (string) $r->start_time;
                    if (strlen($st) === 5) $st .= ':00';
                    $us = \App\Http\Controllers\Api\BaganrikiTime::us(
                        $r->date . 'T' . $st . '+09:00');
                    if ($us !== null) {
                        $ov['sales_close_at'] = \App\Http\Controllers\Api\BaganrikiPrompt::rfc3339(
                            $us - $offset * 1000000);
                    }
                }
                $res = $ctrl->r122Freeze($r->date, $r->kaisuu, $r->basho, $r->day, $r->race,
                                         $ov, ($assume || $offset > 0) ? 'REPLAY' : 'PRODUCTION',
                                         $dry);
                $code = $res['ok'] ? ($res['skipped'] ? 'SKIP(既存)' : 'OK') : (string) $res['code'];
                $byCode[$code] = ($byCode[$code] ?? 0) + 1;
                if ($res['ok'] && !$res['skipped']) {
                    $okN++;
                    $c = $res['counts'];
                    $rows[] = sprintf('  ○ %-22s 出馬%2s 取得%2s 凍結%2s 活動%2s hash=%s',
                        $res['race_id'], $c['entry'] ?? '-', $c['acquired'] ?? '-',
                        $c['frozen'] ?? '-', $c['active'] ?? '-',
                        substr((string) $res['snapshot_hash'], 0, 12));
                } elseif ($res['skipped']) {
                    $skipN++;
                }
            }
        }
        ksort($byCode);
        foreach ($byCode as $k => $n) $this->line(sprintf('    %-30s %4d レース', $k, $n));
        $this->line('');
        foreach (array_slice($rows, 0, 12) as $x) $this->line($x);
        if (count($rows) > 12) $this->line('    …ほか ' . (count($rows) - 12) . ' レース');
        $this->line('');
        $this->line('  ※ 4つの頭数は別物です。出馬＝正本出馬表／取得＝読み込めた一意件数／');
        $this->line('    凍結＝情報上限までの取消を除いた頭数（N）／活動＝凍結後の取消を除いた頭数。');
        if ($dry) $this->warn('  ※ --r122-freeze-dry なので1行も書いていません。');
        $this->line('');
        $this->info('════════════════════════════════════════════════════════');
        $this->info($dry ? ' 試行おわり（書き込み0件）'
                         : ' 保存 ' . $okN . ' 件／既存で触らず ' . $skipN . ' 件');
        $this->info('════════════════════════════════════════════════════════');
    }
