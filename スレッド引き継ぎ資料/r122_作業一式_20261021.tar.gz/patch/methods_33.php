
    /**
     * ═══════════════════════════════════════════════════════════════════════
     * @ANCHOR-20261020-R122-33R  33レースの候補比較（機械比較）
     * ═══════════════════════════════════════════════════════════════════════
     * 根拠：10月20日003のご指摘④／16_33レース候補比較_方針と材料
     *
     * ■ やること
     *   暫定選出（PROVISIONAL）になるレースについて、
     *   <b>同じ保存済み全頭評価を両側へ当てて、配分差だけを見ます。</b>
     *     比較側 … X6 を使わない従来判定（下側の mode = modeOfS(S_min)）
     *     採用側 … r12.2 の暫定（上側の mode = allocation_mode）
     *   S0=1 なら FIRM→MIXED、S0=3 なら MIXED→VOLATILE になります。
     *   評価は作り直しません（再評価ではなく機械比較です）。
     *
     * ■ 暫定かどうかは r122Decide で判定します
     *   X6 だけが不明で S0 が 1 か 3 のときだけ PROVISIONAL です。
     *   N<7 は X6 が false に決まるので暫定になりません。
     *   S0 を直接 1/3 で拾うのはやめました（X1〜X5・Z に不明があると
     *   S0 が null になり、取りこぼします）。
     *
     * ■ 使う材料
     *   t_horse_odds_finder_ai_merge_result の audit_merge.全頭
     *     統合点・統合順位・独立根拠（tier・独立群数・source_refs）・人気
     *   帯は r12.2 の凍結人気（6分前の単勝昇順）から A/B/D を引き直します
     *   （保存されている「上・中・下」は旧い2〜3帯の呼び方なので使いません）。
     *
     *   ※ 全頭 は「当時その経路が評価した馬」だけです（全出走馬ではありません）。
     *     収録されていない馬は適格判定にのせられないので、
     *     枠が埋まらないときは 不足理由 に収録頭数を書き添えます。
     *
     * ■ 適格の判定
     *   独立根拠の系統が1つ以上あることだけを条件にします（契約4章）。
     *   点数の高さ・人気の低さ・旧資格は条件にしません。
     *
     * ■ 並び
     *   帯の中を 統合点の降順 → 独立系統数の降順 → 馬番の昇順。
     *   A→B→D の順に、枠数ぶんだけ先頭から取ります（飛ばし取りはしません）。
     *
     * 読み取りだけです。AI呼び出し0回、DBへの書き込み0件。
     */
    private function runR12233Races(string $dateArg): void
    {
        self::r122Autoload();
        $dates = array_values(array_filter(array_map('trim', explode(',', $dateArg))));
        $this->info('════════════════════════════════════════════════════════');
        $this->info(' r12.2 33レースの候補比較（機械比較・評価は作り直しません）');
        $this->info('════════════════════════════════════════════════════════');
        $this->line('  実行時刻 : ' . date('c'));
        $this->line('  対象日   : ' . implode(' / ', $dates));
        $this->line('');

        $rows = [];      // CSV用
        // ══════════════════════════════════════════════════════════════
        // @ANCHOR-20261020-R122-33CANCEL  10月20日006のご指摘6-3
        // ══════════════════════════════════════════════════════════════
        //   ご指摘のとおり、03_33レース候補比較.md の説明が逆でした。
        //   正本は「input_freeze_at までに利用可能な正式取消なら
        //   凍結集合から外す」です。「6分前の取消は残す」ではありません。
        //   説明文で言い切るのをやめて、<b>実データをここに出します</b>。
        //   取消のあった時点（cancel_slots）・6分前の生値・分類を並べます。
        $cxRows = [];    // 取消があったレースの内訳
        $nAll = 0; $nNg = 0; $ngList = [];
        $stat = ['CONFIRMED' => 0, 'PROVISIONAL' => 0, 'UNRESOLVED' => 0];
        $nSame = 0; $nDiff = 0; $nNoEval = 0;

        foreach ($dates as $date) {
            // ── オッズを読む（--mode-check と同じ形）───────────────────
            $series = []; $entry = []; $declared = [];
            $signal = [21, 18, 15, 12, 9, 6];
            $read   = array_merge($signal, [3, \App\Constants\Constants::ODDS_DB_LAST]);
            foreach (\DB::table('t_horse_odds_finder_odds')->where('date', $date)
                        ->whereIn('minutes_before_start', $read)
                        ->get(['kaisuu','basho','day','race','num','minutes_before_start',
                               'odds','fuku_min']) as $o) {
                $k = $o->kaisuu . '|' . $o->basho . '|' . $o->day . '|' . $o->race;
                $t = (int) $o->minutes_before_start; $n = (int) $o->num;
                $raw = trim((string) $o->odds);
                if ($raw === '取消' || $raw === '除外') {
                    $series[$k][$n]['cancel'] = $raw;
                    $series[$k][$n]['cancel_slots'][] = $t;
                    continue;
                }
                if (!in_array($t, $signal, true)) continue;
                $v = self::decScale($o->odds);
                if ($v !== null) { $series[$k][$n]['t'][$t] = $v; $series[$k][$n]['ts'][$t] = $raw; }
                $v = self::decScale($o->fuku_min);
                if ($v !== null) { $series[$k][$n]['f'][$t] = $v;
                                   $series[$k][$n]['fs'][$t] = trim((string) $o->fuku_min); }
            }
            foreach (\DB::table('t_horse_odds_finder_horses')->where('date', $date)
                        ->get(['kaisuu','basho','day','race','num']) as $h) {
                $entry[$h->kaisuu . '|' . $h->basho . '|' . $h->day . '|' . $h->race][(int) $h->num] = true;
            }
            foreach (\DB::table('t_horse_odds_finder_races')->where('date', $date)
                        ->get(['kaisuu','basho','day','race','num_horses']) as $x) {
                $declared[$x->kaisuu . '|' . $x->basho . '|' . $x->day . '|' . $x->race]
                    = ($x->num_horses === null) ? null : (int) $x->num_horses;
            }

            foreach ($series as $key => $sr) {
                [$kaisuu, $basho, $day, $race] = explode('|', $key);
                $nAll++;
                // @ANCHOR-20261020-R122-33R  modeCheckOne は「馬番=>true」の配列を受けます。
                //   array_keys を通すと 0〜N-1 の並びになり、出馬表照合が必ず外れます。
                $es  = $entry[$key] ?? null;
                $res = $this->modeCheckOne($sr, $es, $declared[$key] ?? null);
                if (($res['状態'] ?? '') === '計算不能') {
                    $nNg++;
                    $ngList[] = [$date . '/' . str_replace('|', '/', $key), (string) ($res['理由'] ?? '')];
                    continue;
                }
                $N = (int) $res['N'];

                // ── 暫定かどうか（X6だけ不明で S0=1 か 3）────────────────
                $dec = self::r122Decide([
                    'X1' => $res['X1'], 'X2' => $res['X2'], 'X3' => $res['X3'],
                    'X4' => $res['X4'], 'X5' => $res['X5'], 'Z'  => $res['Z'],
                    'X6' => (($N >= 7) ? null : false),
                ]);
                $stat[$dec['mode_status']]++;

                // @ANCHOR-20261020-R122-33CANCEL  取消があったレースの内訳を残します
                //   （暫定かどうかに関係なく、取消があれば全部出します）
                foreach ($sr as $hn => $ho) {
                    if (!isset($ho['cancel'])) { continue; }
                    $sl = array_values(array_map('intval',
                              (array) ($ho['cancel_slots'] ?? [])));
                    usort($sl, static fn($a, $b) => self::slotOrd($b) <=> self::slotOrd($a));
                    $in6 = array_key_exists(6, (array) ($ho['t'] ?? []))
                         ? (string) ($ho['ts'][6] ?? '') : '（6分前は欠損）';
                    $cls = in_array((int) $hn, (array) ($res['cancelled'] ?? []), true)
                         ? 'cancelPre'
                         : (in_array((int) $hn, (array) ($res['cancelled_post'] ?? []), true)
                            ? 'cancelPost'
                            : (in_array((int) $hn, (array) ($res['cancelled_late'] ?? []), true)
                               ? 'cancelLate' : '（分類なし）'));
                    $cxRows[] = [
                        'race'     => $date . '/' . str_replace('|', '/', $key),
                        'num'      => (int) $hn,
                        'slots'    => implode('→', array_map('strval', $sl)),
                        'odds6'    => $in6,
                        'class'    => $cls,
                        'frozen'   => ($cls === 'cancelPre') ? '外す' : '残す',
                        'N'        => $N,
                        'declared' => ($declared[$key] ?? null),
                        'entry'    => ($es === null) ? null : count($es),
                        'status'   => (string) $dec['mode_status'],
                    ];
                }

                if ($dec['mode_status'] !== 'PROVISIONAL') continue;

                $s0      = $dec['S0'];
                $useMode = (string) $dec['allocation_mode'];
                $cmpMode = self::modeOfS((int) $dec['S_min']);
                $qCmp    = self::r122StructuralQuota($N, $cmpMode)['quota'];
                $qUse    = self::r122StructuralQuota($N, $useMode)['quota'];

                $raceId = \App\Http\Controllers\Api\AiController::r122RaceId(
                    $date, $kaisuu, $basho, $day, $race);

                // ── 保存済みの全頭評価 ───────────────────────────────
                //   basho_code まで見ます。東京と京都は kaisuu・day・race が
                //   そろうことがあり、場を外すと別の場の行を拾います。
                $mr = \DB::table('t_horse_odds_finder_ai_merge_result')
                        ->where('date', $date)->where('kaisuu', (int) $kaisuu)
                        ->where('basho_code', $basho)
                        ->where('day', (int) $day)->where('race', (int) $race)->first();
                $all = null;
                if ($mr !== null) {
                    $j = json_decode((string) $mr->merge_result, true);
                    $all = $j['audit_merge']['全頭'] ?? null;
                }
                if (!is_array($all) || $all === []) {
                    $nNoEval++;
                    $rows[] = [$raceId, $N, $s0, $cmpMode, $useMode,
                        self::r122Fmt($qCmp), self::r122Fmt($qUse),
                        '', '', '', '', '保存済み全頭評価がありません'];
                    continue;
                }

                // ── 帯は r12.2 の凍結人気から引き直します ───────────────
                $horses = [];
                foreach ($all as $num => $h) {
                    $n = (int) $num;
                    $pop = $res['frozen'][$n] ?? null;
                    if ($pop === null) continue;              // 凍結集合にいない馬
                    $groups = (int) ($h['独立根拠']['独立群数'] ?? 0);
                    $refs = [];
                    foreach ((array) ($h['独立根拠']['判定数値'] ?? []) as $d) {
                        foreach ((array) ($d['source_refs'] ?? []) as $sref) $refs[] = (string) $sref;
                    }
                    $horses[$n] = [
                        'num'     => $n,
                        'pop'     => (int) $pop,
                        'band'    => \App\Http\Controllers\Api\BaganrikiAllocation::v04Band((int) $pop),
                        'score'   => $h['統合点'] ?? null,
                        'groups'  => $groups,
                        'tier'    => (string) ($h['独立根拠']['tier'] ?? ''),
                        'refs'    => array_values(array_unique($refs)),
                        // ══════════════════════════════════════════════
                        // @ANCHOR-20261020-R122-33ELIG  006のご指摘6-2
                        // ══════════════════════════════════════════════
                        //   【旧】'eligible' => ($groups >= 1 && $h['統合点'] !== null)
                        //     統合点が無い馬（採点が partial で点が出ていない馬）を
                        //     落としていました。契約は<b>「確認済み個別SIGNALが
                        //     1系統あれば資格を保持する」</b>で、点数の有無は条件に
                        //     ありません。説明の「1系統以上だけで判定」とも
                        //     食い違っていました。点の無い馬は<b>並びの最後</b>に
                        //     置きますが、資格からは外しません。
                        'eligible'=> ($groups >= 1),
                    ];
                }
                $pick = static function (array $quota) use ($horses) {
                    $idx = ['A' => 0, 'B' => 1, 'D' => 2];
                    $byBand = ['A' => [], 'B' => [], 'D' => []];
                    foreach ($horses as $h) {
                        if (!$h['eligible']) continue;
                        $byBand[$h['band']][] = $h;
                    }
                    foreach ($byBand as $b => $list) {
                        usort($list, static function ($x, $y) {
                            // @ANCHOR-20261020-R122-33ELIG  点の無い馬は最後に置きます
                            //   （資格からは外しません。点数を資格の条件にしません）
                            $xs = ($x['score'] === null); $ys = ($y['score'] === null);
                            if ($xs !== $ys) { return $xs ? 1 : -1; }
                            if (!$xs && $x['score'] !== $y['score']) {
                                return ($y['score'] <=> $x['score']);
                            }
                            if ($x['groups'] !== $y['groups']) return ($y['groups'] <=> $x['groups']);
                            return ($x['num'] <=> $y['num']);
                        });
                        $byBand[$b] = $list;
                    }
                    // ══════════════════════════════════════════════════
                    // @ANCHOR-20261020-R122-33FILL  006のご指摘6-2
                    // ══════════════════════════════════════════════════
                    //   【旧】帯ごとに先頭から取るだけで、<b>適格馬が足りない
                    //     ときの枠移動をしていませんでした。</b>
                    //     契約は「D不足はBだけから、B不足はDだけから、
                    //     A不足はB→Dから補う（B・DをAで埋めない）」です。
                    //   本体の BaganrikiRanking::fillShortfall を呼びます。
                    $q0 = ['A' => (int) ($quota[$idx['A']] ?? 0),
                           'B' => (int) ($quota[$idx['B']] ?? 0),
                           'D' => (int) ($quota[$idx['D']] ?? 0)];
                    $avail = ['A' => count($byBand['A']), 'B' => count($byBand['B']),
                              'D' => count($byBand['D'])];
                    $fill = \App\Http\Controllers\Api\BaganrikiRanking::fillShortfall(
                                $q0, $avail);
                    $q1 = (array) $fill['quota'];
                    $out = []; $short = [];
                    foreach (['A', 'B', 'D'] as $b) {
                        $want = (int) ($q1[$b] ?? 0);
                        $have = count($byBand[$b]);
                        $take = min($want, $have);
                        for ($i = 0; $i < $take; $i++) $out[] = $byBand[$b][$i]['num'];
                        if ($want > $have) {
                            $short[] = $b . '帯 要求' . $want . '・適格' . $have
                                     . '・不足' . ($want - $have);
                        }
                    }
                    foreach ((array) ($fill['shortfalls'] ?? []) as $sf) {
                        $short[] = '枠移動 ' . json_encode($sf, JSON_UNESCAPED_UNICODE);
                    }
                    return ['nums' => $out, 'short' => $short, 'byBand' => $byBand,
                            'quota_before' => $q0, 'quota_after' => $q1];
                };
                $pCmp = $pick((array) $qCmp);
                $pUse = $pick((array) $qUse);

                $same = ($pCmp['nums'] === $pUse['nums']);
                if ($same) $nSame++; else $nDiff++;

                $refsOf = static function (array $nums) use ($horses) {
                    $o = [];
                    foreach ($nums as $n) {
                        $o[] = $n . ':' . ($horses[$n]['tier'] ?? '')
                             . '[' . implode(' ', (array) ($horses[$n]['refs'] ?? [])) . ']';
                    }
                    return implode(' / ', $o);
                };

                $short = [];
                foreach ($pCmp['short'] as $s) $short[] = '比較側 ' . $s;
                foreach ($pUse['short'] as $s) $short[] = '採用側 ' . $s;
                if ($short !== []) {
                    $short[] = '当時の保存は' . $N . '頭のうち' . count($horses) . '頭ぶんです';
                }

                $rows[] = [
                    $raceId, $N, $s0, $cmpMode, $useMode,
                    self::r122Fmt($qCmp), self::r122Fmt($qUse),
                    implode('-', $pCmp['nums']), implode('-', $pUse['nums']),
                    $same ? '同じ' : '違う',
                    $refsOf($pUse['nums']),
                    implode('／', $short),
                ];

                if (count($rows) <= 12) {
                    $this->line(sprintf('  %-22s N=%2d S0=%d  %-8s %-8s → %-8s %-8s  %s',
                        $raceId, $N, (int) $s0, $cmpMode, self::r122Fmt($qCmp),
                        $useMode, self::r122Fmt($qUse),
                        $same ? '候補 同じ' : '候補 違う'));
                    $this->line('      比較側 ' . implode('-', $pCmp['nums']));
                    $this->line('      採用側 ' . implode('-', $pUse['nums']));
                }
            }
        }
        if (count($rows) > 12) $this->line('    …ほか ' . (count($rows) - 12) . ' レース');

        $this->line('');
        $this->line('  読んだレース                 : ' . $nAll . ' レース');
        $this->line('  計算不能                     : ' . $nNg . ' レース');
        $this->line('  確定（CONFIRMED）            : ' . $stat['CONFIRMED'] . ' レース');
        $this->line('  判定できない（UNRESOLVED）   : ' . $stat['UNRESOLVED'] . ' レース');
        $this->line('  対象（暫定選出 PROVISIONAL） : ' . $stat['PROVISIONAL'] . ' レース');
        $this->line('  候補が違う                   : ' . $nDiff . ' レース');
        $this->line('  候補が同じ                   : ' . $nSame . ' レース（省かずに載せます）');
        if ($nNoEval > 0) {
            $this->line('  保存済み評価が無い           : ' . $nNoEval . ' レース');
        }
        if ($ngList !== []) {
            $this->line('');
            $this->line('  ── 計算不能の内訳 ──');
            foreach (array_slice($ngList, 0, 10) as $g) {
                $this->line('    ' . $g[0] . ' : ' . $g[1]);
            }
            if (count($ngList) > 10) $this->line('    …ほか ' . (count($ngList) - 10) . ' 件');
        }

        $path = storage_path('logs/r122_33races_' . date('Ymd_His') . '.csv');
        $fp = fopen($path, 'w');
        fwrite($fp, "\xEF\xBB\xBF");
        fputcsv($fp, ['race_id','N','S0','比較側mode','採用側mode','比較側1st枠','採用側1st枠',
                      '比較側の候補馬番','採用側の候補馬番','候補の異同',
                      '採用側の根拠（馬番:tier[source_refs]）','不足理由']);
        foreach ($rows as $r) fputcsv($fp, $r);
        fclose($fp);
        $this->line('');
        $this->info('  書き出しました: ' . $path . '（' . count($rows) . '行）');
        $this->line('');
        // ══════════════════════════════════════════════════════════════
        // @ANCHOR-20261020-R122-33LIMIT  この比較で言えること・言えないこと
        // ══════════════════════════════════════════════════════════════
        // ══════════════════════════════════════════════════════════════
        // @ANCHOR-20261020-R122-33CANCEL  取消があったレースの内訳（006の6-3）
        // ══════════════════════════════════════════════════════════════
        $this->warn('  ■ 取消があったレースの内訳（10月20日006のご指摘6-3）');
        $this->line('    正本の規則 : input_freeze_at（発走330秒前）までに');
        $this->line('                 利用可能な正式取消なら凍結集合から外します。');
        $this->line('                 「6分前の取消は残す」という規則ではありません。');
        $this->line('    コードの境目: 取消が見えた最も早い時点を slotOrd で比べ、');
        $this->line('                 6分前の時点以前なら cancelPre（外す）、');
        $this->line('                 6分前に実数値があってその後なら cancelPost（残す）、');
        $this->line('                 6分前が欠損で根拠が凍結後だけなら cancelLate（残す）。');
        $this->line('                 6分前の取得期限は input_freeze_at 以前です（R122-CL06）。');
        $this->line('                 3分前の行は input_freeze_at より後なので使いません。');
        $this->line('');
        if ($cxRows === []) {
            $this->line('    対象日に取消はありませんでした。');
        } else {
            $this->line(sprintf('    %-26s %3s %-34s %-14s %-11s %-5s %s',
                'レース', '馬番', '取消が見えた時点（早い順）', '6分前の単勝',
                '分類', '凍結', '頭数（N／出馬表／num_horses）'));
            foreach ($cxRows as $c) {
                $this->line(sprintf('    %-26s %3d %-34s %-14s %-11s %-5s %d／%s／%s  %s',
                    (string) $c['race'], (int) $c['num'], (string) $c['slots'],
                    (string) $c['odds6'], (string) $c['class'], (string) $c['frozen'],
                    (int) $c['N'],
                    ($c['entry'] === null) ? '-' : (string) $c['entry'],
                    ($c['declared'] === null) ? '-' : (string) $c['declared'],
                    (string) $c['status']));
            }
            $this->line('');
            $this->line('    ※ 時点は minutes_before_start です。−999=確定。');
            $this->line('    ※ この比較が読む時点は 21・18・15・12・9・6・3・確定 の8つです。');
            $this->line('       999（最初の取得）はこの経路では読みません。信号6点に');
            $this->line('       含まれないためです。そのため、表のcancel_slotsを直接');
            $this->line('       数えた値（999を含む）とは、999のぶんだけ並びが違います。');
            $this->line('    ※ この表の元値は t_horse_odds_finder_odds をそのまま読んだものです。');
            $this->line('    ※ この表には取得時刻の列がありません。だから「正式取消が');
            $this->line('       いつ利用可能になったか」は時刻では示せません。');
            $this->line('       契約どおり、取得時点（スロット）の前後で判定しています。');
        }
        $this->line('');
        $this->warn('  ■ この比較で言えること・言えないこと（10月20日006のご指摘6-2）');
        $this->line('    言えること : 保存済みの全頭評価を、比較側と採用側の');
        $this->line('                 配分規則だけ変えて当て直した結果の違いです。');
        $this->line('                 資格は「確認済み個別SIGNALが1系統以上」で判定し、');
        $this->line('                 不足時の枠移動は本体の fillShortfall を使っています。');
        $this->line('    言えないこと: r12.2 の統合経路（両AIの局所回復・帯順位・');
        $this->line('                 原公開一致の加点）を通した比較ではありません。');
        $this->line('                 当時の実予想・成績とも別物です。');
        $this->line('                 全頭評価が無いレースは CSV の不足理由に書いています。');
        $this->line('');
        $this->line('  ※ 評価は作り直していません。保存済みの全頭評価をそのまま両側へ当てています。');
        $this->line('  ※ 帯は r12.2 の凍結人気（6分前の単勝昇順）から引き直しています。');
        $this->line('  ※ 適格は「独立した根拠の系統が1つ以上」だけで判定しています。');
        $this->line('  ※ 全頭 は当時その経路が評価した馬だけです（全出走馬ではありません）。');
        $this->line('  ※ 当時の実運用の選出結果とは別物です（当時は旧い2帯の配分でした）。');
    }
