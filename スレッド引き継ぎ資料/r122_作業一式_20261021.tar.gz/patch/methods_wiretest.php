    /**
     * ═══════════════════════════════════════════════════════════════════════
     * @ANCHOR-20261020-R122-WIRETEST  送信口を試験用に置き換えて接続を通す
     * ═══════════════════════════════════════════════════════════════════════
     * 10月20日007の「次の提出で確認したい最小セット」E：
     *   「上限前呼出し→上限後凍結、片側失敗、応答期限到達、
     *     プロセス停止後の復旧を通す実起動経路。」
     *   「まず送信口を試験用に置き換えて接続を通し、
     *     その後で実AIの時間と出力品質を測ってください。」
     *
     * ■ どうやって実AIを呼ばずに実経路を通すか
     *   送信口（Httpクライアント）そのものを偽の応答に差し替えます。
     *   Laravel の Http::fake() は facade の下に入るので、
     *   <b>本番のコードを1行も変えずに</b>、
     *     AnthropicService::sendWithRetry（1st）
     *     Http::post('https://api.deepseek.com/...')（2nd）
     *   の両方が偽応答を受け取ります。
     *   通るのは本番の関数です（r122AfterReceive →
     *   r122InspectResponse → r122SendFix → r122CallAi →
     *   r122AcceptedHorses → r122PublishWhenReady）。
     *   実AIへの通信は0回です（偽の送信口が何回呼ばれたかも数えます）。
     *
     * ■ 書き込みについて
     *   全部ひとつのトランザクションで行い、最後に必ずロールバックします。
     */
    private function runR122WireTest(string $root): void
    {
        self::r122Autoload();
        $vDir = rtrim($root, '/') . '/validation/normal';
        $this->info('════════════════════════════════════════════════════════');
        $this->info(' r12.2 送信口を試験用に置き換えて接続を通す（007のE）');
        $this->info('════════════════════════════════════════════════════════');
        $this->line('  実行時刻 : ' . date('c'));
        $this->line('  資料     : ' . $vDir);
        $this->warn('  ※ 実AIは1回も呼びません（送信口を偽応答に差し替えます）');
        $this->warn('  ※ 全部ロールバックします。DBへ残る書き込みは0件です');
        $this->line('');
        $need = ['MIXED_N16_1st_input.json', 'MIXED_N16_1st_output.json',
                 'MIXED_N16_2nd_input.json', 'MIXED_N16_2nd_output.json'];
        foreach ($need as $f) {
            if (!is_file($vDir . '/' . $f)) {
                $this->error('  × ' . $vDir . '/' . $f . ' がありません');
                return;
            }
        }

        $pass = 0; $fail = 0;
        $check = function (string $id, string $what, $got, $want) use (&$pass, &$fail) {
            $okk = ($got === $want);
            if ($okk) { $pass++; } else { $fail++; }
            $this->line(sprintf('  %s %-8s %-52s %s',
                $okk ? '○' : '×', $id, $what,
                $okk ? '' : ('得=' . var_export($got, true)
                             . ' 期待=' . var_export($want, true))));
        };
        $rd = static fn(string $f) => json_decode((string) file_get_contents($f), true);
        $j  = static fn($v) => (string) json_encode($v,
            JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PRESERVE_ZERO_FRACTION);
        $W     = \App\Http\Controllers\Api\BaganrikiWorker::class;
        // @ANCHOR-20261021-R122-SETTLE  採否確定の印を見るために使います
        $A     = \App\Http\Controllers\Api\AiController::class;
        $BEGIN = \App\Http\Controllers\Api\BaganrikiResponse::BEGIN;
        $END   = \App\Http\Controllers\Api\BaganrikiResponse::END;
        $HTTP  = \Illuminate\Support\Facades\Http::class;

        $in1  = $rd($vDir . '/MIXED_N16_1st_input.json');
        $out1 = $rd($vDir . '/MIXED_N16_1st_output.json');
        $in2  = $rd($vDir . '/MIXED_N16_2nd_input.json');
        $out2 = $rd($vDir . '/MIXED_N16_2nd_output.json');

        // ── 偽の送信口 ───────────────────────────────────────────────
        // ══════════════════════════════════════════════════════════════
        //   【ここは1回だけ登録します】Http::fake() は呼ぶたびに
        //   <b>積み重なります</b>（置き換えではありません）。
        //   Laravel は登録した順に全部呼んで、最初に応答を返したものを
        //   使うので、2回目以降に登録した偽応答は<b>使われません。</b>
        //   10月20日の最初の試作でこれを踏みました（1回目の応答が
        //   ずっと返り続け、片側失敗も通信不能も再現できていませんでした）。
        //   なので登録は1回だけにして、<b>振る舞いは変数で切り替えます。</b>
        $calls = [];
        $mode  = 'ok';
        $doc   = [];
        $docFix = [];       // @ANCHOR-20261021-R122-FIXPROVE  訂正で返す本文
        $bodyOf = function (array $d) use ($j, $BEGIN, $END): string {
            return $BEGIN . $j($d) . $END;
        };
        $seq2 = 0;          // @ANCHOR-20261021-R122-FIXPROVE  何回目の送信か
        $HTTP::fake(function ($request)
                    use (&$calls, &$mode, &$doc, &$docFix, &$seq2, $bodyOf, $HTTP) {
            $url = (string) $request->url();
            $calls[] = $url;
            $seq2++;
            // @ANCHOR-20261021-R122-FIXPROVE  2回目以降（＝訂正）は別の本文を返します
            //   初回と訂正に同じ応答を返すと、訂正で直ったことを確かめられません。
            if ($docFix !== [] && $seq2 >= 2) { $doc = $docFix; }
            if ($mode === 'down') {
                throw new \Illuminate\Http\Client\ConnectionException(
                    '試験用：送信口につながりません');
            }
            if ($mode === 'http500') {
                return $HTTP::response('{"error":"試験用"}', 500);
            }
            $body = $bodyOf($doc);
            if (strpos($url, 'api.deepseek.com') !== false) {
                return $HTTP::response(['choices' => [['message' =>
                    ['content' => $body],
                    'finish_reason' => ($mode === 'truncated') ? 'length' : 'stop']]], 200);
            }
            return $HTTP::response([
                'content' => [['type' => 'text', 'text' => $body]],
                'stop_reason' => ($mode === 'truncated') ? 'max_tokens' : 'end_turn',
            ], 200);
        });
        // $mode: 'ok' 正しい応答／'http500' 明確な失敗／'down' 通信できない
        //        'truncated' 途中で切れた（complete=false）
        $port = function (string $m, array $d = [], array $f = [])
                use (&$calls, &$mode, &$doc, &$docFix, &$seq2): void {
            $mode = $m; $doc = $d; $docFix = $f; $calls = []; $seq2 = 0;
        };
        $sentTo = function () use (&$calls): string {
            if ($calls === []) { return '（送信なし）'; }
            $last = (string) $calls[count($calls) - 1];
            if (strpos($last, 'api.deepseek.com') !== false) { return 'DeepSeek'; }
            if (strpos($last, 'api.anthropic.com') !== false) { return 'Anthropic'; }
            return $last;
        };

        // ── 凍結入力と初回の枠を「本番の関数で」作る道具 ─────────────
        //   枠は reserve → allowSend → receive の本番3段で作ります。
        //   手で RECEIVED を入れないので、予約の見張りも通ります。
        $seq = 0;
        $mk = function (array $doc1, array $doc2, array $opt = [])
              use ($in1, $in2, $j, $BEGIN, $END, &$seq, $W): array {
            $seq++;
            $now   = $W::nowUs();
            $sales = $now + ((int) ($opt['sales_in_sec'] ?? 3600)) * 1000000;
            $nums  = [];
            foreach ((array) $in1['runners'] as $r) { $nums[] = (int) $r['horse_no']; }
            $sid = \DB::table('baganriki_snapshots')->insertGetId([
                // @ANCHOR-20261021-R122-SENDFIRST  race_id は本番と同じ形にします
                //   r122SendFirst は受領のあと、race_id を5つに分けて
                //   r122AfterReceive（検証→訂正→解決→公開）を呼びます。
                //   'WT-1' のような形だと分けられず、そこで止まっていました。
                //   試験の側を本番と同じ形（日付-回-場-日-R）にします。
                //   場コード99は実在しないので、本番のレースとは混ざりません。
                'race_id' => '20261018-9-99-9-' . $seq,
                // @ANCHOR-20261021-R122-SENDFIRST  初回送信は本番の世代（0）を見ます
                'generation' => (($opt['gen0'] ?? false) === true) ? 0 : 900,
                'run_id' => 'WT',
                'snapshot_hash'   => (string) $in1['snapshot_hash'],
                'input_json_1st'  => $j($in1), 'input_json_2nd' => $j($in2),
                'frozen_nums'     => $j($nums),
                'allocation_mode' => (string) $in1['allocation_mode'],
                'mode'            => (string) $in1['mode'],
                'mode_status'     => (string) $in1['mode_status'],
                'target_count'    => (int) $in1['target_count'],
                'quota_1st'       => $j($in1['quota']),
                'sales_close_at'  => $W::toDb($sales),
                'created_at'      => $W::toDb($now),
            ]);
            \DB::table('baganriki_live_states')->insert([
                'snapshot_id' => $sid, 'cancellations' => $j([]),
                'active_count' => count($nums),
                'live_target_count' => (int) $in1['target_count'],
                'live_quota' => $j($in1['quota']), 'live_close' => null,
                'state_revision' => 0, 'response_revision' => 0,
                'publication_revision' => 0, 'latest_publication_id' => null,
                'updated_at' => $W::toDb($now),
            ]);
            $tok = [];
            // @ANCHOR-20261021-R122-SENDFIRST  枠を1つも作らない指定
            if (($opt['no_attempt'] ?? false) === true) {
                return ['sid' => (int) $sid, 'nums' => $nums, 'token' => []];
            }
            foreach ([['1st', $doc1], ['2nd', $doc2]] as $pair) {
                [$role, $doc] = $pair;
                if ($doc === []) { continue; }       // 枠を作らない role
                $r = $W::reserve((int) $sid, $role, $W::FIRST, $W::nowUs());
                if (!$r['ok']) { continue; }
                $tok[$role] = (string) $r['token'];
                $W::allowSend((string) $r['token'], $W::nowUs());
                if (($opt['leave_sent'] ?? null) === $role) { continue; }  // 送信済みのまま
                $W::receive((string) $r['token'], $BEGIN . $j($doc) . $END,
                            !(($opt['incomplete'] ?? null) === $role), $W::nowUs());
            }
            return ['sid' => (int) $sid, 'nums' => $nums, 'token' => $tok];
        };

        // 1頭落ちた初回（訂正が必要になります）
        $broken = $out1;
        $goneNo = (int) $broken['horses'][2]['horse_no'];
        array_splice($broken['horses'], 2, 1);

        $ok = true;
        \DB::beginTransaction();
        try {
            $ctrl = app(\App\Http\Controllers\Api\AiController::class);
            $D = ['2026-10-18', '4', '04', '2', 1];   // race_id を作るためだけの引数

            // ── ① 初回→検証→訂正→解決→公開を、本番の関数で通す ──────
            $this->info('── ① 初回→検証→訂正→解決→公開（偽の送信口で実経路）──');
            $port('ok', $out1);                       // 訂正では正しい全頭を返す
            $m = $mk($broken, $out2);
            $q = ['skip' => false, 'ok' => true, 'snapshot_id' => $m['sid']];
            $r = $ctrl->r122AfterReceive($D[0], $D[1], $D[2], $D[3], $D[4], '1st', $q);
            $check('E-01', '接続が動いた', $r['ran'], true);
            $check('E-02', '初回を検証した（直すところがある）',
                   (bool) ($r['inspect']['needs_fix'] ?? null), true);
            $check('E-03', '欠落しても他の15頭は残した',
                   (int) ($r['inspect']['normal'] ?? -1), 15);
            $check('E-04', '訂正を実際に送った', (bool) ($r['fix']['sent'] ?? null), true);
            $check('E-05', '偽の応答を受け取れた', (bool) ($r['fix']['ok'] ?? null), true);
            $check('E-06', '送信口が呼ばれた回数は1回', count($calls), 1);
            $this->line('      送信先 : ' . $sentTo());
            $check('E-07', '1st の送信先は Anthropic', $sentTo(), 'Anthropic');
            $check('E-08', '訂正の枠が RECEIVED になった',
                   (string) \DB::table('baganriki_ai_attempts')
                       ->where('snapshot_id', $m['sid'])->where('role', '1st')
                       ->where('attempt_no', 1)->value('status'), $W::RECEIVED);
            $acc = $ctrl->r122AcceptedHorses($m['sid'], '1st');
            $this->line('      解決 : ' . (string) ($acc['code'] ?? '')
                      . '／' . mb_strimwidth((string) ($acc['reason'] ?? ''), 0, 60, '…'));
            $check('E-09', '訂正を当てて全16頭そろう',
                   count((array) ($acc['merged'] ?? [])), 16);
            $check('E-10', '欠落していた馬を救済した',
                   in_array($goneNo, array_map('intval',
                       (array) ($acc['rescued'] ?? [])), true), true);
            // ══════════════════════════════════════════════════════════
            // @ANCHOR-20261021-R122-SETTLE  公開は両roleの採否確定の後です
            // ══════════════════════════════════════════════════════════
            //   【試験の前提が変わりました】
            //   これまでは 1st だけ接続を通し、2nd は枠を RECEIVED に
            //   しただけで「両roleが終端」と数えられていました。
            //   010の2-4 のとおり、RECEIVED は「HTTPが返った」だけです。
            //   本番は両roleが r122AfterReceive を通るので、試験もそう
            //   します。そのうえで<b>1stだけでは公開しない</b>ことを
            //   先に確かめます（これが010の2-4 の競合そのものです）。
            $check('E-11-0', '1st の採否が確定した',
                   (bool) ($r['settled']['marked'] ?? false), true);
            // $check('E-11', '両roleが終端なので公開した',
            //        (string) ($r['publish']['code'] ?? ''), 'PUBLISHED');  // 旧
            $check('E-11-1', '1st だけでは公開しない（2nd は受領済みだが採否未確定）',
                   (string) ($r['publish']['code'] ?? ''), 'WAITING');
            $check('E-11-2', '待っている相手は 2nd の採否',
                   (string) ($r['publish']['reason'] ?? ''),
                   'まだ終端でないroleがあります: 2nd（採否未確定）');
            $r1b = $ctrl->r122AfterReceive($D[0], $D[1], $D[2], $D[3], $D[4], '2nd', $q);
            $check('E-11-3', '2nd の採否も確定した',
                   (bool) ($r1b['settled']['marked'] ?? false), true);
            $check('E-11', '両roleの採否が確定したので公開した',
                   (string) ($r1b['publish']['code'] ?? ''), 'PUBLISHED');
            $this->line('      公開候補 : ' . (int) ($r1b['publish']['candidates'] ?? 0) . ' 頭');

            // ── ①-2 2nd（DeepSeek）側の送信口も同じように通す ───────────
            $this->info('── ①-2 2nd 側の送信口（DeepSeek）──');
            $broken2 = $out2;
            $gone2   = (int) $broken2['horses'][1]['horse_no'];
            array_splice($broken2['horses'], 1, 1);
            $port('ok', $out2);
            $mb = $mk($out1, $broken2);
            $qb = ['skip' => false, 'ok' => true, 'snapshot_id' => $mb['sid']];
            $rb = $ctrl->r122AfterReceive($D[0], $D[1], $D[2], $D[3], $D[4], '2nd', $qb);
            $check('E-47', '2nd も訂正を実際に送った',
                   (bool) ($rb['fix']['sent'] ?? null), true);
            $check('E-48', '2nd の送信先は DeepSeek', $sentTo(), 'DeepSeek');
            $check('E-49', '2nd も偽の応答を受け取れた',
                   (bool) ($rb['fix']['ok'] ?? null), true);
            $accb = $ctrl->r122AcceptedHorses($mb['sid'], '2nd');
            $this->line('      解決 : ' . (string) ($accb['code'] ?? '')
                      . '／' . mb_strimwidth((string) ($accb['reason'] ?? ''), 0, 60, '…'));
            $check('E-50', '2nd も訂正を当てて全16頭そろう',
                   count((array) ($accb['merged'] ?? [])), 16);
            $check('E-51', '2nd の欠落馬を救済した',
                   in_array($gone2, array_map('intval',
                       (array) ($accb['rescued'] ?? [])), true), true);
            // @ANCHOR-20261021-R122-SETTLE  こちらも両roleの採否確定が必要です
            $check('E-52-1', '2nd だけでは公開しない',
                   (string) ($rb['publish']['code'] ?? ''), 'WAITING');
            $rb2 = $ctrl->r122AfterReceive($D[0], $D[1], $D[2], $D[3], $D[4], '1st', $qb);
            $check('E-52-2', '1st の採否も確定した',
                   (bool) ($rb2['settled']['marked'] ?? false), true);
            // $check('E-52', '2nd 側も公開まで進む',
            //        (string) ($rb['publish']['code'] ?? ''), 'PUBLISHED');  // 旧
            $check('E-52', '2nd 側から始めても、両roleの確定後に公開まで進む',
                   (string) ($rb2['publish']['code'] ?? ''), 'PUBLISHED');

            // ── ② 訂正は最大1回（2回目は送らない）─────────────────────
            $this->info('── ② 訂正は最大1回 ──');
            $before = count($calls);
            $insp = $ctrl->r122InspectResponse($m['sid'], '1st', 0);
            $fx2  = $ctrl->r122SendFix($m['sid'], '1st', $insp);
            $check('E-12', '2回目の訂正は送らない', (bool) $fx2['sent'], false);
            //   訂正の枠がすでにある、という理由です（fixAllowed）。
            $check('E-13', 'その理由が読める', (string) $fx2['code'], 'SLOT_TAKEN');
            $check('E-14', '送信口は増えない', count($calls), $before);

            // ── ③ 片側が失敗しても、もう片方で公開できる ────────────────
            $this->info('── ③ 片側失敗（HTTP 500）──');
            $port('http500');
            $m2 = $mk($broken, $out2);
            $q2 = ['skip' => false, 'ok' => true, 'snapshot_id' => $m2['sid']];
            $r2 = $ctrl->r122AfterReceive($D[0], $D[1], $D[2], $D[3], $D[4], '1st', $q2);
            $check('E-15', '訂正は送った', (bool) ($r2['fix']['sent'] ?? null), true);
            $check('E-16', '明確な失敗として扱う',
                   (string) ($r2['fix']['code'] ?? ''), 'API_ERROR');
            $check('E-17', '枠は FAILED（結果不明にしない）',
                   (string) \DB::table('baganriki_ai_attempts')
                       ->where('snapshot_id', $m2['sid'])->where('role', '1st')
                       ->where('attempt_no', 1)->value('status'), $W::FAILED);
            $acc2 = $ctrl->r122AcceptedHorses($m2['sid'], '1st');
            $check('E-18', '初回の正常部分は残る（15頭）',
                   count((array) ($acc2['merged'] ?? [])), 15);
            // @ANCHOR-20261021-R122-SETTLE  訂正が失敗しても、採否は確定します
            //   初回が RECEIVED で訂正が FAILED なら、初回の正常部分を
            //   採って確定です。2nd は受領済みなので、こちらも接続を通します。
            $check('E-19-0', '訂正が失敗しても 1st の採否は確定する',
                   (bool) ($r2['settled']['marked'] ?? false), true);
            $check('E-19-1', '1st だけでは公開しない',
                   (string) ($r2['publish']['code'] ?? ''), 'WAITING');
            $r2b = $ctrl->r122AfterReceive($D[0], $D[1], $D[2], $D[3], $D[4], '2nd', $q2);
            // $check('E-19', '失敗しても公開まで進む',
            //        (string) ($r2['publish']['code'] ?? ''), 'PUBLISHED');  // 旧
            $check('E-19', '訂正が失敗しても、両roleの確定後に公開まで進む',
                   (string) ($r2b['publish']['code'] ?? ''), 'PUBLISHED');

            // ── ④ 通信できないときは「結果不明」（再送しない）───────────
            $this->info('── ④ 通信できない（結果不明）──');
            $port('down');
            $m3 = $mk($broken, $out2);
            $insp3 = $ctrl->r122InspectResponse($m3['sid'], '1st', 0);
            $fx3   = $ctrl->r122SendFix($m3['sid'], '1st', $insp3);
            $check('E-20', '送信はした', (bool) $fx3['sent'], true);
            $check('E-21', '通信できないので CONNECTION',
                   (string) $fx3['code'], 'CONNECTION');
            $check('E-22', '枠は結果不明（UNKNOWN）',
                   (string) \DB::table('baganriki_ai_attempts')
                       ->where('snapshot_id', $m3['sid'])->where('role', '1st')
                       ->where('attempt_no', 1)->value('status'), $W::UNKNOWN);
            $check('E-23', '自動で再送していない', count($calls), 1);

            // ── ⑤ 途中で切れた応答は選出に使わない ──────────────────────
            $this->info('── ⑤ 途中で切れた応答（complete=false）──');
            $port('truncated', $out1);
            $m4 = $mk($broken, $out2);
            $insp4 = $ctrl->r122InspectResponse($m4['sid'], '1st', 0);
            $fx4   = $ctrl->r122SendFix($m4['sid'], '1st', $insp4);
            $check('E-24', '切れていても原応答は保存する', (bool) $fx4['ok'], true);
            $check('E-25', 'complete=false で保存している',
                   (int) \DB::table('baganriki_ai_attempts')
                       ->where('snapshot_id', $m4['sid'])->where('role', '1st')
                       ->where('attempt_no', 1)->value('complete'), 0);
            $u4 = $W::usable($m4['sid'], '1st');
            $check('E-26', '選出に使うのは初回のほう',
                   (int) ($u4['attempt_no'] ?? -1), 0);

            // ── ⑥ 応答期限まで時間が無ければ訂正を送らない ──────────────
            $this->info('── ⑥ 応答期限到達 ──');
            $port('ok', $out1);
            $m5 = $mk($broken, $out2, ['sales_in_sec' => 100]);  // 応答期限まで約10秒
            $n5 = (int) \DB::table('baganriki_ai_attempts')
                      ->where('snapshot_id', $m5['sid'])->count();
            $insp5 = $ctrl->r122InspectResponse($m5['sid'], '1st', 0);
            $fx5   = $ctrl->r122SendFix($m5['sid'], '1st', $insp5);
            $check('E-27', '残り時間が無いので送らない', (bool) $fx5['sent'], false);
            $check('E-28', 'その理由が読める', (string) $fx5['code'], 'NO_TIME_FOR_FIX');
            $check('E-29', '空振りの枠を作らない',
                   (int) \DB::table('baganriki_ai_attempts')
                       ->where('snapshot_id', $m5['sid'])->count(), $n5);
            $check('E-30', '送信口は呼ばれない', count($calls), 0);

            // ── ⑦ 公開期限を過ぎたら公開しない ──────────────────────────
            $this->info('── ⑦ 公開期限到達 ──');
            $port('ok', $out1);
            $m6 = $mk($out1, $out2, ['sales_in_sec' => 30]);  // 公開期限はもう過ぎている
            $p6 = $ctrl->r122PublishWhenReady($m6['sid']);
            $check('E-31', '公開期限を過ぎたら公開しない', (bool) ($p6['ok'] ?? false), false);
            $check('E-32', 'その理由が読める',
                   (string) ($p6['code'] ?? ''), 'DEADLINE_PASSED');

            // ── ⑧ プロセス停止後の復旧（再送しない）──────────────────────
            $this->info('── ⑧ プロセス停止後の復旧 ──');
            $port('ok', $out1);
            $m7 = $mk($broken, $out2, ['leave_sent' => '1st']);  // 1stは送信済みのまま
            $check('E-33', '落ちる前は送信済み（SENT）',
                   (string) \DB::table('baganriki_ai_attempts')
                       ->where('snapshot_id', $m7['sid'])->where('role', '1st')
                       ->where('attempt_no', 0)->value('status'), $W::SENT);
            $rs = $W::resume($m7['sid'], $W::nowUs());
            $check('E-34', '後始末をした', (bool) $rs['ok'], true);
            $check('E-35', '送信済みは結果不明にする',
                   (array) ($rs['unknown'] ?? []), ['1st#0']);
            $check('E-36', '初回の送信はやり直さない', count($calls), 0);
            // ══════════════════════════════════════════════════════════
            // @ANCHOR-20261021-R122-NOTHINGTOADOPT  採るものが無い role
            // ══════════════════════════════════════════════════════════
            //   1st は結果不明（UNKNOWN_RESULT）で終わりました。
            //   この役には診断も訂正も採否も、やることが残っていません。
            //   印を待っても永久に付かない（印を付けるのは受領に成功した
            //   ときだけ）ので、「採るものが無い」ことを確定として
            //   数えます。RECEIVED のときは数えません（010の2-4）。
            $sv1st = $A::r122RoleSettled($m7['sid'], '1st');
            $check('E-37-0', '結果不明の役は「採るものが無い」で確定',
                   [$sv1st['settled'], (string) ($sv1st['by'] ?? '')],
                   [true, 'NOTHING_TO_ADOPT']);
            $p7w = $ctrl->r122PublishWhenReady($m7['sid']);
            $check('E-37-1', 'それでも 2nd の採否が未確定なら公開しない',
                   (string) ($p7w['code'] ?? ''), 'WAITING');
            $q7 = ['skip' => false, 'ok' => true, 'snapshot_id' => $m7['sid']];
            $r7b = $ctrl->r122AfterReceive($D[0], $D[1], $D[2], $D[3], $D[4], '2nd', $q7);
            $check('E-37-2', '2nd の採否が確定した',
                   (bool) ($r7b['settled']['marked'] ?? false), true);
            $p7 = $ctrl->r122PublishWhenReady($m7['sid']);
            // $check('E-37', '結果不明も終端なので公開まで進む',
            //        (string) ($p7['code'] ?? ''), 'PUBLISHED');  // 旧
            $check('E-37', '結果不明の役があっても公開まで進む',
                   in_array((string) ($p7['code'] ?? ''),
                            ['PUBLISHED', 'ALREADY'], true), true);
            $check('E-38', '片方だけなので加点しない',
                   count(array_filter((array) ($p7['candidates'] ?? []),
                       static fn($c) => ((float) ($c['bonus'] ?? 0)) > 0.0)), 0);

            // ══════════════════════════════════════════════════════════
            // @ANCHOR-20261021-R122-SENDFIRST  10月21日008のご指摘5
            // ══════════════════════════════════════════════════════════
            //   「旧キャッシュあり・初回枠なしのレースが、上限後に凍結
            //     できただけで止まらず、両AIの初回送信へ進む経路を
            //     示してください。」
            //   その経路がこれです。固定入力から、予約→送信許可→送信→
            //   受領→検証→訂正→解決→公開まで一続きで通します。
            //   初回の送信口も偽の応答に差し替えています（実AIは呼びません）。
            $this->info('── ⑧-2 固定入力から初回を送る（キャッシュ後のやり直し）──');
            //   初回は1頭欠けた応答、訂正は正しい全頭を返します（009のご指摘5）
            // ══════════════════════════════════════════════════════════
            // @ANCHOR-20261021-R122-BANDPROVE  10月21日010の5章③
            // ══════════════════════════════════════════════════════════
            //   ご指摘：
            //     「E-58eの説明は『他の帯の順位は保たれている』ですが、
            //       判定式はband_ranksの件数が1以上かを見るだけです。
            //       これでは順位変更がないことを証明しません。
            //       対象外の帯ごとに初回の配列と一致するか確認してください。」
            //
            //   そのとおりです。しかも初回（$broken）と訂正（$out1）は
            //   band_ranks が同じ中身でした。保持できていなくても
            //   気づけない試験でした。
            //   いまは、<b>訂正の側で、訂正の対象ではない帯の並びを
            //   わざと逆順にします。</b>それでも初回の並びが残ることを、
            //   帯ごとに1つずつ突き合わせて確かめます。
            //
            //   どの帯が訂正の対象かは、①で作った同じ初回応答から
            //   実際の repair_scope を取って決めます（決め打ちしません）。
            $piF  = $ctrl->r122InspectResponse($m['sid'], '1st', $W::FIRST);
            $badF = (array) \App\Http\Controllers\Api\AiController
                        ::r122BadBands($piF['repair_scope'] ?? null);
            $flipBand = null;
            foreach (['A', 'B', 'D'] as $b) {
                if (in_array($b, $badF, true)) { continue; }   // 訂正の対象の帯
                if (count((array) ($out1['band_ranks'][$b] ?? [])) >= 2) {
                    $flipBand = $b; break;
                }
            }
            $check('E-58e-0', '訂正の対象外で2頭以上いる帯がある',
                   $flipBand !== null, true);
            $out1s = $out1;
            if ($flipBand !== null) {
                $out1s['band_ranks'][$flipBand] = array_reverse(
                    array_values((array) $out1['band_ranks'][$flipBand]));
            }
            $port('ok', $broken, $out1s);
            $mf = $mk([], [], ['no_attempt' => true, 'gen0' => true]);  // 枠は作りません
            $check('E-53', '初回の枠が1つも無い状態から始める',
                   (int) \DB::table('baganriki_ai_attempts')
                       ->where('snapshot_id', $mf['sid'])->count(), 0);
            $f1 = $ctrl->r122SendFirst($mf['sid'], '1st', ['test_ignore_flags' => true]);
            $check('E-54', '1st の初回を実際に送った', (bool) $f1['sent'], true);
            $check('E-55', '1st の初回を受け取れた', (bool) $f1['ok'], true);
            $check('E-56', '1st の送信先は Anthropic', $sentTo(), 'Anthropic');
            $check('E-57', '1st の初回の枠が RECEIVED になった',
                   (string) \DB::table('baganriki_ai_attempts')
                       ->where('snapshot_id', $mf['sid'])->where('role', '1st')
                       ->where('attempt_no', 0)->value('status'), $W::RECEIVED);
            $check('E-58', '検証→訂正まで進んだ（訂正の枠ができている）',
                   (int) \DB::table('baganriki_ai_attempts')
                       ->where('snapshot_id', $mf['sid'])->where('role', '1st')
                       ->where('attempt_no', 1)->count(), 1);
            $port('ok', $out2);
            $f2 = $ctrl->r122SendFirst($mf['sid'], '2nd', ['test_ignore_flags' => true]);
            $check('E-59', '2nd の初回も送った', (bool) $f2['sent'], true);
            $check('E-60', '2nd の送信先は DeepSeek', $sentTo(), 'DeepSeek');
            $check('E-61', '2nd の初回の枠も RECEIVED',
                   (string) \DB::table('baganriki_ai_attempts')
                       ->where('snapshot_id', $mf['sid'])->where('role', '2nd')
                       ->where('attempt_no', 0)->value('status'), $W::RECEIVED);
            //   初回を受け取った時点で r122AfterReceive が中で公開まで
            //   進めるので、ここで呼び直すと「同じ intent は作り直さない」
            //   という契約どおり ALREADY が返ります。どちらも公開済みです。
            // ══════════════════════════════════════════════════════════
            // @ANCHOR-20261021-R122-FIXPROVE  10月21日009のご指摘5
            // ══════════════════════════════════════════════════════════
            //   【足りませんでした】E-58 は「訂正の枠ができた」だけを
            //   見ていました。<b>その訂正で欠落馬が直ったか</b>は
            //   見ていません。初回にも訂正にも同じ応答を返していたので、
            //   直りようがありませんでした。
            //   いまは role と 初回／訂正 で返す応答を分けます。
            $accF = $ctrl->r122AcceptedHorses($mf['sid'], '1st');
            $check('E-58b', '訂正を当てている',
                   (string) ($accF['code'] ?? ''), 'FIX_APPLIED');
            $check('E-58c', '欠落していた馬が戻って全16頭そろう',
                   count((array) ($accF['merged'] ?? [])), 16);
            $check('E-58d', '救済したのは欠落していた馬',
                   in_array($goneNo, array_map('intval',
                       (array) ($accF['rescued'] ?? [])), true), true);
            $usedF = $ctrl->r122ResponseUsed($mf['sid'], '1st', $accF);
            // ══════════════════════════════════════════════════════════
            // @ANCHOR-20261021-R122-BANDPROVE  帯ごとに1つずつ突き合わせます
            // ══════════════════════════════════════════════════════════
            // $check('E-58e', '他の帯の順位は保たれている',
            //        count((array) ($usedF['band_ranks'] ?? [])) >= 1, true);  // 旧
            $firstRanks = [];
            foreach ((array) ($broken['band_ranks'] ?? []) as $b => $v) {
                $firstRanks[(string) $b] = array_map('intval', array_values((array) $v));
            }
            $keptAll = true; $keptDetail = [];
            foreach (['A', 'B', 'D'] as $b) {
                if (in_array($b, $badF, true)) { continue; }      // 訂正の対象
                if (!isset($firstRanks[$b]) || $firstRanks[$b] === []) { continue; }
                $got = array_map('intval',
                           array_values((array) ($usedF['band_ranks'][$b] ?? [])));
                $same = ($got === $firstRanks[$b]);
                $keptDetail[$b] = $same ? '一致' : '変わっています';
                if (!$same) { $keptAll = false; }
            }
            $check('E-58e', '訂正の対象外の帯は初回の並びと1つずつ一致する',
                   $keptAll, true);
            $check('E-58e-1', '突き合わせた帯が1つ以上ある',
                   count($keptDetail) >= 1, true);
            $check('E-58e-2', 'わざと逆順にした帯でも初回の並びが残る',
                   array_map('intval',
                       array_values((array) ($usedF['band_ranks'][$flipBand] ?? []))),
                   (array) ($firstRanks[$flipBand] ?? []));
            $check('E-58e-3', 'その帯の順位の出どころは「初回の保持」',
                   (string) ($usedF['rank_source'][$flipBand] ?? ''),
                   'PREVIOUS_KEPT');
            $check('E-58e-4', '訂正が違う並びを返していたことを記録に残す',
                   count(array_filter((array) ($usedF['rank_notes'] ?? []),
                       static fn($t) => strpos((string) $t,
                           '訂正は違う順位を返していました') !== false)) >= 1, true);
            $this->info('     対象外の帯の突き合わせ : '
                . json_encode($keptDetail, JSON_UNESCAPED_UNICODE)
                . ' ／ わざと逆順にした帯 : ' . (string) $flipBand
                . ' ／ 訂正の対象の帯 : '
                . (($badF === []) ? 'なし' : implode('・', $badF)));

            $pf = $ctrl->r122PublishWhenReady($mf['sid']);
            $check('E-62', '両roleがそろって公開まで進んでいる',
                   in_array((string) ($pf['code'] ?? ''),
                            ['PUBLISHED', 'ALREADY'], true), true);
            $check('E-62b', '公開が1件できている',
                   ((string) \DB::table('baganriki_live_states')
                       ->where('snapshot_id', $mf['sid'])
                       ->value('latest_publication_id')) !== '', true);
            $check('E-62c', '公開の版が1になっている',
                   (int) \DB::table('baganriki_live_states')
                       ->where('snapshot_id', $mf['sid'])
                       ->value('publication_revision'), 1);
            $f3 = $ctrl->r122SendFirst($mf['sid'], '1st', ['test_ignore_flags' => true]);
            $check('E-63', '枠があるなら二度と送らない', (bool) $f3['sent'], false);
            $check('E-64', 'その理由が読める', (string) $f3['code'], 'ALREADY');
            //   本番の既定（旗が下りている）では、そもそも送りません。
            $check('E-65', '旗が下りていれば送らない（本番の既定）',
                   (string) $ctrl->r122SendFirst($mf['sid'], '2nd')['code'], 'FLAG_OFF');

            // 本番の呼出元が旗の検査を外していないこと（ソースで見ます）
            $srcF = (string) file_get_contents(
                (new \ReflectionClass(\App\Http\Controllers\Api\AiController::class))
                    ->getFileName());
            $check('E-66', '本番の呼出元は旗の検査を外していない',
                   substr_count($srcF, "test_ignore_flags"), 2);
            $check('E-67', '巡回から初回送信を呼んでいる',
                   strpos($srcF, '$this->r122SendFirst($sid, $role)') !== false, true);
            $check('E-68', 'キャッシュ後の後始末からも初回送信を呼んでいる',
                   strpos($srcF, '$self->r122SendFirst((int) $sn->id, $rl)') !== false,
                   true);

            // ── ⑨ やり直しの巡回は初回の送信をしない ─────────────────────
            $this->info('── ⑨ やり直しの巡回（--r122-sweep と同じ関数）──');
            //   巡回は「訂正の判定」と「公開」だけをやり直します。
            //   初回の送信はしません（二重に予想を呼ばないため）。
            //   枠の段が off のときは拾う対象を見ないので、
            //   <b>関数の中身そのもの</b>を見て確かめます。
            $srcW = (string) file_get_contents(
                (new \ReflectionClass(\App\Http\Controllers\Api\AiController::class))
                    ->getFileName());
            $rmW  = new \ReflectionMethod(
                \App\Http\Controllers\Api\AiController::class, 'r122SweepPending');
            $linesW = explode("\n", $srcW);
            $bodyW  = implode("\n", array_slice($linesW, $rmW->getStartLine() - 1,
                $rmW->getEndLine() - $rmW->getStartLine() + 1));
            // ══════════════════════════════════════════════════════════
            // @ANCHOR-20261021-R122-SWEEPDESC  10月21日009のご指摘5
            // ══════════════════════════════════════════════════════════
            //   【説明が現物と逆でした】
            //   「巡回に初回の送信は入っていない」と書いていましたが、
            //   10月21日008への対応で <b>r122SendFirst を巡回に入れました。</b>
            //   実際の判定式は r122SendFix の出現回数が1であることだけなので、
            //   初回の送信があっても合格してしまいます。
            //   説明と判定式の両方を、現物に合わせて直します。
            $check('E-39', '巡回は訂正を1回だけ呼ぶ',
                   substr_count($bodyW, '$this->r122SendFix('), 1);
            $check('E-39b', '巡回は初回の送信も呼ぶ（枠が無いときだけ）',
                   substr_count($bodyW, '$this->r122SendFirst('), 1);
            $check('E-39c', '初回を呼ぶのは枠が1つも無いときに限る',
                   strpos($bodyW, 'if ($any === null) {') !== false, true);
            $check('E-40', '巡回は本文の組み立てを呼ばない',
                   strpos($bodyW, 'r122AssembleSend') === false, true);
            $check('E-41', '巡回は公開を呼ぶ',
                   substr_count($bodyW, '$this->r122PublishWhenReady('), 1);
            $port('ok', $out1);        // ここから数え直します（⑧-2の送信を持ち越さない）
            $sw = $ctrl->r122SweepPending();
            $check('E-42', '旗が下りていれば何も拾わない',
                   (int) ($sw['scanned'] ?? -1), 0);
            $check('E-43', '巡回しても送信口は呼ばれない', count($calls), 0);

            // ── ⑩ 上限前は固定しない／上限後は断らない ────────────────────
            $this->info('── ⑩ 上限前呼出し→上限後凍結 ──');
            $future = date('Y-m-d', time() + 86400 * 400);   // ずっと先の日付
            \DB::table('t_horse_odds_finder_races')->insert([
                'date' => $future, 'kaisuu' => '9', 'basho' => '99',
                'day' => '9', 'race' => 9, 'start_time' => '23:50:00',
            ]);
            $rf1 = $ctrl->r122ResumeFreeze($future, '9', '99', '9', 9);
            $check('E-44', '情報上限より前は固定しない',
                   (string) ($rf1['code'] ?? ''), 'TOO_EARLY');
            //   @ANCHOR-20261021-R122-SENDFIRST  この試験の凍結入力も
            //   race_id に 99 を含むので、like では当たってしまいます。
            //   仮レースの race_id だけを名指しで見ます。
            $futureId = \App\Http\Controllers\Api\AiController::r122RaceId(
                $future, '9', '99', '9', 9);
            $check('E-45', 'そのとき凍結入力を作らない',
                   (int) \DB::table('baganriki_snapshots')
                       ->where('race_id', $futureId)->count(), 0);
            \DB::table('t_horse_odds_finder_races')
              ->where('date', $future)->where('basho', '99')
              ->update(['date' => date('Y-m-d', time() - 86400)]);
            $past = date('Y-m-d', time() - 86400);
            $rf2 = $ctrl->r122ResumeFreeze($past, '9', '99', '9', 9);
            $check('E-46', '上限を過ぎれば TOO_EARLY では止めない',
                   (string) ($rf2['code'] ?? '') !== 'TOO_EARLY', true);
            $this->line('      上限後のやり直しの結果 : '
                      . (string) ($rf2['code'] ?? '')
                      . '（このレースには実オッズが無いので、'
                      . 'ここで止まるのが正しい動きです）');

        } catch (\Throwable $e) {
            $ok = false;
            $this->error('  × 例外 ' . $e->getMessage()
                       . ' @ ' . $e->getFile() . ':' . $e->getLine());
        } finally {
            \DB::rollBack();
        }

        $this->line('');
        $this->line('  ロールバック後  snapshot '
            . (int) \DB::table('baganriki_snapshots')->where('run_id', 'WT')->count()
            . '／attempts '
            . (int) \DB::table('baganriki_ai_attempts')
                    ->whereIn('snapshot_id', function ($q) {
                        $q->select('id')->from('baganriki_snapshots')
                          ->where('run_id', 'WT');
                    })->count()
            . '／仮レース '
            . (int) \DB::table('t_horse_odds_finder_races')
                    ->where('basho', '99')->count());
        $this->line('');
        $this->line('  判定件数 : ' . ($pass + $fail) . ' 件');
        $this->line('  合格     : ' . $pass . ' 件');
        $this->line('  不合格   : ' . $fail . ' 件');
        $this->line('');
        if ($fail === 0 && $ok) {
            $this->info('════════════════════════════════════════════════════════');
            $this->info(' 送信口を差し替えた実経路が契約どおり動きました'
                      . '（実AI 0回・DBへ残る書き込み0件）');
            $this->info('════════════════════════════════════════════════════════');
        } else {
            $this->error('════════════════════════════════════════════════════════');
            $this->error(' 不合格があります');
            $this->error('════════════════════════════════════════════════════════');
        }
    }
