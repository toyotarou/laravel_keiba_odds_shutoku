
    /**
     * ═══════════════════════════════════════════════════════════════════════
     * @ANCHOR-20261020-R122-PAST  本番の経路で作った入力をSchemaに当てる
     * ═══════════════════════════════════════════════════════════════════════
     * ■ 何をするか
     *   実レース1本について、<b>本番と同じ r122GatherContext</b> で
     *   INPUT_JSON を組み立て、
     *     ・input_schema.json
     *     ・source_registry_schema.json
     *   の両方に当てます。coverage 7区分の状態も並べます。
     *
     *   取得監査の実時刻は過去レースには無いので、仮置き（assume_audit）で
     *   組み立てます。<b>これは形とSchemaを確かめる試験です。</b>
     *   仮置きで作った入力は PRODUCTION として保存できません（別の試験で確認済み）。
     *
     * 読むだけです。DBへは1行も書きません。
     */
    private function runR122ProdInput(string $root): void
    {
        self::r122Autoload();
        $sDir = rtrim($root, '/') . '/schemas';
        $date = (string) ($this->option('date') ?: '2026-10-18');

        $this->info('════════════════════════════════════════════════════════');
        $this->info(' r12.2 本番の経路で作った入力を Schema に当てる');
        $this->info('════════════════════════════════════════════════════════');
        $this->line('  実行時刻 : ' . date('c'));
        $this->line('  Schema   : ' . $sDir);
        $this->warn('  ※ 取得監査は仮置きです（形とSchemaを見る試験です）');
        $this->line('');

        $inSchemaPath  = $sDir . '/input_schema.json';
        $regSchemaPath = $sDir . '/source_registry_schema.json';
        foreach ([$inSchemaPath, $regSchemaPath] as $f) {
            if (!is_file($f)) { $this->error('  × ' . $f . ' がありません'); return; }
        }
        $inSchema  = json_decode((string) file_get_contents($inSchemaPath), true);
        $regSchema = json_decode((string) file_get_contents($regSchemaPath), true);

        $races = \DB::table('t_horse_odds_finder_races')->where('date', $date)
                   ->orderBy('basho')->orderBy('race')->limit(3)->get();
        if ($races->isEmpty()) { $this->error('  × ' . $date . ' のレースがありません'); return; }

        $pass = 0; $fail = 0;
        foreach ($races as $r) {
            $raceId = \App\Http\Controllers\Api\AiController::r122RaceId(
                $r->date, $r->kaisuu, $r->basho, $r->day, $r->race);
            $st = (string) $r->start_time;
            if (strlen($st) === 5) { $st .= ':00'; }
            $anchorUs = \App\Http\Controllers\Api\BaganrikiTime::us($r->date . 'T' . $st . '+09:00');
            if ($anchorUs === null) { continue; }

            $g = \App\Http\Controllers\Api\AiController::r122GatherContext(
                $r->date, $r->kaisuu, $r->basho, $r->day, $r->race,
                ['assume_audit' => true]);
            if (!($g['ok'] ?? false)) {
                $this->line(sprintf('  － %-20s 入力を作れません: %s %s',
                    $raceId, (string) ($g['code'] ?? ''), (string) ($g['reason'] ?? '')));
                continue;
            }
            $asm = \App\Http\Controllers\Api\BaganrikiPrompt::assemble($g['ctx'], '1st');
            if (!($asm['ok'] ?? false)) {
                $this->line(sprintf('  － %-20s 組み立てられません: %s %s',
                    $raceId, (string) ($asm['code'] ?? ''), (string) ($asm['reason'] ?? '')));
                continue;
            }
            $in = $asm['input'];

            // 過去走を外した場合の大きさも出します（応答時間の見当をつけるため）
            $keep = [getenv('BAGANRIKI_PAST_RUNS_MAX'),
                     $_ENV['BAGANRIKI_PAST_RUNS_MAX'] ?? null,
                     $_SERVER['BAGANRIKI_PAST_RUNS_MAX'] ?? null];
            $noPastBytes = null;
            try {
                putenv('BAGANRIKI_PAST_RUNS_MAX=0');
                $_ENV['BAGANRIKI_PAST_RUNS_MAX'] = '0';
                $_SERVER['BAGANRIKI_PAST_RUNS_MAX'] = '0';
                $g0 = \App\Http\Controllers\Api\AiController::r122GatherContext(
                    $r->date, $r->kaisuu, $r->basho, $r->day, $r->race,
                    ['assume_audit' => true]);
                if ($g0['ok'] ?? false) {
                    $a0 = \App\Http\Controllers\Api\BaganrikiPrompt::assemble($g0['ctx'], '1st');
                    if ($a0['ok'] ?? false) { $noPastBytes = strlen((string) $a0['user']); }
                }
            } finally {
                if ($keep[0] === false) { putenv('BAGANRIKI_PAST_RUNS_MAX'); }
                else { putenv('BAGANRIKI_PAST_RUNS_MAX=' . $keep[0]); }
                if ($keep[1] === null) { unset($_ENV['BAGANRIKI_PAST_RUNS_MAX']); }
                else { $_ENV['BAGANRIKI_PAST_RUNS_MAX'] = $keep[1]; }
                if ($keep[2] === null) { unset($_SERVER['BAGANRIKI_PAST_RUNS_MAX']); }
                else { $_SERVER['BAGANRIKI_PAST_RUNS_MAX'] = $keep[2]; }
            }

            $this->info('── ' . $raceId . ' ──');
            $bytes = strlen((string) $asm['user']);
            $this->line(sprintf('    N=%d  source_registry %d 件  送信文 %s バイト',
                (int) $in['N'], count((array) $in['source_registry']),
                number_format($bytes)));
            if ($noPastBytes !== null) {
                $this->line(sprintf('    過去走を外すと %s バイト（過去走の分 %s バイト・%+.1f%%）',
                    number_format($noPastBytes),
                    number_format($bytes - $noPastBytes),
                    ($noPastBytes > 0) ? (($bytes - $noPastBytes) / $noPastBytes * 100) : 0));
            }
            $this->line('    直近何走まで : '
                . \App\Http\Controllers\Api\AiController::r122PastRunsMax() . ' 走'
                . '／OPI・推定確定オッズ : '
                . (\App\Http\Controllers\Api\AiController::r122MarketPriorEnabled()
                    ? '載せる' : '載せない'));

            // ── ① 入力Schema ──────────────────────────────────────────
            $e1 = self::jsCheck($in, $inSchema, '');
            if ($e1 === []) {
                $pass++; $this->line('    ○ input_schema に適合');
            } else {
                $fail++;
                $this->error('    × input_schema 違反 ' . count($e1) . ' 件');
                foreach (array_slice($e1, 0, 5) as $m) { $this->error('        ' . $m); }
            }

            // ── ② source_registry Schema ─────────────────────────────
            $e2 = self::jsCheck((array) $in['source_registry'], $regSchema, '');
            if ($e2 === []) {
                $pass++; $this->line('    ○ source_registry_schema に適合');
            } else {
                $fail++;
                $this->error('    × source_registry_schema 違反 ' . count($e2) . ' 件');
                foreach (array_slice($e2, 0, 8) as $m) { $this->error('        ' . $m); }
            }

            // ── ③ coverage 7区分 ─────────────────────────────────────
            $cov = (array) $in['coverage'];
            $inc = 0;
            foreach (\App\Http\Controllers\Api\BaganrikiPrompt::COVERAGE_KEYS as $k) {
                $c = (array) ($cov[$k] ?? []);
                $s = (string) ($c['status'] ?? '?');
                if ($s === 'INCLUDED') {
                    $inc++;
                    $this->line(sprintf('    ○ %-22s INCLUDED  出典 %d 件',
                        $k, count((array) ($c['source_refs'] ?? []))));
                } else {
                    $this->line(sprintf('    － %-22s %s  %s', $k, $s,
                        mb_strimwidth((string) ($c['reason'] ?? ''), 0, 54, '…')));
                }
            }
            $this->line('    coverage INCLUDED ' . $inc . ' / 7 区分');

            // ── ④ 過去走が実際に入っているか ───────────────────────────
            $pastRefs = 0; $pastHorses = [];
            foreach ((array) $in['source_registry'] as $ref => $e) {
                if (strpos((string) $ref, '_past_') === false) { continue; }
                $pastRefs++;
                foreach ((array) ($e['horse_nos'] ?? []) as $n) { $pastHorses[(int) $n] = true; }
            }
            // OPI と推定確定オッズが入っているか
            $mkRefs = 0;
            foreach ((array) $in['source_registry'] as $ref => $e) {
                $r2 = (string) $ref;
                if (strpos($r2, 'popavg_') === 0 || strpos($r2, 'fukuavg_') === 0
                    || strpos($r2, 'corr_') === 0
                    || strpos($r2, '_opi') !== false
                    || strpos($r2, '_estimated_final_') !== false) {
                    $mkRefs++;
                }
            }
            if ($mkRefs > 0) {
                $pass++;
                $this->line('    ○ OPI・推定確定オッズ ' . $mkRefs . ' 件');
            } else {
                $this->line('    － OPI・推定確定オッズは載っていません（理由は上の coverage）');
            }

            if ($pastRefs > 0) {
                $pass++;
                $this->line('    ○ 過去走 ' . $pastRefs . ' 件／'
                          . count($pastHorses) . ' 頭ぶん');
            } else {
                $this->line('    － 過去走は載っていません（理由は上の coverage）');
            }
            foreach ((array) ($g['notes'] ?? []) as $n) {
                if (is_string($n) && strpos($n, '過去走') !== false) {
                    $this->line('      ' . $n);
                }
            }
            $this->line('');
        }

        $this->line('  合格 : ' . $pass . ' 件');
        $this->line('  不合格 : ' . $fail . ' 件');
        $this->line('');
        $this->info('════════════════════════════════════════════════════════');
        $this->info(($fail === 0)
            ? ' 本番の経路で作った入力は Schema に適合しました（書き込み0件）'
            : ' Schema に合わない箇所があります。上の × をご確認ください');
        $this->info('════════════════════════════════════════════════════════');
    }
