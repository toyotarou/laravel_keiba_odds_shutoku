
    /**
     * ═══════════════════════════════════════════════════════════════════════
     * @ANCHOR-20261020-R122-COVERAGE  オッズ以外の材料を source_registry へ載せる
     * ═══════════════════════════════════════════════════════════════════════
     * 根拠：server_contract_r12.2.txt 3章「利用できるデータを黙って捨てない」
     *       10月20日004 のご判断2（A案）／21_追加材料7区分の接続表
     *
     * ■ 今回つなぐ3区分
     *   gap_history          断層（21→6分前の単勝の増減率）
     *   recovery_statistics  その増減率帯と人気帯の回収率
     *   similar_statistics   人気順位×頭数帯の過去類似成績
     *
     *   この3つを先につなぐ理由は、<b>算出時刻の列を持っているから</b>です。
     *   過去走とOPIは取得・算出時刻の列が無いので、時刻の出どころが決まるまで
     *   載せません（接続表のA/B/Cのご判断待ち）。作り話の時刻で埋めません。
     *
     * ■ 由来の残し方
     *   ・1頭ごとの増減率は <b>DERIVED</b> にし、
     *     parents にその馬の21分前と6分前の登録IDをそのまま入れます。
     *     どの元値から出したかが1件ずつ辿れます。
     *   ・帯別の統計は <b>DERIVED</b> で、parents には集計元のテーブル名を入れます。
     *     元になった18万行の履歴は入力に載せないので、個々の行IDではなく
     *     テーブル名を由来として書きます。ここは正直に書いておきます。
     *   ・computed_at は、集計テーブルが持っている実際の算出時刻です。
     *
     * ■ 情報上限
     *   増減率は21分前と6分前の値だけから出します。3分前・発走時は使いません。
     *   帯別統計の computed_at が input_freeze_at より後なら載せません。
     *
     * @param array $ctx        これまでに組み立てた文脈（registry・audit を含む）
     * @param array $frozenRank 馬番 => 凍結人気
     * @param array $cells      [馬番][スロット][項目] => 元の十進数文字列
     * @param int   $freezeUs   情報上限（マイクロ秒）
     * @return array ['registry'=>追加分, 'coverage'=>区分ごとの状態]
     */
    public static function r122ExtraRegistry(array $ctx, array $frozenRank,
                                             array $cells, ?int $freezeUs): array
    {
        // @ANCHOR-20261020-R122-DERIVEDAT  1回の組み立てで1つの計算時刻にします
        $buildAt = BaganrikiPrompt::rfc3339(BaganrikiWorker::nowUs());
        $raceId = (string) ($ctx['race_id'] ?? '');
        $add    = [];
        $refs   = ['gap_history' => [], 'recovery_statistics' => [],
                   'similar_statistics' => []];
        // @ANCHOR-20261020-R122-COVERAGE  載せなかった理由を取り違えないための控え
        //   「集計が無い」と「情報上限より後に算出された」は別の話です。
        $late   = ['recovery_statistics' => null, 'similar_statistics' => null];
        // @ANCHOR-20261020-R122-COVWIN  集計期間が対象レースの開催日を含んでいた控え
        //   OPI・推定確定オッズと同じ判定を、列を持っている回収率にも当てます。
        //   （過去類似成績の表には集計期間の列がありません。無い列は作りません）
        $covWin = ['recovery_statistics' => null];
        $freezeAt = ($freezeUs === null) ? null : BaganrikiPrompt::rfc3339($freezeUs);
        $N      = count($frozenRank);
        if ($N < 1) {
            return ['registry' => [], 'coverage' => []];
        }
        // @ANCHOR-20261020-R122-COVWIN  対象レースの開催日（race_id の先頭8桁）
        $day = '';
        if (preg_match('/^(\d{4})(\d{2})(\d{2})-/', $raceId, $mm) === 1) {
            $day = $mm[1] . '-' . $mm[2] . '-' . $mm[3];
        }
        $audit6 = $ctx['audit']['6'] ?? ($ctx['audit'][6] ?? null);
        $obs6   = is_array($audit6) ? ($audit6['response_received_at'] ?? null) : null;
        $av6    = is_array($audit6) ? ($audit6['available_at'] ?? null) : null;
        if ($obs6 === null || $av6 === null) {
            return ['registry' => [], 'coverage' => []];
        }

        // ── ① 1頭ごとの増減率（21分前 → 6分前の単勝）──────────────────
        $gapPct = [];
        foreach (array_keys($frozenRank) as $no) {
            $o21 = $cells[$no][21]['win_odds'] ?? null;
            $o6  = $cells[$no][6]['win_odds']  ?? null;
            if ($o21 === null || $o6 === null) continue;
            // @ANCHOR-20261020-R122-DEC  小数5桁以上でも落としません
            //   【旧】BaganrikiSnapshot::scale は小数4桁までで、
            //     1.23456 のオッズだと増減率を作れずに捨てていました。
            $a = AiController::r122DecOrNull($o21);
            $b = AiController::r122DecOrNull($o6);
            if ($a === null || $b === null || $a <= 0) continue;
            $pct = round((($b - $a) / $a) * 100, 4);
            $gapPct[$no] = $pct;
            $ref = 'h' . $no . '_odds_gap_pct_21_6';
            $add[$ref] = [
                'source_ref'           => $ref,
                'race_id'              => $raceId,
                'value'                => $pct,
                'scope'                => 'HORSE',
                'horse_nos'            => [(int) $no],
                'applicable_horse_nos' => [],
                'field'                => 'odds_gap_pct_21_6',
                'unit'                 => 'percent',
                'slot_offset'          => 6,
                'observed_at'          => $obs6,
                'available_at'         => $av6,
                // @ANCHOR-20261020-R122-DERIVEDAT  006のご指摘4-2
                //   【旧】今回こちらで出した増減率なのに、原オッズの
                //     利用可能時刻を computed_at に入れていました。
                'computed_at'          => $buildAt,
                'source_kind'          => 'DERIVED',
                'parents'              => ['h' . $no . '_win_odds_21', 'h' . $no . '_win_odds_6'],
                'formula_id'           => 'ODDS_GAP_PCT_21_TO_6',
                'formula_version'      => 'v1',
                'dependency_key'       => 'h' . $no . '_odds_gap_pct',
                'dependency_role'      => 'CONTEXT',
            ];
            $refs['gap_history'][] = $ref;
        }

        // ── ② 増減率帯 × 人気帯 の回収率 ────────────────────────────────
        if ($gapPct !== [] && \Schema::hasTable('t_horse_odds_finder_odds_gap_recovery')) {
            foreach (\DB::table('t_horse_odds_finder_odds_gap_recovery')->get() as $r) {
                $gmin = (float) $r->gap_min; $gmax = (float) $r->gap_max;
                $pmin = (int) $r->popularity_min; $pmax = (int) $r->popularity_max;
                $hit = [];
                foreach ($gapPct as $no => $pct) {
                    $pop = (int) $frozenRank[$no];
                    if ($pct < $gmin || $pct > $gmax) continue;
                    if ($pop < $pmin || $pop > $pmax) continue;
                    $hit[] = (int) $no;
                }
                if ($hit === []) continue;
                sort($hit);
                // @ANCHOR-20261020-R122-COVWIN  当日を含む集計でその日のレースを評価しない
                //   この表は start_date / end_date を持っているので、
                //   OPI・推定確定オッズとまったく同じ判定を当てます。
                $ed = substr(str_replace('/', '-', (string) ($r->end_date ?? '')), 0, 10);
                if ($day !== '' && $ed !== '' && strcmp($ed, $day) >= 0) {
                    if ($covWin['recovery_statistics'] === null) {
                        $covWin['recovery_statistics'] = $ed;
                    }
                    continue;
                }
                $c = self::r122DbTime($r->computed_at);
                if ($c === null) continue;
                if ($freezeUs !== null) {
                    $cu = BaganrikiTime::us($c);
                    if ($cu === null || $cu > $freezeUs) {
                        // 情報上限より後に算出された集計は載せません。
                        // 「集計が無い」のではないので、理由を分けて残します。
                        if ($late['recovery_statistics'] === null
                            || strcmp($c, (string) $late['recovery_statistics']) < 0) {
                            $late['recovery_statistics'] = $c;
                        }
                        continue;
                    }
                }
                // @ANCHOR-20261020-R122-COVWIN  使った集計の期間も残します（OPIと同じ）
                $sd = substr(str_replace('/', '-', (string) ($r->start_date ?? '')), 0, 10);
                foreach (['start_date' => $sd, 'end_date' => $ed] as $wf => $wv) {
                    if ($wv === '') { continue; }
                    $wref = 'gaprec_' . $wf;
                    if (isset($add[$wref])) { continue; }
                    $add[$wref] = [
                        'source_ref'           => $wref,
                        'race_id'              => $raceId,
                        'value'                => $wv,
                        'scope'                => 'RACE',
                        'horse_nos'            => [],
                        'applicable_horse_nos' => [],
                        'field'                => 'gaprec_' . $wf,
                        'unit'                 => 'date',
                        'slot_offset'          => null,
                        'observed_at'          => $c,
                        'available_at'         => $c,
                        'computed_at'          => null,
                        'source_kind'          => 'OBSERVED',
                        'parents'              => [],
                        'formula_id'           => null,
                        'formula_version'      => null,
                        'dependency_key'       => 'gaprec_' . $wf,
                        'dependency_role'      => 'CONTEXT',
                    ];
                    $refs['recovery_statistics'][] = $wref;
                }
                $key = self::r122Slug((string) $r->gap_band) . '_' . $pmin . '_' . $pmax;
                foreach (['recovery_rate' => 'percent', 'win_rate' => 'percent',
                          'sample_count'  => 'races'] as $f => $unit) {
                    $v = $r->{$f};
                    if ($v === null) continue;
                    $ref = 'gaprec_' . $key . '_' . $f;
                    $add[$ref] = [
                        'source_ref'           => $ref,
                        'race_id'              => $raceId,
                        'value'                => ($f === 'sample_count') ? (int) $v : (float) $v,
                        'scope'                => 'COHORT',
                        'horse_nos'            => [],
                        'applicable_horse_nos' => $hit,
                        'field'                => 'gap_recovery_' . $f,
                        'unit'                 => $unit,
                        'slot_offset'          => null,
                        'observed_at'          => $c,
                        'available_at'         => $c,
                        'computed_at'          => $c,
                        'source_kind'          => 'DERIVED',
                        'parents'              => ['t_horse_odds_finder_race_result_history'],
                        'formula_id'           => 'SummaryOddsGapRecoveryRate',
                        'formula_version'      => 'v1',
                        'dependency_key'       => 'gaprec_' . $key,
                        'dependency_role'      => 'CONTEXT',
                    ];
                    $refs['recovery_statistics'][] = $ref;
                }
            }
        }

        // ── ③ 人気順位 × 頭数帯 の過去類似成績 ──────────────────────────
        //   頭数帯は small=8以下／medium=9〜13／large=14以上
        if (\Schema::hasTable('t_horse_odds_finder_similar_race_stats')) {
            $band = ($N <= 8) ? 'small' : (($N <= 13) ? 'medium' : 'large');
            foreach (\DB::table('t_horse_odds_finder_similar_race_stats')
                        ->where('horse_count_band', $band)->get() as $r) {
                $pop = (int) $r->popularity_rank;
                $hit = [];
                foreach ($frozenRank as $no => $p) {
                    if ((int) $p === $pop) $hit[] = (int) $no;
                }
                if ($hit === []) continue;
                sort($hit);
                $c = self::r122DbTime($r->updated_at);
                if ($c === null) continue;
                if ($freezeUs !== null) {
                    $cu = BaganrikiTime::us($c);
                    if ($cu === null || $cu > $freezeUs) {
                        if ($late['similar_statistics'] === null
                            || strcmp($c, (string) $late['similar_statistics']) < 0) {
                            $late['similar_statistics'] = $c;
                        }
                        continue;
                    }
                }
                foreach (['top3_rate' => 'rate', 'top5_rate' => 'rate',
                          'avg_finishing_position' => 'position',
                          'outside_rate' => 'rate', 'sample_count' => 'races',
                          'reliability' => 'label'] as $f => $unit) {
                    $v = $r->{$f};
                    if ($v === null) continue;
                    $ref = 'similar_' . $band . '_p' . $pop . '_' . $f;
                    $val = ($f === 'sample_count') ? (int) $v
                         : (($f === 'reliability') ? (string) $v : (float) $v);
                    $add[$ref] = [
                        'source_ref'           => $ref,
                        'race_id'              => $raceId,
                        'value'                => $val,
                        'scope'                => 'COHORT',
                        'horse_nos'            => [],
                        'applicable_horse_nos' => $hit,
                        'field'                => 'similar_' . $f,
                        'unit'                 => $unit,
                        'slot_offset'          => null,
                        'observed_at'          => $c,
                        'available_at'         => $c,
                        'computed_at'          => $c,
                        'source_kind'          => 'DERIVED',
                        'parents'              => ['t_horse_odds_finder_race_result_history'],
                        'formula_id'           => 'SummarySimilarRaceStats',
                        'formula_version'      => 'v1',
                        'dependency_key'       => 'similar_' . $band . '_p' . $pop,
                        'dependency_role'      => 'CONTEXT',
                    ];
                    $refs['similar_statistics'][] = $ref;
                }
            }
        }

        // ── coverage ──────────────────────────────────────────────────
        $cov = [];
        $why = [
            'gap_history'         => '21→6分前の単勝の増減率を1頭ずつ出せませんでした',
            'recovery_statistics' => '当てはまる増減率帯・人気帯の集計がありませんでした',
            'similar_statistics'  => 'この頭数帯・人気順位の集計がありませんでした',
        ];
        foreach ($refs as $k => $list) {
            $list = array_values(array_unique($list));
            sort($list, SORT_STRING);
            if ($list !== []) {
                $cov[$k] = ['status' => 'INCLUDED', 'source_refs' => $list];
                continue;
            }
            // 「集計が無い」のか「情報上限より後に算出された」のか
            // 「当日を含む集計だった」のかを分けます。
            $reason = $why[$k];
            if (!empty($covWin[$k])) {
                $reason = '集計期間の終わり（' . $covWin[$k] . '）が対象レースの開催日（'
                        . $day . '）以降です。当日を含む集計で'
                        . 'その日のレースを評価しないためです。';
            } elseif (!empty($late[$k])) {
                $reason = 'この集計は情報上限より後に算出されたものしかありません'
                        . '（いちばん早い算出時刻 ' . $late[$k]
                        . '／情報上限 ' . ($freezeAt ?? '不明') . '）。'
                        . '過去のレースを後から作った集計で評価しないためです。';
            }
            $cov[$k] = ['status' => 'UNAVAILABLE', 'reason' => $reason];
        }
        return ['registry' => $add, 'coverage' => $cov];
    }

    /**
     * @ANCHOR-20261020-R122-MICRO  DBの DATETIME が入っているタイムゾーン
     *   10月20日005のご指摘2-1「DB列の保存タイムゾーンを明示」への対応です。
     *   環境の既定タイムゾーンに依存させません。
     */
    public const DB_TIMEZONE = 'Asia/Tokyo';

    /**
     * @ANCHOR-20261020-R122-COVERAGE  DBの日時をRFC3339（JST）へ
     *
     * ══════════════════════════════════════════════════════════════
     * @ANCHOR-20261020-R122-MICRO  10月20日006のご指摘4-3（本物の不具合）
     * ══════════════════════════════════════════════════════════════
     *   【旧】strtotime は<b>秒の整数</b>しか返しません。
     *     それに1,000,000を掛けていたので、
     *     `09:34:30.000001` が `09:34:30` へ切り捨てられ、
     *     情報上限 `09:34:30` を<b>超えているのに上限内として通り得ました。</b>
     *     取得側の r122DbRfc3339 は小数秒を保っていたのに、
     *     追加材料側のこの関数だけが落としていました。
     *   【いま】小数秒を取り出して、マイクロ秒まで保ちます。
     *     保存タイムゾーンは日本時間（DBのDATETIMEはJSTで入っています）。
     */
    public static function r122DbTime($v): ?string
    {
        if ($v === null) { return null; }
        $s = trim((string) $v);
        if ($s === '' || strncmp($s, '0000', 4) === 0) { return null; }
        // DBの DATETIME / DATE をそのまま読みます（区切りは空白でもTでも可）
        $re = '/^(\d{4})-(\d{2})-(\d{2})'
            . '(?:[ T](\d{2}):(\d{2}):(\d{2})(?:\.(\d{1,6})\d*)?)?$/';
        if (preg_match($re, $s, $m) !== 1) { return null; }
        $frac = isset($m[7]) ? (int) str_pad($m[7], 6, '0') : 0;
        $d = \DateTimeImmutable::createFromFormat(
            'Y-m-d H:i:s',
            $m[1] . '-' . $m[2] . '-' . $m[3] . ' '
            . ($m[4] ?? '00') . ':' . ($m[5] ?? '00') . ':' . ($m[6] ?? '00'),
            new \DateTimeZone(self::DB_TIMEZONE));
        if ($d === false) { return null; }
        // 繰上がり（2026-02-30 など）を受け取りません
        if ($d->format('Y-m-d') !== $m[1] . '-' . $m[2] . '-' . $m[3]) { return null; }
        return BaganrikiPrompt::rfc3339($d->getTimestamp() * 1000000 + $frac);
    }


    /** @ANCHOR-20261020-R122-COVERAGE  帯の名前を source_ref に使える形へ */
    public static function r122Slug(string $s): string
    {
        $map = ['30%以上下落' => 'dn30', '20〜30%下落' => 'dn20', '10〜20%下落' => 'dn10',
                '5〜10%下落' => 'dn05', '±5%以内' => 'flat', '5〜10%上昇' => 'up05',
                '10〜20%上昇' => 'up10', '20〜30%上昇' => 'up20', '30%以上上昇' => 'up30'];
        if (isset($map[$s])) return $map[$s];
        $h = substr(hash('sha256', $s), 0, 8);
        return 'band' . $h;
    }
