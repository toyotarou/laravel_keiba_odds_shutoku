
    /**
     * ═══════════════════════════════════════════════════════════════════════
     * @ANCHOR-20261020-R122-FP  元値の指紋（固定対象を一意に表す方法）
     * ═══════════════════════════════════════════════════════════════════════
     * 根拠：10月20日005のご指摘8
     *
     * ■ 前の方法で何が足りなかったか
     *   ・NULL を文字列 '\N' で表していたので、実値の '\N' と区別できない。
     *   ・区切り 0x1F を値の中でエスケープしていないので、値が区切りを
     *     含むと列の境目が曖昧になる。
     *   ・型を書いていない。主キー id を行のhashに入れていない。
     *   ・固定した主キー集合を指定しておらず、件数・最小・最大・XOR では
     *     同じ行集合だと言い切れない（[1,2,5,8] と [1,3,4,8] は全部同じ）。
     *   ・一貫した読取（スナップショット）の指定がない。
     *
     * ■ この実装
     *   ・<b>長さ付きの表現</b>にします。各列を
     *       N:            NULL
     *       V<バイト数>:<値>  実値
     *     と書くので、NULL と空文字と区切り入りの値が全部区別できます。
     *   ・行の先頭に主キー id を同じ書き方で入れます。
     *   ・<b>主キー順に全行を流し</b>、SHA-256 を逐次計算します（連結しません）。
     *   ・主キーの並びだけを別に SHA-256 して、<b>固定した集合そのもの</b>も
     *     一意に表します。件数・最小・最大では足りないというご指摘に対応します。
     *   ・<b>一貫した読取</b>のため、REPEATABLE READ のトランザクションを
     *     開いて読み、最後にロールバックします（読むだけ・書き込み0件）。
     *   ・結果はファイルへ書き出し、次回はそのファイルと比べられます。
     *
     * 使い方
     *   --r122-fingerprint            いまの指紋を出す
     *   --r122-fingerprint=<path>     そのファイルと突き合わせる
     */
    private function runR122Fingerprint($arg): void
    {
        $targets = [
            't_horse_odds_finder_odds' =>
                ['date','kaisuu','basho','day','race','num','minutes_before_start',
                 'odds','fuku_min','fuku_max'],
            't_horse_odds_finder_horses' =>
                ['date','kaisuu','basho','day','race','waku','num','name'],
            't_horse_odds_finder_races' =>
                ['date','kaisuu','basho','day','race','start_time','num_horses'],
            't_horse_odds_finder_race_results' =>
                ['date','kaisuu','basho','day','race','num','result'],
        ];
        $this->info('════════════════════════════════════════════════════════');
        $this->info(' r12.2 元値の指紋（読むだけ・DBへの書き込み0件）');
        $this->info('════════════════════════════════════════════════════════');
        $this->line('  実行時刻 : ' . date('c'));
        $this->line('  方法     : 列ごとに「N」または「V<バイト数>:<値>」で書き、');
        $this->line('             主キー id を先頭に入れて、主キー順に SHA-256 を逐次計算');
        $this->line('  読取     : REPEATABLE READ の一貫した読取（最後にロールバック）');
        $this->line('');

        $now = [];
        // ══════════════════════════════════════════════════════════════
        // @ANCHOR-20261020-R122-FPFAIL  10月20日006のご指摘6-5
        // ══════════════════════════════════════════════════════════════
        //   【旧】表が無いときや読取で落ちたときに警告だけ出して先へ進み、
        //     最後に「すべて一致しました」と言える経路がありました。
        //   <b>必須の対象が欠けた比較は、合格にしてはいけません。</b>
        //   欠けと失敗を数えて、1件でもあれば不合格にします。
        $fpMissing = []; $fpError = [];
        \DB::statement('SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ');
        \DB::beginTransaction();
        try {
            foreach ($targets as $table => $cols) {
                if (!\Schema::hasTable($table)) {
                    // @ANCHOR-20261020-R122-FPFAIL  欠けは不合格です
                    $fpMissing[] = $table;
                    $this->error('  × ' . $table . ' がありません（必須の対象です）');
                    continue;
                }
                $rowH = hash_init('sha256');
                $keyH = hash_init('sha256');
                $n = 0; $min = null; $max = null;
                \DB::table($table)->orderBy('id')->select(array_merge(['id'], $cols))
                   ->chunk(2000, function ($rows) use (&$rowH, &$keyH, &$n, &$min, &$max, $cols) {
                        foreach ($rows as $r) {
                            $id = (int) $r->id;
                            if ($min === null || $id < $min) $min = $id;
                            if ($max === null || $id > $max) $max = $id;
                            $line = self::fpField((string) $id);
                            foreach ($cols as $c) {
                                $line .= self::fpField($r->{$c} ?? null);
                            }
                            hash_update($rowH, $line . "\n");
                            hash_update($keyH, $id . "\n");
                            $n++;
                        }
                   });
                $now[$table] = [
                    'rows' => $n, 'id_min' => $min, 'id_max' => $max,
                    'rows_sha256' => hash_final($rowH),
                    'keys_sha256' => hash_final($keyH),
                    'columns' => array_merge(['id'], $cols),
                ];
                $this->line(sprintf('  %-34s %6d行  id %s〜%s', $table, $n,
                    $min ?? '-', $max ?? '-'));
                $this->line('      行の指紋 ' . $now[$table]['rows_sha256']);
                $this->line('      主キーの指紋 ' . $now[$table]['keys_sha256']);
            }
        } catch (\Throwable $e) {
            // @ANCHOR-20261020-R122-FPFAIL  読取の失敗も不合格です
            $fpError[] = $e->getMessage();
            $this->error('  × 読み取りに失敗しました: ' . $e->getMessage());
        } finally {
            \DB::rollBack();
        }
        if ($fpMissing !== [] || $fpError !== []) {
            $this->line('');
            $this->error('  指紋を出せなかった対象があります'
                       . '（欠け ' . count($fpMissing) . ' 件／失敗 '
                       . count($fpError) . ' 件）。この比較は合格にしません。');
        }
        $this->line('');

        // ── 前回のファイルと突き合わせ ────────────────────────────────
        $path = is_string($arg) ? $arg : '';
        if ($path !== '' && is_file($path)) {
            $prev = json_decode((string) file_get_contents($path), true);
            $this->info('── 前回との突き合わせ ──');
            $this->line('  前回のファイル: ' . $path);
            $this->line('  前回の実行時刻: ' . (string) ($prev['generated_at'] ?? '不明'));
            $ng = 0;
            // 前回にあって今回に無い対象も見ます
            foreach (array_keys((array) ($prev['tables'] ?? [])) as $t0) {
                if (!array_key_exists($t0, $now)) {
                    $ng++;
                    $this->error('  × ' . $t0 . ' が今回ありません');
                }
            }
            foreach ($now as $t => $v) {
                $p = $prev['tables'][$t] ?? null;
                if ($p === null) {
                    // @ANCHOR-20261020-R122-FPFAIL  前回に無い対象も不合格です
                    $ng++;
                    $this->error('  × ' . $t . ' が前回のファイルにありません'
                               . '（比べられないので合格にしません）');
                    continue;
                }
                $same = ($p['rows_sha256'] ?? '') === $v['rows_sha256']
                     && ($p['keys_sha256'] ?? '') === $v['keys_sha256']
                     && ($p['rows'] ?? -1) === $v['rows'];
                if ($same) {
                    $this->line(sprintf('  ○ %-34s 変わっていません（%d行）', $t, $v['rows']));
                } else {
                    $ng++;
                    $this->error(sprintf('  × %-34s 変わっています', $t));
                    $this->error(sprintf('      行数 %s → %s', $p['rows'] ?? '?', $v['rows']));
                    $this->error('      行の指紋 ' . substr((string) ($p['rows_sha256'] ?? ''), 0, 16)
                               . ' → ' . substr($v['rows_sha256'], 0, 16));
                    if (($p['keys_sha256'] ?? '') !== $v['keys_sha256']) {
                        $this->error('      主キーの集合が変わっています（行の増減）');
                    } else {
                        $this->error('      主キーの集合は同じです（既存の値の書き換え）');
                    }
                }
            }
            $this->line('');
            $ng += count($fpMissing) + count($fpError);
            if ($ng === 0) {
                $this->info('  すべて一致しました（元値は動いていません）');
            } else {
                $this->error('  一致を確認できなかった対象が ' . $ng . ' 件あります');
            }
            $this->line('');
        } elseif ($path !== '') {
            $this->warn('  突き合わせ先が見つかりません: ' . $path);
        }

        $out = storage_path('logs/r122_fingerprint_' . date('Ymd_His') . '.json');
        file_put_contents($out, (string) json_encode([
            'generated_at' => date('c'),
            'method'       => 'per-row-length-prefixed-sha256-ordered-by-pk-v1',
            'note'         => '列は N（NULL）か V<バイト数>:<値>。行の先頭に主キー id。'
                            . '主キー順に逐次SHA-256。主キーの並びも別にSHA-256。',
            'tables'       => $now,
        ], JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT));
        $this->info('  書き出しました: ' . $out);
        $this->line('  次回はこれを渡して突き合わせます:');
        $this->line('    php artisan keiba:ai-analysis-compensate --r122-fingerprint=' . $out);
    }

    /**
     * @ANCHOR-20261020-R122-FP  1つの列を、取り違えようのない形にします
     *   NULL            → 'N|'
     *   それ以外        → 'V<バイト数>:<値>|'
     * 長さを前に置くので、値が区切りや改行を含んでいても境目が決まります。
     */
    private static function fpField($v): string
    {
        if ($v === null) { return 'N|'; }
        $s = (string) $v;
        return 'V' . strlen($s) . ':' . $s . '|';
    }
