# -*- coding: utf-8 -*-
"""
@ANCHOR-20261020-R122-AUDIT  ImportKeibaOdds.php への追補
お願い②（A案・ご承認済み）の取得監査を記録します。
既存の列・元値・保存処理には一切触れません。新しいテーブルへINSERTするだけです。
"""
import io, sys, os, hashlib
p = sys.argv[1]
src = io.open(p, encoding='utf-8').read()
orig = src
if '@ANCHOR-20261020-R122-AUDIT' in src:
    print('すでに当たっています（何もしません）: ' + p); sys.exit(0)

def rep(old, new, why, count=1):
    global src
    n = src.count(old)
    assert n == count, '%s: 見つかった数 %d（期待 %d）' % (why, n, count)
    src = src.replace(old, new, count)

# ── 1) クラス説明に追記 ────────────────────────────────────────────────
rep(""" *   【ブロック 10】有意変動（2位以上）の WebPush 通知
 *""",
    """ *   【ブロック 10】有意変動（2位以上）の WebPush 通知
 *   【ブロック 11】r12.2 取得監査の記録（@ANCHOR-20261020-R122-AUDIT）
 *
 * 【r12.2 取得監査について】
 *   server_contract_r12.2.txt 4章・8章／詳細設計書 4.3 のお願い②（A案）です。
 *   「いつ要求を出し、いつ受け取り、いつ読めるようになったか」の実時刻と、
 *   受け取った原ペイロードそのものを baganriki_acquisition_batches へ残します。
 *   既存の t_horse_odds_finder_odds_get_timing の get_datetime は
 *   「保存が終わった時刻」なので、要求開始・受信完了の代わりには使えません。
 *
 *   <b>既存の列・元値・保存処理には一切触れていません。</b>
 *   新しいテーブルへ1行 INSERT するだけで、失敗しても本番は止めません
 *   （記録できなかったことをログに残し、そのバッチは採用しません）。
 *
 *   止め方: .env に BAGANRIKI_R122_AUDIT=0 を入れると記録しません。
 *   テーブルが無い環境では自動的に何もしません。
 *""",
    'クラス説明')

# ── 2) 要求開始の時刻を控える ─────────────────────────────────────────
rep("""            $raceStart = microtime(true);
            $command   = 'timeout 120 ' . $nodeBin . ' ' . escapeshellarg($script)""",
    """            $raceStart = microtime(true);
            // @ANCHOR-20261020-R122-AUDIT  要求を出す直前の実時刻
            $r122ReqStartedAt = self::r122Now();
            $command   = 'timeout 120 ' . $nodeBin . ' ' . escapeshellarg($script)""",
    '要求開始の時刻')

# ── 3) 受信完了の時刻を控える ─────────────────────────────────────────
rep("""            $fetchMs  = round((microtime(true) - $raceStart) * 1000);
            $fetchSec = number_format($fetchMs / 1000, 2);

            if (!$odds) {
                $this->error("  [単複] オッズ取得失敗。このレースをスキップします。({$fetchSec}秒 / {$fetchMs}ms)");
                $this->error("  Node.js 出力: " . $output);
                continue;
            }""",
    """            $fetchMs  = round((microtime(true) - $raceStart) * 1000);
            $fetchSec = number_format($fetchMs / 1000, 2);
            // @ANCHOR-20261020-R122-AUDIT  受信し終えた実時刻（= observed_at）
            $r122RespReceivedAt = self::r122Now();

            if (!$odds) {
                $this->error("  [単複] オッズ取得失敗。このレースをスキップします。({$fetchSec}秒 / {$fetchMs}ms)");
                $this->error("  Node.js 出力: " . $output);
                // ─────────────────────────────────────────────────────
                // @ANCHOR-20261020-R122-AUDIT  取れなかったことも残します
                //   採用しない監査行（committed=0・REJECTED）として入れます。
                //   「記録が無い」と「取れなかった」を区別するためです。
                // ─────────────────────────────────────────────────────
                $this->r122RecordBatch($race, $diff, [
                    'request_started_at'   => $r122ReqStartedAt,
                    'response_received_at' => $r122RespReceivedAt,
                    'available_at'         => null,
                    'raw_payload'          => (string) $output,
                    'validation_result'    => 'REJECTED',
                    'rejection_reason'     => 'オッズ取得に失敗（Node.jsの出力をJSONとして読めない）',
                    'committed'            => 0,
                ]);
                continue;
            }""",
    '受信完了の時刻と失敗時の記録')

# ── 4) 保存完了後に採用の監査行を入れる ───────────────────────────────
rep("""            $totalMs  = round((microtime(true) - $raceStart) * 1000);
            $totalSec = number_format($totalMs / 1000, 2);
            $this->info("  [単複] DB保存完了 → {$saved} 頭分 (合計 {$totalSec}秒 / {$totalMs}ms)");
            $totalInserted += $saved;""",
    """            $totalMs  = round((microtime(true) - $raceStart) * 1000);
            $totalSec = number_format($totalMs / 1000, 2);
            $this->info("  [単複] DB保存完了 → {$saved} 頭分 (合計 {$totalSec}秒 / {$totalMs}ms)");
            $totalInserted += $saved;

            // ─────────────────────────────────────────────────────────────
            // 【ブロック 11】r12.2 取得監査の記録
            // @ANCHOR-20261020-R122-AUDIT
            //   available_at は「保存が終わって読めると確かめた実時刻」です。
            //   予定時刻で埋めません。ここは保存トランザクションの<b>後</b>です。
            // ─────────────────────────────────────────────────────────────
            $this->r122RecordBatch($race, $diff, [
                'request_started_at'   => $r122ReqStartedAt,
                'response_received_at' => $r122RespReceivedAt,
                'available_at'         => self::r122Now(),
                'raw_payload'          => (string) $output,
                'validation_result'    => 'ADOPTED',
                'rejection_reason'     => null,
                'committed'            => 1,
            ]);""",
    '採用の監査行')

# ── 5) メソッドを足す（クラスの閉じ括弧の直前）────────────────────────
methods = io.open(os.path.join(os.path.dirname(os.path.abspath(__file__)),
                               'methods_audit.php'), encoding='utf-8').read()
tail = """        $this->info('');
        $this->info('========== keiba:importOdds 終了 ' . date('Y-m-d H:i:s') . ' ==========');
        $this->info('');
    }

}"""
rep(tail, """        $this->info('');
        $this->info('========== keiba:importOdds 終了 ' . date('Y-m-d H:i:s') . ' ==========');
        $this->info('');
    }
""" + methods + """
}""", 'メソッドの追加')

io.open(p, 'w', encoding='utf-8').write(src)
print('当てました: %s  %d行 -> %d行  md5=%s'
      % (p, orig.count('\n')+1, src.count('\n')+1,
         hashlib.md5(src.encode('utf-8')).hexdigest()))
