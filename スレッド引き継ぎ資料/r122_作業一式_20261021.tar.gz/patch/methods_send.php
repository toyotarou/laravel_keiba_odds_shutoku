
    /**
     * ═══════════════════════════════════════════════════════════════════════
     * @ANCHOR-20261020-R122-PROMPT  r12.2 の race_id（YYYYMMDD-回-場-日-R）
     * ═══════════════════════════════════════════════════════════════════════
     */
    public static function r122RaceId($date, $kaisuu, $basho, $day, $race): string
    {
        return str_replace('-', '', (string) $date) . '-' . (string) $kaisuu . '-'
             . (string) $basho . '-' . (string) $day . '-' . (int) $race;
    }

    /**
     * ═══════════════════════════════════════════════════════════════════════
     * @ANCHOR-20261020-R122-PROMPT  INPUT_JSON の材料を正本から集める
     * ═══════════════════════════════════════════════════════════════════════
     * 根拠：server_contract_r12.2.txt 2章〜5章・11章／詳細設計書 4章・14章
     *
     * ■ 作り話をしないための決まり
     *   ・投票締切 sales_close_at の正本がDBに無いので、既定では作りません
     *     （契約11.2）。$override['sales_close_at'] に正本を渡したときだけ
     *     時刻契約を作ります。発走時刻で代用しません。
     *   ・取得監査の実時刻（request_started_at / response_received_at /
     *     available_at / batch_id / raw_payload）も既定ではDBにありません。
     *     baganriki_acquisition_batches に確定行があればそれを使います。
     *     無ければ作りません。$override['assume_audit'] を立てたときだけ、
     *     「予定時刻で埋めた仮の監査」で組み立て、結果に assumed を立てます
     *     （本番送信には使いません。送信文の形を確かめる用です）。
     *
     * ■ 取消の扱い
     *   このDBは取消馬のオッズ列へ「取消」「除外」の文字を入れています。
     *   情報上限（6分前+30秒）までの時点に印があるものを正式取消とし、
     *   凍結集合から外します。3分前・発走時だけに印があるものは
     *   凍結後の取消なので、凍結集合には残し cancelled_post として返します。
     *
     * @return array ['ok','ctx','code','reason','race_id','notes']
     */
    public static function r122GatherContext($date, $kaisuu, $basho, $day, $race,
                                             array $override = []): array
    {
        $raceId = self::r122RaceId($date, $kaisuu, $basho, $day, $race);
        $ng = static fn(string $code, string $why) =>
            ['ok' => false, 'ctx' => null, 'code' => $code, 'reason' => $why,
             'race_id' => $raceId, 'notes' => []];
        $notes = [];

        // ── 正本のレース情報（発走時刻） ───────────────────────────────
        $r = \DB::table('t_horse_odds_finder_races')
                ->where('date', $date)->where('kaisuu', $kaisuu)
                ->where('basho', $basho)->where('day', $day)
                ->where('race', (int) $race)->first();
        if ($r === null)  return $ng('ENTRY_MISSING', 'このレースは正本にありません');
        $st = trim((string) ($r->start_time ?? ''));
        if (!preg_match('/^\d{1,2}:\d{2}(?::\d{2})?$/', $st)) {
            return $ng('TIME_CONTRACT_INVALID', '発走時刻を読めません: ' . $st);
        }
        if (strlen($st) === 5) $st .= ':00';
        if (strlen($st) === 7) $st = '0' . $st;
        $anchorAt = (string) $date . 'T' . $st . '+09:00';
        $anchorUs = BaganrikiTime::us($anchorAt);
        if ($anchorUs === null) {
            return $ng('TIME_CONTRACT_INVALID', '発走時刻を組み立てられません: ' . $anchorAt);
        }

        // ── 出馬表（正本の馬番） ──────────────────────────────────────
        $entryNums = [];
        // @ANCHOR-20261020-R122-PAST  馬名も取ります（過去走を引くため）
        $entryNames = [];
        foreach (\DB::table('t_horse_odds_finder_horses')
                    ->where('date', $date)->where('kaisuu', $kaisuu)
                    ->where('basho', $basho)->where('day', $day)
                    ->where('race', (int) $race)->get(['num', 'name']) as $h) {
            $n = (int) $h->num;
            if ($n > 0) {
                $entryNums[$n] = true;
                $nm = trim((string) ($h->name ?? ''));
                if ($nm !== '') { $entryNames[$n] = $nm; }
            }
        }
        if ($entryNums === []) {
            return $ng('ENTRY_MISSING', '出馬表の馬番がありません（契約2章で必須）');
        }
        ksort($entryNums);
        $entryNums = array_keys($entryNums);

        // ── オッズ（信号に使う6時点＋取消の見張り2時点） ───────────────
        $first = \App\Constants\Constants::ODDS_DB_FIRST;
        $last  = \App\Constants\Constants::ODDS_DB_LAST;
        $slots = BaganrikiTime::INPUT_SLOTS;                    // 21,18,15,12,9,6
        $watch = BaganrikiTime::WATCH_SLOTS;                    // 3,0
        $read  = array_merge($slots, [3, $last, $first]);

        $cells = [];          // [馬番][スロット][フィールド] => 元の文字列
        $cancelPre = [];      // 情報上限までに取消の印があった馬番
        $cancelPost = [];     // 3分前・発走時だけに印があった馬番
        foreach (\DB::table('t_horse_odds_finder_odds')
                    ->where('date', $date)->where('kaisuu', $kaisuu)
                    ->where('basho', $basho)->where('day', $day)
                    ->where('race', (int) $race)
                    ->whereIn('minutes_before_start', $read)
                    ->get(['num', 'minutes_before_start', 'odds', 'fuku_min', 'fuku_max'])
                 as $o) {
            $n = (int) $o->num;
            $t = (int) $o->minutes_before_start;
            $raw = trim((string) $o->odds);
            if ($raw === '取消' || $raw === '除外') {
                if (in_array($t, $slots, true))      $cancelPre[$n]  = true;
                elseif ($t === 3 || $t === $last)    $cancelPost[$n] = true;
                continue;
            }
            if (!in_array($t, $slots, true)) continue;          // 将来のオッズは混ぜない
            if (BaganrikiAcquisition::usableDecimal($o->odds)) {
                $cells[$n][$t]['win_odds'] = trim((string) $o->odds);
            }
            if (BaganrikiAcquisition::usableDecimal($o->fuku_min)) {
                $cells[$n][$t]['place_min'] = trim((string) $o->fuku_min);
            }
            if (BaganrikiAcquisition::usableDecimal($o->fuku_max)) {
                $cells[$n][$t]['place_max'] = trim((string) $o->fuku_max);
            }
        }
        $cancelled = array_keys($cancelPre);
        sort($cancelled);
        $cancelledPost = array_values(array_diff(array_keys($cancelPost), $cancelled));
        sort($cancelledPost);

        // ── 取得監査（実時刻）────────────────────────────────────────
        // ══════════════════════════════════════════════════════════════
        // @ANCHOR-20261020-R122-ACQFIX  10月20日005のご指摘2（3件とも本物）
        // ══════════════════════════════════════════════════════════════
        // 2-1 DBの日時を RFC3339 へ直していませんでした。
        //     DBは「2026-10-18 15:04:00.123456」で保存します。
        //     BaganrikiTime::us は T区切りとタイムゾーンを必須にするので、
        //     そのまま渡すと実際の監査行が必ず TIME_UNREADABLE で落ちます。
        //     マイクロ秒を保ったまま RFC3339（+09:00）へ変換します。
        // 2-2 input_freeze_at を採用判定へ渡していませんでした。
        //     acceptBatch はこのキーを必須で読みます。
        //     正本の発走時刻から出した情報上限を渡し、
        //     バッチが自己申告する予定時刻が正本と一致するかも検査します。
        // 2-3 採用バッチの原値ではなく、オッズ表の共通の値を使っていました。
        //     採用した batch_id の raw_payload を厳密に読み、
        //     SHA-256 を再計算して payload_hash と照合し、
        //     <b>そのバッチの値だけ</b>を入力に使います。
        //     別のバッチの馬や値が混ざらないようにします。
        $assumeAudit = (bool) ($override['assume_audit'] ?? false);
        $freezeUs    = BaganrikiTime::inputFreeze($anchorUs);
        $freezeAt    = BaganrikiPrompt::rfc3339($freezeUs);
        $audit  = null;
        $batchCells = [];     // 採用バッチの原値 [馬番][スロット][項目]
        $batchCancel = [];    // 採用バッチの中の取消 [馬番] => [スロット]
        if (\Schema::hasTable('baganriki_acquisition_batches')) {
            $rows = \DB::table('baganriki_acquisition_batches')
                       ->where('race_id', $raceId)->get();
            if (count($rows) > 0) {
                $bySlot = [];
                foreach ($rows as $b) {
                    $slot = (int) $b->slot;
                    if (!in_array($slot, $slots, true)) continue;   // 3分前・発走時は入力に使わない
                    $raw  = (string) ($b->raw_payload ?? '');
                    $hash = (string) ($b->payload_hash ?? '');
                    $bad  = null;
                    if ($raw === '')                                  $bad = '原ペイロードがありません';
                    elseif ($hash === '')                             $bad = 'payload_hash がありません';
                    elseif (hash('sha256', $raw) !== $hash)           $bad = '原ペイロードのSHA-256が保存hashと違います';
                    // 予定時刻は正本の発走時刻から作ったものと一致させます
                    $schAt = BaganrikiPrompt::rfc3339(BaganrikiTime::slotScheduled($anchorUs, $slot));
                    $decl  = self::r122DbRfc3339($b->slot_scheduled_at);
                    if ($bad === null && $decl !== null && $decl !== $schAt) {
                        $bad = '自己申告の予定時刻が正本の発走時刻から出した値と違います（'
                             . $decl . ' / ' . $schAt . '）';
                    }
                    $vals = [];
                    $cncl = [];
                    if ($bad === null) {
                        $pl = json_decode($raw, true);
                        if (!is_array($pl)) {
                            $bad = '原ペイロードをJSONとして読めません';
                        } else {
                            // ══════════════════════════════════════════
                            // @ANCHOR-20261020-R122-PAYSET  007のご指摘5
                            // ══════════════════════════════════════════
                            //   【旧】馬番をキーに $vals へ<b>上書き</b>して
                            //     いました。同じ馬番が2回出てきても気づかず、
                            //     出馬表に無い馬番も素通りし、取消の行と数値の
                            //     行が併存していても最後に読んだ方が勝ちます。
                            //     005・006で求められていた集合検査が、
                            //     この場所に入っていませんでした。
                            //   【いま】読みながら数え、<b>理由を付けて不採用に
                            //     します。</b>バッチごとに見るので、1つの
                            //     バッチが汚れても他のバッチは使えます。
                            $seenNum = []; $dupNum = []; $unkNum = []; $bothNum = [];
                            foreach ($pl as $h) {
                                $n = (int) ($h['num'] ?? 0);
                                if ($n <= 0) continue;
                                if (isset($seenNum[$n])) { $dupNum[$n] = true; }
                                $seenNum[$n] = true;
                                if ($entryNums !== [] && !in_array($n, $entryNums, true)) {
                                    $unkNum[$n] = true;
                                }
                                $t = trim((string) ($h['tan'] ?? ''));
                                if ($t === '取消' || $t === '除外') {
                                    if (isset($vals[$n])) { $bothNum[$n] = true; }
                                    $cncl[] = $n;
                                    continue;
                                }
                                if (in_array($n, $cncl, true)) { $bothNum[$n] = true; }
                                $vals[$n] = [
                                    'win'       => BaganrikiAcquisition::usableDecimal($t) ? $t : null,
                                    'place_min' => BaganrikiAcquisition::usableDecimal($h['fuku_min'] ?? null)
                                                   ? trim((string) $h['fuku_min']) : null,
                                    'place_max' => BaganrikiAcquisition::usableDecimal($h['fuku_max'] ?? null)
                                                   ? trim((string) $h['fuku_max']) : null,
                                ];
                            }
                            $why = [];
                            if ($dupNum !== []) {
                                $why[] = '同じ馬番が2回以上あります（'
                                       . implode('・', array_keys($dupNum)) . '）';
                            }
                            if ($unkNum !== []) {
                                $why[] = '出馬表に無い馬番があります（'
                                       . implode('・', array_keys($unkNum)) . '）';
                            }
                            if ($bothNum !== []) {
                                $why[] = '取消の行と数値の行が同じ馬番で併存しています（'
                                       . implode('・', array_keys($bothNum)) . '）';
                            }
                            if ($why !== []) { $bad = implode('／', $why); }
                            $cncl = array_values(array_unique($cncl));
                        }
                    }
                    $bySlot[$slot][] = [
                        'batch_id'             => (string) $b->batch_id,
                        'payload_hash'         => $hash,
                        'slot_scheduled_at'    => $schAt,
                        'source_updated_at'    => self::r122DbRfc3339($b->source_updated_at),
                        'request_started_at'   => self::r122DbRfc3339($b->request_started_at),
                        'response_received_at' => self::r122DbRfc3339($b->response_received_at),
                        'available_at'         => self::r122DbRfc3339($b->available_at),
                        'input_freeze_at'      => $freezeAt,
                        'committed'            => ((int) $b->committed === 1) && ($bad === null),
                        'payload_ng'           => $bad,
                        'values'               => $vals,
                        'cancelled'            => $cncl,
                    ];
                }
                if ($bySlot !== []) {
                    // 6分前の全頭確認は、出馬表から「そのバッチで取消でない馬」を活動馬とします
                    $picked = [];
                    foreach ($slots as $slot) {
                        $cand = $bySlot[$slot] ?? [];
                        // ══════════════════════════════════════════════
                        // @ANCHOR-20261020-R122-CANDCANCEL  006のご指摘3-2
                        // ══════════════════════════════════════════════
                        //   【本物の不具合でした】候補バッチ<b>全件</b>の取消を
                        //   先に差し引いて活動馬を作っていました。
                        //   期限を過ぎて不採用になるバッチの取消まで効くので、
                        //   「同じバッチに全活動馬の単勝がそろうか」という
                        //   6分前の検査が<b>弱まります。</b>
                        //   例：期限内のAに16番の単勝が無く、期限外のBだけに
                        //   16番の取消がある。16番が活動馬から落ちるので、
                        //   Aが全頭確認を通ってしまいます。
                        //   時刻の条件を満たしたバッチの取消だけを使います。
                        // ══════════════════════════════════════════════
                        // @ANCHOR-20261020-R122-COMMITFIRST  007のご指摘5
                        // ══════════════════════════════════════════════
                        //   【まだ残っていました】ここは acceptBatch（時刻）
                        //   しか見ていませんでした。<b>committed を見るのは
                        //   後段の pick です。</b>そのため、
                        //     ・Aは時刻適合・commit済み。16番の単勝だけ欠落
                        //     ・Bは時刻適合・<b>未commit</b>。16番取消あり
                        //   という並びだと、Bの取消で16番が活動馬から落ち、
                        //   Aが「全頭そろった」として採用されます。
                        //   hash不一致で committed=false にした候補でも同じです。
                        //   【いま】pick と<b>同じ条件</b>を先に当てます。
                        // ══════════════════════════════════════════════
                        // @ANCHOR-20261021-R122-PERCAND  008のご指摘4
                        // ══════════════════════════════════════════════
                        //   【まだ足りませんでした】commit済み・時刻適合の
                        //   候補<b>全部</b>の取消を合算した1つの集合を、
                        //   各バッチの全頭検査に使っていました。
                        //   「採用され得る」は「全頭検査を通った」ではありません。
                        //   別の候補の取消で欠損が隠れ、取消を持たない候補が
                        //   採用され、採用判定と凍結集合が食い違います。
                        //   【いま】合算しません。基礎集合（出馬表）だけを渡し、
                        //   <b>その候補自身の取消</b>は pick の中で引きます。
                        $cancelSrc = [];
                        foreach ($cand as $cb) {
                            if ((array) $cb['cancelled'] !== []) {
                                $cancelSrc[] = (string) $cb['batch_id']
                                             . '（' . implode('・',
                                               array_map('strval', (array) $cb['cancelled']))
                                             . '）';
                            }
                        }
                        if ($cancelSrc !== []) {
                            $notes[] = $slot . '分前の全頭検査は、候補ごとに'
                                     . '<b>その候補自身の取消だけ</b>を引いて行いました'
                                     . '（取消を持つ候補 ' . implode('・', $cancelSrc) . '）';
                        }
                        $picked[$slot] = BaganrikiAcquisition::pick($slot, $cand,
                                                                    $entryNums, $anchorUs);
                        if (($picked[$slot]['status'] ?? '') === 'ADOPTED') {
                            $bt = $picked[$slot]['batch'];
                            foreach ((array) $bt['values'] as $n => $v) {
                                foreach (['win' => 'win_odds', 'place_min' => 'place_min',
                                          'place_max' => 'place_max'] as $k => $f) {
                                    if (($v[$k] ?? null) !== null) $batchCells[$n][$slot][$f] = $v[$k];
                                }
                            }
                            foreach ((array) $bt['cancelled'] as $n) $batchCancel[$n][] = $slot;
                        }
                    }
                    $audit = BaganrikiAcquisition::buildAudit($picked);
                    $notes[] = 'collection_audit と原値は、採用した監査バッチの'
                             . 'raw_payload から作りました（SHA-256照合つき）';
                }
            }
        }
        if ($audit === null) {
            if (!$assumeAudit) {
                return $ng('ACQUISITION_AUDIT_MISSING',
                    '取得監査の実時刻（batch_id・request_started_at・'
                  . 'response_received_at・available_at・raw_payload）が'
                  . '既存DBにありません。お願い②（A案）の記録を入れてから送れます');
            }
            // 仮の監査。予定時刻で埋めたことを必ず残します。
            $audit = [];
            foreach ($slots as $slot) {
                $has = false;
                foreach ($entryNums as $n) {
                    if (isset($cells[$n][$slot]['win_odds'])) { $has = true; break; }
                }
                if (!$has) {
                    $audit[(string) $slot] = ['status' => 'UNAVAILABLE',
                        'reason' => 'このスロットの単勝オッズが1頭も読めません'];
                    continue;
                }
                $sch = BaganrikiTime::slotScheduled($anchorUs, $slot);
                $audit[(string) $slot] = [
                    'status'               => 'ADOPTED',
                    'batch_id'             => 'ASSUMED-' . $raceId . '-' . $slot,
                    'payload_hash'         => hash('sha256',
                        BaganrikiPrompt::canonical(['race_id' => $raceId, 'slot' => $slot,
                                                    'cells' => $cells]) ?? ''),
                    'slot_scheduled_at'    => BaganrikiPrompt::rfc3339($sch),
                    'source_updated_at'    => null,
                    'request_started_at'   => BaganrikiPrompt::rfc3339($sch),
                    'response_received_at' => BaganrikiPrompt::rfc3339($sch),
                    'available_at'         => BaganrikiPrompt::rfc3339($sch),
                ];
            }
            $notes[] = '【仮】collection_audit の実時刻は予定時刻で埋めました'
                     . '（本番送信には使いません）';
        } else {
            // 実監査行があるときは、採用バッチの原値だけを使います
            $cells = $batchCells;
            // ══════════════════════════════════════════════════════════
            // @ANCHOR-20261020-R122-CANCELSRC  10月20日006のご指摘3-1
            // ══════════════════════════════════════════════════════════
            //   【本物の不具合でした】数値は $batchCells へ入れ替えるのに、
            //   <b>$cancelPre は通常オッズ表のまま残していました。</b>
            //   通常表は後から上書きされるので、採用しなかったバッチや
            //   情報上限より後に書かれた取消が凍結集合へ混ざります。
            //   例：上限内の採用バッチAでは16頭が活動中。その後の期限超過
            //   バッチBで16番が取消になり通常表の6分前行が更新される。
            //   Aの数値を使っていても、B由来の取消で16番が消えていました。
            //   取消は<b>情報上限までに利用可能だった採用バッチ</b>だけで決めます。
            //   名目スロットが6だから上限内、という扱いもしません。
            $cancelPre = [];
            foreach ($batchCancel as $n => $sl) {
                if (array_intersect($sl, $slots) !== []) $cancelPre[(int) $n] = true;
            }
            $notes[] = '取消は採用した監査バッチだけから決めました'
                     . '（通常オッズ表の取消は凍結集合に入れていません）';
            $cancelled = array_keys($cancelPre);
            sort($cancelled);
            $cancelledPost = array_values(array_diff(array_keys($cancelPost), $cancelled));
            sort($cancelledPost);
        }

        // ── source_registry（原値のまま・丸めません）──────────────────
        $registry = [];
        foreach ($entryNums as $n) {
            if (in_array($n, $cancelled, true)) continue;
            foreach ($slots as $slot) {
                foreach (['win_odds', 'place_min', 'place_max'] as $f) {
                    $v = $cells[$n][$slot][$f] ?? null;
                    if ($v === null) continue;              // 欠損は入れません
                    $a = $audit[(string) $slot] ?? null;
                    if ($a === null || ($a['status'] ?? '') !== 'ADOPTED') continue;
                    // ══════════════════════════════════════════════════
                    // @ANCHOR-20261020-R122-DIGITS2  10月20日006のご指摘6-1
                    // ══════════════════════════════════════════════════
                    //   【旧】PHPの数値で正確に持てない値は<b>登録から落として
                    //     いました</b>。ご指摘のとおり、「文字列で保持した」と
                    //     言いながら、後段で捨てていたので直っていませんでした。
                    //   【いま】落としません。<b>元の十進数の文字列をそのまま
                    //     value に入れます。</b>
                    //     ・source_registry Schema の value は
                    //       ["string","number","boolean","null"] なので、
                    //       文字列のままでも適合します（Schemaは変えていません）。
                    //     ・信号の計算は BaganrikiPrompt::horsesForSignals() が
                    //       文字列をそのまま受け取り、多倍長整数のたすき掛けで
                    //       比べます。floatを通らないので桁は落ちません。
                    //     ・数値で持てたものは今までどおり数値で入れます
                    //       （送信文のバイト列を変えないため）。
                    $nv = self::r122NumValue($v);
                    if (!is_int($nv) && !is_float($nv)) {
                        // 元の十進数の形だけは確かめます（契約9章・最大128桁）。
                        //   形が違うものは作り話になるので入れません。
                        if (!preg_match('/^-?\d{1,128}(?:\.\d{1,128})?$/',
                                        trim((string) $v))) {
                            $notes[] = '馬番 ' . $n . ' の ' . $f . '（' . $slot
                                     . '分前）は十進数の形ではないので登録しません'
                                     . 'でした: ' . $v;
                            continue;
                        }
                        $nv = trim((string) $v);
                        $notes[] = '馬番 ' . $n . ' の ' . $f . '（' . $slot . '分前）は'
                                 . 'PHPの数値では丸めが起きるので、十進数の文字列'
                                 . 'のまま登録しました（桁は落としていません）: ' . $nv;
                    }
                    $ref = 'h' . $n . '_' . $f . '_' . $slot;
                    $registry[$ref] = [
                        'source_ref'           => $ref,
                        'race_id'              => $raceId,
                        'value'                => $nv,
                        'scope'                => 'HORSE',
                        'horse_nos'            => [$n],
                        'applicable_horse_nos' => [],
                        'field'                => $f,
                        'unit'                 => 'odds',
                        'slot_offset'          => $slot,
                        'observed_at'          => $a['response_received_at'],
                        'available_at'         => $a['available_at'],
                        'computed_at'          => null,
                        'source_kind'          => 'OBSERVED',
                        'parents'              => [],
                        'formula_id'           => null,
                        'formula_version'      => null,
                        'dependency_key'       => 'h' . $n . '_' . $f,
                        'dependency_role'      => 'SIGNAL',
                    ];
                }
            }
        }
        if ($registry === []) {
            return $ng('SOURCE_REGISTRY_EMPTY', '登録できる原値がありません');
        }

        // ── オッズ以外の材料（@ANCHOR-20261020-R122-COVERAGE）─────────
        //   断層・回収率統計・過去類似統計を載せます。
        //   「無いから UNAVAILABLE」ではなく「有るのに繋いでいない」状態を
        //   なくすための接続です（契約3章・10月20日004 のご判断2）。
        $extraCov = [];
        {
            $win6 = [];
            foreach ($entryNums as $n) {
                if (in_array($n, $cancelled, true)) continue;
                $v = $cells[$n][6]['win_odds'] ?? null;
                if ($v !== null) $win6[$n] = $v;
            }
            $fr = BaganrikiSnapshot::frozenRank($win6);
            if (($fr['ok'] ?? false) === true) {
                $ex = self::r122ExtraRegistry(
                    ['race_id' => $raceId, 'audit' => $audit],
                    $fr['rank'], $cells, BaganrikiTime::inputFreeze($anchorUs));
                foreach ($ex['registry'] as $k => $v) $registry[$k] = $v;
                $extraCov = $ex['coverage'];
                if ($ex['registry'] !== []) {
                    $notes[] = '追加材料を ' . count($ex['registry']) . ' 件 載せました'
                             . '（断層・回収率統計・過去類似統計）';
                }

                // ── @ANCHOR-20261020-R122-MARKET  OPI と推定確定オッズ ──
                //   式はいまの商品と同じものを使います（作り直しません）。
                //   当日を含む集計・情報上限より後に算出された集計は載せません。
                $mp = self::r122MarketPriorRegistry($raceId, (string) $date,
                          $fr['rank'], $cells,
                          BaganrikiPrompt::rfc3339(BaganrikiTime::inputFreeze($anchorUs)));
                foreach ($mp['registry'] as $k => $v) { $registry[$k] = $v; }
                $extraCov = $mp['coverage'] + $extraCov;
                if ($mp['registry'] !== []) {
                    $notes[] = 'OPI と推定確定オッズを ' . count($mp['registry'])
                             . ' 件 載せました';
                }
            }
        }

        // ── @ANCHOR-20261020-R122-PAST  過去走 ─────────────────────────
        //   取消になった馬は凍結集合に残るので、過去走も載せます。
        //   情報上限の切り方は r122PastRunsRegistry の中に書いてあります。
        $pr = self::r122PastRunsRegistry($raceId, (string) $date, $entryNames,
                  BaganrikiPrompt::rfc3339(BaganrikiTime::inputFreeze($anchorUs)));
        foreach ($pr['registry'] as $k => $v) { $registry[$k] = $v; }
        $extraCov = $pr['coverage'] + $extraCov;
        if ($pr['registry'] !== []) {
            $notes[] = '過去走を ' . count($pr['registry']) . ' 件 載せました'
                     . '（' . ($pr['horses_with_past'] ?? 0) . '頭ぶん・直近5走まで）';
        }

        // ── coverage（入れていない区分は理由を書いて UNAVAILABLE）─────
        $coverage = [
            'past_runs'  => ['status' => 'UNAVAILABLE',
                'reason' => '過去走は今回の入力へ入れていません（残作業・source_registry未整備）'],
            'OPI'        => ['status' => 'UNAVAILABLE',
                'reason' => 'OPIは今回の入力へ入れていません（残作業・source_registry未整備）'],
            'estimated_odds' => ['status' => 'UNAVAILABLE',
                'reason' => '推定確定オッズは今回の入力へ入れていません（残作業）'],
            'recovery_statistics' => ['status' => 'UNAVAILABLE',
                'reason' => '回収率統計は今回の入力へ入れていません（残作業）'],
            'similar_statistics'  => ['status' => 'UNAVAILABLE',
                'reason' => 'この頭数帯・人気順位の集計がありませんでした'],
            'legacy_qualifications' => ['status' => 'UNAVAILABLE',
                'reason' => '旧資格は r12.2 では使いません'],
            'gap_history' => ['status' => 'UNAVAILABLE',
                'reason' => '断層履歴は今回の入力へ入れていません（残作業）'],
        ];
        // 実際に載せた区分は INCLUDED と source_refs で上書きします
        if ($extraCov !== []) {
            $coverage = $extraCov + $coverage;
        }
        if (isset($override['coverage']) && is_array($override['coverage'])) {
            $coverage = $override['coverage'] + $coverage;
        }

        $ctx = [
            'race_id'         => $raceId,
            'anchor_at'       => BaganrikiPrompt::rfc3339($anchorUs),
            'sales_close_at'  => $override['sales_close_at'] ?? null,
            'registry'        => $registry,
            'audit'           => $audit,
            'coverage'        => $coverage,
            'entry_nums'      => $entryNums,
            'cancelled'       => $cancelled,
            'cancelled_post'  => $cancelledPost,
            'legacy_gap_type' => null,
            'similar'         => $override['similar'] ?? null,
        ];
        return ['ok' => true, 'ctx' => $ctx, 'code' => null, 'reason' => null,
                'race_id' => $raceId, 'notes' => $notes];
    }

    /**
     * ═══════════════════════════════════════════════════════════════════════
     * @ANCHOR-20261020-R122-ACQFIX  DBの日時を RFC3339（JST）へ
     * ═══════════════════════════════════════════════════════════════════════
     * DATETIME(6) は「2026-10-18 15:04:00.123456」の形で返ります。
     * マイクロ秒を落とさずに「2026-10-18T15:04:00.123456+09:00」へ直します。
     * 小数部が無ければ付けません。読めない値は null を返します（埋めません）。
     *
     * DBの保存タイムゾーンはサーバのローカル時刻（JST）です。
     * ここで +09:00 を付けるのは、その前提を明示するためです。
     */
    public static function r122DbRfc3339($v): ?string
    {
        if ($v === null) return null;
        $s = trim((string) $v);
        if ($s === '' || strncmp($s, '0000', 4) === 0) return null;
        if (preg_match('/^(\d{4}-\d{2}-\d{2})[ T](\d{2}:\d{2}:\d{2})(\.\d{1,6})?/', $s, $m)) {
            $frac = $m[3] ?? '';
            if ($frac === '.000000' || $frac === '.0') $frac = '';
            return $m[1] . 'T' . $m[2] . $frac . '+09:00';
        }
        return null;
    }

    /**
     * @ANCHOR-20261020-R122-PROMPT  十進数の文字列を JSON の数値へ
     *   「2.1」→ 2.1、「11」→ 11。桁を増やしたり減らしたりしません。
     *   読めないものは文字列のまま返します（作り話をしないため）。
     */
    public static function r122NumValue(string $s)
    {
        // @ANCHOR-20261020-R122-DIGITS  10月20日005のご指摘7-1
        //   契約9章は「整数・小数は最大128桁」です。
        //   【旧】'/^\d+(?:\.\d{1,4})?$/' … 小数4桁より下を黙って捨てていました。
        if (!preg_match('/^\d{1,128}(?:\.\d{1,128})?$/', $s)) return $s;
        if (strpos($s, '.') === false) {
            // PHPの整数で正確に表せる範囲だけ数値にします。
            // 超えるものは文字列のまま返し、呼び出し側が登録しません。
            return (strlen(ltrim($s, '0')) <= 18) ? (int) $s : $s;
        }
        // 小数は「floatにして文字列へ戻すと元と一致する」ものだけ数値にします。
        // 一致しないものは丸めが起きているので、数値にしません。
        //   PHPの (string)(float) は、元へ戻せる最短の表記を返します
        //   （serialize_precision=-1）。sprintf('%.17F') は
        //   2.1 を '2.10000000000000009' にしてしまうので使いません。
        $norm = rtrim(rtrim($s, '0'), '.');
        if ($norm === '') { $norm = '0'; }
        $back = (string) (float) $s;
        return ($back === $norm) ? (float) $s : $s;
    }

    /**
     * ═══════════════════════════════════════════════════════════════════════
     * @ANCHOR-20261020-R122-PROMPT  送信文（system＋INPUT_JSON）を1組にする
     * @ANCHOR-20261020-R122-ONEBUILD  10月20日007のご指摘2（最優先）
     * ═══════════════════════════════════════════════════════════════════════
     * 失敗したら ok=false を返します。<b>旧本文へ落ちません。</b>
     *
     * ■ ご指摘のとおりでした
     *   【旧】送信用と保存用で r122GatherContext を<b>2回</b>呼んでいました。
     *     ① r122AssembleSend が本文Aを作る
     *     ② r122QueueReserve が r122Freeze を呼ぶ
     *     ③ r122Freeze が<b>もう一度</b>組み立てて本文Bを保存する
     *     ④ 保存した snapshot_hash と本文Aの snapshot_hash を比べる
     *   派生の computed_at を実計算時刻へ直した（007の4-2）ので、
     *   ①と③の時刻が違えば共通hashも違います。④で SNAPSHOT_MISMATCH に
     *   なり、<b>自分で自分の送信を拒否します。</b>DBが動かなくても起きます。
     *   log/02_凍結.txt に出ていた2つのhashの食い違いを、前回
     *   「組み立てが別だから」と説明しましたが、無害ではありませんでした。
     *
     * ■ いまの形
     *   <b>組み立ては1回だけです。</b>
     *     ① 固定入力（generation=0）があるか見る
     *     ② 無ければ r122Freeze で<b>1回だけ</b>作って固定する
     *     ③ <b>保存した本文をそのまま読んで返す</b>（作り直しません）
     *   1st も 2nd も 訂正も、同じ保存物を読みます。
     *   詳細設計書7.2「両roleのJSONは保存した本文をそのまま送信する」です。
     *
     *   hash検査を外す・computed_at を予定時刻へ戻す・時刻をhash対象から
     *   外す、という回避はしていません。
     *
     * ■ 作り直す側（試験・調査用）
     *   保存を見ずに組み立てたいときは r122AssembleFresh() を呼びます。
     *   <b>送信には使いません。</b>
     */
    public function r122AssembleSend($date, $kaisuu, $basho, $day, $race,
                                     string $role, array $override = []): array
    {
        $raceId = self::r122RaceId($date, $kaisuu, $basho, $day, $race);
        $fail = static function (string $code, string $reason)
                use ($role, $raceId): array {
            return ['ok' => false, 'role' => $role, 'race_id' => $raceId,
                    'code' => $code, 'reason' => $reason,
                    'system' => null, 'system_sha256' => null, 'user' => null,
                    'user_bytes' => 0, 'input' => null, 'snapshot_hash' => null,
                    'issues' => [], 'derived' => [], 'notes' => []];
        };
        if ($role !== '1st' && $role !== '2nd') {
            return $fail('ROLE_INVALID', 'role は 1st か 2nd だけです（' . $role . '）');
        }
        if (!\Schema::hasTable('baganriki_snapshots')) {
            return $fail('TABLE_MISSING',
                'r12.2 のテーブルがありません（--r122-install で作ります）');
        }

        // ── ① 固定入力を探します（本番は generation=0 だけ）──────────
        $snap = \DB::table('baganriki_snapshots')
                  ->where('race_id', $raceId)->where('generation', 0)->first();

        // ── ② 無ければ1回だけ作って固定します ────────────────────────
        $notes = [];
        if ($snap === null) {
            $fz = $this->r122Freeze($date, $kaisuu, $basho, $day, $race,
                                    $override, 'PRODUCTION', false);
            if (!($fz['ok'] ?? false)) {
                return $fail((string) ($fz['code'] ?? 'FREEZE_FAILED'),
                             (string) ($fz['reason'] ?? '固定入力を作れません'));
            }
            $notes[] = 'このレースの固定入力をいま作りました（1回だけ）';
            $snap = \DB::table('baganriki_snapshots')
                      ->where('race_id', $raceId)->where('generation', 0)->first();
        } else {
            $notes[] = '固定済みの入力をそのまま使いました（作り直していません）';
        }
        if ($snap === null) {
            return $fail('NO_SNAPSHOT', '固定入力を読み戻せません');
        }

        // ── ③ 保存した本文をそのまま読みます ─────────────────────────
        $col  = ($role === '2nd') ? 'input_json_2nd' : 'input_json_1st';
        $user = (string) ($snap->{$col} ?? '');
        if ($user === '') {
            return $fail('NO_SAVED_INPUT',
                '固定入力に ' . $role . ' の本文が入っていません（' . $col . '）');
        }
        $in = json_decode($user, true);
        if (!is_array($in)) {
            return $fail('SAVED_INPUT_BROKEN',
                '固定入力の ' . $role . ' 本文を読めません');
        }
        // 保存本文の共通hashと、snapshot_hash 列が合っているか
        if ((string) ($in['snapshot_hash'] ?? '') !== (string) $snap->snapshot_hash) {
            return $fail('SAVED_HASH_MISMATCH',
                '保存本文の snapshot_hash と列の値が違います（保存が壊れています）');
        }

        // ── ④ system は配布された本文ファイルから（中身は決まっています）──
        $sys = BaganrikiPrompt::systemBody($role);
        if (!$sys['ok']) {
            return $fail('PROMPT_BODY_INVALID', (string) $sys['reason']);
        }

        $asm = ['ok' => true, 'role' => $role, 'race_id' => $raceId,
                'system' => $sys['body'], 'system_sha256' => $sys['sha256'],
                'user' => $user, 'user_bytes' => strlen($user),
                'input' => $in, 'snapshot_hash' => (string) $snap->snapshot_hash,
                'code' => null, 'reason' => null, 'issues' => [],
                'derived' => [], 'notes' => $notes,
                // @ANCHOR-20261020-R122-ONEBUILD  保存物をそのまま送った印
                'from_saved' => true];

        // ── ⑤ 保存物でも、送る前の検査は同じように通します ───────────
        $asm['issues'] = BaganrikiPrompt::selfCheck($asm);
        if ($asm['issues'] !== []) {
            $asm['ok']     = false;
            $asm['code']   = 'SEND_SELF_CHECK_FAILED';
            $asm['reason'] = implode('／', array_column($asm['issues'], 'reason'));
        }
        return $asm;
    }

    /**
     * @ANCHOR-20261020-R122-ONEBUILD  保存を見ずに組み立てます（試験・調査用）
     *
     *   <b>送信には使いません。</b>実レースの入力がどう組み上がるかを
     *   見るための関数です（--r122-prod-input や市場試験など）。
     *   呼ぶたびに派生の計算時刻が変わるので、2回呼べば共通hashは変わります。
     *   それが普通です。送信経路はこの関数を通りません。
     */
    public function r122AssembleFresh($date, $kaisuu, $basho, $day, $race,
                                      string $role, array $override = []): array
    {
        $g = self::r122GatherContext($date, $kaisuu, $basho, $day, $race, $override);
        if (!$g['ok']) {
            return ['ok' => false, 'role' => $role, 'race_id' => $g['race_id'],
                    'code' => $g['code'], 'reason' => $g['reason'],
                    'system' => null, 'system_sha256' => null, 'user' => null,
                    'user_bytes' => 0, 'input' => null, 'snapshot_hash' => null,
                    'issues' => [], 'derived' => [], 'notes' => $g['notes']];
        }
        $asm = BaganrikiPrompt::assemble($g['ctx'], $role);
        $asm['race_id']    = $g['race_id'];
        $asm['notes']      = $g['notes'];
        $asm['from_saved'] = false;
        return $asm;
    }
