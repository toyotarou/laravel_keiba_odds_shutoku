
    /**
     * ═══════════════════════════════════════════════════════════════════════
     * @ANCHOR-20261020-R122-PUB  統合・公開・intent・revision の通し試験
     * ═══════════════════════════════════════════════════════════════════════
     * ■ 何を確かめるか
     *   1. 両roleの検証済み応答を統合して公開できること
     *   2. 枠ぶんの候補が出て、馬番が重複しないこと
     *   3. 両AIの検証済み原公開一致を証明できたときだけ +5 が付くこと
     *   4. 同じ intent の再実行は同じ publication_id を返すこと
     *   5. 読取のあとに版が変わっていたら保存しないこと（STALE）
     *   6. 期限・全頭取消・原応答手渡しで止まること
     *   7. publication_revision が増え、公開の監査に3つの時刻が残ること
     *
     * ■ 書き込みについて
     *   全部ひとつのトランザクションで行い、最後に必ずロールバックします。
     */
    private function runR122PublishTest(string $root): void
    {
        self::r122Autoload();
        $vDir = rtrim($root, '/') . '/validation/normal';
        $this->info('════════════════════════════════════════════════════════');
        $this->info(' r12.2 統合・公開・intent・revision の通し試験');
        $this->info('════════════════════════════════════════════════════════');
        $this->line('  実行時刻 : ' . date('c'));
        $this->line('  資料     : ' . $vDir);
        $this->warn('  ※ 全部ロールバックします。DBへ残る書き込みは0件です');
        $this->line('');
        $need = ['MIXED_N16_1st_input.json', 'MIXED_N16_1st_output.json',
                 'MIXED_N16_2nd_input.json', 'MIXED_N16_2nd_output.json'];
        foreach ($need as $f) {
            if (!is_file($vDir . '/' . $f)) {
                $this->error('  × ' . $vDir . '/' . $f . ' がありません');
                return;
            }
        }

        $pass = 0; $fail = 0;
        $check = function (string $id, string $what, $got, $want) use (&$pass, &$fail) {
            $okk = ($got === $want);
            if ($okk) { $pass++; } else { $fail++; }
            $this->line(sprintf('  %s %-9s %-50s %s',
                $okk ? '○' : '×', $id, $what,
                $okk ? '' : ('得=' . var_export($got, true) . ' 期待=' . var_export($want, true))));
        };
        $rd = static fn(string $f) => json_decode(
            (string) file_get_contents($f), true);
        $j = static fn($v) => (string) json_encode($v,
            JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PRESERVE_ZERO_FRACTION);
        $BEGIN = \App\Http\Controllers\Api\BaganrikiResponse::BEGIN;
        $END   = \App\Http\Controllers\Api\BaganrikiResponse::END;

        $in1  = $rd($vDir . '/MIXED_N16_1st_input.json');
        $out1 = $rd($vDir . '/MIXED_N16_1st_output.json');
        $in2  = $rd($vDir . '/MIXED_N16_2nd_input.json');
        $out2 = $rd($vDir . '/MIXED_N16_2nd_output.json');

        $seq = 0;
        $mk = function (array $o1, array $o2, array $opt = [])
              use ($in1, $in2, $j, $BEGIN, $END, &$seq): int {
            $seq++;
            $now  = \App\Http\Controllers\Api\BaganrikiWorker::nowUs();
            $sales = $now + 3600 * 1000000;
            $nums = [];
            foreach ((array) $in1['runners'] as $r) { $nums[] = (int) $r['horse_no']; }
            $cancel = array_map('intval', (array) ($opt['cancelled'] ?? []));
            $sid = \DB::table('baganriki_snapshots')->insertGetId([
                'race_id' => 'PT-' . $seq, 'generation' => 900, 'run_id' => 'PT',
                'snapshot_hash'   => (string) $in1['snapshot_hash'],
                'input_json_1st'  => $j($in1), 'input_json_2nd' => $j($in2),
                'frozen_nums'     => $j($nums),
                'allocation_mode' => (string) $in1['allocation_mode'],
                'mode'            => (string) $in1['mode'],
                'mode_status'     => (string) $in1['mode_status'],
                'target_count'    => (int) $in1['target_count'],
                'quota_1st'       => $j($in1['quota']),
                'sales_close_at'  => \App\Http\Controllers\Api\BaganrikiWorker::toDb($sales),
                'created_at'      => \App\Http\Controllers\Api\BaganrikiWorker::toDb($now),
            ]);
            \DB::table('baganriki_live_states')->insert([
                'snapshot_id' => $sid, 'cancellations' => $j($cancel),
                'active_count' => count($nums) - count($cancel),
                'live_target_count' => (int) $in1['target_count'],
                'live_quota' => $j($in1['quota']), 'live_close' => null,
                'state_revision' => 0, 'response_revision' => 0,
                'publication_revision' => 0, 'latest_publication_id' => null,
                'updated_at' => \App\Http\Controllers\Api\BaganrikiWorker::toDb($now),
            ]);
            foreach ([['1st', $o1], ['2nd', $o2]] as $k => $pair) {
                [$role, $doc] = $pair;
                if ($doc === []) { continue; }
                $raw = $BEGIN . $j($doc) . $END;
                \DB::table('baganriki_ai_attempts')->insert([
                    'snapshot_id' => $sid, 'role' => $role, 'attempt_no' => 0,
                    'token' => hash('sha256', 'PT' . $sid . $role),
                    'status' => \App\Http\Controllers\Api\BaganrikiWorker::RECEIVED,
                    'reserved_at' => \App\Http\Controllers\Api\BaganrikiWorker::toDb($now),
                    'received_at' => \App\Http\Controllers\Api\BaganrikiWorker::toDb($now),
                    'complete' => (($opt['incomplete'] ?? null) === $role) ? 0 : 1,
                    'raw_response' => $raw,
                    'response_hash' => hash('sha256', $j($doc)),
                ]);
                // @ANCHOR-20261021-R122-BANDSCOPE  訂正の枠も作れるようにします
                $fx = $opt['fix_' . $role] ?? null;
                if (is_array($fx) && $fx !== []) {
                    $rawF = $BEGIN . $j($fx) . $END;
                    \DB::table('baganriki_ai_attempts')->insert([
                        'snapshot_id' => $sid, 'role' => $role, 'attempt_no' => 1,
                        'token' => hash('sha256', 'PTF' . $sid . $role),
                        'status' => \App\Http\Controllers\Api\BaganrikiWorker::RECEIVED,
                        'reserved_at' => \App\Http\Controllers\Api\BaganrikiWorker::toDb($now + 1000),
                        'received_at' => \App\Http\Controllers\Api\BaganrikiWorker::toDb($now + 1000),
                        'complete' => 1,
                        'raw_response' => $rawF,
                        'response_hash' => hash('sha256', $j($fx)),
                    ]);
                }
            }
            return (int) $sid;
        };

        $ok = true;
        \DB::beginTransaction();
        try {
            $ctrl = app(\App\Http\Controllers\Api\AiController::class);

            // ── ① ふつうに公開する ──────────────────────────────────
            $this->info('── ① 統合して公開する ──');
            $sid = $mk($out1, $out2);
            $p = $ctrl->r122Publish($sid);
            $check('P-01', '公開できる', $p['code'], 'PUBLISHED');
            $q = (array) $p['quota'];
            $check('P-02', '枠ぶんの候補が出る', count($p['candidates']),
                   (int) array_sum($q));
            $nos = array_column($p['candidates'], 'horse_no');
            $check('P-03', '馬番が重複しない', count(array_unique($nos)), count($nos));
            $this->line('      枠 ' . $j($q) . '  候補 ' . implode('-', $nos));
            $check('P-04', 'publication_revision が1増える',
                   (int) \DB::table('baganriki_live_states')->where('snapshot_id', $sid)
                       ->value('publication_revision'), 1);
            $check('P-05', 'latest_publication_id が入る',
                   (string) \DB::table('baganriki_live_states')->where('snapshot_id', $sid)
                       ->value('latest_publication_id'), (string) $p['publication_id']);

            // ── ② 加点（両AIの原公開一致を証明できたときだけ）──────────
            $this->info('── ② 加点は証明できたときだけ ──');
            $both = array_values(array_intersect(
                array_map('intval', (array) $out1['public_candidates']),
                array_map('intval', (array) $out2['public_candidates'])));
            $bonused = [];
            foreach ($p['candidates'] as $c) {
                if ($c['bonus'] === 5.0) { $bonused[] = (int) $c['horse_no']; }
            }
            sort($both); sort($bonused);
            $check('P-06', '両AIの原公開一致した馬に +5',
                   $bonused, array_values(array_intersect($both, $nos)));
            $check('P-07', '証明がそろっている', $p['proof'], ['1st', '2nd']);
            $pub = \DB::table('baganriki_publications')
                     ->where('publication_id', $p['publication_id'])->first();
            $pf = json_decode((string) ($pub->public_proof_hash ?? '[]'), true);
            $check('P-08', '加点を証明する応答hashを別に残す',
                   is_array($pf) ? count($pf) : 0, count($bonused));

            // ── ③ 同じ intent の再実行 ──────────────────────────────
            $this->info('── ③ 同じ intent の再実行 ──');
            $p2 = $ctrl->r122Publish($sid);
            $check('P-09', '同じ結果を返す', $p2['code'], 'ALREADY');
            $check('P-10', '同じ publication_id', (string) $p2['publication_id'],
                   (string) $p['publication_id']);
            $check('P-11', '公開は1件のまま',
                   (int) \DB::table('baganriki_publications')
                       ->where('snapshot_id', $sid)->count(), 1);

            // ── ④ 読取のあとに版が変わったら保存しない ─────────────────
            $this->info('── ④ 版が変わったら保存しない（STALE）──');
            $sid3 = $mk($out1, $out2);
            // ほかの処理がライブ状態を進めた場面を作ります
            \DB::table('baganriki_live_states')->where('snapshot_id', $sid3)
              ->update(['state_revision' => 1]);
            // 進む前に読んだ版のまま保存を試みます
            $stale = $ctrl->r122Publish($sid3,
                ['read_revisions' => ['state' => 0, 'response' => 0,
                                      'publication' => 0]]);
            $check('P-12', '古い版の計算は保存しない', $stale['code'], 'STALE');
            $check('P-13', '公開は作られない',
                   (int) \DB::table('baganriki_publications')
                       ->where('snapshot_id', $sid3)->count(), 0);
            // 版を合わせれば保存できます
            $fresh = $ctrl->r122Publish($sid3,
                ['read_revisions' => ['state' => 1, 'response' => 0,
                                      'publication' => 0]]);
            $check('P-14', '版を合わせれば公開できる', $fresh['code'], 'PUBLISHED');

            // ── ⑤ 片方が complete=false ─────────────────────────────
            $this->info('── ⑤ 片方が complete=false ──');
            $sid4 = $mk($out1, $out2, ['incomplete' => '2nd']);
            $p4 = $ctrl->r122Publish($sid4);
            $check('P-15', '片方だけでも公開できる', $p4['code'], 'PUBLISHED');
            $check('P-16', '証明は1roleだけ', $p4['proof'], ['1st']);
            $b4 = 0;
            foreach ($p4['candidates'] as $c) { if ($c['bonus'] === 5.0) { $b4++; } }
            $check('P-17', '片方だけなら加点しない', $b4, 0);

            // ══════════════════════════════════════════════════════════
            // @ANCHOR-20261020-R122-COMPLETE  未完了は選出に使わない
            // ══════════════════════════════════════════════════════════
            $this->info('── ⑤-2 未完了は候補にも順位点にも入れない ──');
            //   2nd だけで上位に来る馬を 2nd の帯の先頭へ置き、
            //   その 2nd を complete=false にします。
            //   結果が「1st だけのとき」と同じになることを見ます。
            $sidA = $mk($out1, [], []);                       // 1stだけ
            $pA   = $ctrl->r122Publish($sidA);
            $out2b = $out2;
            foreach (array_keys((array) $out2b['band_ranks']) as $bk) {
                $arr = array_map('intval', (array) $out2b['band_ranks'][$bk]);
                if (count($arr) >= 2) {
                    $arr = array_merge([array_pop($arr)], $arr);   // 末尾を先頭へ
                    $out2b['band_ranks'][$bk] = $arr;
                }
            }
            $sidB = $mk($out1, $out2b, ['incomplete' => '2nd']);
            $pB   = $ctrl->r122Publish($sidB);
            $check('P-25', '未完了側は公開を止めない', $pB['code'], 'PUBLISHED');
            $check('P-26', '候補が1st単独のときと同じ',
                   array_column((array) $pB['candidates'], 'horse_no'),
                   array_column((array) $pA['candidates'], 'horse_no'));
            $scA = array_column((array) $pA['candidates'], 'score', 'horse_no');
            $scB = array_column((array) $pB['candidates'], 'score', 'horse_no');
            ksort($scA); ksort($scB);
            $check('P-27', '順位点も1st単独のときと同じ', $scB, $scA);
            $check('P-28', '使った応答は1stだけ', $pB['proof'], ['1st']);
            $sidC = $mk($out1, $out2, ['incomplete' => 'both']);
            // どちらも未完了にします（mk は role 名一致で見るので2回に分けます）
            \DB::table('baganriki_ai_attempts')->where('snapshot_id', $sidC)
               ->update(['complete' => 0]);
            $pC = $ctrl->r122Publish($sidC);
            $check('P-29', '両方とも未完了なら候補を作らない',
                   $pC['code'], 'NO_RESPONSE');

            // ══════════════════════════════════════════════════════════
            // @ANCHOR-20261020-R122-ELIG  根拠のない馬で枠を埋めない
            // ══════════════════════════════════════════════════════════
            $this->info('── ⑤-3 全頭NO_EVIDENCEなら候補0 ──');
            $noEv = function (array $doc) {
                foreach (array_keys((array) $doc['horses']) as $i) {
                    $doc['horses'][$i]['eligibility']     = 'NO_EVIDENCE';
                    $doc['horses'][$i]['public_candidate'] = false;
                    $doc['horses'][$i]['rank_basis']      = 'NOT_RANKED';
                    $doc['horses'][$i]['family_review']   = [];
                }
                $doc['public_candidates'] = [];
                return $doc;
            };
            $sidD = $mk($noEv($out1), $noEv($out2));
            $pD = $ctrl->r122Publish($sidD);
            $check('P-30', '全頭NO_EVIDENCEでは候補を作らない',
                   in_array((string) $pD['code'], ['NO_RESPONSE', 'NO_CANDIDATE'], true), true);
            $check('P-31', '候補は0頭', count((array) ($pD['candidates'] ?? [])), 0);

            // ══════════════════════════════════════════════════════════
            // @ANCHOR-20261020-R122-USEDORDER  10月20日006のご指摘2-3
            // ══════════════════════════════════════════════════════════
            //   「馬の評価を1頭訂正しつつ対象外の帯順を入れ替える例、
            //     順位集合不正の例を、候補生成まで通してください。」
            //   直すところがある応答の帯順位は、統合に使いません。
            //   「+5を付けない」だけでは順位の正しさは担保できないためです。
            // ══════════════════════════════════════════════════════════
            // @ANCHOR-20261020-R122-BANDKEEP  10月20日007のご指摘3-1
            // ══════════════════════════════════════════════════════════
            //   【前回の試験が間違っていました】P-34〜P-38 は
            //   「1頭の採点集計が壊れたら全帯の順位を捨てる」動きを
            //   <b>合格にしていました。</b>設計書10.2の局所回復と
            //   一致しません。期待値のほうを直します。
            //   いまは帯ごとに見て、指摘の無い帯はそのまま使い、
            //   使えない帯だけを 旧順位 → 予備根拠順位 → 明示縮退 の
            //   順に落とします。
            $this->info('── ⑤-5 採点の不備で正常な帯の順位を捨てない ──');

            // ① 1頭の observed_sum だけ 999（採点集計だけの誤り）
            $badSum = function (array $doc) {
                $nums = array_keys((array) $doc['horses']);
                $t = (int) $doc['horses'][$nums[0]]['horse_no'];
                $doc['horses'][$nums[0]]['observed_sum'] = 999;
                return [$doc, $t];
            };
            [$out1G, $tgtG] = $badSum($out1);
            $sidG  = $mk($out1G, $out2);
            $accG  = $ctrl->r122AcceptedHorses($sidG, '1st');
            $usedG = $ctrl->r122ResponseUsed($sidG, '1st', $accG);
            $check('P-34', '採点集計だけの誤りでも帯の順位は残る',
                   ($usedG['band_ranks'] !== []), true);
            $check('P-35', '指摘の無い帯は応答の順位をそのまま使う',
                   ($usedG['rank_source']['A'] ?? null), 'RESPONSE');
            $check('P-36', '縮退した帯は無い', $usedG['fallback'], []);
            $check('P-37', '直すところがあるので加点の証明は出さない',
                   $usedG['proof'], null);
            // 壊した馬の採点は消さず、合計だけ計算し直します
            $hG = (array) (($accG['merged'] ?? [])[$tgtG] ?? []);
            $check('P-38', '壊した馬も残る', ($hG !== []), true);
            //   この資料の正常出力は、もともと採点が全部 null（score_status
            //   は partial）です。だから「null の数」では見られません。
            //   <b>応答にあった採点と1項目も変わっていないこと</b>を見ます。
            $scoreBefore = null;
            foreach ((array) $out1G['horses'] as $hh) {
                if ((int) $hh['horse_no'] === $tgtG) { $scoreBefore = (array) $hh['scores']; break; }
            }
            $check('P-39', '採点を1項目も書き換えていない',
                   (array) ($hG['scores'] ?? []), (array) $scoreBefore);
            $check('P-40', 'observed_sum は計算し直した値',
                   ((int) ($hG['observed_sum'] ?? -1) !== 999), true);
            // 公開まで通して、正常な馬が候補へ届くこと
            $pG = $ctrl->r122Publish($sidG);
            $check('P-41', '公開できる', $pG['code'], 'PUBLISHED');
            $pGnums = array_column((array) $pG['candidates'], 'horse_no');
            $check('P-42', '候補の数が正常なときと同じ',
                   count($pGnums), count((array) $pA['candidates']));
            $check('P-43', '候補の馬番も正常なときと同じ',
                   $pGnums, array_column((array) $pA['candidates'], 'horse_no'));

            // ② 1st だけ（2nd は未完了）でも、1stのB／D帯の馬が消えない
            $sidI = $mk($out1G, $out2, ['incomplete' => '2nd']);
            $pI   = $ctrl->r122Publish($sidI);
            $check('P-44', '2ndが未完了でも1st単独で公開できる',
                   $pI['code'], 'PUBLISHED');
            $check('P-45', '1stのB／D帯の馬が採点ミスだけで消えない',
                   (count((array) $pI['candidates']) > 0), true);

            // ③ 順位集合が不正（凍結集合に無い馬番を帯順位へ入れる）
            //    その帯だけ縮退し、他の帯は残します
            $ghost = function (array $doc) {
                $doc['band_ranks']['A'] = array_merge(
                    [999], (array) ($doc['band_ranks']['A'] ?? []));
                return $doc;
            };
            $sidH  = $mk($ghost($out1), $out2);
            $usedH = $ctrl->r122ResponseUsed($sidH, '1st',
                         $ctrl->r122AcceptedHorses($sidH, '1st'));
            //   evidence_band_ranks（予備根拠順位）はそのままなので、
            //   設計書10.2の順で<b>先にそちらへ切り替わります。</b>
            //   明示縮退はその次です。
            $check('P-46', '集合の壊れた帯は予備根拠順位へ切り替わる',
                   ($usedH['rank_source']['A'] ?? null), 'EVIDENCE_RANK');
            $check('P-47', '予備根拠順位で足りるので明示縮退はしない',
                   $usedH['fallback'], []);
            $check('P-48', '他の帯は応答の順位のまま',
                   ($usedH['rank_source']['B'] ?? null), 'RESPONSE');
            $check('P-49', '縮退があるので加点の証明は出さない',
                   $usedH['proof'], null);
            $check('P-50', '幽霊馬は順位に入らない',
                   in_array(999, (array) ($usedH['band_ranks']['A'] ?? []), true),
                   false);
            $pH = $ctrl->r122Publish($sidH);
            $check('P-51', '幽霊馬は候補に入らない',
                   in_array(999, array_column((array) $pH['candidates'],
                                              'horse_no'), true), false);
            $check('P-52', '切り替えても公開は止まらない', $pH['code'], 'PUBLISHED');

            // ④ 予備根拠順位も壊れていたら、明示縮退まで落ちます
            $ghost2 = function (array $doc) {
                $doc['band_ranks']['A'] = array_merge(
                    [999], (array) ($doc['band_ranks']['A'] ?? []));
                $doc['evidence_band_ranks']['A'] = array_merge(
                    [998], (array) ($doc['evidence_band_ranks']['A'] ?? []));
                return $doc;
            };
            $sidJ  = $mk($ghost2($out1), $out2);
            $usedJ = $ctrl->r122ResponseUsed($sidJ, '1st',
                         $ctrl->r122AcceptedHorses($sidJ, '1st'));
            $check('P-53', '予備根拠順位も壊れていれば明示縮退になる',
                   ($usedJ['rank_source']['A'] ?? null), 'EXPLICIT_FALLBACK');
            $check('P-54', '縮退した帯を記録する', $usedJ['fallback'], ['A']);
            $check('P-55', '縮退してもA帯の馬は全部そろう',
                   count((array) ($usedJ['band_ranks']['A'] ?? [])),
                   count((array) ($out1['band_ranks']['A'] ?? [])));
            $check('P-56', '他の帯は応答の順位のまま',
                   ($usedJ['rank_source']['B'] ?? null), 'RESPONSE');
            $pJ = $ctrl->r122Publish($sidJ);
            $check('P-57', '明示縮退でも公開は止まらない', $pJ['code'], 'PUBLISHED');

            // ══════════════════════════════════════════════════════════
            // @ANCHOR-20261021-R122-BANDSCOPE  10月21日008のご指摘3（後半）
            // ══════════════════════════════════════════════════════════
            //   訂正は馬の行しか照合していないので、トップレベルの
            //   band_ranks を黙って変えても通ります。FIX_APPLIED なら
            //   その変えた並びが使われていました。
            //   訂正の対象になっていない帯は、初回の並びを保持します。
            $this->info('── ⑤-6 訂正の対象外の帯は初回の順位を保持する ──');
            $bo1 = $out1;
            // A帯だけを壊します（幽霊馬を入れて集合を不正にします）
            $bo1['band_ranks']['A'] = array_merge(
                array_slice((array) $out1['band_ranks']['A'], 0, -1), [999]);
            // 訂正は A帯を正しく直すが、<b>B帯の並びも勝手に入れ替える</b>
            $bf1 = $out1;
            $bf1['band_ranks']['B'] = array_reverse((array) $out1['band_ranks']['B']);
            $sidB = $mk($bo1, $out2, ['fix_1st' => $bf1]);
            $accB = $ctrl->r122AcceptedHorses($sidB, '1st');
            $check('P-58', '訂正は採用される',
                   (string) ($accB['code'] ?? ''), 'FIX_APPLIED');
            $usedB = $ctrl->r122ResponseUsed($sidB, '1st', $accB);
            $check('P-59', 'A帯は訂正の順位を使う（対象なので）',
                   (string) ($usedB['rank_source']['A'] ?? ''), 'RESPONSE');
            $check('P-60', 'A帯の並びは訂正のもの',
                   array_map('intval', (array) ($usedB['band_ranks']['A'] ?? [])),
                   array_map('intval', (array) $bf1['band_ranks']['A']));
            $check('P-61', 'B帯は初回の順位を保持する（対象外なので）',
                   (string) ($usedB['rank_source']['B'] ?? ''), 'PREVIOUS_KEPT');
            $check('P-62', 'B帯の並びは初回のまま（訂正の並びを採らない）',
                   array_map('intval', (array) ($usedB['band_ranks']['B'] ?? [])),
                   array_map('intval', (array) $out1['band_ranks']['B']));
            $check('P-63', 'B帯の並びは訂正のものと違う',
                   array_map('intval', (array) ($usedB['band_ranks']['B'] ?? []))
                   !== array_map('intval', (array) $bf1['band_ranks']['B']), true);
            $noteB = implode('／', (array) ($usedB['rank_notes'] ?? []));
            $check('P-64', '訂正が違う順位を返していたことを記録する',
                   strpos($noteB, '訂正は違う順位を返していました') !== false, true);
            $check('P-65', 'D帯も対象外なので初回を保持する',
                   (string) ($usedB['rank_source']['D'] ?? ''), 'PREVIOUS_KEPT');

            // 訂正が B帯を変えていなければ、記録も「変えていた」とは書きません
            $bf2 = $out1;                      // 帯順位はそのまま
            $sidC = $mk($bo1, $out2, ['fix_1st' => $bf2]);
            $accC = $ctrl->r122AcceptedHorses($sidC, '1st');
            $usedC = $ctrl->r122ResponseUsed($sidC, '1st', $accC);
            $check('P-66', '変えていなければ初回と同じ並び',
                   array_map('intval', (array) ($usedC['band_ranks']['B'] ?? [])),
                   array_map('intval', (array) $out1['band_ranks']['B']));
            $noteC = implode('／', (array) ($usedC['rank_notes'] ?? []));
            $check('P-67', '「違う順位を返していた」とは書かない',
                   strpos($noteC, '訂正は違う順位を返していました') !== false, false);

            // ══════════════════════════════════════════════════════════
            // @ANCHOR-20261020-R122-FROZENK  取消で順位点を変えない
            // ══════════════════════════════════════════════════════════
            $this->info('── ⑤-4 取消しても凍結Kと順位点は変わらない ──');
            $sidE = $mk($out1, $out2);
            $pE   = $ctrl->r122Publish($sidE);
            $baseScore = array_column((array) $pE['candidates'], 'score', 'horse_no');
            // A帯の先頭（band_ranks の A の1頭目）を取り消します
            $headA = (int) (((array) $out1['band_ranks']['A'])[0] ?? 0);
            $sidF  = $mk($out1, $out2, ['cancelled' => [$headA]]);
            $pF    = $ctrl->r122Publish($sidF);
            $afterScore = array_column((array) $pF['candidates'], 'score', 'horse_no');
            $same = true;
            foreach ($afterScore as $hn => $sv) {
                if (!array_key_exists($hn, $baseScore)) { continue; }
                if ($baseScore[$hn] !== $sv) { $same = false; break; }
            }
            $check('P-32', '残った馬の順位点が取消前と同じ', $same, true);
            $check('P-33', '取消馬は候補に入らない',
                   in_array($headA, array_column((array) $pF['candidates'], 'horse_no'), true),
                   false);

            // ── ⑥ 期限・全頭取消・手渡し ───────────────────────────
            $this->info('── ⑥ 止まるところ ──');
            $sid5 = $mk($out1, $out2);
            $late = \App\Http\Controllers\Api\BaganrikiWorker::nowUs()
                  + 3600 * 1000000;
            $p5 = $ctrl->r122Publish($sid5, ['now_us' => $late]);
            $check('P-18', '公開期限を過ぎたら止まる', $p5['code'], 'DEADLINE_PASSED');

            $allNums = [];
            foreach ((array) $in1['runners'] as $r) { $allNums[] = (int) $r['horse_no']; }
            $sid6 = $mk($out1, $out2, ['cancelled' => $allNums]);
            $p6 = $ctrl->r122Publish($sid6);
            $check('P-19', '全頭取消で止まる', $p6['code'], 'ALL_CANCELLED');

            $sid7 = $mk($out1, $out2);
            $p7 = $ctrl->r122Publish($sid7, ['handed' => [['horse_no' => 1]]]);
            $check('P-20', 'ジャーナルがあるのに手渡しは受け付けない',
                   $p7['code'], 'HANDED_REFUSED');

            // ── ⑦ 監査に3つの時刻が残る ────────────────────────────
            $this->info('── ⑦ 公開の監査 ──');
            $ev = \DB::table('baganriki_audit_events')
                    ->where('snapshot_id', $sid)->where('kind', 'PUBLISHED')->first();
            $check('P-21', '公開の監査が残る', ($ev !== null), true);
            if ($ev !== null) {
                $d = json_decode((string) $ev->diagnostics, true);
                $has = is_array($d) && isset($d['verify_started_at'],
                        $d['verify_finished_at'], $d['committed_at']);
                $check('P-22', '3つの時刻が残る', $has, true);
                if ($has) {
                    $a = \App\Http\Controllers\Api\BaganrikiTime::us($d['verify_started_at']);
                    $b = \App\Http\Controllers\Api\BaganrikiTime::us($d['verify_finished_at']);
                    $c = \App\Http\Controllers\Api\BaganrikiTime::us($d['committed_at']);
                    $check('P-23', '検証開始<=完了<=commit直前',
                           ($a <= $b && $b <= $c), true);
                }
                $check('P-24', '版の増え方が残る',
                       [(int) $ev->old_revision, (int) $ev->new_revision], [0, 1]);
            }

        } catch (\Throwable $e) {
            $ok = false; $fail++;
            $this->error('  × 例外: ' . $e->getMessage());
            $this->error('     ' . $e->getFile() . ':' . $e->getLine());
        } finally {
            \DB::rollBack();
        }

        $this->line('');
        $this->line(sprintf('  ロールバック後  snapshot %d／公開 %d／intent %d',
            \DB::table('baganriki_snapshots')->count(),
            \DB::table('baganriki_publications')->count(),
            \DB::table('baganriki_publication_intents')->count()));
        $this->line('');
        $this->line('  判定件数 : ' . ($pass + $fail) . ' 件');
        $this->line('  合格     : ' . $pass . ' 件');
        $this->line('  不合格   : ' . $fail . ' 件');
        $this->line('');
        $this->info('════════════════════════════════════════════════════════');
        $this->info(($fail === 0 && $ok)
            ? ' 統合・公開・intent・revision は契約どおりに動きました（DBへ残る書き込み0件）'
            : ' 通らなかった箇所があります。上の × をご確認ください');
        $this->info('════════════════════════════════════════════════════════');
    }
