
    /**
     * ═══════════════════════════════════════════════════════════════════════
     * @ANCHOR-20261020-R122-QUEUE  キューと永続予約の通し試験
     * ═══════════════════════════════════════════════════════════════════════
     * 根拠：server_contract_r12.2.txt 10章・11章
     *
     * ■ 何を確かめるか
     *   1. 枠は1レース・1世代・1roleにつき2つだけ（初回0・訂正1）
     *   2. 同じ枠は作り直さない（重複キュー・期限切れ・再起動のどれでも）
     *   3. 予約を確定してから送る。送信許可は1回だけ
     *   4. 初回の原応答と complete を保存してから訂正に入る
     *   5. 同じ token に同じ応答は冪等。別の応答・終端の付け替えは拒否
     *   6. complete=false の本文は残すが選出に使わない
     *   7. 期限・全頭取消・版の変化では予約しない
     *   8. 再起動：SENT は結果不明にして再送しない。RESERVED は枠として残る
     *   9. response_revision は 予約の回数＋終端が変わった回数
     *  10. 読み取りは token も原文も返さない
     *
     * ■ 書き込みについて
     *   <b>全部ひとつのトランザクションで行い、最後に必ずロールバックします。</b>
     *   DBへ残る書き込みは0件です。
     */
    private function runR122QueueTest(): void
    {
        self::r122Autoload();

        $this->info('════════════════════════════════════════════════════════');
        $this->info(' r12.2 キューと永続予約の通し試験');
        $this->info('════════════════════════════════════════════════════════');
        $this->line('  実行時刻 : ' . date('c'));
        $this->warn('  ※ 全部ロールバックします。DBへ残る書き込みは0件です');
        $this->line('');

        if (!\App\Http\Controllers\Api\BaganrikiWorker::ready()) {
            $this->error('  × 必要な表がありません'
                . '（baganriki_snapshots / _ai_attempts / _live_states / _audit_events）');
            return;
        }

        $pass = 0; $fail = 0;
        $check = function (string $id, string $what, $got, $want) use (&$pass, &$fail) {
            $okk = ($got === $want);
            if ($okk) { $pass++; } else { $fail++; }
            $this->line(sprintf('  %s %-10s %-52s %s',
                $okk ? '○' : '×', $id, $what,
                $okk ? '' : ('得=' . var_export($got, true) . ' 期待=' . var_export($want, true))));
        };

        // 試験用の凍結入力を作る小さな道具
        $j = static fn($v) => (string) json_encode($v,
            JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        $mkSnap = function (string $raceId, int $salesUs, int $active, int $gen = 900)
                  use ($j): int {
            $id = \DB::table('baganriki_snapshots')->insertGetId([
                'race_id' => $raceId, 'generation' => $gen, 'run_id' => 'QT-' . $raceId,
                'release_version' => \App\Http\Controllers\Api\BaganrikiPrompt::PROMPT_VERSION,
                'snapshot_hash'  => hash('sha256', $raceId),
                'frozen_nums'    => $j(range(1, max(1, $active))),
                'target_count'   => 5,
                'quota_1st'      => $j([3, 2, 0]),
                'sales_close_at' => \App\Http\Controllers\Api\BaganrikiWorker::toDb($salesUs),
                'created_at'     => \App\Http\Controllers\Api\BaganrikiWorker::toDb(\App\Http\Controllers\Api\BaganrikiWorker::nowUs()),
            ]);
            \DB::table('baganriki_live_states')->insert([
                'snapshot_id' => $id, 'cancellations' => $j([]),
                'active_count' => $active, 'live_target_count' => 5,
                'live_quota' => $j([3, 2, 0]), 'live_close' => null,
                'state_revision' => 0, 'response_revision' => 0,
                'publication_revision' => 0, 'latest_publication_id' => null,
                'updated_at' => \App\Http\Controllers\Api\BaganrikiWorker::toDb(\App\Http\Controllers\Api\BaganrikiWorker::nowUs()),
            ]);
            return (int) $id;
        };
        $rev = static fn(int $sid) => (int) \DB::table('baganriki_live_states')
                 ->where('snapshot_id', $sid)->value('response_revision');

        $ok = true;
        \DB::beginTransaction();
        try {
            // 現在時刻は「期限のだいぶ前」に置きます
            $now   = \App\Http\Controllers\Api\BaganrikiWorker::nowUs();
            $sales = $now + 3600 * 1000000;          // 投票締切は1時間後
            $dl    = \App\Http\Controllers\Api\BaganrikiTime::effectiveDeadlines($sales, null);

            $this->info('── ① 初回の予約と送信許可 ──');
            $sid = $mkSnap('QT-20261020-A', $sales, 16);
            $r = \App\Http\Controllers\Api\BaganrikiWorker::reserve($sid, '1st', 0, $now);
            $check('Q-01', '初回の枠を予約できる', $r['ok'], true);
            $tok1 = (string) ($r['token'] ?? '');
            $check('Q-02', '予約で response_revision が1増える', $rev($sid), 1);

            $r2 = \App\Http\Controllers\Api\BaganrikiWorker::reserve($sid, '1st', 0, $now);
            $check('Q-03', '同じ枠は作り直さない', $r2['code'], 'SLOT_TAKEN');
            $check('Q-04', '作り直さないので版も増えない', $rev($sid), 1);

            $g = \App\Http\Controllers\Api\BaganrikiWorker::reserve($sid, '1st', 1, $now);
            $check('Q-05', '初回が未受領なら訂正を予約しない', $g['code'], 'FIRST_NOT_RECEIVED');

            $rc = \App\Http\Controllers\Api\BaganrikiWorker::receive($tok1, '{"a":1}', true, $now);
            $check('Q-06', '送信許可の前に受領はできない', $rc['code'], 'NOT_SENT');

            $s = \App\Http\Controllers\Api\BaganrikiWorker::allowSend($tok1, $now);
            $check('Q-07', '送信許可が出る', $s['ok'], true);
            $s2 = \App\Http\Controllers\Api\BaganrikiWorker::allowSend($tok1, $now);
            $check('Q-08', '送信許可は1回だけ', $s2['code'], 'ALREADY_SENT');

            $this->info('── ② 受領の冪等と付け替えの拒否 ──');
            $rc = \App\Http\Controllers\Api\BaganrikiWorker::receive($tok1, '{"a":1}', true, $now + 1000);
            $check('Q-09', '原応答を保存できる', $rc['ok'], true);
            $check('Q-10', '受領で version が1増える', $rev($sid), 2);
            $rc2 = \App\Http\Controllers\Api\BaganrikiWorker::receive($tok1, '{"a":1}', true, $now + 2000);
            $check('Q-11', '同じ応答の再保存は冪等', $rc2['code'], 'IDEMPOTENT');
            $check('Q-12', '冪等なら版は増えない', $rev($sid), 2);
            $rc3 = \App\Http\Controllers\Api\BaganrikiWorker::receive($tok1, '{"a":2}', true, $now + 3000);
            $check('Q-13', '別の応答は保存しない', $rc3['code'], 'RESPONSE_MISMATCH');
            $f = \App\Http\Controllers\Api\BaganrikiWorker::fail($tok1, 'あとから失敗にしてみる', $now + 4000);
            $check('Q-14', '終端の付け替えは拒否', $f['code'], 'TERMINAL');

            $this->info('── ③ 訂正の枠 ──');
            $g = \App\Http\Controllers\Api\BaganrikiWorker::fixAllowed($sid, '1st');
            $check('Q-15', '初回がcomplete=trueなら訂正できる', $g['ok'], true);
            $rf = \App\Http\Controllers\Api\BaganrikiWorker::reserve($sid, '1st', 1, $now + 5000);
            $check('Q-16', '訂正の枠を予約できる', $rf['ok'], true);
            $tokF = (string) ($rf['token'] ?? '');
            $check('Q-17', '訂正の予約で版が1増える', $rev($sid), 3);
            $r3 = \App\Http\Controllers\Api\BaganrikiWorker::reserve($sid, '1st', 2, $now + 6000);
            $check('Q-18', '3つめの枠は作らない', $r3['code'], 'INVALID_ATTEMPT');
            $g2 = \App\Http\Controllers\Api\BaganrikiWorker::fixAllowed($sid, '1st');
            $check('Q-19', '訂正の枠はもう作り直さない', $g2['code'], 'SLOT_TAKEN');

            \App\Http\Controllers\Api\BaganrikiWorker::allowSend($tokF, $now + 7000);
            $rbad = \App\Http\Controllers\Api\BaganrikiWorker::receive($tokF, '{"fix":1}', true, $now - 10000);
            $check('Q-20', '訂正の受領が初回より前なら拒否', $rbad['code'], 'RECEIVE_ORDER');
            $rgood = \App\Http\Controllers\Api\BaganrikiWorker::receive($tokF, '{"fix":1}', true, $now + 8000);
            $check('Q-21', '訂正の受領（初回以降の時刻）は通る', $rgood['ok'], true);
            $u = \App\Http\Controllers\Api\BaganrikiWorker::usable($sid, '1st');
            $check('Q-22', '選出には訂正を使う', $u['attempt_no'] ?? null, 1);
            $check('Q-23', '版は 予約2＋終端2 = 4', $rev($sid), 4);

            $this->info('── ④ complete=false は選出に使わない ──');
            $sidB = $mkSnap('QT-20261020-B', $sales, 14);
            $rb = \App\Http\Controllers\Api\BaganrikiWorker::reserve($sidB, '2nd', 0, $now);
            $tokB = (string) ($rb['token'] ?? '');
            \App\Http\Controllers\Api\BaganrikiWorker::allowSend($tokB, $now);
            $rcb = \App\Http\Controllers\Api\BaganrikiWorker::receive($tokB, '{"partial":true}', false, $now + 1000);
            $check('Q-24', 'complete=false でも本文は保存する', $rcb['ok'], true);
            $ub = \App\Http\Controllers\Api\BaganrikiWorker::usable($sidB, '2nd');
            $check('Q-25', 'complete=false は選出に使わない', $ub['code'], 'NONE');
            $gb = \App\Http\Controllers\Api\BaganrikiWorker::fixAllowed($sidB, '2nd');
            $check('Q-26', 'complete=false では訂正を予約しない', $gb['code'], 'FIRST_NOT_COMPLETE');

            $this->info('── ⑤ 期限・全頭取消・版の変化 ──');
            $sidC = $mkSnap('QT-20261020-C', $sales, 12);
            $late = \App\Http\Controllers\Api\BaganrikiWorker::reserve($sidC, '1st', 0, (int) $dl['reply'] + 1);
            $check('Q-27', '応答期限を1マイクロ秒でも超えたら予約しない',
                   $late['code'], 'DEADLINE_PASSED');
            $just = \App\Http\Controllers\Api\BaganrikiWorker::reserve($sidC, '1st', 0, (int) $dl['reply']);
            $check('Q-28', '期限ちょうどは予約できる', $just['ok'], true);

            $sidD = $mkSnap('QT-20261020-D', $sales, 0);
            $allc = \App\Http\Controllers\Api\BaganrikiWorker::reserve($sidD, '1st', 0, $now);
            $check('Q-29', '全頭取消では予約しない', $allc['code'], 'ALL_CANCELLED');

            $sidE = $mkSnap('QT-20261020-E', $sales, 10);
            \App\Http\Controllers\Api\BaganrikiWorker::reserve($sidE, '1st', 0, $now);              // ここで版が1になる
            $stale = \App\Http\Controllers\Api\BaganrikiWorker::reserve($sidE, '2nd', 0, $now, ['response_revision' => 0]);
            $check('Q-30', '版が変わっていたら予約しない', $stale['code'], 'STATE_CHANGED');
            $fresh = \App\Http\Controllers\Api\BaganrikiWorker::reserve($sidE, '2nd', 0, $now, ['response_revision' => 1]);
            $check('Q-31', '版が合っていれば予約できる', $fresh['ok'], true);

            $this->info('── ⑥ 再起動（結果不明にして再送しない）──');
            $sidF = $mkSnap('QT-20261020-F', $sales, 16);
            $t1 = (string) \App\Http\Controllers\Api\BaganrikiWorker::reserve($sidF, '1st', 0, $now)['token'];
            \App\Http\Controllers\Api\BaganrikiWorker::allowSend($t1, $now);                         // SENT のまま落ちた
            $t2 = (string) \App\Http\Controllers\Api\BaganrikiWorker::reserve($sidF, '2nd', 0, $now)['token'];  // RESERVED のまま
            $before = $rev($sidF);
            $rs = \App\Http\Controllers\Api\BaganrikiWorker::resume($sidF, $now + 1000);
            $check('Q-32', '送信済みは結果不明にする', $rs['unknown'], ['1st#0']);
            $check('Q-33', '未送信の枠はそのまま残す', $rs['reserved_kept'], ['2nd#0']);
            $check('Q-34', '結果不明は終端なので版が1増える', $rev($sidF), $before + 1);
            $again = \App\Http\Controllers\Api\BaganrikiWorker::reserve($sidF, '1st', 0, $now + 2000);
            $check('Q-35', '再起動でも枠は作り直さない', $again['code'], 'SLOT_TAKEN');
            $gf = \App\Http\Controllers\Api\BaganrikiWorker::fixAllowed($sidF, '1st');
            $check('Q-36', '結果不明の初回では訂正を予約しない', $gf['code'], 'FIRST_FAILED');
            $sr = \App\Http\Controllers\Api\BaganrikiWorker::allowSend($t2, $now + 3000);
            $check('Q-37', '未送信だった枠は送信許可が1回残る', $sr['ok'], true);
            $rs2 = \App\Http\Controllers\Api\BaganrikiWorker::resume($sidF, $now + 4000);
            $check('Q-38', '2回目の再起動で終端は動かさない', $rs2['unknown'], ['2nd#0']);

            $this->info('── ⑦ 読み取りに token と原文を出さない ──');
            $sl = \App\Http\Controllers\Api\BaganrikiWorker::slots($sid, '1st');
            $keys = ($sl === []) ? [] : array_keys($sl[0]);
            $check('Q-39', 'slots に token は無い', in_array('token', $keys, true), false);
            $check('Q-40', 'slots に原文は無い', in_array('raw_response', $keys, true), false);
            $check('Q-41', 'slots は2枠を返す', count($sl), 2);

            $this->info('── ⑧ 監査が残っているか ──');
            $ev = \DB::table('baganriki_audit_events')
                    ->where('race_id', 'QT-20261020-A')->pluck('kind')->all();
            $check('Q-42', 'Aレースの監査は 予約・送信・受領 で6件', count($ev), 6);
            $check('Q-43', '予約の監査が2件', count(array_filter($ev,
                   static fn($k) => $k === 'QUEUE_RESERVED')), 2);
            $evF = \DB::table('baganriki_audit_events')
                     ->where('race_id', 'QT-20261020-F')
                     ->where('kind', 'QUEUE_UNKNOWN_RESULT')->count();
            $check('Q-44', '結果不明の監査が2件', $evF, 2);

            // ───────────────────────────────────────────────────────────
            // ⑨ 送信口（r122QueueReserve / Receive / Fail）のつなぎ
            //    実AIは呼びません。凍結入力は試験用に1件だけ入れます。
            // ───────────────────────────────────────────────────────────
            if (function_exists('app')) {
                $this->info('── ⑨ 送信口のつなぎ（実AIは呼びません）──');
                $ctrl  = app(\App\Http\Controllers\Api\AiController::class);
                $keep  = [getenv('BAGANRIKI_R122_QUEUE'),
                          $_ENV['BAGANRIKI_R122_QUEUE'] ?? null,
                          $_SERVER['BAGANRIKI_R122_QUEUE'] ?? null];
                try {
                    // 旗が下りているときは素通り（1バイトも変わらない）
                    putenv('BAGANRIKI_R122_QUEUE=0');
                    $_ENV['BAGANRIKI_R122_QUEUE'] = '0';
                    $_SERVER['BAGANRIKI_R122_QUEUE'] = '0';
                    $w = $ctrl->r122QueueReserve('2026-10-18', '4', '04', '2', 1,
                                                 '1st', ['snapshot_hash' => 'x']);
                    $check('W-01', '旗が0なら素通りする（skip）', $w['skip'], true);

                    // 旗を上げて、試験用の凍結入力（generation=0）を1件だけ置きます。
                    //   すでに固定済みなので r122Freeze は呼ばれません。
                    putenv('BAGANRIKI_R122_QUEUE=1');
                    $_ENV['BAGANRIKI_R122_QUEUE'] = '1';
                    $_SERVER['BAGANRIKI_R122_QUEUE'] = '1';
                    $rid  = \App\Http\Controllers\Api\AiController::r122RaceId(
                                '2026-10-18', '4', '04', '2', 1);
                    $hash = hash('sha256', $rid);
                    $sidW = \DB::table('baganriki_snapshots')->insertGetId([
                        'race_id' => $rid, 'generation' => 0, 'run_id' => 'QT-W',
                        'snapshot_hash' => $hash, 'frozen_nums' => $j(range(1, 12)),
                        'target_count' => 5, 'quota_1st' => $j([3, 2, 0]),
                        'sales_close_at' => \App\Http\Controllers\Api\BaganrikiWorker::toDb($sales),
                        'created_at' => \App\Http\Controllers\Api\BaganrikiWorker::toDb($now),
                    ]);
                    \DB::table('baganriki_live_states')->insert([
                        'snapshot_id' => $sidW, 'cancellations' => $j([]),
                        'active_count' => 12, 'live_target_count' => 5,
                        'live_quota' => $j([3, 2, 0]), 'live_close' => null,
                        'state_revision' => 0, 'response_revision' => 0,
                        'publication_revision' => 0, 'latest_publication_id' => null,
                        'updated_at' => \App\Http\Controllers\Api\BaganrikiWorker::toDb($now),
                    ]);

                    // 固定した入力と送信文のhashが違えば送りません
                    $wNg = $ctrl->r122QueueReserve('2026-10-18', '4', '04', '2', 1,
                               '1st', ['snapshot_hash' => 'ちがうhash']);
                    $check('W-02', 'hashが違えば送らない', $wNg['code'], 'SNAPSHOT_MISMATCH');

                    // hashが合えば予約して送信許可まで進みます
                    $wOk = $ctrl->r122QueueReserve('2026-10-18', '4', '04', '2', 1,
                               '1st', ['snapshot_hash' => $hash]);
                    $check('W-03', 'hashが合えば枠を取って送信許可まで進む', $wOk['ok'], true);
                    $check('W-04', '予約した枠は初回（0）', (int) \DB::table('baganriki_ai_attempts')
                        ->where('snapshot_id', $sidW)->value('attempt_no'), 0);

                    // 2回目は送りません（重複送信の防止）
                    $wAgain = $ctrl->r122QueueReserve('2026-10-18', '4', '04', '2', 1,
                                  '1st', ['snapshot_hash' => $hash]);
                    $check('W-05', '2回目は送らない', $wAgain['code'], 'SLOT_TAKEN');

                    $cw = $ctrl->r122QueueReceive($wOk, '{"w":1}', true);
                    $check('W-06', '送信口から原応答を保存できる', $cw['ok'], true);
                    $cw2 = $ctrl->r122QueueReceive($wOk, '{"w":1}', true);
                    $check('W-07', '送信口から2回保存しても冪等', $cw2['code'], 'IDEMPOTENT');
                    $fw = $ctrl->r122QueueFail($wOk, '試験', true);
                    $check('W-08', '終端になった枠は付け替えない', $fw['code'], 'TERMINAL');
                    $cwS = $ctrl->r122QueueReceive(['skip' => true, 'ok' => false],
                               '{"w":2}', true);
                    $check('W-09', '素通りの枠には何もしない', $cwS['skip'], true);

                    // ── ⑩ shadow（記録はするが送信は止めない）─────────
                    $this->info('── ⑩ shadow（記録はするが送信を止めない）──');
                    $setq = static function (string $v) {
                        putenv('BAGANRIKI_R122_QUEUE=' . $v);
                        $_ENV['BAGANRIKI_R122_QUEUE'] = $v;
                        $_SERVER['BAGANRIKI_R122_QUEUE'] = $v;
                    };
                    $setq('0');
                    $check('S-01', '0 は何もしない',
                        [\App\Http\Controllers\Api\BaganrikiWorker::mode(),
                         \App\Http\Controllers\Api\BaganrikiWorker::enabled(),
                         \App\Http\Controllers\Api\BaganrikiWorker::blocking()],
                        ['off', false, false]);
                    $setq('shadow');
                    $check('S-02', 'shadow は動くが止めない',
                        [\App\Http\Controllers\Api\BaganrikiWorker::mode(),
                         \App\Http\Controllers\Api\BaganrikiWorker::enabled(),
                         \App\Http\Controllers\Api\BaganrikiWorker::blocking()],
                        ['shadow', true, false]);
                    $setq('1');
                    $check('S-03', '1 は契約どおり止める',
                        [\App\Http\Controllers\Api\BaganrikiWorker::mode(),
                         \App\Http\Controllers\Api\BaganrikiWorker::enabled(),
                         \App\Http\Controllers\Api\BaganrikiWorker::blocking()],
                        ['on', true, true]);

                    // shadow で枠が取れなくても shadow=true（呼出側は送ります）
                    $setq('shadow');
                    $sh = $ctrl->r122QueueReserve('2026-10-18', '4', '04', '2', 1,
                              '1st', ['snapshot_hash' => 'ちがうhash']);
                    $check('S-04', 'shadow は失敗しても止めない印を返す',
                        [$sh['ok'], $sh['shadow'], $sh['code']],
                        [false, true, 'SNAPSHOT_MISMATCH']);
                    $setq('1');
                    $on = $ctrl->r122QueueReserve('2026-10-18', '4', '04', '2', 1,
                              '1st', ['snapshot_hash' => 'ちがうhash']);
                    $check('S-05', '1 のときは止める印を返す',
                        [$on['ok'], $on['shadow']], [false, false]);

                    // ── 待ち時間を応答期限から決める ───────────────
                    $this->info('── ⑪ AIを待つ時間（応答期限から決めます）──');
                    $T = \App\Http\Controllers\Api\BaganrikiTime::class;
                    $check('S-06', '予約が無ければ今までの秒数',
                        $ctrl->r122AiTimeout(90, null), 90);
                    $check('S-07', '素通りでも今までの秒数',
                        $ctrl->r122AiTimeout(90, ['skip' => true, 'ok' => false]), 90);
                    $far = ['skip' => false, 'ok' => true,
                            'reply_deadline' => $T::toJst($now + 600 * 1000000)];
                    $check('S-08', '期限が遠ければ170秒で止める',
                        $ctrl->r122AiTimeout(90, $far), 170);
                    // 期限は「いま」から数え直します。試験の途中で実時間が
                    //   進むので、$now を使い回すと1秒ずれて落ちます。
                    //   秒の端で割れるので、1秒の幅を許します。
                    $mid = ['skip' => false, 'ok' => true,
                            'reply_deadline' => $T::toJst(
                                \App\Http\Controllers\Api\BaganrikiWorker::nowUs()
                                + 100 * 1000000)];
                    $t09 = $ctrl->r122AiTimeout(240, $mid);
                    $check('S-09', '期限が近ければ短くする（5秒残す）',
                        ($t09 === 95 || $t09 === 94), true);
                    $near = ['skip' => false, 'ok' => true,
                             'reply_deadline' => $T::toJst($now + 10 * 1000000)];
                    $check('S-10', '下限は20秒',
                        $ctrl->r122AiTimeout(90, $near), 20);
                    $past = ['skip' => false, 'ok' => true,
                             'reply_deadline' => $T::toJst($now - 60 * 1000000)];
                    $check('S-11', '期限を過ぎていても20秒',
                        $ctrl->r122AiTimeout(90, $past), 20);

                    // ── ⑫ 本文の旗の3段 ──────────────────────────
                    $this->info('── ⑫ 本文の旗（0／shadow／1）──');
                    $kp = [getenv('BAGANRIKI_R122_PROMPT'),
                           $_ENV['BAGANRIKI_R122_PROMPT'] ?? null,
                           $_SERVER['BAGANRIKI_R122_PROMPT'] ?? null];
                    $setp = static function (string $v) {
                        putenv('BAGANRIKI_R122_PROMPT=' . $v);
                        $_ENV['BAGANRIKI_R122_PROMPT'] = $v;
                        $_SERVER['BAGANRIKI_R122_PROMPT'] = $v;
                    };
                    $P = \App\Http\Controllers\Api\BaganrikiPrompt::class;
                    try {
                        $setp('0');
                        $check('S-12', '0 は旧本文のまま',
                            [$P::mode(), $P::enabled(), $P::sending()],
                            ['off', false, false]);
                        $setp('shadow');
                        $check('S-13', 'shadow は入力を作るが送らない',
                            [$P::mode(), $P::enabled(), $P::sending()],
                            ['shadow', true, false]);
                        $setp('1');
                        $check('S-14', '1 は r12.2 の本文で送る',
                            [$P::mode(), $P::enabled(), $P::sending()],
                            ['on', true, true]);
                    } finally {
                        if ($kp[0] === false) { putenv('BAGANRIKI_R122_PROMPT'); }
                        else { putenv('BAGANRIKI_R122_PROMPT=' . $kp[0]); }
                        if ($kp[1] === null) { unset($_ENV['BAGANRIKI_R122_PROMPT']); }
                        else { $_ENV['BAGANRIKI_R122_PROMPT'] = $kp[1]; }
                        if ($kp[2] === null) { unset($_SERVER['BAGANRIKI_R122_PROMPT']); }
                        else { $_SERVER['BAGANRIKI_R122_PROMPT'] = $kp[2]; }
                    }
                } finally {
                    // 旗を元へ戻します（この後の処理に残さないため）
                    if ($keep[0] === false) { putenv('BAGANRIKI_R122_QUEUE'); }
                    else { putenv('BAGANRIKI_R122_QUEUE=' . $keep[0]); }
                    if ($keep[1] === null) { unset($_ENV['BAGANRIKI_R122_QUEUE']); }
                    else { $_ENV['BAGANRIKI_R122_QUEUE'] = $keep[1]; }
                    if ($keep[2] === null) { unset($_SERVER['BAGANRIKI_R122_QUEUE']); }
                    else { $_SERVER['BAGANRIKI_R122_QUEUE'] = $keep[2]; }
                }
            }

            // ───────────────────────────────────────────────────────────
            // ⑬ @ANCHOR-20261020-R122-WIRE  実送信の後への接続（006の6-4）
            //    実AIは呼びません。呼ぶ手前で断る経路と、
            //    依頼本文の組み立て、公開の待ち合わせ、そして
            //    「本番の関数から本当に呼ばれているか」を確かめます。
            // ───────────────────────────────────────────────────────────
            if (function_exists('app')) {
                $this->info('── ⑬ 実送信の後への接続（006の6-4。実AIは呼びません）──');
                $ctrlX = app(\App\Http\Controllers\Api\AiController::class);
                $A = \App\Http\Controllers\Api\AiController::class;
                $W = \App\Http\Controllers\Api\BaganrikiWorker::class;

                // 旗を一時的に動かすための道具（終わったら必ず戻します）
                $keepX = [];
                foreach (['BAGANRIKI_R122_PROMPT', 'BAGANRIKI_R122_QUEUE'] as $kk) {
                    $keepX[$kk] = [getenv($kk), $_ENV[$kk] ?? null, $_SERVER[$kk] ?? null];
                }
                $setX = static function (string $k, string $v) {
                    putenv($k . '=' . $v);
                    $_ENV[$k] = $v; $_SERVER[$k] = $v;
                };
                try {
                    // ── 設定の食い違い（006：旗を1にすれば完成経路にしない）──
                    $setX('BAGANRIKI_R122_PROMPT', '0');
                    $setX('BAGANRIKI_R122_QUEUE', '0');
                    $x1 = $A::r122WireConfig();
                    $check('X-01', '旧本文のままなら何も言わない',
                        [$x1['ok'], $x1['code']], [true, 'OK']);

                    $setX('BAGANRIKI_R122_PROMPT', '1');
                    $setX('BAGANRIKI_R122_QUEUE', '0');
                    $x2 = $A::r122WireConfig();
                    $check('X-02', '本文だけ1で枠が0なら送らせない',
                        [$x2['ok'], $x2['code']], [false, 'QUEUE_REQUIRED']);

                    $setX('BAGANRIKI_R122_QUEUE', 'shadow');
                    $x3 = $A::r122WireConfig();
                    $check('X-03', '枠がshadowなら進めるが印を付ける',
                        [$x3['ok'], $x3['code']], [true, 'QUEUE_SHADOW']);

                    $setX('BAGANRIKI_R122_QUEUE', '1');
                    $x4 = $A::r122WireConfig();
                    $check('X-04', '両方1なら契約どおり',
                        [$x4['ok'], $x4['code']], [true, 'OK']);

                    // ── 旗が下りている枠では1バイトも動かない ──
                    $x5 = $ctrlX->r122AfterReceive('2026-10-18', '4', '04', '2', 9,
                              '1st', ['skip' => true, 'ok' => false]);
                    $check('X-05', '素通りの枠では接続を動かさない', $x5['ran'], false);

                    // ── 訂正依頼の本文 ──
                    $ridX = $A::r122RaceId('2026-10-18', '4', '04', '2', 9);
                    $hashX = hash('sha256', $ridX . '-X');
                    $srcX = ['race_id' => $ridX, 'ai_role' => '1st',
                             'snapshot_hash' => $hashX,
                             'runners' => [
                                 ['horse_no' => 1, 'band' => 'A'],
                                 ['horse_no' => 2, 'band' => 'B'],
                                 ['horse_no' => 3, 'band' => 'D'],
                             ]];
                    $sidX = \DB::table('baganriki_snapshots')->insertGetId([
                        'race_id' => $ridX, 'generation' => 0, 'run_id' => 'QT-X',
                        'snapshot_hash' => $hashX, 'frozen_nums' => $j([1, 2, 3]),
                        'input_json_1st' => $j($srcX), 'input_json_2nd' => $j($srcX),
                        'target_count' => 3, 'quota_1st' => $j([2, 1, 0]),
                        'sales_close_at' => $W::toDb($sales),
                        'created_at' => $W::toDb($now),
                    ]);
                    \DB::table('baganriki_live_states')->insert([
                        'snapshot_id' => $sidX, 'cancellations' => $j([]),
                        'active_count' => 3, 'live_target_count' => 3,
                        'live_quota' => $j([2, 1, 0]), 'live_close' => null,
                        'state_revision' => 0, 'response_revision' => 0,
                        'publication_revision' => 0, 'latest_publication_id' => null,
                        'updated_at' => $W::toDb($now),
                    ]);

                    $inspX = ['repair_scope' => ['horses' => [2],
                                  'rank_bands' => ['B'], 'presentation_horses' => [],
                                  'summary_horses' => [], 'public_candidates' => false,
                                  'top_fields' => []],
                              'diag' => ['findings' => [
                                  ['scope' => 'horses', 'target' => 2,
                                   'code' => 'SCORES_RANGE', 'reason' => 'H1が範囲外'],
                              ], 'missing' => [3], 'duplicated' => [],
                                 'unknown' => [], 'isolated' => [2]]];

                    $fa0 = $ctrlX->r122AssembleFix($sidX, '1st', $inspX);
                    $check('X-06', '初回の原応答が無ければ依頼を作らない',
                        $fa0['code'], 'FIRST_NOT_RECEIVED');

                    // 初回の枠を「受領済み・complete=false」で置きます
                    $rawX = '{"race_id":"' . $ridX . '","ai_role":"1st"}';
                    \DB::table('baganriki_ai_attempts')->insert([
                        'snapshot_id' => $sidX, 'role' => '1st', 'attempt_no' => 0,
                        'token' => 'QT-X-1st-0', 'status' => $W::RECEIVED,
                        'reserved_at' => $W::toDb($now), 'received_at' => $W::toDb($now),
                        'complete' => 0, 'raw_response' => $rawX,
                        'response_hash' => hash('sha256', $rawX),
                    ]);
                    $faX = $ctrlX->r122AssembleFix($sidX, '1st', $inspX);
                    $check('X-07', '依頼本文を作れる', $faX['ok'], true);
                    $bodyX = json_decode((string) $faX['user'], true);
                    $check('X-08', '依頼は4つの中身だけを持つ',
                        array_keys((array) $bodyX),
                        ['first_response', 'fix_request', 'input']);
                    $check('X-09', '同じsnapshotのhashを載せる',
                        (string) ($bodyX['fix_request']['snapshot_hash'] ?? ''), $hashX);
                    $check('X-10', '当該AIの初回応答を原文のまま載せる',
                        (string) ($bodyX['first_response'] ?? ''), $rawX);
                    $check('X-11', 'repair_scope を載せる',
                        (array) ($bodyX['fix_request']['repair_scope']['horses'] ?? []),
                        [2]);
                    $check('X-12', '具体的なエラー一覧を載せる',
                        (string) ($bodyX['fix_request']['errors'][0]['code'] ?? ''),
                        'SCORES_RANGE');
                    $check('X-13', '欠落馬も伝える',
                        (array) ($bodyX['fix_request']['missing_horses'] ?? []), [3]);
                    $check('X-14', '訂正は1回だけと書いてある',
                        [(int) ($bodyX['fix_request']['attempt_no'] ?? -1),
                         (int) ($bodyX['fix_request']['max_attempts'] ?? -1)], [1, 1]);
                    $check('X-15', '相手AIの応答は載せない',
                        strpos((string) $faX['user'], '"second_response"'), false);
                    $check('X-16', '依頼本文が自分の厳密読込を通る',
                        \App\Http\Controllers\Api\BaganrikiJson::strict(
                            (string) $faX['user'])['ok'], true);

                    // ── 送る手前で断る経路（実AIは呼びません）──
                    $sf1 = $ctrlX->r122SendFix($sidX, '1st', $inspX);
                    $check('X-17', '初回がcomplete=falseなら訂正を予約しない',
                        [$sf1['sent'], $sf1['code']], [false, 'FIRST_NOT_COMPLETE']);

                    \DB::table('baganriki_ai_attempts')
                      ->where('snapshot_id', $sidX)->where('role', '1st')
                      ->where('attempt_no', 0)->update(['complete' => 1]);

                    // 締切を目前にすると、時間が無いので送りません
                    \DB::table('baganriki_snapshots')->where('id', $sidX)
                      ->update(['sales_close_at' => $W::toDb($now + 10 * 1000000)]);
                    $sf2 = $ctrlX->r122SendFix($sidX, '1st', $inspX);
                    $check('X-18', '応答期限まで時間が無ければ訂正を送らない',
                        [$sf2['sent'], $sf2['code']], [false, 'NO_TIME_FOR_FIX']);

                    // 時間を戻し、訂正の枠が先にあれば送りません（最大1回）
                    \DB::table('baganriki_snapshots')->where('id', $sidX)
                      ->update(['sales_close_at' => $W::toDb($sales)]);
                    \DB::table('baganriki_ai_attempts')->insert([
                        'snapshot_id' => $sidX, 'role' => '1st', 'attempt_no' => 1,
                        'token' => 'QT-X-1st-1', 'status' => $W::RECEIVED,
                        'reserved_at' => $W::toDb($now), 'received_at' => $W::toDb($now),
                        'complete' => 1, 'raw_response' => $rawX,
                        'response_hash' => hash('sha256', $rawX),
                    ]);
                    $sf3 = $ctrlX->r122SendFix($sidX, '1st', $inspX);
                    $check('X-19', '訂正の枠が既にあれば送らない（最大1回）',
                        [$sf3['sent'], $sf3['code']], [false, 'SLOT_TAKEN']);

                    // ── 公開の待ち合わせ ──
                    $pw1 = $ctrlX->r122PublishWhenReady($sidX, ['now_us' => $now]);
                    $check('X-20', '2ndが終端でなければ公開しない',
                        $pw1['code'], 'WAITING');
                    // ══════════════════════════════════════════════════
                    // @ANCHOR-20261021-R122-SETTLE  待ちの中身が増えました
                    // ══════════════════════════════════════════════════
                    //   1st は初回も訂正も RECEIVED ですが、採否確定の印が
                    //   まだ無いので「採否未確定」として待ちに入ります。
                    //   （010の2-4。RECEIVED は HTTPが返っただけです）
                    // $check('X-21', '待っている相手を名前で返す',
                    //     (array) ($pw1['waiting'] ?? []), ['2nd（枠なし）']);  // 旧
                    $check('X-21', '待っている相手を名前で返す',
                        (array) ($pw1['waiting'] ?? []),
                        ['1st（採否未確定）', '2nd（枠なし）']);

                    \DB::table('baganriki_ai_attempts')->insert([
                        'snapshot_id' => $sidX, 'role' => '2nd', 'attempt_no' => 0,
                        'token' => 'QT-X-2nd-0', 'status' => $W::RESERVED,
                        'reserved_at' => $W::toDb($now), 'complete' => 0,
                    ]);
                    $pw2 = $ctrlX->r122PublishWhenReady($sidX, ['now_us' => $now]);
                    $check('X-22', '2ndが予約中でも公開しない', $pw2['code'], 'WAITING');

                    // ══════════════════════════════════════════════════
                    // @ANCHOR-20261021-R122-SETTLE  受領の終端≠採否の確定
                    // ══════════════════════════════════════════════════
                    //   ご指摘（010の2-4）の競合そのものを試験にします。
                    //   「片方が受領済みだが訂正の要否をまだ判定していない
                    //     間に、もう片方が両role完了とみなして公開へ進む」
                    $check('X-22b', 'RECEIVEDだけでは採否は未確定',
                        $A::r122RoleSettled($sidX, '1st')['settled'], false);

                    $mk1 = $A::r122MarkRoleSettled($sidX, '1st',
                                                   ['from' => 'queue-test'], $now);
                    $check('X-22c', '採否確定の印を付けられる',
                        [$mk1['marked'], $mk1['already']], [true, false]);
                    $check('X-22d', '同じ版に二度は付けない',
                        $A::r122MarkRoleSettled($sidX, '1st', [], $now)['already'],
                        true);
                    $check('X-22e', '印が付けば採否確定',
                        $A::r122RoleSettled($sidX, '1st')['settled'], true);

                    $pw2b = $ctrlX->r122PublishWhenReady($sidX, ['now_us' => $now]);
                    $check('X-22f', '1stが確定しても2ndが未了なら公開しない',
                        [$pw2b['code'], (array) ($pw2b['waiting'] ?? [])],
                        ['WAITING', ['2nd（RESERVED）']]);

                    // 印を付けたあとに訂正の中身が変われば、版が変わります
                    \DB::table('baganriki_ai_attempts')->where('snapshot_id', $sidX)
                      ->where('role', '1st')->where('attempt_no', 1)
                      ->update(['response_hash' => hash('sha256', $rawX . '-another')]);
                    $check('X-22g', '応答の版が変われば印は効かない',
                        $A::r122RoleSettled($sidX, '1st')['settled'], false);
                    $pw2c = $ctrlX->r122PublishWhenReady($sidX, ['now_us' => $now]);
                    $check('X-22h', '版が変わったら待ちへ戻る',
                        (array) ($pw2c['waiting'] ?? []),
                        ['1st（採否未確定）', '2nd（RESERVED）']);

                    // もとの版へ戻し、2nd も終端＋確定にして公開まで通します
                    \DB::table('baganriki_ai_attempts')->where('snapshot_id', $sidX)
                      ->where('role', '1st')->where('attempt_no', 1)
                      ->update(['response_hash' => hash('sha256', $rawX)]);
                    $check('X-22i', '版を戻せば印は効く',
                        $A::r122RoleSettled($sidX, '1st')['settled'], true);

                    // 応答期限を過ぎたら、来ないものを待ちません
                    $lateX = (int) $W::dbUs($W::toDb($sales)) + 100 * 1000000;
                    $pw3 = $ctrlX->r122PublishWhenReady($sidX, ['now_us' => $lateX]);
                    $check('X-23', '応答期限を過ぎたら待たない',
                        ($pw3['code'] === 'WAITING'), false);

                    // ══════════════════════════════════════════════════
                    // @ANCHOR-20261021-R122-ATDEADLINE  期限ぴったりの1回
                    // ══════════════════════════════════════════════════
                    //   ご指摘（010の2-3 末尾）：
                    //     「$now > reply の判定なので、期限ぴったりの1回で
                    //       WAITINGになって終わらないように」
                    //   `>=` にしたので、期限と同じ時刻でも待ちません。
                    $snapD = \DB::table('baganriki_snapshots')
                               ->where('id', $sidX)->first();
                    $liveD = \DB::table('baganriki_live_states')
                               ->where('snapshot_id', $sidX)->first();
                    $dlD   = $W::deadlines($snapD, $liveD);
                    $pwD   = $ctrlX->r122PublishWhenReady(
                                 $sidX, ['now_us' => (int) $dlD['reply']]);
                    $check('X-23b', '応答期限ぴったりでも待たない',
                        ($pwD['code'] === 'WAITING'), false);

                    // ═══════════════════════════════════════════════════
                    // 呼出経路そのものの確認（006：実ファイル・呼出経路）
                    // ═══════════════════════════════════════════════════
                    //   関数の行範囲を取って、その中に呼び出しがあるかを見ます。
                    //   「他ファイルに接続があるなら経路を出せ」へのお答えです。
                    $rc   = new \ReflectionClass($A);
                    $file = (array) file((string) $rc->getFileName());
                    $slice = static function (string $m) use ($rc, $file): string {
                        $r = $rc->getMethod($m);
                        return implode('', array_slice($file, $r->getStartLine() - 1,
                            $r->getEndLine() - $r->getStartLine() + 1));
                    };
                    $b1 = $slice('getHorseOddsFinderAiAnalysis');
                    $b2 = $slice('getHorseOddsFinderSecondAiOpinion');
                    $check('X-24', '1st の本番関数から接続を呼んでいる',
                        strpos($b1, '->r122AfterReceive(') !== false, true);
                    $check('X-25', '1st は応答を返したあとに動かす',
                        strpos($b1, 'app()->terminating(function () use ($wireSelf')
                            !== false, true);
                    $check('X-26', '2nd の本番関数から接続を呼んでいる',
                        strpos($b2, '->r122AfterReceive(') !== false, true);
                    $check('X-27', '1st の本番関数で設定の食い違いを見ている',
                        strpos($b1, 'self::r122WireConfig()') !== false, true);
                    $bw = $slice('r122AfterReceive');
                    $check('X-28', '接続は検証→訂正→解決→公開の順に呼ぶ',
                        [strpos($bw, '->r122InspectResponse(') !== false,
                         strpos($bw, '->r122SendFix(') !== false,
                         strpos($bw, '->r122AcceptedHorses(') !== false,
                         strpos($bw, '->r122PublishWhenReady(') !== false],
                        [true, true, true, true]);
                    // ── @ANCHOR-20261020-R122-RESUME  007の6-1 ──────────
                    //   キャッシュを返す経路から、固定のやり直しを
                    //   呼んでいるか。TOO_EARLY で空回答をキャッシュ
                    //   しないようにしているか。
                    $bz = $slice('getHorseOddsFinderAiAnalysis');
                    $check('X-31', 'キャッシュ返却のあとに固定をやり直す',
                        substr_count($bz, '$this->r122AfterCached('), 2);
                    $check('X-32', 'TOO_EARLY では空回答をキャッシュしない',
                        strpos($bz, "if ((string) \$r122['code'] === 'TOO_EARLY') {")
                            !== false, true);
                    $br = $slice('r122ResumeFreeze');
                    $check('X-33', 'やり直しは固定済みなら何もしない',
                        strpos($br, "'ALREADY'") !== false, true);
                    $check('X-34', 'やり直しは旗が0なら何もしない',
                        strpos($br, "'FLAG_OFF'") !== false, true);
                    $bac = $slice('r122AfterCached');
                    $check('X-35', 'キャッシュ後の後始末は応答を返したあとに動かす',
                        strpos($bac, 'app()->terminating(') !== false, true);
                    $check('X-36', 'キャッシュ後の後始末は公開も起動する',
                        strpos($bac, '->r122PublishWhenReady(') !== false, true);

                    $bc = $slice('r122CallAi');
                    $check('X-29', '1st は Anthropic・2nd は DeepSeek へ送る',
                        [strpos($bc, '$this->anthropic->sendWithRetry(') !== false,
                         strpos($bc, 'api.deepseek.com') !== false], [true, true]);
                    $check('X-30', '訂正の自動再試行は0（maxAttempts: 1）',
                        strpos($bc, 'maxAttempts: 1') !== false, true);
                } finally {
                    foreach ($keepX as $kk => $vv) {
                        if ($vv[0] === false) { putenv($kk); }
                        else { putenv($kk . '=' . $vv[0]); }
                        if ($vv[1] === null) { unset($_ENV[$kk]); }
                        else { $_ENV[$kk] = $vv[1]; }
                        if ($vv[2] === null) { unset($_SERVER[$kk]); }
                        else { $_SERVER[$kk] = $vv[2]; }
                    }
                }
            }

        } catch (\Throwable $e) {
            $ok = false; $fail++;
            $this->error('  × 例外: ' . $e->getMessage());
            $this->error('     ' . $e->getFile() . ':' . $e->getLine());
        } finally {
            \DB::rollBack();
        }

        $n1 = \DB::table('baganriki_snapshots')->count();
        $n2 = \DB::table('baganriki_ai_attempts')->count();
        $n3 = \DB::table('baganriki_live_states')->count();
        $n4 = \DB::table('baganriki_audit_events')->count();
        $this->line('');
        $this->line(sprintf('  ロールバック後  snapshot %d／attempts %d／live %d／audit %d',
            $n1, $n2, $n3, $n4));
        $this->line('');
        $this->line('  判定件数 : ' . ($pass + $fail) . ' 件');
        $this->line('  合格     : ' . $pass . ' 件');
        $this->line('  不合格   : ' . $fail . ' 件');
        $this->line('');
        $this->info('════════════════════════════════════════════════════════');
        $this->info(($fail === 0 && $ok)
            ? ' キューと永続予約は契約どおりに動きました（DBへ残る書き込み0件）'
            : ' 通らなかった箇所があります。上の × をご確認ください');
        $this->info('════════════════════════════════════════════════════════');
    }
