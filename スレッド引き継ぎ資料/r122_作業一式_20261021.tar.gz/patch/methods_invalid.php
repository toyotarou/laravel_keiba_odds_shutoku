
    /**
     * ═══════════════════════════════════════════════════════════════════════
     * @ANCHOR-20261020-R122-INVALID  異常例32本の突き合わせ
     * ═══════════════════════════════════════════════════════════════════════
     * 根拠：10月20日004の確認結果 §5／validation/invalid_cases.json
     *
     * 「正常入力が通る」ことは、正しいものを誤って弾いていない確認にしかなりません。
     * 不正を弾けることは、不正例で確かめる必要があります。
     *
     *   入力 23本（Schemaで弾く16本／意味検証で弾く7本）
     *   出力  9本（Schemaで弾く 5本／意味検証で弾く4本）
     *
     * Schema で弾くものと意味検証で弾くものを分けて判定し、
     * 先方の expected_schema / expected_contract と1件ずつ突き合わせます。
     * DBも外部APIも使いません（費用0円・書き込み0件）。
     */
    private function runR122InvalidCases(string $root): void
    {
        self::r122Autoload();
        $root = rtrim($root, '/');
        $vDir = is_dir($root . '/validation') ? $root . '/validation' : $root;
        $sDir = is_dir($root . '/schemas')    ? $root . '/schemas'
              : dirname($vDir) . '/schemas';
        $base = dirname($vDir);

        $this->info('════════════════════════════════════════════════════════');
        $this->info(' r12.2 異常例の突き合わせ（Schema と 意味検証 を分けて判定）');
        $this->info('════════════════════════════════════════════════════════');
        $this->line('  実行時刻 : ' . date('c'));
        $this->line('  資材      : ' . $vDir);
        $this->line('');

        $casesFile = $vDir . '/invalid_cases.json';
        if (!is_file($casesFile)) {
            $this->error('  × invalid_cases.json がありません: ' . $casesFile);
            return;
        }
        $cases = (array) (json_decode((string) file_get_contents($casesFile), true)['cases'] ?? []);
        $inS  = json_decode((string) @file_get_contents($sDir . '/input_schema.json'), true);
        $outS = json_decode((string) @file_get_contents($sDir . '/output_schema.json'), true);
        if (!is_array($inS) || !is_array($outS)) {
            $this->error('  × Schemaを読めません: ' . $sDir);
            return;
        }

        // ── 固定入力を snapshot_hash で引けるようにします ───────────
        //   本番では、応答が名乗る snapshot_hash で固定入力を引き当て、
        //   識別・版・mode・配分の「おうむ返し」を照合します。
        //   対になる入力が invalid_cases.json に書かれていないので、
        //   ここでも同じやり方（hashで引く）で照合します。
        $byHash = [];
        foreach (glob($vDir . '/normal/*_input.json') ?: [] as $f) {
            $x = json_decode((string) file_get_contents($f), true);
            if (!is_array($x) || !isset($x['snapshot_hash'], $x['ai_role'])) continue;
            $byHash[(string) $x['snapshot_hash']][(string) $x['ai_role']] = $x;
        }

        $ngS = 0; $ngC = 0; $miss = 0;
        $rows = [];
        foreach ($cases as $c) {
            $id   = (string) ($c['id'] ?? '');
            $kind = (string) ($c['kind'] ?? '');
            $file = (string) ($c['file'] ?? '');
            $path = (strpos($file, '/') === 0) ? $file : $base . '/' . $file;
            if (!is_file($path)) $path = $vDir . '/' . basename(dirname($file)) . '/' . basename($file);
            if (!is_file($path)) {
                $this->error("  × {$id} ファイルがありません: {$file}");
                $miss++;
                continue;
            }
            $doc = json_decode((string) file_get_contents($path), true);
            if (!is_array($doc)) {
                $this->error("  × {$id} JSONとして読めません");
                $miss++;
                continue;
            }

            // ── Schema で弾けるか ────────────────────────────────────
            $schemaErr = ($kind === 'input')
                ? self::jsCheck($doc, $inS, '')
                : self::jsCheck($doc, $outS, '');
            $gotSchema = ($schemaErr === []) ? 'PASS' : 'FAIL';

            // ── 意味検証で弾けるか ──────────────────────────────────
            $contractErr = ($kind === 'input')
                ? self::r122ContractCheckInput($doc)
                : self::r122ContractCheckOutput($doc);
            // 出力は、固定入力を引けたら「おうむ返し」も照合します
            if ($kind === 'output') {
                $h  = (string) ($doc['snapshot_hash'] ?? '');
                $rl = (string) ($doc['ai_role'] ?? '');
                $src = $byHash[$h][$rl] ?? null;
                if (is_array($src)) {
                    $env = \App\Http\Controllers\Api\BaganrikiResponse::checkEnvelope($doc, [
                        'prompt_version'  => $src['prompt_version'],
                        'schema_version'  => $src['schema_version'],
                        'race_id'         => $src['race_id'],
                        'ai_role'         => $src['ai_role'],
                        'snapshot_hash'   => $src['snapshot_hash'],
                        'mode'            => $src['mode'],
                        'mode_status'     => $src['mode_status'],
                        'allocation_mode' => $src['allocation_mode'],
                        'mode_policy_id'  => $src['mode_policy_id'],
                        'role_cap'        => $src['role_cap'],
                        'role_quota'      => $src['role_quota'],
                    ]);
                    if (!$env['ok']) $contractErr[] = 'おうむ返し: ' . $env['reason'];
                }
            }
            // Schemaで落ちたものは契約上も不採用です（両方FAILで扱います）
            $gotContract = ($schemaErr === [] && $contractErr === []) ? 'PASS' : 'FAIL';

            $expS = (string) ($c['expected_schema']   ?? '');
            $expC = (string) ($c['expected_contract'] ?? '');
            $okS  = ($gotSchema   === $expS);
            $okC  = ($gotContract === $expC);
            if (!$okS) $ngS++;
            if (!$okC) $ngC++;

            $why = ($schemaErr !== []) ? $schemaErr[0]
                 : (($contractErr !== []) ? $contractErr[0] : '（弾けていません）');
            $rows[] = [$kind, $id, $expS, $gotSchema, $okS, $expC, $gotContract, $okC, $why];
        }

        $this->info('── 入力 ──');
        $this->line(sprintf('  %-28s %-9s %-9s %s', 'ケース', 'Schema', '意味検証', '弾いた理由'));
        foreach ($rows as $r) {
            if ($r[0] !== 'input') continue;
            $this->r122InvalidRow($r);
        }
        $this->line('');
        $this->info('── 出力 ──');
        foreach ($rows as $r) {
            if ($r[0] !== 'output') continue;
            $this->r122InvalidRow($r);
        }
        $this->line('');
        $n = count($rows);
        $this->line(sprintf('  対象 %d 件（入力 %d ／ 出力 %d）',
            $n,
            count(array_filter($rows, static fn($r) => $r[0] === 'input')),
            count(array_filter($rows, static fn($r) => $r[0] === 'output'))));
        $this->line('  Schemaの判定が期待と違ったもの   : ' . $ngS . ' 件');
        $this->line('  意味検証の判定が期待と違ったもの : ' . $ngC . ' 件');
        if ($miss > 0) $this->line('  読めなかったファイル             : ' . $miss . ' 件');
        // ───────────────────────────────────────────────────────────
        // @ANCHOR-20261020-R122-CHAIN  本番の応答処理へ通す（ご指摘6-2・6-3）
        // ───────────────────────────────────────────────────────────
        //   Schema と意味検証だけでなく、本番で通す順番
        //     extract → checkEnvelope → isolateHorses
        //   へ実際に通します。固定入力は snapshot_hash で引きます。
        //   <b>応答が名乗る role は照合相手を選ぶのに使いません。</b>
        //   本番は予約済みの role と固定 snapshot を正とするので、
        //   ここでも 1st・2nd の両方を正として突き合わせ、
        //   どちらとも合わなければ不採用にします。
        $this->line('');
        $this->info('── 本番の応答処理へ通す（extract→封筒照合→馬ごとの隔離）──');
        $chainNg = 0;
        $run = function (array $doc, string $name, bool $expectReject, ?string $bindRole = null)
                use ($byHash, &$chainNg) {
            $raw = \App\Http\Controllers\Api\BaganrikiResponse::BEGIN
                 . json_encode($doc, JSON_UNESCAPED_UNICODE)
                 . \App\Http\Controllers\Api\BaganrikiResponse::END;
            $ex = \App\Http\Controllers\Api\BaganrikiResponse::extract($raw);
            if (!$ex['ok']) { return ['stage' => 'extract', 'reason' => $ex['reason'] ?? '']; }
            $res = $ex['json'];
            $h   = (string) ($res['snapshot_hash'] ?? '');
            $cands = $byHash[$h] ?? [];
            if ($cands === []) {
                return ['stage' => 'envelope', 'reason' => '固定入力を snapshot_hash で引けません'];
            }
            // 予約済みの role を正とします。応答の自己申告では選びません。
            //   正常出力はファイル名に role が入っているので、そのroleに固定します。
            //   異常出力は対になる入力が示されていないので、両方の役を試し、
            //   どちらとも合わないときだけ不採用にします（甘いほうへ倒します）。
            $tryRoles = ($bindRole !== null) ? [$bindRole] : ['1st', '2nd'];
            $envOk = false; $envWhy = ''; $src0 = null;
            foreach ($tryRoles as $role) {
                $src = $cands[$role] ?? null;
                if ($src === null) continue;
                $e = \App\Http\Controllers\Api\BaganrikiResponse::checkEnvelope($res, [
                    'prompt_version'  => $src['prompt_version'],
                    'schema_version'  => $src['schema_version'],
                    'race_id'         => $src['race_id'],
                    'ai_role'         => $src['ai_role'],
                    'snapshot_hash'   => $src['snapshot_hash'],
                    'mode'            => $src['mode'],
                    'mode_status'     => $src['mode_status'],
                    'allocation_mode' => $src['allocation_mode'],
                    'mode_policy_id'  => $src['mode_policy_id'],
                    'role_cap'        => $src['role_cap'],
                    'role_quota'      => $src['role_quota'],
                ]);
                if ($e['ok']) { $envOk = true; $src0 = $src; break; }
                if ($envWhy === '') $envWhy = (string) $e['reason'];
            }
            if (!$envOk) { return ['stage' => 'envelope', 'reason' => $envWhy]; }
            $frozen = array_map(static fn($x) => (int) $x['horse_no'],
                                (array) ($src0['runners'] ?? []));
            $iso = \App\Http\Controllers\Api\BaganrikiResponse::isolateHorses(
                (array) ($res['horses'] ?? []), $frozen);
            return ['stage' => 'ok', 'kept' => count($iso['kept']),
                    'isolated' => count($iso['isolated']),
                    'missing' => count($iso['missing']), 'frozen' => count($frozen)];
        };
        foreach ($cases as $c) {
            if (($c['kind'] ?? '') !== 'output') continue;
            $path = $vDir . '/invalid/' . basename((string) $c['file']);
            if (!is_file($path)) continue;
            $doc = json_decode((string) file_get_contents($path), true);
            if (!is_array($doc)) continue;
            $r = $run($doc, (string) $c['id'], true);
            if ($r['stage'] === 'ok') {
                // 封筒を通ったものは、馬の隔離で落ちていることを確かめます
                $caught = ($r['isolated'] > 0 || $r['missing'] > 0);
                if ($caught) {
                    $this->line(sprintf('  ○ %-28s 馬ごとの隔離で検出（隔離%d・欠落%d）',
                        $c['id'], $r['isolated'], $r['missing']));
                } else {
                    $this->line(sprintf('  － %-28s 本番の3段では落ちません'
                        . '（Schema／意味検証で落とします）', $c['id']));
                }
            } else {
                $this->line(sprintf('  ○ %-28s %s で不採用  %s',
                    $c['id'], $r['stage'], mb_strimwidth((string) ($r['reason'] ?? ''), 0, 54, '…')));
            }
        }
        $this->line('');
        $this->line('  正常な出力14本を同じ経路へ通します（正常馬が失われないこと）');
        $nOk = 0; $nNg = 0;
        foreach (glob($vDir . '/normal/*_output.json') ?: [] as $f) {
            $doc = json_decode((string) file_get_contents($f), true);
            if (!is_array($doc)) continue;
            $bind = null;
            if (preg_match('/_(1st|2nd)_output\.json$/', basename($f), $bm)) {
                $bind = $bm[1];
            }
            $r = $run($doc, basename($f), false, $bind);
            if ($r['stage'] !== 'ok') {
                $nNg++; $chainNg++;
                $this->error(sprintf('  × %-34s %s で落ちました  %s',
                    basename($f), $r['stage'], mb_strimwidth((string) ($r['reason'] ?? ''), 0, 44, '…')));
                continue;
            }
            if ($r['isolated'] > 0 || $r['missing'] > 0) {
                $nNg++; $chainNg++;
                $this->error(sprintf('  × %-34s 正常な馬が失われました（隔離%d・欠落%d）',
                    basename($f), $r['isolated'], $r['missing']));
                continue;
            }
            $nOk++;
        }
        $this->line(sprintf('    通った %d 本 / 落ちた %d 本（全頭そろったまま）', $nOk, $nNg));
        $ngC += $chainNg;

        $this->line('');
        $this->info('════════════════════════════════════════════════════════');
        if ($ngS === 0 && $ngC === 0 && $miss === 0) {
            $this->info(' すべて先方の期待どおりに弾けました（不一致 0 件）');
        } else {
            $this->error(' 期待と違うものがあります。上の × をご確認ください');
        }
        $this->info('════════════════════════════════════════════════════════');
        $this->line('');
        $this->line('※ Schemaで弾くものと意味検証で弾くものを分けて判定しています。');
        $this->line('※ Schemaで落ちたものは、契約上も不採用（FAIL）として扱います。');
        $this->line('※ 出力の検査は、入力を対にできない前提で「出力だけで分かる矛盾」を見ています。');
    }

    /** 1行表示 */
    private function r122InvalidRow(array $r): void
    {
        [$kind, $id, $expS, $gotS, $okS, $expC, $gotC, $okC, $why] = $r;
        $line = sprintf('  %s %-28s %-4s(期待%-4s) %-4s(期待%-4s)  %s',
            ($okS && $okC) ? '○' : '×', $id, $gotS, $expS, $gotC, $expC,
            mb_strimwidth((string) $why, 0, 70, '…'));
        if ($okS && $okC) $this->line($line); else $this->error($line);
    }

    /**
     * @ANCHOR-20261020-R122-INVALID  入力の意味検証
     *   Schemaでは分からない「数字の辻褄」を見ます。
     *   @return array 違反の説明（空なら通過）
     */
    public static function r122ContractCheckInput(array $in): array
    {
        $e = [];
        $BP = '\App\Http\Controllers\Api\BaganrikiPrompt';
        $BT = '\App\Http\Controllers\Api\BaganrikiTime';
        $BS = '\App\Http\Controllers\Api\BaganrikiSignals';
        $BA = '\App\Http\Controllers\Api\BaganrikiAllocation';

        // ── 版 ────────────────────────────────────────────────────────
        if (($in['schema_version'] ?? null) !== $BP::SCHEMA_VERSION) $e[] = '版: schema_version が違います';
        if (($in['prompt_version'] ?? null) !== $BP::PROMPT_VERSION) $e[] = '版: prompt_version が違います';
        if (($in['snapshot_hash_version'] ?? null) !== $BP::HASH_VERSION) $e[] = '版: snapshot_hash_version が違います';
        if (($in['learning_stage'] ?? null) !== 'COLLECT_ONLY') $e[] = '学習: learning_stage は COLLECT_ONLY だけです';
        if (array_key_exists('model_version', $in) && $in['model_version'] !== null) $e[] = '学習: model_version は null だけです';

        // ── 時刻の辻褄 ────────────────────────────────────────────────
        $tc = (array) ($in['time_contract'] ?? []);
        $anchor = $BT::us($tc['anchor_at'] ?? null);
        $cut    = $BT::us($in['cutoff_at'] ?? null);
        $frz    = $BT::us($in['input_freeze_at'] ?? null);
        $sales  = $BT::us($tc['sales_close_at'] ?? null);
        $pub    = $BT::us($tc['publish_deadline'] ?? null);
        $rep    = $BT::us($tc['reply_deadline'] ?? null);
        if ($anchor === null) $e[] = '時刻: anchor_at を読めません';
        if ($cut === null)    $e[] = '時刻: cutoff_at を読めません';
        if ($frz === null)    $e[] = '時刻: input_freeze_at を読めません';
        if ($anchor !== null && $cut !== null && $cut !== $BT::cutoff($anchor)) {
            $e[] = '時刻: cutoff_at が 発走−360秒 ではありません';
        }
        if ($cut !== null && $frz !== null && $frz !== $cut + 30 * 1000000) {
            $e[] = '時刻: input_freeze_at が cutoff_at＋30秒 ではありません';
        }
        if ($sales !== null && $pub !== null && $pub !== $BT::publishDeadline($sales)) {
            $e[] = '時刻: publish_deadline が 投票締切−60秒 ではありません';
        }
        if ($sales !== null && $rep !== null && $rep !== $BT::replyDeadline($sales)) {
            $e[] = '時刻: reply_deadline が 公開期限−30秒 ではありません';
        }

        // ── 取得監査 ─────────────────────────────────────────────────
        $ca = (array) ($in['collection_audit'] ?? []);
        $six = $ca['6'] ?? ($ca[6] ?? null);
        if (!is_array($six) || ($six['status'] ?? '') !== 'ADOPTED') {
            $e[] = '取得: 6分前が ADOPTED ではありません';
        }
        foreach ($BT::INPUT_SLOTS as $slot) {
            $a = $ca[(string) $slot] ?? ($ca[$slot] ?? null);
            if (!is_array($a) || ($a['status'] ?? '') !== 'ADOPTED') continue;
            $sch = $BT::us($a['slot_scheduled_at'] ?? null);
            $req = $BT::us($a['request_started_at'] ?? null);
            $res = $BT::us($a['response_received_at'] ?? null);
            $av  = $BT::us($a['available_at'] ?? null);
            $src = $BT::us($a['source_updated_at'] ?? null);
            if ($anchor !== null && $sch !== null && $sch !== $BT::slotScheduled($anchor, $slot)) {
                $e[] = "取得{$slot}: slot_scheduled_at が 発走−{$slot}分 ではありません";
            }
            if ($sch !== null && $req !== null && $req < $sch) {
                $e[] = "取得{$slot}: 予定時刻より前に要求を出しています";
            }
            if ($req !== null && $res !== null && $res < $req) {
                $e[] = "取得{$slot}: 受信が要求より前になっています";
            }
            if ($res !== null && $av !== null && $av < $res) {
                $e[] = "取得{$slot}: 利用可能が受信より前になっています";
            }
            $grace = ($BT::GRACE_MS[$slot] ?? 120000) * 1000;
            if ($sch !== null && $av !== null && $av > $sch + $grace) {
                $e[] = "取得{$slot}: 取得猶予を超えています";
            }
            if ($frz !== null && $av !== null && $av > $frz) {
                $e[] = "取得{$slot}: 情報上限（input_freeze_at）より後の値です";
            }
            if ($src !== null && $res !== null && $src > $res) {
                $e[] = "取得{$slot}: 取得元の更新時刻が受信より未来です";
            }
        }

        // ── 信号と mode ──────────────────────────────────────────────
        $sig = (array) ($in['signals'] ?? []);
        $tri = static function ($v) {
            if ($v === true)  return 'TRUE';
            if ($v === false) return 'FALSE';
            return 'UNKNOWN';
        };
        $flags = [];
        foreach (['X1', 'X2', 'X3', 'X4', 'X5', 'X6', 'Z'] as $k) {
            $flags[$k] = $tri($sig[$k] ?? null);
        }
        $N = (int) ($in['N'] ?? 0);
        if ($N >= 7 && ($sig['X6'] ?? null) !== null) {
            $e[] = 'X6: N>=7 では null だけです（決着事項①B案）';
        }
        if ($N > 0 && $N < 7 && ($sig['X6'] ?? null) !== false) {
            $e[] = 'X6: N<7 では false だけです（決着事項①B案）';
        }
        $cls = $BS::v04Classify($flags);
        foreach ([['S', 'S'], ['S_min', 'S_min'], ['S_max', 'S_max']] as [$k, $kk]) {
            if (array_key_exists($k, $in) && $in[$k] !== $cls[$kk]) {
                $e[] = "mode: {$k} が信号から計算した値と違います（"
                     . json_encode($in[$k]) . ' / ' . json_encode($cls[$kk]) . '）';
            }
        }
        foreach (['mode', 'mode_status', 'allocation_mode', 'mode_policy_id',
                  'selection_enabled', 'display_rating'] as $k) {
            if (array_key_exists($k, $in) && $in[$k] !== $cls[$k]) {
                $e[] = "mode: {$k} が信号から決まる値と違います（"
                     . json_encode($in[$k]) . ' / ' . json_encode($cls[$k]) . '）';
            }
        }

        // ── 配分 ─────────────────────────────────────────────────────
        if ($N > 0) {
            $al = $BA::v04Allocation($N, $cls);
            foreach (['target_count', 'base_quota', 'quota'] as $k) {
                $want = ($k === 'target_count') ? $al['target_count']
                      : (($k === 'base_quota') ? ($al['base_quota'] ?? null) : $al['quota']);
                if (array_key_exists($k, $in)
                    && json_encode($in[$k]) !== json_encode($want)) {
                    $e[] = "配分: {$k} が N と mode から決まる値と違います（"
                         . json_encode($in[$k]) . ' / ' . json_encode($want) . '）';
                }
            }
            $role = (string) ($in['ai_role'] ?? '1st');
            $wantRq = ($cls['selection_enabled'] === false) ? null
                    : (($role === '2nd') ? $al['quota_2nd'] : $al['quota']);
            if (array_key_exists('role_quota', $in)
                && json_encode($in['role_quota']) !== json_encode($wantRq)) {
                $e[] = '配分: role_quota が指定と違います（'
                     . json_encode($in['role_quota']) . ' / ' . json_encode($wantRq) . '）';
            }
            $wantCap = ($cls['selection_enabled'] === false) ? 0
                     : (($role === '2nd') ? min(5, (int) $al['target_count'])
                                          : (int) $al['target_count']);
            if (array_key_exists('role_cap', $in) && (int) $in['role_cap'] !== $wantCap) {
                $e[] = '配分: role_cap が指定と違います（'
                     . json_encode($in['role_cap']) . ' / ' . $wantCap . '）';
            }
        }

        // ── 凍結集合 ─────────────────────────────────────────────────
        $runners = (array) ($in['runners'] ?? []);
        if ($N > 0 && count($runners) !== $N) {
            $e[] = '頭数: runners の件数が N と違います';
        }
        $ranks = [];
        foreach ($runners as $r) {
            $ranks[] = (int) ($r['win_rank'] ?? 0);
            $want = $BA::v04Band((int) ($r['win_rank'] ?? 0));
            if (($r['band'] ?? null) !== $want) {
                $e[] = '帯: 馬番 ' . ($r['horse_no'] ?? '?') . ' の帯が人気と合いません';
            }
        }
        sort($ranks);
        if ($ranks !== range(1, count($ranks))) {
            $e[] = '順位: 凍結人気が 1..N の連番になっていません';
        }

        return $e;
    }

    /**
     * @ANCHOR-20261020-R122-INVALID  出力の意味検証
     *   対になる入力を使わず、出力だけで分かる矛盾を見ます。
     *   @return array 違反の説明（空なら通過）
     */
    public static function r122ContractCheckOutput(array $res): array
    {
        $e = [];
        $BP = '\App\Http\Controllers\Api\BaganrikiPrompt';
        $BS = '\App\Http\Controllers\Api\BaganrikiSignals';
        $BA = '\App\Http\Controllers\Api\BaganrikiAllocation';

        if (($res['schema_version'] ?? null) !== $BP::SCHEMA_VERSION) $e[] = '版: schema_version が違います';
        if (($res['prompt_version'] ?? null) !== $BP::PROMPT_VERSION) $e[] = '版: prompt_version が違います';
        if (($res['learning_stage'] ?? null) !== 'COLLECT_ONLY')      $e[] = '学習: learning_stage は COLLECT_ONLY だけです';

        // 入力専用のキーを返していないか（契約9章）
        foreach (['input_freeze_at', 'collection_audit', 'signals', 'S', 'S_min',
                  'S_max', 'buy_recommended', 'source_registry', 'field_catalog',
                  'input_indices', 'coverage', 'time_contract', 'cutoff_at',
                  'base_quota', 'runners'] as $k) {
            if (array_key_exists($k, $res)) $e[] = '出力: 入力専用のキーを返しています（' . $k . '）';
        }

        // mode 一式の内部の辻褄
        $ms = $res['mode_status'] ?? null;
        $am = $res['allocation_mode'] ?? null;
        $mp = $res['mode_policy_id'] ?? null;
        $md = $res['mode'] ?? null;
        $sel = $res['selection_enabled'] ?? null;
        if ($ms === 'PROVISIONAL') {
            if ($md !== 'UNKNOWN')                   $e[] = 'mode: 暫定では正式modeは UNKNOWN のままです';
            if ($mp !== 'X6_ONLY_UPPER_MODE_V1')     $e[] = 'mode: 暫定の mode_policy_id が違います';
            if (!in_array($am, ['MIXED', 'VOLATILE'], true)) $e[] = 'mode: 暫定の allocation_mode が違います';
        }
        if ($ms === 'CONFIRMED') {
            if ($mp !== 'BASE_TRI_STATE_V1')         $e[] = 'mode: 確定の mode_policy_id が違います';
            if ($am !== $md)                         $e[] = 'mode: 確定では allocation_mode は正式modeと同じです';
        }
        if ($ms === 'UNRESOLVED') {
            if ($am !== null)                        $e[] = 'mode: 判定不能では allocation_mode は null です';
            if ($sel !== false)                      $e[] = 'mode: 判定不能では selection_enabled は false です';
        }

        // role と枠
        $role = $res['ai_role'] ?? null;
        if (!in_array($role, ['1st', '2nd'], true)) $e[] = 'role: ai_role が 1st / 2nd ではありません';
        $rq  = $res['role_quota'] ?? null;
        $cap = $res['role_cap'] ?? null;
        if ($sel === false) {
            if ($cap !== 0 || $rq !== null) $e[] = 'role: 選出停止では role_cap=0・role_quota=null です';
        } else {
            if (!is_array($rq)) {
                $e[] = 'role: role_quota がありません';
            } else {
                $sum = (int) ($rq['A'] ?? 0) + (int) ($rq['B'] ?? 0) + (int) ($rq['D'] ?? 0);
                if ($sum !== (int) $cap) $e[] = 'role: role_quota の合計が role_cap と合いません';
            }
            if ($role === '2nd' && (int) $cap > 5) $e[] = 'role: 2ndの role_cap が5を超えています';
            $tc = $res['target_count'] ?? null;
            if ($role === '1st' && $tc !== null && (int) $cap !== (int) $tc) {
                $e[] = 'role: 1stの role_cap は target_count と同じです';
            }
            if ($role === '2nd' && $tc !== null && (int) $cap !== min(5, (int) $tc)) {
                $e[] = 'role: 2ndの role_cap は min(5, target_count) です';
            }
        }

        // 全頭と順位
        $horses = (array) ($res['horses'] ?? []);
        $br = (array) ($res['band_ranks'] ?? []);
        $er = (array) ($res['evidence_band_ranks'] ?? []);
        $inBr = []; foreach ($br as $b => $list) foreach ((array) $list as $n) $inBr[(int) $n] = (string) $b;
        $inEr = []; foreach ($er as $b => $list) foreach ((array) $list as $n) $inEr[(int) $n] = (string) $b;
        foreach ($horses as $h) {
            $no = (int) ($h['horse_no'] ?? 0);
            $el = (string) ($h['eligibility'] ?? '');
            if ($el === 'ELIGIBLE') {
                if (!isset($inBr[$no])) $e[] = '全頭: 適格馬 ' . $no . ' が band_ranks にいません';
                if (!isset($inEr[$no])) $e[] = '全頭: 適格馬 ' . $no . ' が evidence_band_ranks にいません';
                if (isset($inBr[$no]) && $inBr[$no] !== (string) ($h['band'] ?? ''))
                    $e[] = '全頭: 馬番 ' . $no . ' の帯と順位の帯が違います';
            } else {
                if (isset($inBr[$no]) || isset($inEr[$no]))
                    $e[] = '全頭: 非適格馬 ' . $no . ' が順位に入っています';
                if (($h['rank_basis'] ?? null) !== 'NOT_RANKED')
                    $e[] = '全頭: 非適格馬 ' . $no . ' の rank_basis は NOT_RANKED です';
            }
        }
        foreach (array_keys($inBr) as $no) {
            $found = false;
            foreach ($horses as $h) if ((int) ($h['horse_no'] ?? 0) === $no) { $found = true; break; }
            if (!$found) $e[] = '全頭: band_ranks の馬番 ' . $no . ' が horses にいません';
        }

        // 公開候補は帯の先頭から飛ばさずに取る
        if (is_array($rq)) {
            $eligByBand = [];
            foreach ($horses as $h) {
                if ((string) ($h['eligibility'] ?? '') !== 'ELIGIBLE') continue;
                $eligByBand[(string) ($h['band'] ?? '')][] = (int) $h['horse_no'];
            }
            $want = [];
            foreach (['A', 'B', 'D'] as $b) {
                $list = array_values(array_filter((array) ($br[$b] ?? []),
                    static fn($n) => in_array((int) $n, $eligByBand[$b] ?? [], true)));
                $take = min((int) ($rq[$b] ?? 0), count($list));
                for ($i = 0; $i < $take; $i++) $want[] = (int) $list[$i];
            }
            $got = array_map('intval', (array) ($res['public_candidates'] ?? []));
            if ($got !== $want) {
                $e[] = '公開候補: 帯の先頭から枠数ぶん取っていません（得た値 '
                     . json_encode($got) . ' / 期待値 ' . json_encode($want) . '）';
            }
            foreach ($horses as $h) {
                $no = (int) ($h['horse_no'] ?? 0);
                $isPub = (bool) ($h['public_candidate'] ?? false);
                if ($isPub !== in_array($no, $want, true)) {
                    $e[] = '公開候補: 馬番 ' . $no . ' の public_candidate が公開リストと合いません';
                }
                if ($isPub && ($h['nonselect_reason'] ?? null) !== null) {
                    $e[] = '公開候補: 選出馬 ' . $no . ' に nonselect_reason が付いています';
                }
                if (!$isPub && !is_array($h['nonselect_reason'] ?? null)) {
                    $e[] = '公開候補: 非選出馬 ' . $no . ' の nonselect_reason がオブジェクトではありません';
                }
            }
        }

        return $e;
    }
