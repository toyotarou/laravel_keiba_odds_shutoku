    /**
     * ═══════════════════════════════════════════════════════════════════════
     * @ANCHOR-20261021-R122-TOKENS  トークン数を課金ゼロで実測します
     * ═══════════════════════════════════════════════════════════════════════
     * 10月21日008のご指摘1：
     *   「金額は回数だけでは決まりません。実際のモデル名、入力・出力トークン、
     *     初回／訂正、キャッシュ等の内訳を付け、24回時と48回時の見積もりを
     *     お願いします。log/14の13頭入力でも本文は267,887バイトあります。
     *     バイト数をトークン数として扱わないでください。」
     *
     * ■ 課金は発生しません
     *   Anthropic の `POST /v1/messages/count_tokens` は<b>料金がかかりません</b>。
     *   出力を生成しないためです（1分あたりのリクエスト数の制限だけがあります）。
     *   本文の生成（/v1/messages）は<b>1回も呼びません</b>。
     *
     * ■ 何を数えるか
     *   ① 代表レースの初回の入力（system ＋ user）を role ごとに
     *   ② 正常出力14本（出力トークンの目安）
     *   ③ 訂正の入力（固定入力 ＋ 初回応答 ＋ 依頼文の3つの合計）
     *
     * ■ DeepSeek 側
     *   DeepSeek には無料のトークン計数APIがありません。
     *   ここでは本文を<b>ファイルへ書き出す</b>だけにして、
     *   公開トークナイザで別途数えます（これも課金ゼロです）。
     *
     * 読むだけです。DBへは1行も書きません。
     */
    private function runR122TokenCount(string $root): void
    {
        self::r122Autoload();
        $date = (string) ($this->option('date') ?: '2026-10-18');
        $outDir = rtrim((string) ($this->option('r122-token-out') ?: ''), '/');
        $this->info('════════════════════════════════════════════════════════');
        $this->info(' r12.2 トークン数の実測（課金ゼロ）');
        $this->info('════════════════════════════════════════════════════════');
        $this->line('  実行時刻 : ' . date('c'));
        $this->warn('  ※ 本文の生成（/v1/messages）は1回も呼びません');
        $this->warn('  ※ 使うのは count_tokens だけです（料金がかかりません）');
        $this->line('');

        $key = (string) (env('ANTHROPIC_API_KEY')
                      ?: config('services.anthropic.api_key'));
        if ($key === '') {
            $this->error('  × ANTHROPIC_API_KEY が読めません（.env をご確認ください）');
            return;
        }
        // ══════════════════════════════════════════════════════════════
        // @ANCHOR-20261021-R122-TWOMODELS  両モデルで数えます
        // ══════════════════════════════════════════════════════════════
        //   ・Haiku 5.5 の $0.10／$0.50 は<b>入力10万トークンまで</b>。
        //     10万を超えると、そのリクエスト全体が $0.50／$2.50 になります。
        //   ・Haiku 5.5 はトークナイザが違うので、同じ本文でも数が変わります。
        //     旧モデルの数値は使えません。モデルを指定して数え直します。
        //   count_tokens はモデルを指定して呼べます。料金はかかりません。
        $MODELS = [
            'claude-haiku-4-5' => [
                'name' => 'Haiku 4.5（いま使っているもの）',
                'ctx'  => 200000,
                // [長文のしきい値, 短文入力, 短文出力, 長文入力, 長文出力]
                'price' => [null, 1.00, 5.00, 1.00, 5.00],
            ],
            'claude-haiku-5-5' => [
                'name' => 'Haiku 5.5（新しいもの）',
                'ctx'  => 1000000,
                'price' => [100000, 0.10, 0.50, 0.50, 2.50],
            ],
        ];
        $only = trim((string) ($this->option('r122-token-model') ?: ''));
        if ($only !== '' && isset($MODELS[$only])) {
            $MODELS = [$only => $MODELS[$only]];
        }
        $this->line('  単価の公式確認日 : 2026年10月21日');
        foreach ($MODELS as $mid => $mi) {
            $pr = $mi['price'];
            $this->line(sprintf('    %-18s 上限 %s トークン／入力 $%.2f・出力 $%.2f%s',
                $mid, number_format($mi['ctx']), $pr[1], $pr[2],
                ($pr[0] === null) ? ''
                  : sprintf('（入力%sトークン超は $%.2f・$%.2f）',
                            number_format($pr[0]), $pr[3], $pr[4])));
        }
        $this->line('');
        $model = array_key_first($MODELS);

        // ── 数える道具（count_tokens は無料）──────────────────────────
        $count = function (string $system, string $user, ?string $m = null)
                 use ($key, &$model) {
            try {
                $res = \Illuminate\Support\Facades\Http::timeout(60)
                    ->withHeaders([
                        'x-api-key'         => $key,
                        'anthropic-version' => '2023-06-01',
                        'content-type'      => 'application/json',
                    ])->post('https://api.anthropic.com/v1/messages/count_tokens', [
                        'model'    => ($m ?? $model),
                        'system'   => $system,
                        'messages' => [['role' => 'user', 'content' => $user]],
                    ]);
                if ($res->failed()) {
                    return ['ok' => false,
                            'reason' => 'status=' . $res->status() . ' '
                                      . mb_strimwidth((string) $res->body(), 0, 120, '…')];
                }
                return ['ok' => true, 'tokens' => (int) $res->json('input_tokens')];
            } catch (\Throwable $e) {
                return ['ok' => false, 'reason' => $e->getMessage()];
            }
        };

        // ── 代表レースを選びます（頭数の多い順に3本）──────────────────
        $races = \DB::table('t_horse_odds_finder_races')
                   ->where('date', $date)->whereNotNull('num_horses')
                   ->orderByDesc('num_horses')->orderBy('basho')->orderBy('race')
                   ->get();
        $picked = []; $seenN = [];
        foreach ($races as $r) {
            $n = (int) $r->num_horses;
            if (isset($seenN[$n])) { continue; }
            $seenN[$n] = true; $picked[] = $r;
            if (count($picked) >= 3) { break; }
        }
        if ($picked === []) {
            $this->error('  × ' . $date . ' のレースがありません'); return;
        }

        $rows = [];
        $this->info('── ① 初回の入力（system ＋ user）をモデルごとに数えます ──');
        foreach ($picked as $r) {
            $raceId = \App\Http\Controllers\Api\AiController::r122RaceId($r->date, $r->kaisuu, $r->basho, $r->day, $r->race);
            $g = \App\Http\Controllers\Api\AiController::r122GatherContext($r->date, $r->kaisuu, $r->basho,
                                         $r->day, $r->race, ['assume_audit' => true]);
            if (!($g['ok'] ?? false)) {
                $this->line(sprintf('  － %-22s 入力を作れません（%s）',
                    $raceId, (string) ($g['code'] ?? '')));
                continue;
            }
            foreach (['1st', '2nd'] as $role) {
                $asm = \App\Http\Controllers\Api\BaganrikiPrompt::assemble($g['ctx'], $role);
                if (!($asm['ok'] ?? false)) { continue; }
                $sys = \App\Http\Controllers\Api\BaganrikiPrompt::systemBody($role);
                $sysBody = ($sys['ok'] ?? false) ? (string) $sys['body'] : '';
                $user = (string) $asm['user'];
                $n = (int) ($asm['input']['N'] ?? 0);
                if ($outDir !== '') {
                    @mkdir($outDir, 0775, true);
                    file_put_contents($outDir . '/input_' . $raceId . '_' . $role . '.json',
                                      $user);
                    file_put_contents($outDir . '/system_' . $role . '.txt', $sysBody);
                }
                $tk = [];
                foreach ($MODELS as $mid => $mi) {
                    $c = $count($sysBody, $user, $mid);
                    if (!$c['ok']) {
                        $this->error(sprintf('  × %-22s %-4s %-18s 数えられません：%s',
                            $raceId, $role, $mid, (string) $c['reason']));
                        continue;
                    }
                    $tk[$mid] = (int) $c['tokens'];
                }
                if ($tk === []) { continue; }
                $rows[] = ['race' => $raceId, 'n' => $n, 'role' => $role,
                           'bytes' => strlen($user) + strlen($sysBody),
                           'tok' => $tk];
                $this->line(sprintf('  %-22s N=%-3d %-4s  %9s バイト',
                    $raceId, $n, $role, number_format(strlen($user) + strlen($sysBody))));
                foreach ($tk as $mid => $v) {
                    $ctx = (int) $MODELS[$mid]['ctx'];
                    $this->line(sprintf('      %-18s %9s トークン  %s（上限 %s まで %+d）',
                        $mid, number_format($v),
                        ($v <= $ctx ? '○ 収まる' : '× 超える'),
                        number_format($ctx), $ctx - $v));
                }
                if (count($tk) === 2) {
                    $a = $tk['claude-haiku-4-5'] ?? 0;
                    $b = $tk['claude-haiku-5-5'] ?? 0;
                    if ($a > 0) {
                        $this->line(sprintf('      → 5.5 は 4.5 の %+.1f%%',
                            ($b - $a) / $a * 100));
                    }
                }
            }
            // ── 本文の内訳（なる様の6章：16頭と17頭で量が急増する理由）──
            $in1 = (array) (\App\Http\Controllers\Api\BaganrikiPrompt::assemble($g['ctx'], '1st')['input'] ?? []);
            $parts = [];
            foreach ($in1 as $k => $v) {
                $parts[$k] = strlen((string) json_encode($v,
                    JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES));
            }
            arsort($parts);
            $pastN = 0;
            foreach ((array) ($in1['source_registry'] ?? []) as $e) {
                if (strpos((string) ($e['ref'] ?? ''), '_past_') !== false) { $pastN++; }
            }
            $this->line(sprintf('      内訳：出走 %d 頭／source_registry %d 件'
                              . '（うち過去走の出典 %d 件）',
                $n, count((array) ($in1['source_registry'] ?? [])), $pastN));
            $top = array_slice($parts, 0, 5, true);
            $ps = [];
            foreach ($top as $k => $v) { $ps[] = $k . ' ' . number_format($v); }
            $this->line('      大きい順：' . implode('／', $ps));
        }
        $this->line('');

        // ══════════════════════════════════════════════════════════════
        // @ANCHOR-20261021-R122-CTXLIMIT  入力がモデルの上限に収まるか
        // ══════════════════════════════════════════════════════════════
        //   claude-haiku-4-5 のコンテキストウィンドウは 200,000 トークンです。
        //   実測で 18頭が 257,696 トークンだったので、<b>そのままでは
        //   送れません。</b>過去走を何走まで減らせば収まるかを測ります。
        //   ここも count_tokens だけなので料金はかかりません。
        $this->info('── ①-3 過去走を減らすと、どこまで下がるか ──');
        $this->line('  いちばん大きいレースについて、直近何走まで載せるかを変えて数えます。');
        $this->line('  訂正は「初回の入力 ＋ 初回応答 ＋ 依頼文」なので、その分を足して見ます。');
        // 初回応答の目安は②で数えますが、先にここで要るので仮に数えます
        $fixAdd = 0;
        $vDir0 = rtrim($root, '/') . '/validation/normal';
        $f0 = $vDir0 . '/MIXED_N16_1st_output.json';
        if (is_file($f0)) {
            $c0 = $count('', \App\Http\Controllers\Api\BaganrikiResponse::BEGIN
                 . trim((string) file_get_contents($f0))
                 . \App\Http\Controllers\Api\BaganrikiResponse::END);
            if ($c0['ok'] ?? false) { $fixAdd = (int) $c0['tokens'] + 165; }
        }
        $this->line('  足す分 : ' . number_format($fixAdd) . ' トークン'
                  . '（初回応答の目安 ＋ 依頼文165）');
        $big = null;
        foreach ($picked as $r) {
            if ($big === null || (int) $r->num_horses > (int) $big->num_horses) { $big = $r; }
        }
        if ($big !== null) {
            $keep = [getenv('BAGANRIKI_PAST_RUNS_MAX'),
                     $_ENV['BAGANRIKI_PAST_RUNS_MAX'] ?? null,
                     $_SERVER['BAGANRIKI_PAST_RUNS_MAX'] ?? null];
            $bigId = \App\Http\Controllers\Api\AiController::r122RaceId(
                $big->date, $big->kaisuu, $big->basho, $big->day, $big->race);
            $this->line('  対象 ' . $bigId . '（N=' . (int) $big->num_horses . '）');
            try {
                foreach ([5, 4, 3, 2, 1, 0] as $pm) {
                    putenv('BAGANRIKI_PAST_RUNS_MAX=' . $pm);
                    $_ENV['BAGANRIKI_PAST_RUNS_MAX'] = (string) $pm;
                    $_SERVER['BAGANRIKI_PAST_RUNS_MAX'] = (string) $pm;
                    $gp = \App\Http\Controllers\Api\AiController::r122GatherContext(
                        $big->date, $big->kaisuu, $big->basho, $big->day, $big->race,
                        ['assume_audit' => true]);
                    if (!($gp['ok'] ?? false)) { continue; }
                    $ap = \App\Http\Controllers\Api\BaganrikiPrompt::assemble($gp['ctx'], '1st');
                    if (!($ap['ok'] ?? false)) { continue; }
                    $sp = \App\Http\Controllers\Api\BaganrikiPrompt::systemBody('1st');
                    $spBody = ($sp['ok'] ?? false) ? (string) $sp['body'] : '';
                    $this->line(sprintf('    直近%d走  %9s バイト', $pm,
                        number_format(strlen((string) $ap['user']) + strlen($spBody))));
                    foreach ($MODELS as $mid => $mi) {
                        $cp = $count($spBody, (string) $ap['user'], $mid);
                        if (!($cp['ok'] ?? false)) {
                            $this->error(sprintf('      %-18s 数えられません：%s',
                                $mid, (string) $cp['reason']));
                            continue;
                        }
                        $tk = (int) $cp['tokens'];
                        // 訂正は「初回の入力＋初回応答＋依頼文」なので、その分を足して見ます
                        $fx = $tk + $fixAdd;
                        $ctx = (int) $mi['ctx'];
                        $this->line(sprintf('      %-18s 初回 %9s %s ／ 訂正 %9s %s',
                            $mid, number_format($tk),
                            ($tk <= $ctx ? '○' : '×'),
                            number_format($fx),
                            ($fx <= $ctx ? '○' : '×')));
                    }
                }
            } finally {
                if ($keep[0] === false) { putenv('BAGANRIKI_PAST_RUNS_MAX'); }
                else { putenv('BAGANRIKI_PAST_RUNS_MAX=' . $keep[0]); }
                if ($keep[1] === null) { unset($_ENV['BAGANRIKI_PAST_RUNS_MAX']); }
                else { $_ENV['BAGANRIKI_PAST_RUNS_MAX'] = $keep[1]; }
                if ($keep[2] === null) { unset($_SERVER['BAGANRIKI_PAST_RUNS_MAX']); }
                else { $_SERVER['BAGANRIKI_PAST_RUNS_MAX'] = $keep[2]; }
            }
            $this->line('  ※ いまの設定は BAGANRIKI_PAST_RUNS_MAX='
                      . \App\Http\Controllers\Api\AiController::r122PastRunsMax() . ' 走です（戻しました）');
        }
        $this->line('');

        // ── ② 出力トークンの目安（正常出力14本）────────────────────────
        $this->info('── ② 出力トークンの目安（配布された正常出力14本）──');
        $vDir = rtrim($root, '/') . '/validation/normal';
        $outTok = [];
        foreach (glob($vDir . '/*_output.json') as $f) {
            $body = (string) file_get_contents($f);
            $c = $count('', \App\Http\Controllers\Api\BaganrikiResponse::BEGIN . trim($body) . \App\Http\Controllers\Api\BaganrikiResponse::END);
            if (!$c['ok']) { continue; }
            $outTok[basename($f)] = (int) $c['tokens'];
        }
        if ($outTok !== []) {
            $vals = array_values($outTok);
            sort($vals);
            $this->line(sprintf('  本数 %d ／ 最小 %s ／ 中央 %s ／ 最大 %s トークン',
                count($vals), number_format($vals[0]),
                number_format($vals[intdiv(count($vals), 2)]),
                number_format($vals[count($vals) - 1])));
            foreach ($outTok as $k => $v) {
                $this->line(sprintf('    %-42s %7s', $k, number_format($v)));
            }
        } else {
            $this->warn('  正常出力を数えられませんでした（' . $vDir . '）');
        }
        $this->line('');

        // ── ③④ 12レースの見積もり（初回のみ／訂正込み）────────────────
        $this->info('── ③ 12レースの見積もり（モデル別・初回のみ／訂正込み）──');
        $this->line('  訂正の入力 ＝ 初回の入力 ＋ 初回応答 ＋ 依頼文165トークン');
        $this->line('  キャッシュは使っていません（cache_control を付けていません）');
        $this->line('  出力は「配布された正常出力14本で観測した中央値」です。');
        $this->warn('  ※ これから生成される出力の保証上限ではありません');
        $this->line('');
        $outMid = [];
        foreach ($MODELS as $mid => $mi) {
            $vals = [];
            foreach (glob($vDir . '/*_output.json') as $f) {
                $c = $count('', \App\Http\Controllers\Api\BaganrikiResponse::BEGIN
                     . trim((string) file_get_contents($f))
                     . \App\Http\Controllers\Api\BaganrikiResponse::END, $mid);
                if ($c['ok'] ?? false) { $vals[] = (int) $c['tokens']; }
            }
            sort($vals);
            $outMid[$mid] = $vals === [] ? 0 : $vals[intdiv(count($vals), 2)];
        }
        $priceOf = static function (array $mi, int $inTok): array {
            $p = $mi['price'];
            if ($p[0] !== null && $inTok > (int) $p[0]) {
                return [(float) $p[3], (float) $p[4], '長文側'];
            }
            return [(float) $p[1], (float) $p[2], '通常'];
        };
        foreach ($MODELS as $mid => $mi) {
            $ins = [];
            foreach ($rows as $w) {
                if ($w['role'] !== '1st') { continue; }
                if (isset($w['tok'][$mid])) { $ins[] = $w['tok'][$mid]; }
            }
            if ($ins === []) { continue; }
            $om  = (int) $outMid[$mid];
            $ctx = (int) $mi['ctx'];
            $this->info('  ' . $mid . '（' . $mi['name'] . '）');
            $this->line(sprintf('    出力の中央値 %s トークン／上限 %s トークン',
                number_format($om), number_format($ctx)));
            foreach ([['平均', (int) round(array_sum($ins) / count($ins))],
                      ['最大（18頭）', max($ins)]] as $pair) {
                [$lbl, $in1] = $pair;
                $inFix = $in1 + $om + 165;
                [$pi1, $po1, $t1] = $priceOf($mi, $in1);
                [$pi2, $po2, $t2] = $priceOf($mi, $inFix);
                $usdFirst = $in1 * 12 / 1e6 * $pi1 + $om * 12 / 1e6 * $po1;
                $usdFix   = $inFix * 12 / 1e6 * $pi2 + $om * 12 / 1e6 * $po2;
                $this->line(sprintf('    %-14s 初回 入力%s(%s) → $%.2f'
                                  . '／訂正 入力%s(%s) → $%.2f／合計 $%.2f',
                    $lbl, number_format($in1), $t1, $usdFirst,
                    number_format($inFix), $t2, $usdFix, $usdFirst + $usdFix));
                $this->line(sprintf('    %-14s 上限 : 初回 %s ／ 訂正 %s',
                    '', ($in1 <= $ctx ? '○' : '× 超える'),
                    ($inFix <= $ctx ? '○' : '× 超える')));
            }
            $this->line('');
        }
        $this->warn('  ※ これは 1st（Anthropic）だけの金額です。'
                  . '2nd（DeepSeek）は別に出します');
        $this->warn('  ※ 既存運用の呼び出し・10月25日・別日の事前試験は別枠です');
        $this->line('');
        if ($outDir !== '') {
            $this->info('  本文を書き出しました: ' . $outDir);
            $this->line('    （DeepSeek 側は、この本文を公開トークナイザで数えます）');
        }
        $this->line('');
        $this->info('════════════════════════════════════════════════════════');
        $this->info(' 実測しました（本文の生成は0回・DBへの書き込み0件）');
        $this->info('════════════════════════════════════════════════════════');
    }
