
    /**
     * ═══════════════════════════════════════════════════════════════════════
     * @ANCHOR-20261020-R122-QUEUE  送信の前に枠を予約します
     * ═══════════════════════════════════════════════════════════════════════
     * 根拠：server_contract_r12.2.txt 10章
     *   「予約commit後に送信し、原応答とcompleteをcommitしてから訂正を開始する」
     *
     * ■ 流れ
     *   ① 凍結入力（snapshot）を正本にします。無ければここで固定します。
     *   ② 送る本文の共通hashが、固定したものと同じかを確かめます。
     *      違えば送りません（固定後は変えない、が契約8章です）。
     *   ③ 枠（初回=0）を予約します。すでにあれば<b>送りません</b>。
     *   ④ 送信許可をもらいます（1回だけ）。
     *
     * ■ .env の BAGANRIKI_R122_QUEUE が 0（既定）のときは素通りします。
     *   そのときは skip=true を返し、呼出側は今までどおり送ります。
     *   1バイトも挙動が変わりません。
     *
     * ■ shadow のときは、ここで失敗しても<b>送信を止めません</b>。
     *   shadow=true を返すので、呼出側は記録だけ諦めて送ります。
     *   初めて実物で動かす日に、いまの商品を落とさないための段です。
     *
     * @return array ['skip'=>bool, 'ok'=>bool, 'code'=>?string, 'reason'=>?string,
     *                'token'=>?string, 'snapshot_id'=>?int]
     */
    public function r122QueueReserve($date, $kaisuu, $basho, $day, $race,
                                     string $role, array $asm): array
    {
        $out = ['skip' => true, 'ok' => false, 'code' => null, 'reason' => null,
                'token' => null, 'snapshot_id' => null, 'role' => $role,
                // @ANCHOR-20261020-R122-SHADOW  shadow のときは止めません
                'shadow' => false, 'mode' => BaganrikiWorker::mode()];
        if (!BaganrikiWorker::enabled()) { return $out; }
        $out['skip'] = false;
        $out['shadow'] = !BaganrikiWorker::blocking();
        if (!BaganrikiWorker::ready()) {
            $out['code']   = 'TABLE_MISSING';
            $out['reason'] = 'キューの表がありません（--r122-install で作ります）';
            return $out;
        }
        $raceId = self::r122RaceId($date, $kaisuu, $basho, $day, $race);

        try {
            // ① 凍結入力。本番は generation=0 だけを見ます（REPLAY は 900）
            $snap = \DB::table('baganriki_snapshots')
                      ->where('race_id', $raceId)->where('generation', 0)->first();
            if ($snap === null) {
                $fz = $this->r122Freeze($date, $kaisuu, $basho, $day, $race,
                                        [], 'PRODUCTION', false);
                if (!($fz['ok'] ?? false)) {
                    $out['code']   = (string) ($fz['code'] ?? 'FREEZE_FAILED');
                    $out['reason'] = (string) ($fz['reason'] ?? '凍結入力を作れません');
                    return $out;
                }
                $snap = \DB::table('baganriki_snapshots')
                          ->where('race_id', $raceId)->where('generation', 0)->first();
            }
            if ($snap === null) {
                $out['code']   = 'NO_SNAPSHOT';
                $out['reason'] = '凍結入力を読み戻せません';
                return $out;
            }

            // ② 固定した入力と送信文が同じものか
            if ((string) $snap->snapshot_hash !== (string) ($asm['snapshot_hash'] ?? '')) {
                $out['code']   = 'SNAPSHOT_MISMATCH';
                $out['reason'] = '固定した入力と送信文の共通hashが違います'
                               . '（固定後は変えません）';
                return $out;
            }

            // ③ 枠を予約（ライブと公開の版は見張ります。応答の版は
            //    予約そのもので増えるので見張りに入れません）
            $live = \DB::table('baganriki_live_states')
                      ->where('snapshot_id', $snap->id)->first();
            $expect = ($live === null) ? [] : [
                'state_revision'       => (int) $live->state_revision,
                'publication_revision' => (int) $live->publication_revision,
            ];
            $r = BaganrikiWorker::reserve((int) $snap->id, $role,
                                          BaganrikiWorker::FIRST,
                                          BaganrikiWorker::nowUs(), $expect);
            if (!$r['ok']) {
                $out['code']   = (string) $r['code'];
                $out['reason'] = (string) $r['reason'];
                $out['snapshot_id'] = (int) $snap->id;
                return $out;
            }

            // ④ 送信許可（1回だけ）
            $s = BaganrikiWorker::allowSend((string) $r['token'],
                                            BaganrikiWorker::nowUs());
            if (!$s['ok']) {
                $out['code']   = (string) $s['code'];
                $out['reason'] = (string) $s['reason'];
                $out['snapshot_id'] = (int) $snap->id;
                return $out;
            }

            $out['ok']    = true;
            $out['code']  = 'OK';
            $out['token'] = (string) $r['token'];
            $out['snapshot_id'] = (int) $snap->id;
            $out['reply_deadline'] = $r['reply_deadline'] ?? null;
            return $out;
        } catch (\Throwable $e) {
            $out['code']   = 'QUEUE_EXCEPTION';
            $out['reason'] = $e->getMessage();
            \Log::error('[R122-QUEUE] 予約で例外', [
                'race_id' => $raceId, 'role' => $role,
                'message' => $e->getMessage(),
                'at'      => $e->getFile() . ':' . $e->getLine(),
            ]);
            return $out;
        }
    }

    /**
     * ═══════════════════════════════════════════════════════════════════════
     * @ANCHOR-20261020-R122-DEADLINE  AIを待つ時間を応答期限から決めます
     * ═══════════════════════════════════════════════════════════════════════
     * 固定の秒数だと、2つとも困ったことになります。
     *   短すぎる … 期限まで余裕があるのに、こちらが先に切ってしまう
     *   長すぎる … 期限を過ぎてから返ってきて、遅着で捨てることになる
     * 予約がとれているときは、<b>応答期限まで残っている時間</b>から決めます。
     * 受領と公開のために 5秒だけ残します。
     *
     * 予約がない（旗が0）ときは、今までの秒数をそのまま使います。
     *
     * @param int   $fallback 予約が無いときに使う秒数（今までの値）
     * @param array|null $q   r122QueueReserve の戻り
     */
    public static function r122AiTimeout(int $fallback, ?array $q): int
    {
        if (!is_array($q) || ($q['skip'] ?? true) || !($q['ok'] ?? false)) {
            return $fallback;
        }
        $dl = BaganrikiTime::us((string) ($q['reply_deadline'] ?? ''));
        if ($dl === null) { return $fallback; }
        $left = (int) floor(($dl - BaganrikiWorker::nowUs()) / 1000000) - 5;
        if ($left < 20)  { return 20; }    // これ以下は待っても無駄なので下限
        if ($left > 170) { return 170; }   // 応答期限（発走150秒前）を超えて待ちません
        return $left;
    }

    /**
     * @ANCHOR-20261020-R122-QUEUE  受け取った原応答を枠へ保存します。
     *   同じ応答を2回保存しても冪等です。別の応答は保存しません。
     *   complete=false の本文は、そのまま残して選出には使いません。
     */
    public function r122QueueReceive(array $q, string $raw, bool $complete): array
    {
        if (($q['skip'] ?? true) || !($q['ok'] ?? false)) {
            return ['skip' => true, 'ok' => false];
        }
        try {
            $r = BaganrikiWorker::receive((string) $q['token'], $raw, $complete,
                                          BaganrikiWorker::nowUs());
            if (!$r['ok']) {
                \Log::error('[R122-QUEUE] 原応答を保存できません', [
                    'role' => $q['role'] ?? null, 'snapshot_id' => $q['snapshot_id'] ?? null,
                    'code' => $r['code'], 'reason' => $r['reason'],
                ]);
            } else {
                \Log::info('[R122-QUEUE] 原応答を保存しました', [
                    'role' => $q['role'] ?? null, 'snapshot_id' => $q['snapshot_id'] ?? null,
                    'code' => $r['code'], 'complete' => $complete,
                    'response_hash' => $r['response_hash'] ?? null,
                ]);
            }
            return $r;
        } catch (\Throwable $e) {
            \Log::error('[R122-QUEUE] 受領で例外', ['message' => $e->getMessage()]);
            return ['skip' => false, 'ok' => false, 'code' => 'QUEUE_EXCEPTION',
                    'reason' => $e->getMessage()];
        }
    }

    /**
     * @ANCHOR-20261020-R122-QUEUE  枠を終端にします。
     *   $unknown=true は「結果が分からない」です。再送しないための印です。
     *   通信が切れた・待ち時間で切れた場合はこちらを使います
     *   （向こうに届いているかどうかが分からないためです）。
     */
    public function r122QueueFail(array $q, string $reason, bool $unknown = false): array
    {
        if (($q['skip'] ?? true) || !($q['ok'] ?? false)) {
            return ['skip' => true, 'ok' => false];
        }
        try {
            $r = BaganrikiWorker::fail((string) $q['token'], $reason,
                                       BaganrikiWorker::nowUs(), $unknown);
            \Log::error('[R122-QUEUE] 枠を終端にしました', [
                'role' => $q['role'] ?? null, 'snapshot_id' => $q['snapshot_id'] ?? null,
                'status' => $r['status'] ?? null, 'unknown' => $unknown,
                'reason' => $reason,
            ]);
            return $r;
        } catch (\Throwable $e) {
            \Log::error('[R122-QUEUE] 終端で例外', ['message' => $e->getMessage()]);
            return ['skip' => false, 'ok' => false, 'code' => 'QUEUE_EXCEPTION',
                    'reason' => $e->getMessage()];
        }
    }
