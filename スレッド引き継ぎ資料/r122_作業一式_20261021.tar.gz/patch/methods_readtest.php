
    /**
     * ═══════════════════════════════════════════════════════════════════════
     * @ANCHOR-20261020-R122-API  読取APIの通し試験
     * ═══════════════════════════════════════════════════════════════════════
     * ■ 何を確かめるか
     *   1. 本番の世代（generation=0）だけを読み、REPLAY（900）を出さないこと
     *   2. 3つの版（state／response／publication）を返すこと
     *   3. ワーカーの状態を返し、<b>予約token と原応答を返さない</b>こと
     *   4. 正式公開の枠は動かさず、いまの取消は actual_quota と
     *      available_candidate_count にだけ映すこと
     *   5. 表示状態（PENDING／PUBLISHED／UNAVAILABLE／CANCELLED）
     *   6. 暫定では星を出さないこと、購入推奨が常に false であること
     *
     * ■ 書き込みについて
     *   全部ひとつのトランザクションで行い、最後に必ずロールバックします。
     */
    private function runR122ReadTest(string $root): void
    {
        self::r122Autoload();
        $vDir = rtrim($root, '/') . '/validation/normal';
        $this->info('════════════════════════════════════════════════════════');
        $this->info(' r12.2 読取APIの通し試験');
        $this->info('════════════════════════════════════════════════════════');
        $this->line('  実行時刻 : ' . date('c'));
        $this->warn('  ※ 全部ロールバックします。DBへ残る書き込みは0件です');
        $this->line('');
        foreach (['MIXED_N16_1st_input.json', 'MIXED_N16_1st_output.json',
                  'MIXED_N16_2nd_input.json', 'MIXED_N16_2nd_output.json'] as $f) {
            if (!is_file($vDir . '/' . $f)) {
                $this->error('  × ' . $vDir . '/' . $f . ' がありません');
                return;
            }
        }
        $pass = 0; $fail = 0;
        $check = function (string $id, string $what, $got, $want) use (&$pass, &$fail) {
            $okk = ($got === $want);
            if ($okk) { $pass++; } else { $fail++; }
            $this->line(sprintf('  %s %-9s %-50s %s',
                $okk ? '○' : '×', $id, $what,
                $okk ? '' : ('得=' . var_export($got, true) . ' 期待=' . var_export($want, true))));
        };
        $rd = static fn(string $f) => json_decode((string) file_get_contents($f), true);
        $j  = static fn($v) => (string) json_encode($v,
            JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PRESERVE_ZERO_FRACTION);
        $in1  = $rd($vDir . '/MIXED_N16_1st_input.json');
        $in2  = $rd($vDir . '/MIXED_N16_2nd_input.json');
        $out1 = $rd($vDir . '/MIXED_N16_1st_output.json');
        $out2 = $rd($vDir . '/MIXED_N16_2nd_output.json');
        $BEGIN = \App\Http\Controllers\Api\BaganrikiResponse::BEGIN;
        $END   = \App\Http\Controllers\Api\BaganrikiResponse::END;
        $WK    = \App\Http\Controllers\Api\BaganrikiWorker::class;

        $r = \DB::table('t_horse_odds_finder_races')->where('date', '2026-10-18')
                ->orderBy('basho')->orderBy('race')->first();
        if ($r === null) { $this->error('  × 2026-10-18 のレースがありません'); return; }
        $raceId = \App\Http\Controllers\Api\AiController::r122RaceId(
            $r->date, $r->kaisuu, $r->basho, $r->day, $r->race);
        $this->line('  対象レース : ' . $raceId);
        $this->line('');

        $ok = true;
        \DB::beginTransaction();
        try {
            $ctrl = app(\App\Http\Controllers\Api\AiController::class);
            $now   = $WK::nowUs();
            $sales = $now + 3600 * 1000000;
            $nums  = [];
            foreach ((array) $in1['runners'] as $x) { $nums[] = (int) $x['horse_no']; }

            $mkSnap = function (int $gen) use ($raceId, $in1, $in2, $nums, $sales,
                                               $now, $j, $WK): int {
                return (int) \DB::table('baganriki_snapshots')->insertGetId([
                    'race_id' => $raceId, 'generation' => $gen,
                    'run_id' => 'AT-' . $gen,
                    'snapshot_hash'   => (string) $in1['snapshot_hash'],
                    'input_json_1st'  => $j($in1), 'input_json_2nd' => $j($in2),
                    'frozen_nums'     => $j($nums),
                    'allocation_mode' => (string) $in1['allocation_mode'],
                    'mode'            => ($gen === 0) ? 'MIXED' : 'REPLAYMODE',
                    'mode_status'     => (string) $in1['mode_status'],
                    'mode_policy_id'  => (string) $in1['mode_policy_id'],
                    'display_rating'  => 3,
                    'target_count'    => (int) $in1['target_count'],
                    'quota_1st'       => $j($in1['quota']),
                    'coverage'        => $j(['past_runs' => ['status' => 'INCLUDED']]),
                    'collection_audit' => $j(['6' => ['status' => 'ADOPTED']]),
                    'input_freeze_at' => $WK::toDb($now - 100),
                    'sales_close_at'  => $WK::toDb($sales),
                    'created_at'      => $WK::toDb($now),
                ]);
            };
            // REPLAY を先に入れて、公開APIが拾わないことを見ます
            $sid900 = $mkSnap(900);
            $sid0   = $mkSnap(0);
            \DB::table('baganriki_live_states')->insert([
                'snapshot_id' => $sid0, 'cancellations' => $j([]),
                'active_count' => count($nums),
                'live_target_count' => (int) $in1['target_count'],
                'live_quota' => $j($in1['quota']), 'live_close' => null,
                'state_revision' => 0, 'response_revision' => 0,
                'publication_revision' => 0, 'latest_publication_id' => null,
                'updated_at' => $WK::toDb($now),
            ]);
            foreach ([['1st', $out1], ['2nd', $out2]] as $pair) {
                [$role, $doc] = $pair;
                \DB::table('baganriki_ai_attempts')->insert([
                    'snapshot_id' => $sid0, 'role' => $role, 'attempt_no' => 0,
                    'token' => hash('sha256', 'AT' . $sid0 . $role),
                    'status' => $WK::RECEIVED,
                    'reserved_at' => $WK::toDb($now), 'received_at' => $WK::toDb($now),
                    'complete' => 1, 'raw_response' => $BEGIN . $j($doc) . $END,
                    'response_hash' => hash('sha256', $j($doc)),
                ]);
            }

            // ── ① 未公開（期限内）──────────────────────────────────
            $this->info('── ① 未公開（期限内）──');
            $d = $ctrl->getBaganrikiR122Race($raceId)->getData(true);
            $check('A-01', '期限内・未公開は PENDING', $d['state'], 'PENDING');
            $check('A-02', 'REPLAY の世代を読まない', $d['mode'], 'MIXED');
            $check('A-03', '確定なら星を出す', $d['display_rating'], 3);
            $check('A-04', '購入推奨は常に false', $d['buy_recommended'], false);
            $check('A-05', '学習段階は COLLECT_ONLY', $d['learning_stage'], 'COLLECT_ONLY');
            $check('A-06', 'model_version は null', $d['model_version'], null);
            $check('A-07', '3つの版を返す',
                   [$d['live_state']['state_revision'],
                    $d['live_state']['response_revision'],
                    $d['live_state']['publication_revision']], [0, 0, 0]);
            $ws = (array) ($d['worker_state'] ?? []);
            $check('A-08', 'ワーカーの状態を2枠ぶん返す', count($ws), 2);
            $keys = ($ws === []) ? [] : array_keys($ws[0]);
            $check('A-09', '予約token を返さない',
                   in_array('token', $keys, true), false);
            $check('A-10', '原応答を返さない',
                   in_array('raw_response', $keys, true), false);
            $check('A-11', '未公開では公開欄が null', $d['publication'], null);

            // ── ② 公開したあと ────────────────────────────────────
            $this->info('── ② 公開したあと ──');
            $p = $ctrl->r122Publish($sid0);
            $check('A-12', '公開できる', $p['code'], 'PUBLISHED');
            $d = $ctrl->getBaganrikiR122Race($raceId)->getData(true);
            $check('A-13', '公開済みは PUBLISHED', $d['state'], 'PUBLISHED');
            $check('A-14', '公開IDが一致',
                   (string) $d['publication']['publication_id'],
                   (string) $p['publication_id']);
            $pq = (array) $d['publication']['publication_quota'];
            $check('A-15', '公開した枠がそのまま入る', $pq, (array) $p['quota']);
            $check('A-16', 'いまの枠も同じ（取消なし）',
                   (array) $d['live_state']['actual_quota'], $pq);
            $check('A-17', '公開候補の数', $d['live_state']['available_candidate_count'],
                   count($p['candidates']));
            $check('A-18', 'publication_revision が1になる',
                   $d['live_state']['publication_revision'], 1);

            // ── ③ 取消を入れる（正式公開は動かさない）──────────────
            $this->info('── ③ 取消を入れる ──');
            $gone = (int) $p['candidates'][0]['horse_no'];
            $goneBand = (string) $p['candidates'][0]['band'];
            \DB::table('baganriki_live_states')->where('snapshot_id', $sid0)->update([
                'cancellations' => $j([$gone]),
                'active_count'  => count($nums) - 1,
                'state_revision' => 1,
            ]);
            $d = $ctrl->getBaganrikiR122Race($raceId)->getData(true);
            $check('A-19', '正式公開の枠は動かさない',
                   (array) $d['publication']['publication_quota'], $pq);
            $want = $pq; $want[$goneBand] = (int) $want[$goneBand] - 1;
            $check('A-20', 'いまの枠は取消を映す',
                   (array) $d['live_state']['actual_quota'], $want);
            $check('A-21', '公開候補の数も1つ減る',
                   $d['live_state']['available_candidate_count'],
                   count($p['candidates']) - 1);
            $check('A-22', '取消の馬番を返す',
                   (array) $d['live_state']['cancellations'], [$gone]);
            $check('A-23', '状態は PUBLISHED のまま', $d['state'], 'PUBLISHED');

            // ── ④ 全頭取消 ────────────────────────────────────────
            $this->info('── ④ 全頭取消 ──');
            \DB::table('baganriki_live_states')->where('snapshot_id', $sid0)->update([
                'cancellations' => $j($nums), 'active_count' => 0,
            ]);
            $d = $ctrl->getBaganrikiR122Race($raceId)->getData(true);
            $check('A-24', '全頭取消は CANCELLED', $d['state'], 'CANCELLED');

            // ── ⑤ 未公開で期限超過 ────────────────────────────────
            $this->info('── ⑤ 未公開で期限超過 ──');
            \DB::table('baganriki_publications')->where('snapshot_id', $sid0)->delete();
            \DB::table('baganriki_live_states')->where('snapshot_id', $sid0)->update([
                'cancellations' => $j([]), 'active_count' => count($nums),
            ]);
            \DB::table('baganriki_snapshots')->where('id', $sid0)->update([
                'sales_close_at' => $WK::toDb($now - 7200 * 1000000),
            ]);
            $d = $ctrl->getBaganrikiR122Race($raceId)->getData(true);
            $check('A-25', '未公開で期限超過は UNAVAILABLE', $d['state'], 'UNAVAILABLE');
            $check('A-26', '実効公開期限を返す',
                   is_string($d['live_state']['effective_publish_deadline']), true);

            // ── ⑥ 暫定のときの表示 ────────────────────────────────
            $this->info('── ⑥ 暫定のときの表示 ──');
            \DB::table('baganriki_snapshots')->where('id', $sid0)->update([
                'mode_status' => 'PROVISIONAL', 'mode' => 'UNKNOWN',
                'sales_close_at' => $WK::toDb($sales),
            ]);
            $d = $ctrl->getBaganrikiR122Race($raceId)->getData(true);
            $check('A-27', '暫定では星を出さない', $d['display_rating'], null);
            $check('A-28', '暫定の表示文を出す',
                   (string) ($d['provisional']['label'] ?? ''), '混戦として暫定選出');
            $check('A-29', '暫定の理由を出す',
                   (string) ($d['provisional']['note'] ?? ''),
                   \App\Http\Controllers\Api\BaganrikiPublicView::PROVISIONAL_NOTE);

            // ══════════════════════════════════════════════════════
            // @ANCHOR-20261021-R122-READGATE  非公開の読取経路（010の7章⑤）
            // ══════════════════════════════════════════════════════
            //   【見つかったこと】この読取APIには認証が1つも掛かって
            //   いませんでした。画面側にも誰にでも見える「r12.2」の
            //   ボタンが出ています。旗を上げた瞬間、12レースの予想が
            //   一般の利用者に見えます。
            //   既定で閉じるようにしたので、そのとおりかを見ます。
            //   （web からの呼び出しとみなす指定を使います。
            //     コマンドからは素通りするので、そのままでは試せません）
            $this->info('── ⑥ 非公開の読取経路（010の7章⑤）──');
            $A2 = \App\Http\Controllers\Api\AiController::class;

            $g1 = $A2::r122ReadGate(['force_web' => true, 'key' => '']);
            $check('A-30', '鍵が未設定なら、web からは中身を見せない',
                   [$g1['ok'], (string) $g1['code']], [false, 'NOT_PUBLIC']);
            $check('A-31', '既定の段は key（閉じる側）',
                   (string) $g1['mode'], 'key');
            $g2 = $A2::r122ReadGate();
            $check('A-32', 'コマンドからは素通りする（試験が落ちないため）',
                   [$g2['ok'], (string) $g2['code']], [true, 'CONSOLE']);

            // 鍵を設定したときの動き
            putenv('BAGANRIKI_R122_READ_KEY=qt-secret-20261021');
            $g3 = $A2::r122ReadGate(['force_web' => true, 'key' => 'chigau']);
            $check('A-33', '鍵が違えば見せない',
                   [$g3['ok'], (string) $g3['code']], [false, 'NOT_PUBLIC']);
            $g4 = $A2::r122ReadGate(['force_web' => true, 'key' => '']);
            $check('A-34', '鍵を渡さなければ見せない', $g4['ok'], false);
            $g5 = $A2::r122ReadGate(['force_web' => true,
                                     'key' => 'qt-secret-20261021']);
            $check('A-35', '鍵が合えば見せる',
                   [$g5['ok'], (string) $g5['code']], [true, 'KEY']);

            // 段を open にしたとき
            putenv('BAGANRIKI_R122_READ=open');
            $g6 = $A2::r122ReadGate(['force_web' => true, 'key' => '']);
            $check('A-36', 'open なら鍵なしでも見せる',
                   [$g6['ok'], (string) $g6['code']], [true, 'OPEN']);

            // 段を off にしたとき（鍵があっても見せない）
            putenv('BAGANRIKI_R122_READ=off');
            $g7 = $A2::r122ReadGate(['force_web' => true,
                                     'key' => 'qt-secret-20261021']);
            $check('A-37', 'off なら鍵が合っていても見せない',
                   [$g7['ok'], (string) $g7['code']], [false, 'NOT_PUBLIC']);

            // 知らない値は、閉じる側へ倒す
            putenv('BAGANRIKI_R122_READ=hoge');
            $g8 = $A2::r122ReadGate(['force_web' => true, 'key' => '']);
            $check('A-38', '知らない設定値は閉じる側へ倒す',
                   [(string) $g8['mode'], $g8['ok']], ['key', false]);

            // 試験で触った環境変数を元へ戻します
            putenv('BAGANRIKI_R122_READ');
            putenv('BAGANRIKI_R122_READ_KEY');
            $g9 = $A2::r122ReadGate(['force_web' => true, 'key' => '']);
            $check('A-39', '戻したあとも既定は閉じる',
                   [(string) $g9['mode'], $g9['ok']], ['key', false]);

            // ══════════════════════════════════════════════════════
            // @ANCHOR-20261021-R122-READGATE200  画面が壊れない返し方
            // ══════════════════════════════════════════════════════
            //   画面側（Flutter）の client.dart は 2xx 以外を全部例外に
            //   します。404 で返すと、画面に
            //     「読めませんでした Exception: http 404 [url=https://…]」
            //   と生のエラー文字列とURLが出ます。
            //   なので 200 で、いつもの形のまま断ります。
            //   画面は diagnostics をそのまま並べるので、
            //   「この記録はまだ公開していません」と読める形で出ます。
            $resp = $ctrl->getBaganrikiR122Race($raceId);
            $check('A-40', 'コマンドからは中身が読める（素通り）',
                   (int) $resp->getStatusCode(), 200);
            $dd = $resp->getData(true);
            $check('A-41', '返す形はいつもどおり（race_id と state がある）',
                   [array_key_exists('race_id', (array) $dd),
                    array_key_exists('state', (array) $dd)], [true, true]);
        } catch (\Throwable $e) {
            $ok = false; $fail++;
            $this->error('  × 例外: ' . $e->getMessage());
            $this->error('     ' . $e->getFile() . ':' . $e->getLine());
        } finally {
            putenv('BAGANRIKI_R122_READ');
            putenv('BAGANRIKI_R122_READ_KEY');
            \DB::rollBack();
        }

        $this->line('');
        $this->line(sprintf('  ロールバック後  snapshot %d／公開 %d／attempts %d',
            \DB::table('baganriki_snapshots')->count(),
            \DB::table('baganriki_publications')->count(),
            \DB::table('baganriki_ai_attempts')->count()));
        $this->line('');
        $this->line('  判定件数 : ' . ($pass + $fail) . ' 件');
        $this->line('  合格     : ' . $pass . ' 件');
        $this->line('  不合格   : ' . $fail . ' 件');
        $this->line('');
        $this->info('════════════════════════════════════════════════════════');
        $this->info(($fail === 0 && $ok)
            ? ' 読取APIは契約どおりに返しました（DBへ残る書き込み0件）'
            : ' 通らなかった箇所があります。上の × をご確認ください');
        $this->info('════════════════════════════════════════════════════════');
    }
