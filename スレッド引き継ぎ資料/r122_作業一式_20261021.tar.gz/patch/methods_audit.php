
    /**
     * ═══════════════════════════════════════════════════════════════════════
     * @ANCHOR-20261020-R122-AUDIT  いまの実時刻（マイクロ秒まで）
     * ═══════════════════════════════════════════════════════════════════════
     * DATETIME(6) へそのまま入れられる形で返します。
     * サーバのタイムゾーン（JST）のままです。
     */
    private static function r122Now(): string
    {
        return (new \DateTimeImmutable('now'))->format('Y-m-d H:i:s.u');
    }

    /**
     * ═══════════════════════════════════════════════════════════════════════
     * @ANCHOR-20261020-R122-AUDIT  取得監査を1行残す（お願い②・A案）
     * ═══════════════════════════════════════════════════════════════════════
     * 根拠：server_contract_r12.2.txt 4章・8章／詳細設計書 4.3
     *
     * ■ 残すもの
     *   batch_id              同じ応答バッチの一意ID
     *   slot                  発走までの分（21/18/15/12/9/6。30・3・0も残します）
     *   slot_scheduled_at     発走時刻から slot 分を引いた予定時刻
     *   source_updated_at     取得元の更新時刻。取れないので null のままです
     *   request_started_at    要求を出した実時刻
     *   response_received_at  受信し終えた実時刻（＝ observed_at）
     *   available_at          保存が終わって読めると確かめた実時刻
     *   raw_payload           受け取った原文そのもの（加工しません）
     *   payload_hash          原文の SHA-256
     *   validation_result     ADOPTED / REJECTED
     *   committed             1 のものだけを採用します
     *
     * ■ やらないこと
     *   ・既存の列や元値を書き換えません。新しいテーブルへ INSERT するだけです。
     *   ・時刻を予定時刻で埋めません。取れないものは null のままにします。
     *   ・ここで失敗しても本番を止めません。ログに残してそのまま進みます
     *     （記録できなかったバッチは committed=0 のまま＝採用されません）。
     *
     * ■ 止め方
     *   .env に BAGANRIKI_R122_AUDIT=0 を入れると記録しません。
     *   テーブルが無い環境では何もしません（--r122-install で作ります）。
     */
    private function r122RecordBatch($race, int $diff, array $v): void
    {
        try {
            $sw = (string) env('BAGANRIKI_R122_AUDIT', '1');
            if (in_array($sw, ['0', 'false', 'off', 'no'], true)) {
                return;
            }
            if (!\Illuminate\Support\Facades\Schema::hasTable('baganriki_acquisition_batches')) {
                return;
            }

            $raceId = \App\Http\Controllers\Api\AiController::r122RaceId(
                $race->date, $race->kaisuu, $race->basho, $race->day, $race->race);

            // 予定時刻は「発走時刻 − slot分」。実時刻の代わりには使いません。
            $anchor = strtotime("{$race->date} {$race->start_time}");
            $slotScheduledAt = ($anchor === false) ? null
                : date('Y-m-d H:i:s.000000', $anchor - $diff * 60);

            $raw  = (string) ($v['raw_payload'] ?? '');
            $hash = ($raw === '') ? null : hash('sha256', $raw);

            // batch_id は UNIQUE。同じレース・同じスロットで撮り直したときも
            // 別の行として残るように、実時刻と乱数を混ぜます。
            $batchId = $raceId . '-' . $diff . '-'
                     . date('YmdHis') . '-' . substr(bin2hex(random_bytes(4)), 0, 8);

            \Illuminate\Support\Facades\DB::table('baganriki_acquisition_batches')->insert([
                'race_id'              => $raceId,
                'slot'                 => $diff,
                'batch_id'             => $batchId,
                'slot_scheduled_at'    => $slotScheduledAt,
                'source_updated_at'    => null,   // 取得元の更新時刻は取れません
                'request_started_at'   => $v['request_started_at']   ?? null,
                'response_received_at' => $v['response_received_at'] ?? null,
                'available_at'         => $v['available_at']         ?? null,
                'raw_payload'          => ($raw === '') ? null : $raw,
                'payload_hash'         => $hash,
                'validation_result'    => $v['validation_result'] ?? null,
                'rejection_reason'     => $v['rejection_reason']  ?? null,
                'committed'            => (int) ($v['committed'] ?? 0),
                'created_at'           => self::r122Now(),
            ]);

            $this->info(sprintf('  [r12.2監査] %s slot=%d %s hash=%s',
                $raceId, $diff, (string) ($v['validation_result'] ?? ''),
                ($hash === null) ? '(なし)' : substr($hash, 0, 12)));
        } catch (\Throwable $e) {
            // 記録できなくても本番は止めません。採用もされません。
            $this->warn('  [r12.2監査] 記録できませんでした: ' . $e->getMessage());
            \Log::warning('[R122-AUDIT] 取得監査を記録できませんでした', [
                'date' => $race->date ?? null, 'race' => $race->race ?? null,
                'slot' => $diff, 'err' => $e->getMessage(),
            ]);
        }
    }
