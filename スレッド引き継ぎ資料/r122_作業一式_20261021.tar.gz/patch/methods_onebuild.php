
    /**
     * ═══════════════════════════════════════════════════════════════════════
     * @ANCHOR-20261020-R122-ONEBUILD  固定入力をそのまま送る通し試験
     * ═══════════════════════════════════════════════════════════════════════
     * 根拠：10月20日007のご指摘2（最優先）
     *
     * ■ 何を確かめるか
     *   「保存した入力をそのまま使い、両roleが送信予約まで通ること」です。
     *   なるさんから出た必要な試験を、そのまま並べました。
     *     ・派生値を含む入力を保存し、時間を進めても、両roleの送信本文が
     *       保存本文と一致する
     *     ・snapshotが無い初回から、凍結→予約→送信直前まで通る
     *     ・snapshotがある2ndも、再計算せず同じ固定入力で予約できる
     *     ・実AIを使わなくても、送信口の手前まで検証できる
     *
     *   あわせて、<b>直す前の壊れ方そのもの</b>も試験にしました。
     *   作り直す側（r122AssembleFresh）を2回呼ぶと共通hashが変わります。
     *   変わることが悪いのではなく、<b>それを送信経路で使っていたこと</b>が
     *   問題でした。送信経路は保存物しか読まない、という対比を出します。
     *
     * ■ 書き込みについて
     *   <b>全部ひとつのトランザクションで行い、最後に必ずロールバックします。</b>
     *   DBへ残る書き込みは0件です。実AIは呼びません。
     */
    private function runR122OneBuildTest(): void
    {
        self::r122Autoload();
        $date = (string) ($this->option('date') ?: '2026-10-18');
        $this->info('════════════════════════════════════════════════════════');
        $this->info(' r12.2 固定入力をそのまま送る（007のご指摘2）');
        $this->info('════════════════════════════════════════════════════════');
        $this->line('  実行時刻 : ' . date('c'));
        $this->warn('  ※ 監査行は試験用に作ったものです（実開催の実時刻ではありません）');
        $this->warn('  ※ 全部ロールバックします。DBへ残る書き込みは0件です');
        $this->warn('  ※ 実AIは呼びません');
        $this->line('');

        $A = \App\Http\Controllers\Api\AiController::class;
        $T = \App\Http\Controllers\Api\BaganrikiTime::class;
        $W = \App\Http\Controllers\Api\BaganrikiWorker::class;

        $r = \DB::table('t_horse_odds_finder_races')->where('date', $date)
                ->orderBy('basho')->orderBy('race')->first();
        if ($r === null) { $this->error('  × 対象レースがありません: ' . $date); return; }
        $raceId = $A::r122RaceId($r->date, $r->kaisuu, $r->basho, $r->day, $r->race);
        $st = (string) $r->start_time;
        if (strlen($st) === 5) { $st .= ':00'; }
        $anchorUs = $T::us($r->date . 'T' . $st . '+09:00');
        if ($anchorUs === null) { $this->error('  × 発走時刻を読めません'); return; }
        $this->line('  対象レース : ' . $raceId . '  発走 ' . $st);
        $this->line('');

        $pass = 0; $fail = 0;
        $check = function (string $id, string $what, $got, $want) use (&$pass, &$fail) {
            $okk = ($got === $want);
            if ($okk) { $pass++; } else { $fail++; }
            $this->line(sprintf('  %s %-8s %-54s %s',
                $okk ? '○' : '×', $id, $what,
                $okk ? '' : ('得=' . var_export($got, true)
                           . ' 期待=' . var_export($want, true))));
        };

        // 取得監査の行を作ります（--r122-acq-test と同じ作り方）
        $toDb = static function (int $us): string {
            return (new \DateTimeImmutable('@' . intdiv($us, 1000000)))
                ->setTimezone(new \DateTimeZone('Asia/Tokyo'))
                ->format('Y-m-d H:i:s') . sprintf('.%06d', $us % 1000000);
        };
        $rows = [];
        foreach ($T::INPUT_SLOTS as $slot) {
            $pl = [];
            foreach (\DB::table('t_horse_odds_finder_odds')
                        ->where('date', $r->date)->where('kaisuu', $r->kaisuu)
                        ->where('basho', $r->basho)->where('day', $r->day)
                        ->where('race', (int) $r->race)
                        ->where('minutes_before_start', $slot)
                        ->orderBy('num')->get(['num','odds','fuku_min','fuku_max']) as $o) {
                $pl[] = ['num' => (int) $o->num, 'tan' => (string) $o->odds,
                         'fuku_min' => (string) $o->fuku_min,
                         'fuku_max' => (string) $o->fuku_max];
            }
            if ($pl === []) { continue; }
            $raw = (string) json_encode($pl, JSON_UNESCAPED_UNICODE);
            $sch = $T::slotScheduled($anchorUs, $slot);
            $rows[] = [
                'race_id' => $raceId, 'slot' => $slot,
                'batch_id' => 'ONEBUILD-' . $raceId . '-' . $slot . '-'
                            . substr(bin2hex(random_bytes(3)), 0, 6),
                'slot_scheduled_at'    => $toDb($sch),
                'source_updated_at'    => null,
                'request_started_at'   => $toDb($sch + 500000),
                'response_received_at' => $toDb($sch + 1500000),
                'available_at'         => $toDb($sch + 2500000),
                'raw_payload'          => $raw,
                'payload_hash'         => hash('sha256', $raw),
                'validation_result'    => 'ADOPTED',
                'rejection_reason'     => null,
                'committed'            => 1,
                'created_at'           => $toDb($sch + 2500000),
            ];
        }
        if ($rows === []) { $this->error('  × 監査行を1件も作れません'); return; }

        // 旗を一時的に動かします（終わったら必ず戻します）
        $keep = [];
        foreach (['BAGANRIKI_R122_PROMPT', 'BAGANRIKI_R122_QUEUE'] as $k) {
            $keep[$k] = [getenv($k), $_ENV[$k] ?? null, $_SERVER[$k] ?? null];
        }
        $setEnv = static function (string $k, string $v) {
            putenv($k . '=' . $v); $_ENV[$k] = $v; $_SERVER[$k] = $v;
        };

        $ok = true;
        \DB::beginTransaction();
        try {
            $setEnv('BAGANRIKI_R122_PROMPT', '1');
            $setEnv('BAGANRIKI_R122_QUEUE', '1');
            \DB::table('baganriki_acquisition_batches')->insert($rows);
            $this->info('── ① 監査行を入れました（' . count($rows) . ' 件）──');

            $ctrl = app($A);

            // ══════════════════════════════════════════════════════════
            // ② 1回目。固定入力が無いので、ここで1回だけ作ります
            // ══════════════════════════════════════════════════════════
            $this->info('── ② 1回目の組み立て（固定入力を作ります）──');
            $a1 = $ctrl->r122AssembleSend($r->date, $r->kaisuu, $r->basho,
                                          $r->day, $r->race, '1st');
            if (!($a1['ok'] ?? false)) {
                $ok = false;
                $this->error('  × 1回目が作れません: ' . ($a1['code'] ?? '')
                           . ' ' . ($a1['reason'] ?? ''));
            } else {
                $this->line('  snapshot_hash : ' . $a1['snapshot_hash']);
                $this->line('  user bytes    : ' . $a1['user_bytes']);
                foreach ((array) ($a1['notes'] ?? []) as $nt) {
                    $this->line('  note          : ' . $nt);
                }
            }
            $check('Y-01', '1回目で固定入力ができる', $a1['ok'] ?? false, true);
            $check('Y-02', '保存物から読んだ印が立つ', $a1['from_saved'] ?? null, true);

            $snapRow = \DB::table('baganriki_snapshots')
                         ->where('race_id', $raceId)->where('generation', 0)->first();
            $check('Y-03', '固定入力が1件だけできている',
                (int) \DB::table('baganriki_snapshots')->where('race_id', $raceId)
                         ->where('generation', 0)->count(), 1);
            $check('Y-04', '保存された本文と送信本文のバイト列が同じ',
                (string) ($snapRow->input_json_1st ?? ''), (string) ($a1['user'] ?? ''));
            $check('Y-05', '保存された共通hashと送信本文の共通hashが同じ',
                (string) ($snapRow->snapshot_hash ?? ''),
                (string) ($a1['snapshot_hash'] ?? ''));

            // ══════════════════════════════════════════════════════════
            // ③ 時間を進めてから2回目。作り直さないので1バイトも変わりません
            // ══════════════════════════════════════════════════════════
            $this->info('── ③ 時間を進めてから2回目（作り直しません）──');
            usleep(1100000);                      // 1.1秒。派生の計算時刻が変わる間隔です
            $a1b = $ctrl->r122AssembleSend($r->date, $r->kaisuu, $r->basho,
                                           $r->day, $r->race, '1st');
            $check('Y-06', '2回目も作れる', $a1b['ok'] ?? false, true);
            $check('Y-07', '2回目の本文が1回目と1バイトも違わない',
                (string) ($a1b['user'] ?? 'x'), (string) ($a1['user'] ?? 'y'));
            $check('Y-08', '2回目の共通hashが1回目と同じ',
                (string) ($a1b['snapshot_hash'] ?? 'x'),
                (string) ($a1['snapshot_hash'] ?? 'y'));
            $check('Y-09', '2回目は固定入力を作り直していない',
                (int) \DB::table('baganriki_snapshots')->where('race_id', $raceId)
                         ->where('generation', 0)->count(), 1);

            // ══════════════════════════════════════════════════════════
            // ④ 2nd も同じ固定入力から。再計算しません
            // ══════════════════════════════════════════════════════════
            $this->info('── ④ 2nd も同じ固定入力から ──');
            $a2 = $ctrl->r122AssembleSend($r->date, $r->kaisuu, $r->basho,
                                          $r->day, $r->race, '2nd');
            $check('Y-10', '2nd も作れる', $a2['ok'] ?? false, true);
            $check('Y-11', '2nd も保存物から読んでいる', $a2['from_saved'] ?? null, true);
            $check('Y-12', '2nd の共通hashが 1st と同じ',
                (string) ($a2['snapshot_hash'] ?? 'x'),
                (string) ($a1['snapshot_hash'] ?? 'y'));
            $check('Y-13', '2nd の本文が保存された 2nd の本文と同じ',
                (string) ($snapRow->input_json_2nd ?? ''), (string) ($a2['user'] ?? ''));
            $check('Y-14', '2nd の ai_role が 2nd になっている',
                (string) ((array) ($a2['input'] ?? []))['ai_role'] ?? '', '2nd');

            // ══════════════════════════════════════════════════════════
            // ⑤ 送信予約が hash 不一致で止まらないこと
            // ══════════════════════════════════════════════════════════
            $this->info('── ⑤ 送信予約（SNAPSHOT_MISMATCH で止まらないこと）──');
            $q1 = $ctrl->r122QueueReserve($r->date, $r->kaisuu, $r->basho,
                                          $r->day, $r->race, '1st', $a1);
            $this->line('  1st の予約 : code=' . (string) ($q1['code'] ?? '')
                      . '  ' . (string) ($q1['reason'] ?? ''));
            $check('Y-15', '1st の予約が hash 不一致で止まらない',
                ((string) ($q1['code'] ?? '') === 'SNAPSHOT_MISMATCH'), false);
            $q2 = $ctrl->r122QueueReserve($r->date, $r->kaisuu, $r->basho,
                                          $r->day, $r->race, '2nd', $a2);
            $this->line('  2nd の予約 : code=' . (string) ($q2['code'] ?? '')
                      . '  ' . (string) ($q2['reason'] ?? ''));
            $check('Y-16', '2nd の予約も hash 不一致で止まらない',
                ((string) ($q2['code'] ?? '') === 'SNAPSHOT_MISMATCH'), false);
            $this->warn('  ※ このレースは発走がとうに過ぎているので、');
            $this->warn('     予約そのものは期限の理由で断られます。それが正しい動きです。');
            $this->warn('     ここで見たいのは「hash が合わないせいで断られていないこと」です。');

            // ══════════════════════════════════════════════════════════
            // ⑥ 直す前の壊れ方（作り直す側は、呼ぶたびに hash が変わる）
            // ══════════════════════════════════════════════════════════
            $this->info('── ⑥ 作り直す側は呼ぶたびに変わります（だから送信に使いません）──');
            $f1 = $ctrl->r122AssembleFresh($r->date, $r->kaisuu, $r->basho,
                                           $r->day, $r->race, '1st');
            usleep(1100000);
            $f2 = $ctrl->r122AssembleFresh($r->date, $r->kaisuu, $r->basho,
                                           $r->day, $r->race, '1st');
            $this->line('  作り直し1回目 : ' . substr((string) ($f1['snapshot_hash'] ?? ''), 0, 24));
            $this->line('  作り直し2回目 : ' . substr((string) ($f2['snapshot_hash'] ?? ''), 0, 24));
            $check('Y-17', '作り直す側は2回で共通hashが変わる（これが前回の原因）',
                ((string) ($f1['snapshot_hash'] ?? 'a')
                 === (string) ($f2['snapshot_hash'] ?? 'b')), false);
            $check('Y-18', '作り直す側には保存物の印が立たない',
                $f1['from_saved'] ?? null, false);
            $a1c = $ctrl->r122AssembleSend($r->date, $r->kaisuu, $r->basho,
                                           $r->day, $r->race, '1st');
            $check('Y-19', '作り直しても、送信経路の本文は動かない',
                (string) ($a1c['snapshot_hash'] ?? 'x'),
                (string) ($a1['snapshot_hash'] ?? 'y'));
            $check('Y-20', '固定入力はいまも1件のまま',
                (int) \DB::table('baganriki_snapshots')->where('race_id', $raceId)
                         ->where('generation', 0)->count(), 1);

        } catch (\Throwable $e) {
            $ok = false; $fail++;
            $this->error('  × 例外: ' . $e->getMessage());
            $this->error('     ' . $e->getFile() . ':' . $e->getLine());
        } finally {
            \DB::rollBack();
            foreach ($keep as $k => $v) {
                if ($v[0] === false) { putenv($k); } else { putenv($k . '=' . $v[0]); }
                if ($v[1] === null) { unset($_ENV[$k]); } else { $_ENV[$k] = $v[1]; }
                if ($v[2] === null) { unset($_SERVER[$k]); } else { $_SERVER[$k] = $v[2]; }
            }
        }

        $this->line('');
        $this->line(sprintf('  ロールバック後  監査 %d 件／snapshot %d 件／attempts %d 件',
            (int) \DB::table('baganriki_acquisition_batches')->count(),
            (int) \DB::table('baganriki_snapshots')->count(),
            (int) \DB::table('baganriki_ai_attempts')->count()));
        $this->line('');
        $this->line('  判定件数 : ' . ($pass + $fail) . ' 件');
        $this->line('  合格     : ' . $pass . ' 件');
        $this->line('  不合格   : ' . $fail . ' 件');
        $this->line('');
        $this->info('════════════════════════════════════════════════════════');
        $this->info(($fail === 0 && $ok)
            ? ' 固定入力をそのまま送れました（DBへ残る書き込み0件）'
            : ' 通らなかった箇所があります。上の × をご確認ください');
        $this->info('════════════════════════════════════════════════════════');
    }
