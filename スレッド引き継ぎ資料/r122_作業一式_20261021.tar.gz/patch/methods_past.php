
    /**
     * ═══════════════════════════════════════════════════════════════════════
     * @ANCHOR-20261020-R122-PAST  過去走を source_registry へ載せます
     * ═══════════════════════════════════════════════════════════════════════
     * 根拠：server_contract_r12.2.txt 3章・5章
     *   「past_runs は coverage で INCLUDED または理由付き UNAVAILABLE を
     *     必須記録。利用できるデータを黙って捨てない」
     *
     * ■ 正本
     *   t_horse_odds_finder_shutsuba_history（馬名で引きます）
     *   対象レースの<b>開催日より前</b>のレースだけを使います。
     *   同じ日・後の日のものは入れません（結果の先読みを防ぎます）。
     *
     * ■ 情報上限
     *   その行を<b>いつ手に入れたか</b>で切ります。
     *   created_at と updated_at の<b>遅いほう</b>を available_at とし、
     *   情報上限（入力の凍結時刻）より後のものは載せません。
     *   後から取り直した内容で過去のレースを評価しないためです。
     *
     * ■ observed_at について
     *   過去走の行には発走時刻がありません。
     *   <b>無い時刻を作らない</b>ので、observed_at には
     *   「こちらが手に入れた時刻」を入れ、
     *   そのレースの開催日は past_date として別の項目で渡します。
     *
     * ■ 1頭あたり直近5走まで（.env で変えられます）
     *   生の事実（着順・頭数・人気・距離・馬場・上がり3F・着差・開催日）と、
     *   そこから出した3つのまとめ（走数・最高着順・3着内率）を載せます。
     *
     *   BAGANRIKI_PAST_RUNS_MAX  既定 5（0〜10）。
     *   <b>0 にすると過去走を載せません。</b>
     *   送信文が長くなると応答時間も伸びます。応答期限は発走の150秒前なので、
     *   実測を見てここで絞れるようにしてあります。
     *
     * @param array $nums   馬番 => 馬名
     * @return array ['registry'=>..., 'coverage'=>['past_runs'=>...]]
     */
    public static function r122PastRunsRegistry(string $raceId, string $date,
                                                array $nums, ?string $freezeAt): array
    {
        // @ANCHOR-20261020-R122-DERIVEDAT  1回の組み立てで1つの計算時刻にします
        //   （同じ組み立ての中で時刻がばらつくと、snapshot_hash が揺れます）
        $buildAt = BaganrikiPrompt::rfc3339(BaganrikiWorker::nowUs());
        $empty = static fn(string $why) => ['registry' => [],
            'coverage' => ['past_runs' => ['status' => 'UNAVAILABLE', 'reason' => $why]]];

        if (!\Schema::hasTable('t_horse_odds_finder_shutsuba_history')) {
            return $empty('過去走の表（shutsuba_history）がありません');
        }
        $names = [];
        foreach ($nums as $no => $nm) {
            $nm = trim((string) $nm);
            if ($nm !== '') { $names[trim((string) $nm)][] = (int) $no; }
        }
        if ($names === []) {
            return $empty('出馬表に馬名がありません');
        }

        $max = self::r122PastRunsMax();
        if ($max <= 0) {
            return $empty('.env の BAGANRIKI_PAST_RUNS_MAX が 0 のため載せていません');
        }
        $freezeUs = ($freezeAt === null) ? null : BaganrikiTime::us($freezeAt);
        $add = []; $refs = []; $late = null; $used = 0;

        // 馬名ごとに、対象レースより前の開催日のものを新しい順で取ります
        $rows = \DB::table('t_horse_odds_finder_shutsuba_history')
                  ->whereIn('name', array_keys($names))
                  ->where('date', '<', $date)
                  ->orderBy('name')->orderByDesc('date')->orderBy('race')
                  ->get(['name', 'date', 'basho_code', 'race', 'grade',
                         'finishing_position', 'num_horses', 'gate', 'popularity',
                         'dist', 'time', 'condition', 'last_3f', 'fin_time_diff',
                         'created_at', 'updated_at']);

        $byName = [];
        foreach ($rows as $r) {
            $byName[(string) $r->name][] = $r;
        }

        foreach ($names as $nm => $horseNos) {
            $list = $byName[$nm] ?? [];
            if ($list === []) { continue; }
            foreach ($horseNos as $no) {
                $i = 0; $fin = []; $parents = []; $avail = null;
                foreach ($list as $r) {
                    if ($i >= $max) { break; }
                    // 手に入れた時刻（created_at と updated_at の遅いほう）
                    $cAt = self::r122DbTime($r->created_at);
                    $uAt = self::r122DbTime($r->updated_at);
                    $av  = $cAt;
                    if ($uAt !== null && ($av === null || strcmp($uAt, $av) > 0)) { $av = $uAt; }
                    if ($av === null) { continue; }
                    if ($freezeUs !== null) {
                        $au = BaganrikiTime::us($av);
                        if ($au === null || $au > $freezeUs) {
                            if ($late === null || strcmp($av, (string) $late) < 0) { $late = $av; }
                            continue;
                        }
                    }
                    $i++;
                    if ($avail === null || strcmp($av, $avail) > 0) { $avail = $av; }

                    $pdate = substr((string) $r->date, 0, 10);
                    $vals = [
                        'past_date'       => ['v' => $pdate,                        'u' => 'date'],
                        'past_finish'     => ['v' => self::r122IntOrNull($r->finishing_position), 'u' => 'rank'],
                        'past_num_horses' => ['v' => self::r122IntOrNull($r->num_horses),         'u' => 'horses'],
                        'past_popularity' => ['v' => self::r122IntOrNull($r->popularity),         'u' => 'rank'],
                        'past_dist'       => ['v' => self::r122StrOrNull($r->dist),      'u' => 'text'],
                        'past_condition'  => ['v' => self::r122StrOrNull($r->condition), 'u' => 'text'],
                        'past_last_3f'    => ['v' => self::r122StrOrNull($r->last_3f),   'u' => 'second'],
                        'past_time_diff'  => ['v' => self::r122StrOrNull($r->fin_time_diff), 'u' => 'second'],
                    ];
                    foreach ($vals as $f => $x) {
                        if ($x['v'] === null) { continue; }
                        $ref = 'h' . $no . '_' . $f . '_' . $i;
                        $add[$ref] = [
                            'source_ref'           => $ref,
                            'race_id'              => $raceId,
                            'value'                => $x['v'],
                            'scope'                => 'HORSE',
                            'horse_nos'            => [(int) $no],
                            'applicable_horse_nos' => [],
                            'field'                => $f . '_' . $i,
                            'unit'                 => $x['u'],
                            'slot_offset'          => null,
                            // 過去走の行に発走時刻はありません。
                            // 無い時刻は作らず、手に入れた時刻を入れます。
                            'observed_at'          => $av,
                            'available_at'         => $av,
                            'computed_at'          => null,
                            'source_kind'          => 'OBSERVED',
                            'parents'              => [],
                            'formula_id'           => null,
                            'formula_version'      => null,
                            'dependency_key'       => 'h' . $no . '_past_' . $i,
                            'dependency_role'      => 'CONTEXT',
                        ];
                        $refs[] = $ref;
                        $parents[] = $ref;
                    }
                    $f0 = self::r122IntOrNull($r->finishing_position);
                    if ($f0 !== null && $f0 > 0) { $fin[] = $f0; }
                }
                if ($i === 0 || $avail === null || $parents === []) { continue; }
                $used++;

                // ── まとめ（走数・最高着順・3着内率）────────────────────
                $sum = [
                    'past_runs_count' => ['v' => $i, 'u' => 'races'],
                ];
                if ($fin !== []) {
                    $top3 = 0;
                    foreach ($fin as $x) { if ($x <= 3) { $top3++; } }
                    $sum['past_best_finish'] = ['v' => min($fin), 'u' => 'rank'];
                    // 割り切れるときに整数へ落ちないよう、十進数の文字列で渡します
                    $sum['past_top3_rate'] = [
                        'v' => number_format($top3 / count($fin), 4, '.', ''),
                        'u' => 'ratio',
                    ];
                }
                foreach ($sum as $f => $x) {
                    $ref = 'h' . $no . '_' . $f;
                    $add[$ref] = [
                        'source_ref'           => $ref,
                        'race_id'              => $raceId,
                        'value'                => $x['v'],
                        'scope'                => 'HORSE',
                        'horse_nos'            => [(int) $no],
                        'applicable_horse_nos' => [],
                        'field'                => $f,
                        'unit'                 => $x['u'],
                        'slot_offset'          => null,
                        'observed_at'          => $avail,
                        'available_at'         => $avail,
                        // @ANCHOR-20261020-R122-DERIVEDAT  006のご指摘4-2
                        //   【旧】今回まとめた値なのに、過去走を手に入れた時刻を
                        //     computed_at に入れていました。実際の計算時刻ではありません。
                        'computed_at'          => $buildAt,
                        'source_kind'          => 'DERIVED',
                        'parents'              => array_values(array_unique($parents)),
                        'formula_id'           => 'PAST_RUNS_SUMMARY',
                        'formula_version'      => 'v1',
                        'dependency_key'       => 'h' . $no . '_past_summary',
                        'dependency_role'      => 'CONTEXT',
                    ];
                    $refs[] = $ref;
                }
            }
        }

        if ($refs === []) {
            $why = '対象レースより前の過去走が見つかりませんでした';
            if ($late !== null) {
                $why = '過去走は情報上限より後に手に入れたものしかありません'
                     . '（いちばん早い取得時刻 ' . $late
                     . '／情報上限 ' . ($freezeAt ?? '不明') . '）。'
                     . '後から取り直した内容で過去のレースを評価しないためです。';
            }
            return $empty($why);
        }
        $refs = array_values(array_unique($refs));
        sort($refs, SORT_STRING);
        return [
            'registry' => $add,
            'coverage' => ['past_runs' => ['status' => 'INCLUDED', 'source_refs' => $refs]],
            'horses_with_past' => $used,
        ];
    }

    /**
     * @ANCHOR-20261020-R122-PAST  1頭あたり何走まで載せるか
     *   既定5。0 で載せません。10 を超える指定は10に丸めます。
     *   送信文の長さと応答時間の兼ね合いで絞れるようにしています。
     */
    public static function r122PastRunsMax(): int
    {
        $v = env('BAGANRIKI_PAST_RUNS_MAX', null);
        if ($v === null || !is_numeric((string) $v)) { return 5; }
        $n = (int) $v;
        if ($n < 0)  { return 0; }
        if ($n > 10) { return 10; }
        return $n;
    }

    /** @ANCHOR-20261020-R122-PAST  整数として読めるときだけ整数を返します */
    public static function r122IntOrNull($v): ?int
    {
        if ($v === null) { return null; }
        $s = trim((string) $v);
        if ($s === '' || !preg_match('/^-?\d+$/', $s)) { return null; }
        return (int) $s;
    }

    /** @ANCHOR-20261020-R122-PAST  空でない文字列のときだけ返します */
    public static function r122StrOrNull($v): ?string
    {
        if ($v === null) { return null; }
        $s = trim((string) $v);
        return ($s === '') ? null : $s;
    }
