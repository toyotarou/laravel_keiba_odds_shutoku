# -*- coding: utf-8 -*-
"""@ANCHOR-20261020-R122-PROMPT  SummaryAiAnalysisCompensate.php への追補"""
import io, sys, os, hashlib
p = sys.argv[1]
src = io.open(p, encoding='utf-8').read()
orig = src
if '@ANCHOR-20261020-R122-PROMPT' in src:
    print('すでに当たっています（何もしません）: ' + p); sys.exit(0)

def rep(old, new, why, count=1):
    global src
    n = src.count(old)
    assert n == count, '%s: 見つかった数 %d（期待 %d）' % (why, n, count)
    src = src.replace(old, new, count)

# 1) オプションの登録
rep("""                           . ' {--r122-exact-check : 本番側（AiControllerのv0.4判定）と検証側（--mode-check）の信号が全レースで一致するか突き合わせる。--mode-check と併用（読み取りだけ・AI呼び出し0回）}';""",
    """                           . ' {--r122-exact-check : 本番側（AiControllerのv0.4判定）と検証側（--mode-check）の信号が全レースで一致するか突き合わせる。--mode-check と併用（読み取りだけ・AI呼び出し0回）}'
                           // @ANCHOR-20261020-R122-PROMPT  r12.2の両AI本文（1st・2nd）の全文置換
                           . ' {--r122-prompt-install= : 配布された両AI本文3本（prompt_1st.txt / prompt_2nd.txt / common_prompt.txt）をstorageへ設置し、マーカー・版・差し込み記号を確かめる。promptsフォルダのパスを渡す}'
                           . ' {--r122-prompt-check= : r12.2の送信文（system全文＋INPUT_JSON）を組み立て、先方の参照入力14本・同梱スキーマと突き合わせる。送付資料のルート（prompts/schemas/validationを含む）を渡す（AIへは送らない・費用0円・DB書込なし）}'
                           . ' {--r122-prompt-dump= : 組み立てた送信文（system本文とINPUT_JSON）をこのフォルダへ書き出す}'
                           . ' {--r122-prompt-real : 本番DBの保存済みレースで送信文を組み立てられるか試す。--r122-prompt-check と --date= を併用（読み取りだけ・AI呼び出し0回）}'
                           . ' {--r122-prompt-assume : 取得監査の実時刻を予定時刻で仮置きして送信文の形まで確かめる（本番送信には使わない）。--r122-prompt-real と併用}'
                           . ' {--r122-prompt-sales-offset= : 投票締切を「発走のN秒前」として仮置きする（正本ではない。契約11.2のため本番送信はしない）。--r122-prompt-real と併用}'
                           // @ANCHOR-20261020-R122-AUDIT  お願い②（A案）の取得監査
                           . ' {--r122-audit-check : 取得監査の記録の経路を確かめる（テーブル・列・マイクロ秒・読み戻し）。試し書きは必ずロールバックするのでDBへ残る書き込みは0件。--date= と併用}'
                           // @ANCHOR-20261020-R122-INVALID  異常例32本（入力23・出力9）
                           . ' {--r122-invalid-cases= : 異常例32本を Schema と 意味検証 に分けて判定し、先方の期待と突き合わせる。送付資料のルートを渡す（読み取りだけ・AI呼び出し0回）}'
                           // @ANCHOR-20261020-R122-FREEZE  凍結入力の保存
                           . ' {--r122-freeze : 保存済みレースの凍結入力（snapshot）を作って保存する。--date= と併用。--r122-freeze-dry で書かずに結果だけ見る}'
                           . ' {--r122-freeze-dry : --r122-freeze を1行も書かずに試す}'
                           // @ANCHOR-20261020-R122-ACQFIX  監査行からの通し試験
                           . ' {--r122-acq-test : 取得側と同じ形の監査行を作り、採用バッチの選定→INPUT_JSON→凍結保存→読戻しまで本番の経路で通す。すべてロールバックするのでDBへ残る書き込みは0件。--date= と併用}'
                           // @ANCHOR-20261020-R122-FP  元値の指紋（切り捨ての起きない方法）
                           . ' {--r122-fingerprint= : 元値の指紋を、主キー順の逐次SHA-256で出す（長さ付きの列表現・主キー集合も別hash・一貫した読取）。前回のJSONのパスを渡すと突き合わせる。読むだけ・書き込み0件}'
                           // @ANCHOR-20261020-R122-33R  33レースの候補比較
                           . ' {--r122-33races : 暫定選出になるレースについて、保存済みの全頭評価をそのまま両側へ当てて候補の違いを出す（再評価なし・読み取りだけ）。--date= と併用。CSVへ書き出す}'
                           // @ANCHOR-20261020-R122-QUEUE  キューと永続予約
                           . ' {--r122-queue-test : キューと永続予約（初回0・訂正1の2枠、重複送信の防止、再起動の後始末）が契約どおりか通しで確かめる。すべてロールバックするのでDBへ残る書き込みは0件}'
                           // @ANCHOR-20261020-R122-ONEBUILD  固定入力の通し試験（007の2）
                           . ' {--r122-onebuild-test : 固定した入力をそのまま両roleへ送れるか（作り直していないか）を通しで確かめる。--date= と併用。実AIは呼ばない。すべてロールバックする}'
                           // @ANCHOR-20261021-R122-TOKENS  008のご指摘1（費用）
                           . ' {--r122-token-count= : トークン数を課金ゼロで実測する。count_tokens だけを使い、本文の生成は1回も呼ばない。送付資料ルートのパスを渡す。読むだけ}'
                           . ' {--r122-token-out= : 実測した本文の書き出し先（DeepSeek側を公開トークナイザで数えるため）}'
                           . ' {--r122-token-model= : 数えるモデルを1つに絞る（既定は claude-haiku-4-5 と claude-haiku-5-5 の両方）}'
                           // @ANCHOR-20261020-R122-WIRETEST  007のE（実起動経路）
                           . ' {--r122-wire-test= : 送信口（Httpクライアント）を偽応答に差し替え、初回→検証→訂正→解決→公開を本番の関数で通す。片側失敗・通信不能・途中切れ・応答期限到達・公開期限到達・プロセス停止後の復旧・上限前呼出しも通す。送付資料ルートのパスを渡す。実AIは1回も呼ばない。すべてロールバックする}'
                           // @ANCHOR-20261021-R122-E2E  実凍結から一続きの通し試験（010の5章末尾）
                           . ' {--r122-e2e-test= : 実在レースの出馬表・オッズから監査行を作り、発走時刻を10分後へ寄せて、締切を渡さずに導出させ、キャッシュ後の入口が呼ぶ関数で実凍結し、期限の幅を1つずつ確かめ、送信口を偽応答に差し替えて初回→検証→訂正→採否→公開まで本番の関数で通す。3,600秒の決め打ちはしない。送付資料ルートのパスを渡す。実AIは1回も呼ばない。すべてロールバックする}'
                           // @ANCHOR-20261021-R122-TYPETEST  型保持の通し試験（010の3章）
                           . ' {--r122-type-test= : JSONの型（数値／文字列、オブジェクト／配列、整数／小数／指数）を、診断→訂正比較→保存→読戻しまで落とさずに通せることを確かめる。010の3-5の6例をすべて含む。型の地図を渡さない場合に何を見逃すかも並べて出す。送付資料ルートのパスを渡す。実AIは1回も呼ばない。すべてロールバックする}'
                           // @ANCHOR-20261021-R122-JOBTEST  Job構成の通し試験（010の2章）
                           . ' {--r122-job-test : Job構成（凍結・role・集計・実状態の4本）が、どの待ち行列へどの引数で積まれるかをjobs表の行から確かめる。秒数の整合（Jobの上限・retry_after・HTTPの上限）、経路の固定、対象レースの限定、実状態の変更（取消は足すだけ・締切は前倒しだけ）も見る。workerは立てず、Jobは1本も実行しない。実AIは1回も呼ばない。すべてロールバックする}'
                           // @ANCHOR-20261020-R122-WIRE  再起動後のやり直し（006の6-4）
                           . ' {--r122-sweep : 原応答を保存したあと訂正・公開が始まらないまま止まったレースを拾い、訂正判定と公開だけやり直す。初回の送信はしない。1分おきのcronに入れてよい}'
                           // @ANCHOR-20261020-R122-SWEEPWATCH  007の6-2（期限での起動）
                           . ' {--r122-sweep-watch= : --r122-sweep を、この秒数のあいだ繰り返す（既定55秒）。1分おきのcronでも、応答期限から公開期限までの30秒を取りこぼさないため}'
                           . ' {--r122-sweep-interval= : --r122-sweep-watch のときの間隔（秒。既定5）}'
                           // @ANCHOR-20261020-R122-RESP  応答検証と局所回復
                           . ' {--r122-response-test= : 正常出力14本を本番の経路（extract→封筒→隔離→診断）へ通し、局所回復と訂正（最大1回）を確かめる。送付資料ルートのパスを渡す。すべてロールバックする}'
                           // @ANCHOR-20261020-R122-PUB  統合・公開・intent・revision
                           . ' {--r122-publish-test= : 両roleの検証済み応答を統合して公開し、intentの再実行・版の見張り・期限・加点の証明を確かめる。送付資料ルートのパスを渡す。すべてロールバックする}'
                           // @ANCHOR-20261020-R122-API  読取API
                           . ' {--r122-read-test= : 読取APIが返す中身（3つの版・ワーカーの状態・いまの取消を映した枠・表示状態）を確かめる。送付資料ルートのパスを渡す。すべてロールバックする}'
                           // @ANCHOR-20261020-R122-PAST  本番の経路で作った入力をSchemaに当てる
                           . ' {--r122-prod-input= : 実レースについて本番と同じ経路でINPUT_JSONを作り、入力Schemaとsource_registry Schemaに当て、coverage7区分と過去走の件数を並べる。送付資料ルートのパスを渡す。読むだけ}'
                           // @ANCHOR-20261020-R122-MARKETTEST  OPIと推定確定オッズの通し試験
                           . ' {--r122-market-test= : OPI・複勝OPI・推定確定オッズ・推定確定複勝最小・予測補正OPIを、実レースの実オッズで載せ、SQLから取り直した値と突き合わせる。載らない側（当日を含む集計）と載る側（期間が終わっている集計）の両方を通す。送付資料ルートのパスを渡す。読むだけ}'
                           . ' {--as-of= : --r122-market-test で「仮の開催日」をこの日として呼ぶ（既定は集計期間の終わりの7日後）。動かすのは開催日と情報上限だけで、オッズ・集計表・式はそのまま}'
                           // @ANCHOR-20261020-R122-NATIVE  合成試験と取消の例を本体へ直接通す
                           . ' {--r122-native-test= : 合成729件を本体 v04Classify へ、取得境界4件を本体 acceptBatch へ直接通す。取消で目標数Cが変わる例（16→15・14→13・9→8・全頭取消）と、正本の発走時刻との一致検査・日時の繰上がり検査も本体で確かめる。送付資料ルートのパスを渡す。読むだけ}';""",
    'オプションの登録')

# @ANCHOR-20261020-R122-IDLECAP  クラス定数（旗が下りているときの空回しの上限）
rep("""class SummaryAiAnalysisCompensate extends Command
{""",
    """class SummaryAiAnalysisCompensate extends Command
{
    // ══════════════════════════════════════════════════════════════════
    // @ANCHOR-20261020-R122-IDLECAP  旗が下りているときの空回しの上限（秒）
    // ══════════════════════════════════════════════════════════════════
    //   --r122-sweep --r122-sweep-watch=55 を毎分の cron に入れると、
    //   枠の段が off の間は<b>55秒眠るだけのPHPが毎分立ち続けます。</b>
    //   仕事は何もしません。ただ常駐するだけです。
    //   刻みを見せるのが目的なので、2回まわれば足ります。
    //   旗が shadow か 1 のときは本当に拾いに行くので、打ち切りません。
    private const R122_IDLE_WATCH_MAX_SEC = 10;
""",
    'IDLECAP のクラス定数')

# 2) dispatch
rep("""        // @ANCHOR-20261020-R122CASES  r12.2の合成試験（先方の期待値との突き合わせ）
        if ($this->option('r122-cases')) {""",
    """        // @ANCHOR-20261020-R122-NATIVE  合成試験と取消の例を本体へ直接通す
        if ($this->hasOption('r122-native-test')
            && $this->option('r122-native-test') !== null) {
            $this->runR122Native((string) $this->option('r122-native-test'));
            return;
        }

        // @ANCHOR-20261020-R122-MARKETTEST  OPIと推定確定オッズの通し試験
        if ($this->hasOption('r122-market-test')
            && $this->option('r122-market-test') !== null) {
            $this->runR122MarketTest((string) $this->option('r122-market-test'));
            return;
        }

        // @ANCHOR-20261020-R122-PAST  本番の経路で作った入力をSchemaに当てる
        if ($this->hasOption('r122-prod-input')
            && $this->option('r122-prod-input') !== null) {
            $this->runR122ProdInput((string) $this->option('r122-prod-input'));
            return;
        }

        // @ANCHOR-20261020-R122-API  読取API
        if ($this->hasOption('r122-read-test')
            && $this->option('r122-read-test') !== null) {
            $this->runR122ReadTest((string) $this->option('r122-read-test'));
            return;
        }

        // @ANCHOR-20261020-R122-PUB  統合・公開・intent・revision
        if ($this->hasOption('r122-publish-test')
            && $this->option('r122-publish-test') !== null) {
            $this->runR122PublishTest((string) $this->option('r122-publish-test'));
            return;
        }

        // @ANCHOR-20261020-R122-RESP  応答検証と局所回復
        if ($this->hasOption('r122-response-test')
            && $this->option('r122-response-test') !== null) {
            $this->runR122ResponseTest((string) $this->option('r122-response-test'));
            return;
        }

        // @ANCHOR-20261020-R122-QUEUE  キューと永続予約
        if ((bool) $this->option('r122-queue-test')) {
            $this->runR122QueueTest();
            return;
        }

        // @ANCHOR-20261020-R122-ONEBUILD  固定入力の通し試験（007の2）
        // @ANCHOR-20261021-R122-TOKENS  008のご指摘1（費用）
        if ($this->hasOption('r122-token-count')
            && $this->option('r122-token-count') !== null) {
            $this->runR122TokenCount((string) $this->option('r122-token-count'));
            return;
        }

        // @ANCHOR-20261020-R122-WIRETEST  007のE（実起動経路）
        // @ANCHOR-20261021-R122-E2E  実凍結から一続きの通し試験（010の5章末尾）
        if ($this->hasOption('r122-e2e-test')
            && $this->option('r122-e2e-test') !== null) {
            $this->runR122E2eTest((string) $this->option('r122-e2e-test'));
            return;
        }
        // @ANCHOR-20261021-R122-TYPETEST  型保持の通し試験（010の3章）
        if ($this->hasOption('r122-type-test')
            && $this->option('r122-type-test') !== null) {
            $this->runR122TypeTest((string) $this->option('r122-type-test'));
            return;
        }
        // @ANCHOR-20261021-R122-JOBTEST  Job構成の通し試験（010の2章）
        if ($this->hasOption('r122-job-test')
            && (bool) $this->option('r122-job-test')) {
            $this->runR122JobTest();
            return;
        }
        if ($this->hasOption('r122-wire-test')
            && $this->option('r122-wire-test') !== null) {
            $this->runR122WireTest((string) $this->option('r122-wire-test'));
            return;
        }

        if ((bool) $this->option('r122-onebuild-test')) {
            $this->runR122OneBuildTest();
            return;
        }

        // @ANCHOR-20261020-R122-WIRE  再起動後のやり直し（006の6-4）
        if ((bool) $this->option('r122-sweep')) {
            self::r122Autoload();
            $this->info('════════════════════════════════════════════════════════');
            $this->info(' r12.2 止まったレースのやり直し（初回の送信はしません）');
            $this->info('════════════════════════════════════════════════════════');
            $this->line('  実行時刻 : ' . date('c'));
            // @ANCHOR-20261020-R122-WIRE  0件の理由が読めるようにします。
            //   旗が下りているだけなのか、拾う対象が無かったのかを
            //   区別できないと「動いていない」のと見分けが付きません。
            $swW = \\App\\Http\\Controllers\\Api\\BaganrikiWorker::class;
            $this->line('  枠の段     : ' . $swW::mode()
                      . '（BAGANRIKI_R122_QUEUE）');
            $this->line('  必要な表   : ' . ($swW::ready() ? 'そろっています'
                                                           : 'ありません'));
            // ══════════════════════════════════════════════════════════
            // @ANCHOR-20261020-R122-SWEEPWATCH  10月20日007のご指摘6-2
            // ══════════════════════════════════════════════════════════
            //   【ご指摘のとおりでした】1分おきの巡回では、
            //   応答期限（発走150秒前）から公開期限（発走120秒前）までの
            //   <b>30秒を取りこぼします。</b>
            //   例：発走10:00 → 応答期限09:57:30／公開期限09:58:00。
            //       巡回が 09:57:01 → 09:58:01 なら、前は WAITING、
            //       後は公開期限の後です。
            //   【いま】1回の呼び出しの中で、決めた秒数のあいだ
            //   短い間隔で回せるようにしました。
            //   既定は 55秒を 5秒間隔（12回）です。1分おきの cron に
            //   入れれば、巡回の間隔は<b>最大5秒</b>になります。
            //   30秒の窓を取りこぼしません。
            $swWatch    = (int) ($this->option('r122-sweep-watch') ?? 0);
            $swInterval = (int) ($this->option('r122-sweep-interval') ?? 0);
            if ($swInterval <= 0) { $swInterval = 5; }
            if ($swWatch < 0)     { $swWatch = 0; }
            $ctrlSw = app(\\App\\Http\\Controllers\\Api\\AiController::class);
            $swEnd  = microtime(true) + $swWatch;
            $swRound = 0; $swPub = 0; $swScan = 0; $swRes = 0; $swFirst = 0;
            if ($swWatch > 0) {
                $this->line('  見張り     : ' . $swWatch . '秒を'
                          . $swInterval . '秒おき（最大'
                          . (int) floor($swWatch / max(1, $swInterval)) . '回）');
            }
            // ══════════════════════════════════════════════════════════
            // @ANCHOR-20261020-R122-SWEEPIDLE  旗が下りているときの見張り
            // ══════════════════════════════════════════════════════════
            //   枠の段が off のときは、拾う対象を見に行きません（従来どおり）。
            //   ただし <b>--r122-sweep-watch を付けたときは、刻みだけは
            //   実際に回して見せます。</b>
            //   そうしないと「30秒の窓を取りこぼさない」という話が、
            //   off の環境では一度も動いていない状態で紙の上の主張に
            //   なってしまうためです（10月20日007のご指摘6-2）。
            //   回すのは時計だけで、DBには触りません。
            // ══════════════════════════════════════════════════════════
            // @ANCHOR-20261020-R122-IDLECAP  空回しは10秒で打ち切ります
            // ══════════════════════════════════════════════════════════
            //   【10月20日に気づいたこと】
            //   これを毎分の cron に入れると、枠の段が off の間は
            //   <b>55秒眠るだけのPHPが、1分のうち55秒ずっと立ち続けます。</b>
            //   仕事は何もしません。ただ常駐するだけです。
            //   刻みを見せるのが目的なので、2回まわれば足ります。
            //   旗が下りているときは<b>10秒で打ち切ります。</b>
            //   旗が shadow か 1 のときは、指定どおりの秒数で回します
            //   （そちらは本当に拾いに行くので、打ち切りません）。
            if (!$swW::enabled()) {
                $this->warn('  枠の段が off なので、拾う対象は見ません'
                          . '（これは正常です。shadow か 1 で動きます）');
                if ($swWatch > 0) {
                    $idleMax = min($swWatch, self::R122_IDLE_WATCH_MAX_SEC);
                    if ($idleMax < $swWatch) {
                        $this->line('  ※ 旗が下りているので、空回しは '
                                  . self::R122_IDLE_WATCH_MAX_SEC
                                  . '秒で打ち切ります（指定は ' . $swWatch . '秒）。'
                                  . '毎分のcronに入れても常駐しません');
                    }
                    $t0 = microtime(true);
                    $idleRound = 0; $gapMax = 0.0; $prev = $t0;
                    $idleEnd = $t0 + $idleMax;
                    do {
                        $idleRound++;
                        $now = microtime(true);
                        $gap = $now - $prev;
                        if ($idleRound > 1 && $gap > $gapMax) { $gapMax = $gap; }
                        $prev = $now;
                        // @ANCHOR-20261021-R122-WATCHEND  終わりまで回します
                        $rest = $idleEnd - microtime(true);
                        if ($rest <= 0.05) { break; }
                        usleep((int) round(min((float) $swInterval, $rest) * 1000000));
                    } while (true);
                    $span = microtime(true) - $t0;
                    $this->line('  刻みの実測 : ' . $idleRound . ' 回／'
                              . number_format($span, 1) . ' 秒'
                              . '（最大の間隔 '
                              . number_format($gapMax, 1) . ' 秒）');
                    // ══════════════════════════════════════════════
                    // @ANCHOR-20261021-R122-WATCHDESC  009のご指摘3
                    // ══════════════════════════════════════════════
                    //   【書きすぎでした】「窓の取りこぼし：ありません」と
                    //   出していましたが、これは<b>何も処理していない
                    //   空回しの刻み</b>です。実際のレース処理の期限遵守を
                    //   証明するものではありません。書き方を直します。
                    $this->line('  確認したこと : 無負荷の巡回間隔だけです'
                              . '（実際のレース処理は含みません）');
                    $this->line('  実測の最大間隔 : '
                              . number_format($gapMax, 1) . ' 秒'
                              . ($gapMax > 0 ? '' : '（刻みが1回で終わりました）'));
                    $this->warn('  ※ 実処理では訂正の送信をこの中で待つので、'
                              . 'この間隔のまま回るとは限りません');
                }
                $this->line('');
                return;
            }
            do {
                $swRound++;
                $sw = $ctrlSw->r122SweepPending();
                $swScan = (int) $sw['scanned'];
                $swRes += (int) $sw['resumed'];
                $swFirst += (int) ($sw['first_sent'] ?? 0);
                $swPub += (int) $sw['published'];
                if ((int) $sw['published'] > 0) {
                    foreach ((array) $sw['rows'] as $r) {
                        $this->line(sprintf('    %2d回目 %-28s %s',
                            $swRound, (string) $r['race_id'], (string) $r['publish']));
                    }
                }
                if ($swWatch <= 0) { break; }
                // ══════════════════════════════════════════════════════
                // @ANCHOR-20261021-R122-WATCHEND  10月21日008のご指摘5
                // ══════════════════════════════════════════════════════
                //   【旧】`今 + 間隔 >= 終わり` で抜けていました。
                //     55秒・5秒間隔なら 0,5,…,50秒で終わり、
                //     <b>次の毎分起動まで約10秒空きます。</b>
                //     「最大5秒」という説明と合っていませんでした。
                //   【いま】終わりまで回します。最後の1回は<b>残り時間だけ</b>
                //     眠るので、窓の空きは次の起動までの差だけになります。
                $rest = $swEnd - microtime(true);
                if ($rest <= 0.05) { break; }
                $nap = min((float) $swInterval, $rest);
                usleep((int) round($nap * 1000000));
            } while (true);
            $this->line('  回した回数 : ' . $swRound . ' 回');
            $this->line('  見たレース : ' . $swScan . ' 件'
                      . '（投票締切が1時間前〜6時間後の凍結入力）');
            $this->line('  後始末     : ' . $swRes . ' 件'
                      . '（再起動をまたいだ送信を結果不明にした件数）');
            $this->line('  初回の送信 : ' . $swFirst . ' 件'
                      . '（固定入力があるのに初回の枠が無かったレース）');
            $this->line('  公開できた : ' . $swPub . ' 件');
            if ($swWatch <= 0) {
                foreach ((array) ($sw['rows'] ?? []) as $r) {
                    $this->line(sprintf('    %-28s %s',
                        (string) $r['race_id'], (string) $r['publish']));
                }
            }
            $this->line('');
            $this->warn('  ※ 巡回は訂正の送信をこの中で同期で待ちます。'
                      . '複数レースが同時に期限へ来たときの保証はありません'
                      . '（10月21日009のご指摘3）');
            $this->line('');
            $this->line('  cron の例（1分おき）');
            $this->line('    * * * * * cd /var/www/horse_odds_finder && '
                      . 'php artisan keiba:ai-analysis-compensate '
                      . '--r122-sweep --r122-sweep-watch=55 --r122-sweep-interval=5');
            $this->line('');
            return;
        }

        // @ANCHOR-20261020-R122-33R  33レースの候補比較
        if ((bool) $this->option('r122-33races')) {
            $this->runR12233Races((string) ($this->option('date') ?: '2026-10-17,2026-10-18'));
            return;
        }

        // ══════════════════════════════════════════════════════════════
        // @ANCHOR-20261020-R122-FP  元値の指紋
        // @ANCHOR-20261020-R122-FPFLAG  値なしで渡したときに素通りしていた
        // ══════════════════════════════════════════════════════════════
        //   【旧】option() が null でないことだけを見ていました。
        //     `--r122-fingerprint=` は「値を省ける指定」なので、
        //     <b>値なしで渡すと null になり、付けていないのと見分けが
        //     付きません。</b>そのまま通常の補完処理へ進み、
        //     「[ガードA] レースが存在しません」で終わっていました。
        //     2026年10月20日に実機で踏みました。
        //   【いま】素の引数も見ます。`--r122-fingerprint` だけでも動きます。
        $fpGiven = ($this->option('r122-fingerprint') !== null);
        if (!$fpGiven) {
            foreach ((array) ($_SERVER['argv'] ?? []) as $av) {
                if ($av === '--r122-fingerprint'
                    || strncmp((string) $av, '--r122-fingerprint=', 19) === 0) {
                    $fpGiven = true;
                    break;
                }
            }
        }
        if ($this->hasOption('r122-fingerprint') && $fpGiven) {
            $this->runR122Fingerprint($this->option('r122-fingerprint'));
            return;
        }

        // @ANCHOR-20261020-R122-ACQFIX  監査行からの通し試験
        if ((bool) $this->option('r122-acq-test')) {
            $this->runR122AcqTest();
            return;
        }

        // @ANCHOR-20261020-R122-INVALID  異常例32本の突き合わせ
        if ($this->option('r122-invalid-cases')) {
            $this->runR122InvalidCases((string) $this->option('r122-invalid-cases'));
            return;
        }

        // @ANCHOR-20261020-R122-FREEZE  凍結入力の保存
        if ((bool) $this->option('r122-freeze') || (bool) $this->option('r122-freeze-dry')) {
            $this->runR122Freeze((bool) $this->option('r122-freeze-dry'));
            return;
        }

        // @ANCHOR-20261020-R122-AUDIT  取得監査の記録の確認
        if ((bool) $this->option('r122-audit-check')) {
            $this->runR122AuditCheck();
            return;
        }

        // @ANCHOR-20261020-R122-PROMPT  r12.2の両AI本文の設置と送信文の検査
        if ($this->option('r122-prompt-install')) {
            $this->runR122PromptInstall((string) $this->option('r122-prompt-install'));
            return;
        }
        if ($this->option('r122-prompt-check')) {
            $this->runR122PromptCheck((string) $this->option('r122-prompt-check'));
            return;
        }

        // @ANCHOR-20261020-R122CASES  r12.2の合成試験（先方の期待値との突き合わせ）
        if ($this->option('r122-cases')) {""",
    'dispatch')

# 3) メソッドの追加（クラスの閉じ括弧の直前）
methods = io.open(os.path.join(os.path.dirname(os.path.abspath(__file__)),
                               'methods_check.php'), encoding='utf-8').read()
methods += io.open(os.path.join(os.path.dirname(os.path.abspath(__file__)),
                               'methods_auditcheck.php'), encoding='utf-8').read()
for _f in ('methods_invalid.php', 'methods_freezecmd.php', 'methods_acqtest.php',
           'methods_fp.php', 'methods_33.php', 'methods_queue.php',
           'methods_resptest.php', 'methods_pubtest.php',
           'methods_readtest.php', 'methods_prodinput.php',
           'methods_markettest.php', 'methods_native.php',
           # @ANCHOR-20261020-R122-ONEBUILD  固定入力の通し試験（007の2）
           'methods_onebuild.php',
           # @ANCHOR-20261020-R122-WIRETEST  実起動経路の通し試験（007のE）
           'methods_wiretest.php',
           # @ANCHOR-20261021-R122-TOKENS  トークン数の実測（008のご指摘1）
           'methods_tokens.php',
           # @ANCHOR-20261021-R122-JOBTEST  Job構成の通し試験（010の2章）
           'methods_jobtest.php',
           # @ANCHOR-20261021-R122-TYPETEST  型保持の通し試験（010の3章）
           'methods_typetest.php',
           # @ANCHOR-20261021-R122-E2E  実凍結から一続きの通し試験（010の5章末尾）
           'methods_e2etest.php'):
    methods += io.open(os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                    _f), encoding='utf-8').read()
tail = """        $this->info('CSVを書き出しました: ' . $path . '（' . count($rows) . '行）');
    }

}"""
rep(tail, """        $this->info('CSVを書き出しました: ' . $path . '（' . count($rows) . '行）');
    }
""" + methods + """
}""", 'メソッドの追加')

io.open(p, 'w', encoding='utf-8').write(src)
print('当てました: %s  %d行 -> %d行  md5=%s'
      % (p, orig.count('\n')+1, src.count('\n')+1,
         hashlib.md5(src.encode('utf-8')).hexdigest()))
