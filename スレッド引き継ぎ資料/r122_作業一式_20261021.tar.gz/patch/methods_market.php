
    /**
     * ═══════════════════════════════════════════════════════════════════════
     * @ANCHOR-20261020-R122-MARKET  OPI と推定確定オッズを source_registry へ
     * ═══════════════════════════════════════════════════════════════════════
     * 根拠：server_contract_r12.2.txt 3章・5章／採点辞書 V1・V3・V4
     *
     * ■ 正本と式（いまの商品と同じものを使います。作り直しません）
     *   t_horse_odds_finder_popularity_rank_average       人気順位別の過去平均単勝
     *   t_horse_odds_finder_fuku_popularity_rank_average  人気順位別の過去平均複勝最小
     *   t_horse_odds_finder_compute_odds_correction       人気順位別の補正係数
     *
     *     OPI            = 過去平均単勝 ÷ 6分前単勝
     *     複勝OPI        = 過去平均複勝最小 ÷ 6分前複勝最小
     *     推定確定オッズ = 6分前単勝 × 補正係数
     *     推定確定複勝   = 6分前複勝最小 × 補正係数（複勝専用の係数は未実装）
     *     予測補正OPI    = 過去平均単勝 ÷ 推定確定オッズ
     *
     * ■ 使っていいかの判定（2つとも満たしたときだけ載せます）
     *   ① 集計期間の終わり（end_date）が<b>対象レースの開催日より前</b>
     *      当日を含む集計で、その当日のレースを評価しないためです。
     *   ② 算出時刻（computed_at）が情報上限より前
     *      この列が無い表は①だけで見ます。<b>無い時刻は作りません。</b>
     *      読み取った時刻（入力の凍結時刻）を observed_at に入れ、
     *      集計期間は start_date / end_date として別項目で渡します。
     *
     * ■ .env の BAGANRIKI_MARKET_PRIOR を 0 にすると載せません（既定は1）。
     *
     * @param array $frozenRank 馬番 => 凍結人気
     * @param array $cells      $cells[馬番][スロット]['win_odds'|'place_min']
     * @return array ['registry'=>..., 'coverage'=>['OPI'=>..,'estimated_odds'=>..]]
     */
    public static function r122MarketPriorRegistry(string $raceId, string $date,
                                                   array $frozenRank, array $cells,
                                                   ?string $freezeAt): array
    {
        $ng = static fn(string $o, string $e) => ['registry' => [], 'coverage' => [
            'OPI'            => ['status' => 'UNAVAILABLE', 'reason' => $o],
            'estimated_odds' => ['status' => 'UNAVAILABLE', 'reason' => $e],
        ]];

        if (!self::r122MarketPriorEnabled()) {
            $m = '.env の BAGANRIKI_MARKET_PRIOR が 0 のため載せていません';
            return $ng($m, $m);
        }
        foreach (['t_horse_odds_finder_popularity_rank_average',
                  't_horse_odds_finder_fuku_popularity_rank_average',
                  't_horse_odds_finder_compute_odds_correction'] as $t) {
            if (!\Schema::hasTable($t)) {
                $m = $t . ' がありません';
                return $ng($m, $m);
            }
        }
        if ($frozenRank === []) {
            $m = '凍結人気が出ていないので人気順位別の集計を引けません';
            return $ng($m, $m);
        }

        $freezeUs = ($freezeAt === null) ? null : BaganrikiTime::us($freezeAt);
        $day = substr($date, 0, 10);

        // 使っていいかを見る共通の道具
        $check = static function ($endDate, $computedAt) use ($day, $freezeUs, $freezeAt) {
            $ed = ($endDate === null) ? '' : substr(str_replace('/', '-', (string) $endDate), 0, 10);
            if ($ed === '') {
                return [false, '集計期間の終わりが分かりません', null];
            }
            if (strcmp($ed, $day) >= 0) {
                return [false, '集計期間の終わり（' . $ed . '）が対象レースの開催日（'
                             . $day . '）以降です。当日を含む集計で'
                             . 'その日のレースを評価しないためです。', null];
            }
            $cAt = ($computedAt === null) ? null : self::r122DbTime($computedAt);
            if ($cAt !== null && $freezeUs !== null) {
                $cu = BaganrikiTime::us($cAt);
                if ($cu === null || $cu > $freezeUs) {
                    return [false, 'この集計は情報上限より後に算出されています（算出 '
                                 . $cAt . '／情報上限 ' . ($freezeAt ?? '不明') . '）', null];
                }
            }
            return [true, null, $cAt];
        };

        // 人気順位 => その順位の馬番
        $byRank = [];
        foreach ($frozenRank as $no => $rk) {
            $byRank[(int) $rk][] = (int) $no;
        }
        foreach ($byRank as $rk => $list) { sort($list); $byRank[$rk] = $list; }

        $add = []; $refs = ['OPI' => [], 'estimated_odds' => []];
        $why = ['OPI' => null, 'estimated_odds' => null];

        // ── 表を読む ────────────────────────────────────────────────
        $load = static function (string $table, string $valueCol, string $countCol)
                use ($check) {
            $rows = []; $win = null; $bad = null; $at = null; $atSrc = null;
            foreach (\DB::table($table)->get() as $r) {
                // ══════════════════════════════════════════════════════
                // @ANCHOR-20261021-R122-VERIFIEDAT  10月21日008のご指摘8
                // ══════════════════════════════════════════════════════
                //   computed_at（実際に算出した時刻）を正とします。
                //   列を足す前から在った行は computed_at が無いので、
                //   その行だけ verified_at（この時刻に使えることを確かめた）
                //   で代えます。どちらを使ったかは下の理由文に出ます。
                $cSrc = 'computed_at';
                $cRaw = $r->computed_at ?? null;
                if ($cRaw === null && property_exists($r, 'verified_at')) {
                    $cRaw = $r->verified_at ?? null;
                    if ($cRaw !== null) { $cSrc = 'verified_at'; }
                }
                [$ok, $reason, $cAt] = $check($r->end_date ?? null, $cRaw);
                if (!$ok) { if ($bad === null) { $bad = $reason; } continue; }
                $rk = (int) ($r->popularity_rank ?? 0);
                if ($rk <= 0) { continue; }
                $rows[$rk] = $r;
                if ($at === null || ($cAt !== null && strcmp($cAt, (string) $at) > 0)) {
                    $at = $cAt; $atSrc = $cSrc;
                }
                if ($win === null) {
                    $win = ['start' => substr((string) ($r->start_date ?? ''), 0, 10),
                            'end'   => substr((string) ($r->end_date ?? ''), 0, 10)];
                }
            }
            return ['rows' => $rows, 'window' => $win, 'bad' => $bad,
                    'computed_at' => $at,
                    // @ANCHOR-20261021-R122-VERIFIEDAT  どちらの時刻を使ったか
                    'time_source' => $atSrc];
        };

        $popAvg  = $load('t_horse_odds_finder_popularity_rank_average', 'odds_average', 'count');
        $fukuAvg = $load('t_horse_odds_finder_fuku_popularity_rank_average', 'odds_average', 'count');
        $corr    = $load('t_horse_odds_finder_compute_odds_correction', 'avg_correction_ratio', 'sample_count');

        // ══════════════════════════════════════════════════════════════
        // @ANCHOR-20261020-R122-REALTIME  10月20日006のご指摘4-1（本物の不具合）
        // ══════════════════════════════════════════════════════════════
        //   【旧】算出時刻の無い表には $readAt（＝情報上限、無ければ現在時刻）を
        //     observed_at / available_at として入れていました。
        //     これは<b>真正な取得時刻の記録ではありません。</b>
        //     「無い時刻は作らない」と書きながら、作っていました。
        //     集計期間の終わりが開催日より前でも、その版を上限前に
        //     利用できた証拠にはなりません。
        //   【いま】算出時刻の列が無い表は使いません。理由を付けて外します。
        //     列が入れば（取得・算出側で記録すれば）その日から使えます。
        $nowAt = BaganrikiPrompt::rfc3339(BaganrikiWorker::nowUs());

        $put = static function (array &$add, string $ref, $value, string $field,
                                string $unit, array $applicable, string $at,
                                array $parents = [], ?string $formula = null)
                use ($raceId) {
            $derived = ($parents !== []);
            $add[$ref] = [
                'source_ref'           => $ref,
                'race_id'              => $raceId,
                'value'                => $value,
                'scope'                => ($applicable === []) ? 'RACE' : 'COHORT',
                'horse_nos'            => [],
                'applicable_horse_nos' => $applicable,
                'field'                => $field,
                'unit'                 => $unit,
                'slot_offset'          => null,
                'observed_at'          => $at,
                'available_at'         => $at,
                'computed_at'          => $derived ? $at : null,
                'source_kind'          => $derived ? 'DERIVED' : 'OBSERVED',
                'parents'              => $parents,
                'formula_id'           => $derived ? $formula : null,
                'formula_version'      => $derived ? 'v1' : null,
                'dependency_key'       => $field,
                'dependency_role'      => 'CONTEXT',
            ];
        };

        // @ANCHOR-20261020-R122-REALTIME  算出時刻が無い表は使いません
        //   ここで2つを<b>区別します</b>。混ぜると、直したあとも
        //   「列がありません」と出続けて、何をすれば載るのか読めません。
        //     列が無い   … 取得・算出側に記録する場所がまだ無い
        //     値がNULL   … 場所はあるが、その集計がまだ1回もまわっていない
        $noTime = []; $noTimeWhy = [];
        $r122TblOf = [
            'popavg'  => 't_horse_odds_finder_popularity_rank_average',
            'fukuavg' => 't_horse_odds_finder_fuku_popularity_rank_average',
            'corr'    => 't_horse_odds_finder_compute_odds_correction',
        ];
        foreach ([['popavg', $popAvg], ['fukuavg', $fukuAvg], ['corr', $corr]] as $pair) {
            [$tag, $t] = $pair;
            if ($t['rows'] !== [] && $t['computed_at'] === null) {
                $noTime[$tag] = true;
                $noTimeWhy[$tag] =
                    \Schema::hasColumn((string) $r122TblOf[$tag], 'computed_at')
                        ? 'value' : 'column';
                $t['rows'] = [];                 // 使いません
                if ($tag === 'popavg')  { $popAvg['rows']  = []; }
                if ($tag === 'fukuavg') { $fukuAvg['rows'] = []; }
                if ($tag === 'corr')    { $corr['rows']    = []; }
            }
        }

        // ── ① 集計の窓（レース単位で1組ずつ）───────────────────────
        foreach ([['popavg', $popAvg], ['fukuavg', $fukuAvg], ['corr', $corr]] as $pair) {
            [$tag, $t] = $pair;
            if ($t['window'] === null || $t['rows'] === []) { continue; }
            $at = $t['computed_at'];
            foreach (['start_date' => $t['window']['start'],
                      'end_date'   => $t['window']['end']] as $f => $v) {
                if ($v === '') { continue; }
                $ref = $tag . '_' . $f;
                $put($add, $ref, $v, $tag . '_' . $f, 'date', [], $at);
                $refs[($tag === 'corr') ? 'estimated_odds' : 'OPI'][] = $ref;
            }
        }

        // ── ② 人気順位ごとの集計（その順位の馬にだけ当てはまります）───
        foreach ($byRank as $rk => $list) {
            $at1 = $popAvg['computed_at'];
            if (isset($popAvg['rows'][$rk])) {
                $r = $popAvg['rows'][$rk];
                $v = self::r122DecOrNull($r->odds_average ?? null);
                if ($v !== null) {
                    $ref = 'popavg_rank' . $rk . '_win_odds';
                    $put($add, $ref, $v, 'popavg_win_odds', 'odds', $list, $at1);
                    $refs['OPI'][] = $ref;
                }
                $n = self::r122IntOrNull($r->count ?? null);
                if ($n !== null) {
                    $ref = 'popavg_rank' . $rk . '_count';
                    $put($add, $ref, $n, 'popavg_count', 'races', $list, $at1);
                    $refs['OPI'][] = $ref;
                }
            }
            $at2 = $fukuAvg['computed_at'];
            if (isset($fukuAvg['rows'][$rk])) {
                $r = $fukuAvg['rows'][$rk];
                $v = self::r122DecOrNull($r->odds_average ?? null);
                if ($v !== null) {
                    $ref = 'fukuavg_rank' . $rk . '_place_min';
                    $put($add, $ref, $v, 'fukuavg_place_min', 'odds', $list, $at2);
                    $refs['OPI'][] = $ref;
                }
                $n = self::r122IntOrNull($r->count ?? null);
                if ($n !== null) {
                    $ref = 'fukuavg_rank' . $rk . '_count';
                    $put($add, $ref, $n, 'fukuavg_count', 'races', $list, $at2);
                    $refs['OPI'][] = $ref;
                }
            }
            $at3 = $corr['computed_at'];
            if (isset($corr['rows'][$rk])) {
                $r = $corr['rows'][$rk];
                foreach (['avg_correction_ratio' => 'ratio',
                          'std_correction_ratio' => 'ratio'] as $f => $unit) {
                    $v = self::r122DecOrNull($r->{$f} ?? null);
                    if ($v === null) { continue; }
                    $ref = 'corr_rank' . $rk . '_' . $f;
                    $put($add, $ref, $v, 'corr_' . $f, $unit, $list, $at3);
                    $refs['estimated_odds'][] = $ref;
                }
                $n = self::r122IntOrNull($r->sample_count ?? null);
                if ($n !== null) {
                    $ref = 'corr_rank' . $rk . '_sample_count';
                    $put($add, $ref, $n, 'corr_sample_count', 'races', $list, $at3);
                    $refs['estimated_odds'][] = $ref;
                }
            }
        }

        // ── ③ 馬ごとの値（式はいまの商品と同じ）─────────────────────
        // ══════════════════════════════════════════════════════════════
        // @ANCHOR-20261020-R122-DERIVEDAT  10月20日006のご指摘4-2（本物の不具合）
        // ══════════════════════════════════════════════════════════════
        //   【旧】observed_at / available_at / computed_at の3つに
        //     <b>同じ値（集計の算出時刻）</b>を入れていました。
        //     推定確定オッズは「今回の6分前オッズ × 補正係数」なのに、
        //     係数が前夜算出なら「今回のオッズを使った値が前夜に
        //     利用可能だった」という時刻関係になります。
        //   【いま】3つを分けます。
        //     observed_at / available_at … <b>親のうちいちばん遅い時刻</b>
        //       （親より過去へ戻しません）
        //     computed_at               … この値を実際に計算した時刻
        $later = static function (?string $a, ?string $b): ?string {
            if ($a === null) { return $b; }
            if ($b === null) { return $a; }
            $ua = BaganrikiTime::us($a); $ub = BaganrikiTime::us($b);
            if ($ua === null) { return $b; }
            if ($ub === null) { return $a; }
            return ($ub > $ua) ? $b : $a;
        };
        $putHorse = static function (array &$add, int $no, string $field, $value,
                                     string $unit, array $parents, string $formula,
                                     string $availAt, string $computedAt) use ($raceId) {
            $ref = 'h' . $no . '_' . $field;
            $add[$ref] = [
                'source_ref'           => $ref,
                'race_id'              => $raceId,
                'value'                => $value,
                'scope'                => 'HORSE',
                'horse_nos'            => [$no],
                'applicable_horse_nos' => [],
                'field'                => $field,
                'unit'                 => $unit,
                'slot_offset'          => 6,
                'observed_at'          => $availAt,
                'available_at'         => $availAt,
                'computed_at'          => $computedAt,
                'source_kind'          => 'DERIVED',
                'parents'              => $parents,
                'formula_id'           => $formula,
                'formula_version'      => 'v1',
                'dependency_key'       => 'h' . $no . '_' . $field,
                'dependency_role'      => 'CONTEXT',
            ];
            return $ref;
        };

        foreach ($frozenRank as $no => $rk) {
            $no = (int) $no; $rk = (int) $rk;
            // 6分前オッズが使えるようになった時刻（親のひとつ）
            $odds6At = ($freezeAt !== null) ? $freezeAt : $nowAt;
            $win6  = self::r122DecOrNull($cells[$no][6]['win_odds']  ?? null);
            $fuku6 = self::r122DecOrNull($cells[$no][6]['place_min'] ?? null);
            $pa = isset($popAvg['rows'][$rk])
                ? self::r122DecOrNull($popAvg['rows'][$rk]->odds_average ?? null) : null;
            $fa = isset($fukuAvg['rows'][$rk])
                ? self::r122DecOrNull($fukuAvg['rows'][$rk]->odds_average ?? null) : null;
            $cr = isset($corr['rows'][$rk])
                ? self::r122DecOrNull($corr['rows'][$rk]->avg_correction_ratio ?? null) : null;

            // OPI = 過去平均単勝 ÷ 6分前単勝
            if ($pa !== null && $win6 !== null && $win6 > 0) {
                $refs['OPI'][] = $putHorse($add, $no, 'opi',
                    round($pa / $win6, 2), 'ratio',
                    ['popavg_rank' . $rk . '_win_odds', 'h' . $no . '_win_odds_6'],
                    'OPI_AVG_WIN_DIV_WIN6',
                    $later($popAvg['computed_at'], $odds6At), $nowAt);
            }
            // 複勝OPI = 過去平均複勝最小 ÷ 6分前複勝最小
            if ($fa !== null && $fuku6 !== null && $fuku6 > 0) {
                $refs['OPI'][] = $putHorse($add, $no, 'fuku_opi',
                    round($fa / $fuku6, 2), 'ratio',
                    ['fukuavg_rank' . $rk . '_place_min', 'h' . $no . '_place_min_6'],
                    'FUKU_OPI_AVG_PLACE_DIV_PLACE6',
                    $later($fukuAvg['computed_at'], $odds6At), $nowAt);
            }
            // 推定確定オッズ = 6分前単勝 × 補正係数
            $est = null;
            if ($cr !== null && $win6 !== null && $win6 > 0) {
                $est = round($win6 * $cr, 2);
                $refs['estimated_odds'][] = $putHorse($add, $no, 'estimated_final_odds',
                    $est, 'odds',
                    ['corr_rank' . $rk . '_avg_correction_ratio', 'h' . $no . '_win_odds_6'],
                    'EST_FINAL_ODDS_WIN6_X_RATIO',
                    $later($corr['computed_at'], $odds6At), $nowAt);
            }
            // 推定確定複勝最小（複勝専用の係数は未実装なので単勝の係数を流用）
            if ($cr !== null && $fuku6 !== null && $fuku6 > 0) {
                $refs['estimated_odds'][] = $putHorse($add, $no, 'estimated_final_place_min',
                    round($fuku6 * $cr, 2), 'odds',
                    ['corr_rank' . $rk . '_avg_correction_ratio', 'h' . $no . '_place_min_6'],
                    'EST_FINAL_PLACE_MIN_PLACE6_X_WIN_RATIO',
                    $later($corr['computed_at'], $odds6At), $nowAt);
            }
            // 予測補正OPI = 過去平均単勝 ÷ 推定確定オッズ
            if ($pa !== null && $est !== null && $est > 0) {
                $refs['OPI'][] = $putHorse($add, $no, 'estimated_opi',
                    round($pa / $est, 2), 'ratio',
                    ['popavg_rank' . $rk . '_win_odds', 'h' . $no . '_estimated_final_odds'],
                    'EST_OPI_AVG_WIN_DIV_EST_FINAL',
                    $later($later($popAvg['computed_at'], $corr['computed_at']), $odds6At),
                    $nowAt);
            }
        }

        $cov = [];
        foreach (['OPI' => [$popAvg, $fukuAvg], 'estimated_odds' => [$corr]] as $k => $src) {
            $list = array_values(array_unique($refs[$k]));
            sort($list, SORT_STRING);
            if ($list !== []) {
                $cov[$k] = ['status' => 'INCLUDED', 'source_refs' => $list];
                continue;
            }
            $reason = null;
            // @ANCHOR-20261020-R122-REALTIME  算出時刻が無いことを理由に出します
            //   「列が無い」と「まだ値が入っていない」を分けて書きます。
            $missCol = []; $missVal = [];
            foreach (($k === 'OPI' ? ['popavg', 'fukuavg'] : ['corr']) as $tg) {
                if (empty($noTime[$tg])) { continue; }
                if (($noTimeWhy[$tg] ?? 'column') === 'value') { $missVal[] = $tg; }
                else { $missCol[] = $tg; }
            }
            if ($missCol !== [] || $missVal !== []) {
                $parts = [];
                if ($missCol !== []) {
                    $parts[] = '表に算出時刻（computed_at）の列がありません'
                             . '（該当 ' . implode('・', $missCol) . '）。'
                             . '取得・算出側で算出時刻を記録すれば、その日から使えます。';
                }
                if ($missVal !== []) {
                    $parts[] = '算出時刻（computed_at）の列はありますが、'
                             . 'まだ値が入っていません'
                             . '（該当 ' . implode('・', $missVal) . '）。'
                             // @ANCHOR-20261020-R122-COMPUTEDAT  10月20日に直しました
                             //   【旧】「1回まわれば入ります」と書いていましたが、
                             //     集計は<b>新しいレース結果が無い日はDBに
                             //     1行も書かずに終わる</b>作りでした。
                             //     平日は必ずそちらを通るので、永久に入りません。
                             //     この書き方は読む人に誤った見込みを与えます。
                             . 'その集計が次に走ったときに入ります'
                             . '（新しいレース結果が無い日も、値は変えずに'
                             . '算出時刻だけ入れ直すようにしました）。';
                }
                $reason = '情報上限より前に利用できた証拠が無いので使いません。'
                        . implode('', $parts);
            }
            if ($reason === null) {
                foreach ($src as $t) {
                    if ($t['bad'] !== null) { $reason = $t['bad']; break; }
                }
            }
            $cov[$k] = ['status' => 'UNAVAILABLE',
                        'reason' => $reason ?? '人気順位別の集計が見つかりませんでした'];
        }
        return ['registry' => $add, 'coverage' => $cov];
    }

    /** @ANCHOR-20261020-R122-MARKET  .env で止められます（既定は載せる） */
    public static function r122MarketPriorEnabled(): bool
    {
        $v = (string) env('BAGANRIKI_MARKET_PRIOR', '1');
        return !in_array($v, ['0', 'false', 'off', 'no'], true);
    }

    /** @ANCHOR-20261020-R122-MARKET  十進数として読めるときだけ float を返します */
    public static function r122DecOrNull($v): ?float
    {
        if ($v === null) { return null; }
        $s = trim((string) $v);
        if ($s === '' || !preg_match('/^-?\d+(?:\.\d+)?$/', $s)) { return null; }
        return (float) $s;
    }
