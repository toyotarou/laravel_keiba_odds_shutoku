# -*- coding: utf-8 -*-
"""
@ANCHOR-20261020-R122-PROMPT  AiController.php への追補（r12.2 の両AI本文）
同じ内容を Mac とサーバの両方へ当てるための台本です。
当て方は 1 回だけ（当たっているかを先に確かめて、二重に当てません）。
"""
import io, sys, os, hashlib

p = sys.argv[1]
src = io.open(p, encoding='utf-8').read()
orig = src

def rep(old, new, why, count=1):
    global src
    n = src.count(old)
    assert n == count, '%s: 見つかった数 %d（期待 %d）' % (why, n, count)
    src = src.replace(old, new, count)

if '@ANCHOR-20261020-R122-PROMPT' in src:
    print('すでに当たっています（何もしません）: ' + p)
    sys.exit(0)

# ───────────────────────────────────────────────────────────────────────────
# 1) v04Allocation の戻りに base_quota を足す（構造調整の「前」の表の値）
#    input_schema.json が base_quota を必須にしているためです。
#    既存の戻り値は消しません。足すだけです。
# ───────────────────────────────────────────────────────────────────────────
rep("""        $firstPublishError = $this->_firstAiPublishError((string) $cached->analysis_text);
        if ($firstPublishError !== null) {
            \\Log::warning('[PREDICTION_PARTIAL] 1st AI 回答に問題あり（公開は継続）', [
                'reason' => $firstPublishError,
                'date' => $date, 'kaisuu' => $kaisuu, 'basho' => $basho, 'day' => $day, 'race' => $race,
            ]);
        }""",
    """        $firstPublishError = $this->_firstAiPublishError((string) $cached->analysis_text);
        if ($firstPublishError !== null) {
            \\Log::warning('[PREDICTION_PARTIAL] 1st AI 回答に問題あり（公開は継続）', [
                'reason' => $firstPublishError,
                'date' => $date, 'kaisuu' => $kaisuu, 'basho' => $basho, 'day' => $day, 'race' => $race,
            ]);
        }
        // ══════════════════════════════════════════════════════════════
        // @ANCHOR-20261020-R122-RESUME  10月20日007のご指摘6-1
        // ══════════════════════════════════════════════════════════════
        //   【ご指摘のとおりでした】情報上限の前に呼ばれて凍結を断ったあと、
        //   旧AIの予想がここにキャッシュされると、<b>次のアクセスは
        //   この行で終わり</b>、固定入力を作り直す機会がありませんでした。
        //   いまは応答を返したあとに1回だけやり直します（画面は遅くなりません）。
        $this->r122AfterCached($date, $kaisuu, $basho, $day, $race);""",
    'キャッシュ返却①のあとに固定のやり直しを足す')

rep("""            $firstPublishError = $this->_firstAiPublishError((string) $cached->analysis_text);
            if ($firstPublishError !== null) {
                \\Log::warning('[PREDICTION_PARTIAL] 1st AI 回答に問題あり（公開は継続）', [
                    'reason' => $firstPublishError,
                    'date' => $date, 'kaisuu' => $kaisuu, 'basho' => $basho, 'day' => $day, 'race' => $race,
                ]);
            }""",
    """            $firstPublishError = $this->_firstAiPublishError((string) $cached->analysis_text);
            if ($firstPublishError !== null) {
                \\Log::warning('[PREDICTION_PARTIAL] 1st AI 回答に問題あり（公開は継続）', [
                    'reason' => $firstPublishError,
                    'date' => $date, 'kaisuu' => $kaisuu, 'basho' => $basho, 'day' => $day, 'race' => $race,
                ]);
            }
            // @ANCHOR-20261020-R122-RESUME  ロック後のキャッシュ返却でも同じ
            $this->r122AfterCached($date, $kaisuu, $basho, $day, $race);""",
    'キャッシュ返却②のあとに固定のやり直しを足す')

rep("""        if ($mode === null) {
            return ['target_count' => $cap, 'quota' => null, 'quota_2nd' => null,
                    'quota_adjustments' => [],""",
    """        if ($mode === null) {
            // @ANCHOR-20261020-R122-PROMPT  base_quota は INPUT_JSON の必須キー
            return ['target_count' => $cap, 'quota' => null, 'quota_2nd' => null,
                    'base_quota' => null,
                    'quota_adjustments' => [],""",
    'v04Allocation: UNRESOLVED の戻り')

rep("""            return ['target_count' => 0, 'quota' => null, 'quota_2nd' => null,
                    'quota_adjustments' => [],""",
    """            return ['target_count' => 0, 'quota' => null, 'quota_2nd' => null,
                    'base_quota' => null,
                    'quota_adjustments' => [],""",
    'v04Allocation: N=0 の戻り')

rep("""            $q3 = ['A' => $cap, 'B' => 0, 'D' => 0];
            return ['target_count' => $cap, 'quota' => $q3, 'quota_2nd' => $q3,
                    'quota_adjustments' => [],""",
    """            $q3 = ['A' => $cap, 'B' => 0, 'D' => 0];
            return ['target_count' => $cap, 'quota' => $q3, 'quota_2nd' => $q3,
                    'base_quota' => $q3,
                    'quota_adjustments' => [],""",
    'v04Allocation: N<=3 の戻り')

rep("""            return ['target_count' => $cap, 'quota' => null, 'quota_2nd' => null,
                    'quota_adjustments' => [],
                    'quota_note'   => "配分表に target_count={$cap} / mode={$mode} が無い",""",
    """            return ['target_count' => $cap, 'quota' => null, 'quota_2nd' => null,
                    'base_quota' => null,
                    'quota_adjustments' => [],
                    'quota_note'   => "配分表に target_count={$cap} / mode={$mode} が無い",""",
    'v04Allocation: 表に無い組み合わせの戻り')

rep("""        if (array_sum($q) !== $cap) {
            throw new \\RuntimeException("quota sum mismatch: {$cap} vs " . array_sum($q));
        }
""",
    """        if (array_sum($q) !== $cap) {
            throw new \\RuntimeException("quota sum mismatch: {$cap} vs " . array_sum($q));
        }
        // @ANCHOR-20261020-R122-PROMPT  構造調整の前の表の値を base_quota として残す
        $qBase = ['A' => $q[0], 'B' => $q[1], 'D' => $q[2]];
""",
    'v04Allocation: base_quota の控え')

rep("""        return [
            'target_count' => $cap,
            'quota'        => ['A' => $q[0], 'B' => $q[1], 'D' => $q[2]],
            'quota_2nd'    => ['A' => $q2[0], 'B' => $q2[1], 'D' => $q2[2]],
            'quota_adjustments' => $moves,""",
    """        return [
            'target_count' => $cap,
            'quota'        => ['A' => $q[0], 'B' => $q[1], 'D' => $q[2]],
            'quota_2nd'    => ['A' => $q2[0], 'B' => $q2[1], 'D' => $q2[2]],
            'base_quota'   => $qBase,
            'quota_adjustments' => $moves,""",
    'v04Allocation: 通常の戻り')

# ───────────────────────────────────────────────────────────────────────────
# 2) commonJson のキー順をそろえる（先方の python と1バイト単位で合わせる）
#    【直した中身】キーを並べ替えていなかったので、同じ内容でも
#    作った順でhashが変わり、先方の参照値と一致しませんでした。
# ───────────────────────────────────────────────────────────────────────────
rep("""        $json = json_encode($input,
            JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PRESERVE_ZERO_FRACTION);
        if ($json === false) {
            return ['ok' => false, 'reason' => '共通JSONを作れませんでした', 'json' => null, 'hash' => null];
        }""",
    """        // ══════════════════════════════════════════════════════════════
        // @ANCHOR-20261020-R122-PROMPT  キーを全階層で昇順にそろえます
        // ══════════════════════════════════════════════════════════════
        // 【直した中身】並べ替えをしていなかったので、同じ内容でも
        //   作った順で hash が変わっていました。先方の参照入力14本の
        //   snapshot_hash と一致しない原因でした。
        //   【旧コード】消さずに残します。使っていません。
        //     $json = json_encode($input,
        //         JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PRESERVE_ZERO_FRACTION);
        $json = BaganrikiPrompt::canonical($input);
        if ($json === null) {
            return ['ok' => false, 'reason' => '共通JSONを作れませんでした', 'json' => null, 'hash' => null];
        }""",
    'commonJson: キー順')

# ───────────────────────────────────────────────────────────────────────────
# 2b) X6 の N<7 を FALSE にする（決着事項①B案。本番側に抜けていました）
# ───────────────────────────────────────────────────────────────────────────
rep("""        if ($similar === null
            || ($similar['sample_size'] ?? null) === null
            || ($similar['delta_pp']    ?? null) === null) {
            $X6 = 'UNKNOWN';
            $x6Note = '同条件比較基準率が未定義・未提供（07章B）のため不明。0%で埋めない';
        } elseif ((int) $similar['sample_size'] < $thr['similar_min_races']) {""",
    """        // ══════════════════════════════════════════════════════════════
        // @ANCHOR-20261020-R122-PROMPT  N<7 は構造的非該当で FALSE
        // ══════════════════════════════════════════════════════════════
        // 【直した中身】決着事項①（B案）は「N>=7 で null、N<7 で false」です。
        //   X6 は「7番人気以下の3着内進入率」を見る信号なので、
        //   7番人気以下が存在しない N<7 では成立しません（X3 と同じ扱い）。
        //   検証側（SummaryAiAnalysisCompensate::modeCheckOne）は前から
        //   この扱いでしたが、<b>本番側のここが抜けていました</b>。
        //   X6 は --r122-exact-check の突き合わせ対象（X1〜X5・Z）に
        //   入っていなかったため、これまで見つかっていませんでした。
        //   先方の参照入力 normal/FIRM_N4_1st_input.json の X6=false と
        //   一致しなかったことで分かりました。
        if ($N < 7) {
            $X6 = 'FALSE';
            $x6Note = 'N<7 のため7番人気以下が存在せず構造的に非該当（決着事項①B案）';
        } elseif (AiController::V04_X6_BASELINE === null) {
            // ══════════════════════════════════════════════════════════
            // @ANCHOR-20261020-R122-X6  B案の経路をここで閉じます
            // ══════════════════════════════════════════════════════════
            // 【10月20日004のご指摘（2）】
            //   「類似統計を渡すと旧TRUE/FALSE判定へ進む処理が残っている」
            //   そのとおりでした。本番では V04_X6_BASELINE が null なので
            //   $similar=null で呼ばれ、到達しない経路でしたが、
            //   <b>経路として閉じていませんでした</b>。
            //   基準率（07章B）が未合意のあいだは、類似統計を渡されても
            //   必ず UNKNOWN にします。下の TRUE/FALSE の表は、
            //   基準率が決まって V04_X6_BASELINE に値が入ってから使います。
            $X6 = 'UNKNOWN';
            $x6Note = 'B案：同条件比較基準率（07章B）が未合意のため、'
                    . '類似統計を渡されても TRUE/FALSE にしません';
        } elseif ($similar === null
            || ($similar['sample_size'] ?? null) === null
            || ($similar['delta_pp']    ?? null) === null) {
            $X6 = 'UNKNOWN';
            $x6Note = '同条件比較基準率が未定義・未提供（07章B）のため不明。0%で埋めない';
        } elseif ((int) $similar['sample_size'] < $thr['similar_min_races']) {""",
    'X6: N<7 は FALSE')

rep("""        $check('F-derive', 'X6（基準率未定義）',      $d['flags']['X6'], 'UNKNOWN');""",
    """        // @ANCHOR-20261020-R122-PROMPT  N=6 なので X6 は構造的非該当（FALSE）
        //   【旧期待値】'UNKNOWN'。本番側に N<7 の分岐が無かったころの値です。
        $check('F-derive', 'X6（N<7は構造的非該当）',  $d['flags']['X6'], 'FALSE');
        $check('F-derive', 'X6（N>=7で基準率未定義）',
               self::v04DeriveFlags(16, $pairs, [], null)['flags']['X6'], 'UNKNOWN');""",
    'F-derive の X6 期待値')

# ───────────────────────────────────────────────────────────────────────────
# 2b-2) B-T21 の期待値を B案へ合わせる（@ANCHOR-20261020-R122-X6）
# ───────────────────────────────────────────────────────────────────────────
rep("""        $check('B-T21', 'X6=UNKNOWN', self::v04DeriveFlags(16, [], [], null)['flags']['X6'], 'UNKNOWN');
        $check('B-T21', 'X6=FALSE（母数49件は最低条件未達）',
               self::v04DeriveFlags(16, [], [], ['sample_size' => 49, 'delta_pp' => 30.0])['flags']['X6'], 'FALSE');
        $check('B-T21', 'X6=TRUE（母数50件・差10pp）',
               self::v04DeriveFlags(16, [], [], ['sample_size' => 50, 'delta_pp' => 10.0])['flags']['X6'], 'TRUE');""",
    """        // ══════════════════════════════════════════════════════════════
        // @ANCHOR-20261020-R122-X6  B案：基準率が未合意のあいだは必ずUNKNOWN
        // ══════════════════════════════════════════════════════════════
        //   【旧期待値】消さずに残します。基準率（07章B）が決まり
        //     V04_X6_BASELINE に値が入ってから、この表に戻ります。
        //     $check('B-T21', 'X6=FALSE（母数49件は最低条件未達）', …, 'FALSE');
        //     $check('B-T21', 'X6=TRUE（母数50件・差10pp）',        …, 'TRUE');
        $check('B-T21', 'X6=UNKNOWN', self::v04DeriveFlags(16, [], [], null)['flags']['X6'], 'UNKNOWN');
        $check('B-T21', 'X6=UNKNOWN（母数49件を渡されても旧判定へ進まない）',
               self::v04DeriveFlags(16, [], [], ['sample_size' => 49, 'delta_pp' => 30.0])['flags']['X6'], 'UNKNOWN');
        $check('B-T21', 'X6=UNKNOWN（母数50件・差10ppでも旧判定へ進まない）',
               self::v04DeriveFlags(16, [], [], ['sample_size' => 50, 'delta_pp' => 10.0])['flags']['X6'], 'UNKNOWN');
        $check('B-T21', 'X6=FALSE（N<7は構造的非該当）',
               self::v04DeriveFlags(6, [], [], ['sample_size' => 50, 'delta_pp' => 10.0])['flags']['X6'], 'FALSE');
        $check('B-T21', '基準率は未合意のまま', self::V04_X6_BASELINE, null);""",
    'B-T21 の期待値')

# ───────────────────────────────────────────────────────────────────────────
# 2c) 送信文まわりの受入試験を足す
# ───────────────────────────────────────────────────────────────────────────
rep("""        $check('R122-H01', 'role情報が混ざっていない',
            strpos((string) $c1['json'], 'role_quota'), false);""",
    """        $check('R122-H01', 'role情報が混ざっていない',
            strpos((string) $c1['json'], 'role_quota'), false);

        // ── 送信文（@ANCHOR-20261020-R122-PROMPT）────────────────────────
        $check('R122-P01', 'キー順の正規化（数字キーも文字列として昇順）',
            BaganrikiPrompt::canonical(['b'=>1,'a'=>['d'=>2,'c'=>[3,1]],'10'=>'x','9'=>'y']),
            '{"10":"x","9":"y","a":{"c":[3,1],"d":2},"b":1}');
        $check('R122-P01', '配列の順は変えない',
            BaganrikiPrompt::canonical([['n'=>2],['n'=>1]]), '[{"n":2},{"n":1}]');
        $check('R122-P01', '非ASCIIはエスケープしない',
            BaganrikiPrompt::canonical(['k'=>'あ/い']), '{"k":"あ/い"}');
        $check('R122-P01', '小数秒が0なら付けない',
            BaganrikiPrompt::rfc3339((int) BaganrikiTime::us('2026-10-17T15:00:00+09:00')),
            '2026-10-17T15:00:00+09:00');
        $check('R122-P01', '小数秒があれば残す',
            BaganrikiPrompt::rfc3339((int) BaganrikiTime::us('2026-10-17T15:00:00.5+09:00')),
            '2026-10-17T15:00:00.500000+09:00');
        $check('R122-P01', '索引キー（スロットあり）',
            BaganrikiPrompt::indexKey(['scope'=>'HORSE','field'=>'win_odds',
                'horse_nos'=>[3],'slot_offset'=>6]), 'horse/3/win_odds/6');
        $check('R122-P01', '索引キー（スロットなし）',
            BaganrikiPrompt::indexKey(['scope'=>'HORSE','field'=>'past_performance',
                'horse_nos'=>[3],'slot_offset'=>null]), 'horse/3/past_performance/None');
        $pp1 = BaganrikiPrompt::commonHash(['race_id'=>'R','ai_role'=>'1st',
            'role_cap'=>7,'role_quota'=>['A'=>3,'B'=>3,'D'=>1],'snapshot_hash'=>'zzz']);
        $pp2 = BaganrikiPrompt::commonHash(['race_id'=>'R','ai_role'=>'2nd',
            'role_cap'=>5,'role_quota'=>['A'=>1,'B'=>3,'D'=>1],'snapshot_hash'=>'yyy']);
        $check('R122-P01', '両roleで共通hashが一致', $pp1['hash'], $pp2['hash']);
        $check('R122-P01', '共通本文はrole情報を含まない', $pp1['json'], '{"race_id":"R"}');
        $check('R122-P01', 'hash方式名', $pp1['hash_version'],
            'exact-common-payload-sha256-r8');
        $check('R122-P01', 'NaNは送らない',
            BaganrikiPrompt::encode(['x'=>NAN])['ok'], false);
        $check('R122-P01', '129桁の整数は送らない（指数表記も展開して数える）',
            BaganrikiPrompt::tooLongNumber(['x'=>(float) str_repeat('9', 129)]) !== null, true);
        $check('R122-P01', '普通のオッズは桁あふれにしない',
            BaganrikiPrompt::tooLongNumber(['x'=>2.1, 'y'=>11, 'z'=>1234.5678]), null);
        $check('R122-P01', '投票締切が無ければ送信文を作らない',
            BaganrikiPrompt::buildInput(['race_id'=>'R','anchor_at'=>'2026-10-17T15:00:00+09:00',
                'sales_close_at'=>null], '1st')['code'], 'SALES_CLOSE_UNRESOLVED');
        $check('R122-P01', '6分前の監査が無ければ送信文を作らない',
            BaganrikiPrompt::buildInput(['race_id'=>'R','anchor_at'=>'2026-10-17T15:00:00+09:00',
                'sales_close_at'=>'2026-10-17T14:59:00+09:00','audit'=>[]],
                '1st')['code'], 'COLLECTION_AUDIT_MISSING');
        $check('R122-P01', 'roleは1stか2ndだけ',
            BaganrikiPrompt::buildInput(['race_id'=>'R'], '3rd')['code'], 'ROLE_INVALID');
        $check('R122-P01', '本文が空なら送らない',
            count(BaganrikiPrompt::selfCheck(['role'=>'1st','system'=>'','user'=>'{}',
                'input'=>[]])) > 0, true);
        $check('R122-P01', 'coverageは7区分そろえる',
            array_keys(BaganrikiPrompt::coverageOf(null)),
            BaganrikiPrompt::COVERAGE_KEYS);
        $check('R122-P01', '入れていない区分はUNAVAILABLEと理由',
            BaganrikiPrompt::coverageOf(null)['OPI']['status'], 'UNAVAILABLE');""",
    '送信文の受入試験')

# ───────────────────────────────────────────────────────────────────────────
# 2d) Z を元値のたすき掛けで判定する（@ANCHOR-20261020-R122-Z）
# ───────────────────────────────────────────────────────────────────────────
rep("""        $z = static function (int $k) use ($at, $thr) {
            $w21 = $at($k, 21, 'W'); $w6 = $at($k, 6, 'W'); $p6 = $at($k, 6, 'P');
            if (self::v04Valid($w21) && $w21 < $thr['win_wall'])   return false;
            if (self::v04Valid($w6)  && $w6  < $thr['win_wall'])   return false;
            if (self::v04Valid($p6)  && $p6  < $thr['place_wall']) return false;
            if (!self::v04Valid($w21) || !self::v04Valid($w6) || !self::v04Valid($p6)) return null;
            return ($w21 >= $thr['win_wall']) && ($w6 >= $thr['win_wall']) && ($p6 >= $thr['place_wall']);
        };""",
    """        // ══════════════════════════════════════════════════════════════
        // @ANCHOR-20261020-R122-Z  Z も元値のたすき掛けで判定します
        // ══════════════════════════════════════════════════════════════
        // 【10月20日005のご指摘3。本物の不具合でした】
        //   X1〜X5 は $ex（元値の比較）へ置き換えたのに、<b>Zだけ $at
        //   （round(...,4) した表示用の値）を見たままでした。</b>
        //   そのため 19.9999/10 = 1.99999 が 2.0000 に丸められて
        //   「壁あり」と判定され、16頭の例で
        //   混戦 3/3/1 が 堅い 5/2/0 に変わっていました。
        //   穴側が4枠から2枠、大穴側が1枠から0枠に減ります。
        //
        //   【旧コード】消さずに残します。使っていません。
        //     $z = static function (int $k) use ($at, $thr) {
        //         $w21 = $at($k, 21, 'W'); $w6 = $at($k, 6, 'W'); $p6 = $at($k, 6, 'P');
        //         if (self::v04Valid($w21) && $w21 < $thr['win_wall'])   return false;
        //         …（丸めた値と閾値を比べていました）
        //     };
        $z = static function (int $k) use ($ex) {
            $w21 = $ex($k, 'W21>=2');
            $w6  = $ex($k, 'W6>=2');
            $p6  = $ex($k, 'P6>=1.50');
            // 三値のAND。1つでもFALSEならFALSE、不明が混ざればUNKNOWN。
            if ($w21 === false || $w6 === false || $p6 === false) { return false; }
            if ($w21 === null  || $w6 === null  || $p6 === null)  { return null; }
            return true;
        };""",
    'Z を元値で判定')

# ───────────────────────────────────────────────────────────────────────────
# 2e) ご指摘の16頭の境界例を、元値→配分まで通しで試験する
# ───────────────────────────────────────────────────────────────────────────
rep("""        $check('R122-P01', 'coverageは7区分そろえる',""",
    """        // ── @ANCHOR-20261020-R122-Z  10月20日005のご指摘3の16頭の例 ──────
        //   単勝 10 / 19.9999 / 39.9997 / 44 … 複勝 1 / 1.5 / 2.25 / 2.3 …
        //   境界1は 19.9999/10 = 1.99999 < 2、境界2も 2 未満。
        //   4桁に丸めると両方 2.0000 になり、Zが成立してしまう例です。
        //   元値 → ペア → 全信号 → mode → 配分 まで通します。
        $zTan  = ['10','19.9999','39.9997','44','48','52','56','60','64','68',
                  '72','76','80','84','88','92'];
        $zFuku = ['1','1.5','2.25','2.3','2.4','2.5','2.6','2.7','2.8','2.9',
                  '3','3.1','3.2','3.3','3.4','3.5'];
        $zHorses = [];
        foreach ($zTan as $i => $t) {
            $ts = []; $fs = [];
            foreach ([21, 18, 15, 12, 9, 6] as $tt) {
                $ts[$tt] = $t; $fs[$tt] = $zFuku[$i];
            }
            $zHorses[] = ['num' => $i + 1, 'popularity' => $i + 1,
                          'tan_series' => $ts, 'fuku_min_series' => $fs];
        }
        $zPairs = self::v04Pairs($zHorses);
        $zFlags = self::v04DeriveFlags(16, $zPairs, $zHorses, null)['flags'];
        $check('R122-Z01', 'Z（元値は2未満なので成立しない）', $zFlags['Z'],  'FALSE');
        $check('R122-Z01', 'X1', $zFlags['X1'], 'FALSE');
        $check('R122-Z01', 'X2', $zFlags['X2'], 'FALSE');
        $check('R122-Z01', 'X3', $zFlags['X3'], 'TRUE');
        $check('R122-Z01', 'X4', $zFlags['X4'], 'FALSE');
        $check('R122-Z01', 'X5', $zFlags['X5'], 'FALSE');
        $check('R122-Z01', 'X6（N>=7で基準率未定義）', $zFlags['X6'], 'UNKNOWN');
        $zCls = self::v04Classify($zFlags);
        $check('R122-Z01', 'S_min', $zCls['S_min'], 1);
        $check('R122-Z01', 'S_max', $zCls['S_max'], 2);
        $check('R122-Z01', 'mode',            $zCls['mode'],            'UNKNOWN');
        $check('R122-Z01', 'mode_status',     $zCls['mode_status'],     'PROVISIONAL');
        $check('R122-Z01', 'allocation_mode', $zCls['allocation_mode'], 'MIXED');
        $check('R122-Z01', 'mode_policy_id',  $zCls['mode_policy_id'],  'X6_ONLY_UPPER_MODE_V1');
        $zAlloc = self::v04Allocation(16, $zCls);
        $check('R122-Z01', 'target_count', $zAlloc['target_count'], 7);
        $check('R122-Z01', '1stの配分 A', $zAlloc['quota']['A'], 3);
        $check('R122-Z01', '1stの配分 B', $zAlloc['quota']['B'], 3);
        $check('R122-Z01', '1stの配分 D', $zAlloc['quota']['D'], 1);
        $check('R122-Z01', '2ndの配分 A', $zAlloc['quota_2nd']['A'], 1);
        $check('R122-Z01', '2ndの配分 B', $zAlloc['quota_2nd']['B'], 3);
        $check('R122-Z01', '2ndの配分 D', $zAlloc['quota_2nd']['D'], 1);
        // 丸めたら 2.0000 になることも、同じ入力で示しておきます
        $check('R122-Z01', '表示用のW21は丸めると2.0000',
            number_format((float) $zPairs[1]['W'][21], 4, '.', ''), '2.0000');
        $check('R122-Z01', '元値の比は2未満', $zPairs[1]['exact']['W21>=2'], false);

        $check('R122-P01', 'coverageは7区分そろえる',""",
    '16頭のZ境界例')

# ───────────────────────────────────────────────────────────────────────────
# 2f) 取消後に目標数Cと基本配分を引き直す（@ANCHOR-20261020-R122-RECALC）
# ───────────────────────────────────────────────────────────────────────────
rep("""    public static function afterCancellation(array $frozenBand, array $cancelled,
                                             array $quota1st): array
    {
        $alive = [];
        foreach ($frozenBand as $num => $band) {
            if (in_array((int) $num, array_map('intval', $cancelled), true)) { continue; }
            $alive[$band] = ($alive[$band] ?? 0) + 1;
        }
        $avail = ['A' => $alive['A'] ?? 0, 'B' => $alive['B'] ?? 0, 'D' => $alive['D'] ?? 0];
        $r = self::fillShortfall($quota1st, $avail);
        return ['active_count' => array_sum($avail), 'band_alive' => $avail,
                'live_quota' => $r['quota'], 'shortfalls' => $r['shortfalls'],
                'note' => '取消で人気を詰め直していません（凍結帯のまま）'];
    }""",
    """    public static function afterCancellation(array $frozenBand, array $cancelled,
                                             array $quota1st,
                                             ?string $allocationMode = null): array
    {
        $alive = [];
        foreach ($frozenBand as $num => $band) {
            if (in_array((int) $num, array_map('intval', $cancelled), true)) { continue; }
            $alive[$band] = ($alive[$band] ?? 0) + 1;
        }
        $avail = ['A' => $alive['A'] ?? 0, 'B' => $alive['B'] ?? 0, 'D' => $alive['D'] ?? 0];
        $active = array_sum($avail);

        // ══════════════════════════════════════════════════════════════
        // @ANCHOR-20261020-R122-RECALC  最新の頭数から C と基本配分を引き直す
        // ══════════════════════════════════════════════════════════════
        // 【10月20日005のご指摘4。本物の不具合でした】
        //   これまでは旧 quota の不足移動しかしておらず、
        //   <b>頭数が減っても目標数 C と基本配分を引き直していませんでした。</b>
        //     16→15 … 3/3/1 のまま（正しくは 3/2/1）
        //     14→13 … 3/2/1 のまま（正しくは 3/2/0）
        //      9→8  … 3/2/0 のまま（正しくは 2/2/0）
        //   凍結帯は維持します（人気を詰め直しません）。
        //   引き直すのは「最新の頭数に応じた目標数と基本配分」だけです。
        $base = null; $moves = [];
        if ($allocationMode !== null) {
            $cap = BaganrikiAllocation::v04TargetCount($active);
            if ($cap <= 0) {
                // 全頭取消。候補を作りません。
                return ['active_count' => 0, 'band_alive' => $avail,
                        'target_count' => 0, 'base_quota' => null,
                        'live_quota' => null, 'quota_adjustments' => [],
                        'shortfalls' => [], 'all_cancelled' => true,
                        'note' => '全頭取消のため候補を作りません'];
            }
            $t = ($cap <= 3)
                ? [$cap, 0, 0]
                : (AiController::V04_QUOTA_BY_TARGET[$cap][$allocationMode] ?? null);
            if ($t !== null) {
                $base = ['A' => $t[0], 'B' => $t[1], 'D' => $t[2]];
                // 実在しない帯の枠を D→B→A の順に移します。
                // 実在数は「凍結帯で生き残っている頭数」で見ます。
                $q = [$t[0], $t[1], $t[2]];
                $cp = [$avail['A'], $avail['B'], $avail['D']];
                $idx = ['A' => 0, 'B' => 1, 'D' => 2];
                foreach ([['D', ['B', 'A']], ['B', ['D', 'A']], ['A', ['B', 'D']]] as $pair) {
                    [$from, $tos] = $pair;
                    $i = $idx[$from];
                    while ($q[$i] > $cp[$i]) {
                        $moved = false;
                        foreach ($tos as $to) {
                            $j = $idx[$to];
                            if ($q[$j] < $cp[$j]) {
                                $q[$i]--; $q[$j]++;
                                $moves[] = ['requested_band' => $from, 'actual_band' => $to,
                                            'count' => 1, 'reason' => 'BAND_CAPACITY'];
                                $moved = true; break;
                            }
                        }
                        if (!$moved) {
                            $q[$i]--;
                            $moves[] = ['requested_band' => $from, 'actual_band' => null,
                                        'count' => 1, 'reason' => 'BAND_CAPACITY'];
                        }
                    }
                }
                $quota1st = ['A' => $q[0], 'B' => $q[1], 'D' => $q[2]];
            }
        }

        $r = self::fillShortfall($quota1st, $avail);
        return ['active_count' => $active, 'band_alive' => $avail,
                'target_count' => ($allocationMode === null) ? null
                                  : BaganrikiAllocation::v04TargetCount($active),
                'base_quota' => $base,
                'live_quota' => $r['quota'], 'quota_adjustments' => $moves,
                'shortfalls' => $r['shortfalls'], 'all_cancelled' => false,
                'note' => '取消で人気を詰め直していません（凍結帯のまま）。'
                        . '目標数と基本配分は最新の頭数から引き直しています'];
    }""",
    'afterCancellation の再計算')

# ───────────────────────────────────────────────────────────────────────────
# 2g) 証明のない +5 を止める（@ANCHOR-20261020-R122-PROOF）
# ───────────────────────────────────────────────────────────────────────────
rep("""            if ($both && count($roles) >= 2) {
                $a['bonus'] = 5.0;
                $a['parts'] = self::addScore($a['parts'], 5);
                $a['public_proof_hash'] = $proofHash;
            }""",
    """            // ══════════════════════════════════════════════════════════
            // @ANCHOR-20261020-R122-PROOF  証明が無ければ +5 しません
            // ══════════════════════════════════════════════════════════
            // 【10月20日005のご指摘5-2。そのとおりでした】
            //   これまでは「両roleで public=true」だけで +5 していて、
            //   <b>proofHash の有無も正当性も条件にしていませんでした。</b>
            //   検証済みの原応答から取った証明が、その馬について
            //   両roleぶんそろっているときだけ加点します。
            $proven = $both && count($roles) >= 2
                    && self::proofForHorse($proofHash, $roles, (int) $num) !== null;
            if ($proven) {
                $a['bonus'] = 5.0;
                $a['parts'] = self::addScore($a['parts'], 5);
                $a['public_proof_hash'] = self::proofForHorse($proofHash, $roles, (int) $num);
            } elseif ($both && count($roles) >= 2) {
                $a['no_bonus_reason'] = '両roleの原公開を証明できないため加点しません';
            }""",
    '証明のない+5を止める')

rep("""            $a['both_public'] = $both && count($roles) >= 2;""",
    """            $a['both_public'] = $both && count($roles) >= 2;
            $a['bonus_proven'] = $proven;""",
    'both_public の隣に証明の有無')

rep("""    public static function fillShortfall(array $quota, array $avail): array""",
    """    /**
     * @ANCHOR-20261020-R122-PROOF  その馬の「両roleの原公開」の証明を取り出す
     *
     * 受け取る形は2つとも通します。
     *   $proofHash[role][馬番] = 64桁の16進
     *   $proofHash[馬番][role] = 64桁の16進
     * 全roleぶんそろっていて、どれも64桁の16進のときだけ配列を返します。
     * 1つでも欠けていれば null を返し、呼び出し側は加点しません。
     */
    public static function proofForHorse($proofHash, array $roles, int $num): ?array
    {
        if (!is_array($proofHash) || $proofHash === []) { return null; }
        $out = [];
        foreach ($roles as $r) {
            $v = $proofHash[$r][$num] ?? ($proofHash[$num][$r] ?? null);
            if (!is_string($v) || !preg_match('/^[0-9a-f]{64}$/', $v)) { return null; }
            $out[$r] = $v;
        }
        return ($out === []) ? null : $out;
    }

    public static function fillShortfall(array $quota, array $avail): array""",
    'proofForHorse の追加')

rep("""        $check('R122-R03', '両AIの原公開一致で+5', $mg[0]['bonus'], 5.0);
        $check('R122-R03', '統合点は両roleの最大＋加点', $mg[0]['score'], 105.0);
        $check('R122-R03', '片側だけなら加点しない', $mg[1]['bonus'], 0.0);""",
    """        // @ANCHOR-20261020-R122-PROOF  証明が無ければ加点しません
        //   【旧期待値】証明を渡さずに 5.0 / 105.0 を正解にしていました。
        //     $check('R122-R03', '両AIの原公開一致で+5', $mg[0]['bonus'], 5.0);
        $check('R122-R03', '証明が無ければ加点しない', $mg[0]['bonus'], 0.0);
        $check('R122-R03', '証明が無ければ100点のまま', $mg[0]['score'], 100.0);
        $check('R122-R03', '加点しなかった理由を残す',
            $mg[0]['no_bonus_reason'], '両roleの原公開を証明できないため加点しません');
        $h64 = str_repeat('a', 64);
        $mgP = BaganrikiRanking::merge([
            '1st'=>[7=>['r'=>1,'K'=>4,'public'=>true,'groups'=>2],
                    9=>['r'=>2,'K'=>4,'public'=>false,'groups'=>1]],
            '2nd'=>[7=>['r'=>2,'K'=>4,'public'=>true,'groups'=>2],
                    9=>['r'=>1,'K'=>4,'public'=>false,'groups'=>1]],
        ], ['1st'=>[7=>$h64], '2nd'=>[7=>$h64]]);
        $check('R122-R03', '両AIの証明がそろえば+5', $mgP[0]['bonus'], 5.0);
        $check('R122-R03', '統合点は両roleの最大＋加点', $mgP[0]['score'], 105.0);
        $check('R122-R03', '片側だけなら加点しない', $mgP[1]['bonus'], 0.0);
        $mgH = BaganrikiRanking::merge([
            '1st'=>[7=>['r'=>1,'K'=>4,'public'=>true,'groups'=>2]],
            '2nd'=>[7=>['r'=>2,'K'=>4,'public'=>true,'groups'=>2]],
        ], ['1st'=>[7=>$h64], '2nd'=>[7=>'みじかい']]);
        $check('R122-R03', '片側の証明が不正なら加点しない', $mgH[0]['bonus'], 0.0);""",
    'R122-R03 の期待値')

# ───────────────────────────────────────────────────────────────────────────
# 2h) 正規応答の馬番キー（@ANCHOR-20261020-R122-HORSENO）
# ───────────────────────────────────────────────────────────────────────────
rep("""        $kept = []; $iso = []; $seen = [];
        foreach ($horses as $h) {
            $num = $h['num'] ?? null;""",
    """        $kept = []; $iso = []; $seen = [];
        foreach ($horses as $h) {
            // @ANCHOR-20261020-R122-HORSENO  正規応答のキーは horse_no です
            //   【10月20日005のご指摘5-3】num しか読んでおらず、
            //   正規の応答をそのまま渡すと馬番を読めませんでした。
            //   どちらの綴りでも読めるようにします（horse_no を優先）。
            $num = $h['horse_no'] ?? ($h['num'] ?? null);""",
    'isolateHorses の馬番キー')

# ───────────────────────────────────────────────────────────────────────────
# 2i) 欠落馬救済・repair_scope・row_valid（@ANCHOR-20261020-R122-REPAIR）
# ───────────────────────────────────────────────────────────────────────────
rep("""    public static function acceptCorrection(array $first, array $fix,
                                            ?string $firstAt = null, ?string $fixAt = null): array
    {""",
    """    public static function acceptCorrection(array $first, array $fix,
                                            ?string $firstAt = null, ?string $fixAt = null,
                                            array $frozenNums = [], ?array $repairScope = null,
                                            array $rowValid = [],
                                            ?array $firstMap = null,
                                            ?array $fixMap = null): array
    {
        // ══════════════════════════════════════════════════════════════
        // @ANCHOR-20261021-R122-TYPEMAP  型まで見て比べます（010の3-2）
        // ══════════════════════════════════════════════════════════════
        //   ご指摘：
        //     「既存には、sameHorseRowの厳密比較と、訂正対象外フィールドの
        //       $v0 !== $v1 があります。オブジェクトを導入すると、同じ数値
        //       でも別インスタンスであることを理由に差異と判定する可能性が
        //       あります。共通の比較関数で、JSONの型、正確な十進値、
        //       必要な整数／小数・指数表記の区別を比較してください。
        //       通常のオブジェクトのキー順は無視し、配列の順序は
        //       保持します。」
        //
        //   $firstMap／$fixMap（型の地図）が両方そろっているときは、
        //   <b>BaganrikiJson::same</b> で比べます。
        //   ・PHPの === では、丸まる数値を文字列で持っているときに
        //     「元が数値だったか文字列だったか」が区別できません。
        //   ・値オブジェクトを使う案は、同じ値の別インスタンスを
        //     差異と見るおそれがあります。地図は値を包まないので、
        //     その問題は起きません。
        //   地図が無いときは、これまでどおり === で比べます
        //   （試験用の素の配列はこちらを通ります）。
        $typed = ($firstMap !== null && $fixMap !== null);
        $sameV = static function ($a, $b, array $path) use ($typed, $firstMap, $fixMap) {
            if (!$typed) { return ($a === $b); }
            return (bool) BaganrikiJson::same($a, (array) $firstMap,
                                              $b, (array) $fixMap, true, $path)['same'];
        };
        // ══════════════════════════════════════════════════════════════
        // @ANCHOR-20261020-R122-REPAIR  10月20日005のご指摘5-1
        // ══════════════════════════════════════════════════════════════
        // 【直した中身】
        //   ・初回に無い馬番を<b>一律に拒否</b>していました。
        //     契約6章は「凍結runner集合にいて、horses訂正の対象なら救済する」です。
        //     未知馬（凍結集合にいない）と、初回から漏れた実在馬を分けます。
        //   ・repair_scope と row_valid を受け取っていませんでした。
        //     対象外の馬を変えようとする訂正は採用しません。
        //     row_valid=false の行は適用しません。
        $rescued = []; $skipped = [];""",
    'acceptCorrection の引数')

# ══════════════════════════════════════════════════════════════════════
# @ANCHOR-20261020-R122-CORRKEY  10月20日006のご指摘5-1（本物の不具合）
# ══════════════════════════════════════════════════════════════════════
#   保護の条件が score_state と independent_groups を見ていました。
#   正規の応答にそのキーはありません（正しくは score_status と family_review）。
#   そのため採点状態は常に partial、群数は常に0になり、
#   「complete を partial へ悪化させない」「正常な根拠を全部失わせない」
#   という保護が1度も働いていませんでした。
rep("""            $g0 = (int) ($h0['independent_groups'] ?? 0);
            $g1 = (int) ($h1['independent_groups'] ?? 0);
            if ($g0 > 0 && $g1 === 0) {
                return ['ok' => false, 'reason' => sprintf('馬番 %d の正常な根拠を全部失う訂正', $num)];
            }
            $s0 = $h0['score_state'] ?? 'partial';
            $s1 = $h1['score_state'] ?? 'partial';""",
    """            // @ANCHOR-20261020-R122-CORRKEY  正規キーで数えます
            $grp = static function ($h) {
                $n = 0;
                foreach ((array) ($h['family_review'] ?? []) as $fam) {
                    if ((string) ($fam['status'] ?? '') === 'SUPPORTED') { $n++; }
                }
                // 正規キーの無い試験用の形には independent_groups で応えます
                if ($n === 0 && array_key_exists('independent_groups', (array) $h)) {
                    $n = (int) $h['independent_groups'];
                }
                return $n;
            };
            $g0 = $grp($h0);
            $g1 = $grp($h1);
            if ($g0 > 0 && $g1 === 0) {
                return ['ok' => false, 'reason' => sprintf('馬番 %d の正常な根拠を全部失う訂正', $num)];
            }
            // 正規キーは score_status。score_state は試験用の形のための控えです。
            $s0 = $h0['score_status'] ?? ($h0['score_state'] ?? 'partial');
            $s1 = $h1['score_status'] ?? ($h1['score_state'] ?? 'partial');""",
    '@ANCHOR-20261020-R122-CORRKEY 正規キーで保護')

rep("""        $unknown = array_values(array_diff(array_keys($fix), array_keys($first)));
        if (!empty($unknown)) {
            sort($unknown);
            return ['ok' => false, 'reason' => '初回に無い馬番を足している（馬番 '
                                             . implode('・', $unknown) . '）'];
        }
        return ['ok' => true, 'reason' => null];
    }""",
    """        // ── 初回に無い馬番 ────────────────────────────────────────
        //   凍結集合にいる実在馬 → 救済（初回から漏れていただけ）
        //   凍結集合にいない馬   → 未知馬。応答ごと採用しない
        $frozen  = array_map('intval', $frozenNums);
        $extra   = array_values(array_diff(array_keys($fix), array_keys($first)));
        $unknown = [];
        foreach ($extra as $num) {
            if ($frozen !== [] && in_array((int) $num, $frozen, true)) {
                $rescued[] = (int) $num;
            } else {
                $unknown[] = (int) $num;
            }
        }
        if (!empty($unknown)) {
            sort($unknown);
            return ['ok' => false, 'rescued' => [], 'applied' => [], 'skipped' => [],
                    'reason' => '凍結集合にない馬番を足している（馬番 '
                              . implode('・', $unknown) . '）'];
        }

        // ══════════════════════════════════════════════════════════════
        // @ANCHOR-20261020-R122-SCOPEFIELD  10月20日006のご指摘5-2
        // ══════════════════════════════════════════════════════════════
        //   【本物の不具合でした】許可リストを repair_scope.horses だけに
        //   していたので、採点の集計だけがおかしい馬（summary_horses）を
        //   訂正しようとすると「対象外」で拒否していました。
        //   その馬は row_valid=false で初回からも外れるため、
        //   <b>採点欄の誤りひとつで、正常な根拠を持つ馬が候補から落ちます。</b>
        //   契約は「不正な得点項目だけを直し、正常根拠は保持する」です。
        //
        //   そこで範囲ごとに<b>直してよい項目</b>を決めます。
        //   horses は行ごと、summary_horses は採点と資格の欄だけ、
        //   presentation_horses は表示の欄だけ。
        //   範囲外の馬も、範囲内でも許されない項目を変える訂正も採用しません。
        if (is_array($repairScope)) {
            $inH = array_map('intval', (array) ($repairScope['horses'] ?? []));
            $inS = array_map('intval', (array) ($repairScope['summary_horses'] ?? []));
            $inP = array_map('intval', (array) ($repairScope['presentation_horses'] ?? []));
            $outOfScope = []; $outOfField = [];
            // ══════════════════════════════════════════════════════════
            // @ANCHOR-20261020-R122-RESTATE  10月20日007のご指摘4
            // ══════════════════════════════════════════════════════════
            //   【本物の不具合でした】訂正は<b>常に全頭を返す</b>のが契約です
            //   （配布本文：「常に全頭を含む完全なJSONを返し」）。
            //   ところが、範囲に入っていない馬を<b>初回と同じ中身かどうか
            //   調べる前に</b>「対象外を変えようとしている」と判定して、
            //   訂正をまるごと拒否していました。
            //   例：3頭のうち馬番2の集計だけ不正。訂正は3頭返し、2だけ直す。
            //       1と3は初回と同じ。それでも拒否していました。
            //   【いま】<b>未変更の正常行を再掲することと、対象外の行を
            //   書き換えることを分けます。</b>初回と同じ中身なら通します。
            // @ANCHOR-20261020-R122-RESCUESCOPE  007のご指摘4（救済の範囲）
            //   救済馬も horses の対象に入っていることを明示的に見ます。
            //   以前は範囲の検査ごと continue で飛ばしていました。
            // ══════════════════════════════════════════════════════════
            // @ANCHOR-20261021-R122-METASPLIT  10月21日008のご指摘3
            // ══════════════════════════════════════════════════════════
            //   内部の監査項目（r122_ で始まるキー）は、こちらが足した
            //   ものです。AIの業務項目ではありません。
            //   ・比較からは<b>外します</b>（これが入っていると、正しい
            //     訂正が「範囲外を変えた」と判定されます）
            //   ・訂正の側に入っていたら<b>断ります</b>（AIに内部の監査
            //     項目を書かせることになるためです）
            $metaIn = [];
            foreach ($fix as $num => $h1) {
                foreach (array_keys((array) $h1) as $k) {
                    if (strncmp((string) $k, 'r122_', 5) === 0) {
                        $metaIn[] = (int) $num . ':' . (string) $k;
                    }
                }
            }
            if ($metaIn !== []) {
                sort($metaIn);
                return ['ok' => false, 'rescued' => [], 'applied' => [],
                        'skipped' => [], 'restated' => [],
                        'reason' => '訂正に内部の監査項目が入っています（'
                                  . implode('・', array_slice($metaIn, 0, 5))
                                  . '）。これはAIが返す項目ではありません'];
            }
            $restated = [];
            foreach ($fix as $num => $h1) {
                $num = (int) $num;
                if (in_array($num, $inH, true)) { continue; }      // 行ごと直せます
                if (in_array($num, $rescued, true)) {
                    // @ANCHOR-...-RESCUESCOPE  救済も horses の対象であること
                    if (!in_array($num, $inH, true)) {
                        $outOfScope[] = $num;
                    }
                    continue;
                }
                $fields = [];
                if (in_array($num, $inS, true)) {
                    $fields = array_merge($fields, self::FIX_FIELDS_SUMMARY);
                }
                if (in_array($num, $inP, true)) {
                    $fields = array_merge($fields, self::FIX_FIELDS_PRESENTATION);
                }
                if ($fields === []) {
                    // @ANCHOR-...-RESTATE  初回と同じなら「再掲」です
                    if (array_key_exists($num, $first)
                        && self::sameHorseRow((array) $first[$num], (array) $h1,
                                              $firstMap, $fixMap, [(string) $num])) {
                        $restated[] = $num;
                        continue;
                    }
                    $outOfScope[] = $num;
                    continue;
                }
                $h0 = (array) ($first[$num] ?? []);
                $keys = array_unique(array_merge(array_keys($h0),
                                                 array_keys((array) $h1)));
                foreach ($keys as $k) {
                    if (in_array((string) $k, $fields, true)) { continue; }
                    // @ANCHOR-20261021-R122-METASPLIT  内部の監査項目は見ません
                    if (strncmp((string) $k, 'r122_', 5) === 0) { continue; }
                    // @ANCHOR-20261021-R122-TYPEMAP  型まで見て比べます
                    //   どちらかにキーが無い場合もここで分かります
                    //   （?? null は null の値と見分けが付かないので、
                    //     キーの有無を先に見ます）
                    $has0 = array_key_exists($k, $h0);
                    $has1 = array_key_exists($k, (array) $h1);
                    if ($has0 !== $has1) {
                        $outOfField[] = $num . ':' . $k;
                        continue;
                    }
                    if (!$has0) { continue; }           // どちらにも無い
                    $v0 = $h0[$k];
                    $v1 = ((array) $h1)[$k];
                    if (!$sameV($v0, $v1, [(string) $num, (string) $k])) {
                        $outOfField[] = $num . ':' . $k;
                    }
                }
            }
            if (!empty($outOfScope)) {
                sort($outOfScope);
                return ['ok' => false, 'rescued' => [], 'applied' => [], 'skipped' => [],
                        'restated' => [],
                        'reason' => 'repair_scope の対象外を変えようとしている（馬番 '
                                  . implode('・', $outOfScope) . '）'
                                  . '。初回と同じ中身の再掲は通します'];
            }
            if (!empty($outOfField)) {
                sort($outOfField);
                return ['ok' => false, 'rescued' => [], 'applied' => [], 'skipped' => [],
                        'reason' => 'その範囲で直してよい項目の外を変えています（'
                                  . implode('・', array_slice($outOfField, 0, 5)) . '）'];
            }
        }

        // ══════════════════════════════════════════════════════════════
        // @ANCHOR-20261020-R122-ROWVALID  10月20日006のご指摘5-3
        // ══════════════════════════════════════════════════════════════
        //   【本物の不具合でした】救済した馬を先に rescued へ入れてから
        //   row_valid を見ていたので、row_valid=false の救済馬が
        //   rescued と skipped の<b>両方</b>に入り、applyCorrection の
        //   許可（applied ∪ rescued）を通っていました。
        //   いまは skipped になった馬を rescued からも外します。
        //   row_valid は<b>明示 true のときだけ</b>承認します
        //   （キーが無い＝未設定は承認しません）。
        // @ANCHOR-20261020-R122-ROWVALIDREQ  10月20日007のご指摘4
        //   【旧】`$rowValid !== []` のときだけ見ていたので、
        //     空で渡すと検査そのものが飛び、「未設定は常に通さない」
        //     という説明が関数単体では成立していませんでした。
        //   【いま】<b>row_valid を渡さない呼び方を断ります。</b>
        //     検証結果なしに訂正を承認してはいけないためです。
        //   訂正の中身が空（当てる行が1つも無い）ときは、承認する行も
        //   無いので、この検査は当てません（時刻だけを見る呼び方のためです）。
        if ($fix !== [] && $rowValid === []) {
            return ['ok' => false, 'rescued' => [], 'applied' => [], 'skipped' => [],
                    'restated' => [],
                    'reason' => 'row_valid が渡されていません'
                              . '（明示 true の行だけ承認します）'];
        }
        $applied = [];
        foreach (array_keys($fix) as $num) {
            $num = (int) $num;
            if (($rowValid[$num] ?? null) !== true) {
                $skipped[] = $num;
                continue;
            }
            $applied[] = $num;
        }
        // 再掲（未変更の正常行）は「当てる」側には入れません。初回を保ちます。
        $restated = array_values(array_unique(array_map('intval', $restated ?? [])));
        $applied  = array_values(array_diff($applied, $restated));
        $rescued  = array_values(array_diff($rescued, $skipped));
        $applied  = array_values(array_diff($applied, $skipped));
        sort($rescued); sort($applied); sort($skipped); sort($restated);
        return ['ok' => true, 'reason' => null, 'restated' => $restated,
                'rescued' => $rescued, 'applied' => $applied, 'skipped' => $skipped];
    }

    /**
     * @ANCHOR-20261020-R122-RESTATE  2つの馬行が同じ中身かどうか
     *   キーの並びが違っても同じと見ます（訂正はJSONを作り直すためです）。
     *   入れ子も並べ替えてから比べます。数値の型の違い（1 と 1.0）は
     *   別物として扱います（採点は整数と決まっているためです）。
     */
    public static function sameHorseRow(array $a, array $b,
                                        ?array $mapA = null, ?array $mapB = null,
                                        array $path = []): bool
    {
        // @ANCHOR-20261021-R122-METASPLIT  内部の監査項目（r122_）は比べません。
        //   こちらが足したもので、AIが返す項目ではないためです。
        $strip = static function (array $v): array {
            $o = [];
            foreach ($v as $k => $x) {
                if (strncmp((string) $k, 'r122_', 5) === 0) { continue; }
                $o[$k] = $x;
            }
            return $o;
        };
        // ══════════════════════════════════════════════════════════════
        // @ANCHOR-20261021-R122-TYPEMAP  型の地図があるときは型まで見ます
        // ══════════════════════════════════════════════════════════════
        //   地図があれば、JSON上の型・正確な十進値・整数/小数/指数の
        //   表記まで見ます（010の3-2）。並べ替えは中で行うので、
        //   ここで ksort する必要はありません
        //   （same はオブジェクトのキー順を無視します）。
        if ($mapA !== null && $mapB !== null) {
            $r = BaganrikiJson::same($strip($a), $mapA, $strip($b), $mapB,
                                     true, $path);
            return (bool) $r['same'];
        }
        // 地図が無いとき（試験用の素の配列など）は、これまでどおりです。
        $norm = static function ($v) use (&$norm) {
            if (!is_array($v)) { return $v; }
            $isList = (array_keys($v) === range(0, count($v) - 1));
            $o = [];
            foreach ($v as $k => $x) { $o[$k] = $norm($x); }
            if (!$isList) { ksort($o, SORT_STRING); }
            return $o;
        };
        return $norm($strip($a)) === $norm($strip($b));
    }

    /**
     * @ANCHOR-20261020-R122-SCOPEFIELD  範囲ごとに直してよい項目
     *   summary_horses は採点と資格のまわりだけ、
     *   presentation_horses は表示のまわりだけを直せます。
     *   ここに無い項目を変える訂正は採用しません。
     */
    public const FIX_FIELDS_SUMMARY = [
        'eligibility', 'tier', 'scores', 'score_evidence', 'score_status',
        'total_score', 'observed_sum', 'observed_cap', 'rank_basis',
        'rank_reason', 'family_review',
    ];
    public const FIX_FIELDS_PRESENTATION = [
        'public_candidate', 'nonselect_reason', 'explanation',
        'evidence_rank_reason', 'evidence_rank_evidence_ids',
    ];""",
    'acceptCorrection の本体')

rep("""    public static function applyCorrection(array $first, array $fix): array
    {
        $out = $first;
        foreach ($fix as $num => $h) { $out[$num] = $h; }
        return $out;
    }""",
    """    public static function applyCorrection(array $first, array $fix,
                                           ?array $accept = null): array
    {
        // @ANCHOR-20261020-R122-REPAIR  採否の結果にある行だけを反映します
        //   $accept を渡さないときは、これまでどおり $fix を全部当てます。
        $out = $first;
        if ($accept === null) {
            foreach ($fix as $num => $h) { $out[$num] = $h; }
            return $out;
        }
        if (($accept['ok'] ?? false) !== true) { return $out; }   // 不採用なら初回のまま
        $allow = array_map('intval',
            array_merge((array) ($accept['applied'] ?? []), (array) ($accept['rescued'] ?? [])));
        foreach ($fix as $num => $h) {
            if (!in_array((int) $num, $allow, true)) { continue; }   // 対象外・row_valid=false
            $out[(int) $num] = $h;
        }
        return $out;
    }""",
    'applyCorrection')

rep("""        $check('R122-V03', '根拠を全部消す訂正は採用しない',
            BaganrikiResponse::acceptCorrection($first,
                [1=>['independent_groups'=>0,'score_state'=>'complete']])['ok'], false);
        $check('R122-V03', 'completeをpartialへ悪化させる訂正は採用しない',
            BaganrikiResponse::acceptCorrection($first,
                [1=>['independent_groups'=>2,'score_state'=>'partial']])['ok'], false);""",
    """        // @ANCHOR-20261020-R122-ROWVALIDREQ  10月20日007のご指摘4
        //   row_valid を渡さない呼び方を断るようにしたので、試験でも渡します。
        //   渡さないと「row_valid が無い」で落ちて、見たい検査を
        //   通らないまま合格してしまうためです。
        $check('R122-V03', '根拠を全部消す訂正は採用しない',
            BaganrikiResponse::acceptCorrection($first,
                [1=>['independent_groups'=>0,'score_state'=>'complete']],
                null, null, [], null, [1=>true])['ok'], false);
        $check('R122-V03', 'completeをpartialへ悪化させる訂正は採用しない',
            BaganrikiResponse::acceptCorrection($first,
                [1=>['independent_groups'=>2,'score_state'=>'partial']],
                null, null, [], null, [1=>true])['ok'], false);""",
    'acceptCorrection の試験に row_valid を渡す')

rep("""        $check('R122-V03', '初回に無い馬番を足す訂正は採用しない',
            BaganrikiResponse::acceptCorrection($first,
                [5=>['independent_groups'=>1,'score_state'=>'complete']])['ok'], false);""",
    """        $check('R122-V03', '凍結集合にない馬番を足す訂正は採用しない',
            BaganrikiResponse::acceptCorrection($first,
                [5=>['independent_groups'=>1,'score_state'=>'complete']],
                null, null, [1,2,3], null, [5=>true])['ok'], false);
        // @ANCHOR-20261020-R122-REPAIR  初回から漏れた実在馬は救済します
        $rs = BaganrikiResponse::acceptCorrection($first,
                [3=>['independent_groups'=>1,'score_state'=>'complete']],
                null, null, [1,2,3], null, [3=>true]);
        $check('R122-V03', '凍結集合にいる欠落馬は救済する', $rs['ok'], true);
        $check('R122-V03', '救済した馬番を返す', $rs['rescued'], [3]);
        $apR = BaganrikiResponse::applyCorrection($first,
                [3=>['independent_groups'=>1,'score_state'=>'complete']], $rs);
        $check('R122-V03', '救済した馬が結果へ入る', $apR[3]['score_state'], 'complete');
        // repair_scope の対象外は採用しない
        $check('R122-V03', 'repair_scopeの対象外を変える訂正は採用しない',
            BaganrikiResponse::acceptCorrection($first,
                [2=>['independent_groups'=>2,'score_state'=>'complete']],
                null, null, [1,2,3], ['horses'=>[1]], [2=>true])['ok'], false);
        $check('R122-V03', 'repair_scopeの対象内なら採用する',
            BaganrikiResponse::acceptCorrection($first,
                [1=>['independent_groups'=>2,'score_state'=>'complete']],
                null, null, [1,2,3], ['horses'=>[1]], [1=>true])['ok'], true);

        // ── @ANCHOR-20261020-R122-RESTATE  10月20日007のご指摘4 ──────────
        //   訂正は常に全頭を返します。未変更の正常行の再掲を
        //   「対象外を変えようとしている」と誤判定しないこと。
        $fixAll = [1=>['independent_groups'=>2,'score_state'=>'complete'],
                   2=>$first[2]];
        $rst = BaganrikiResponse::acceptCorrection($first, $fixAll,
                null, null, [1,2], ['horses'=>[1]], [1=>true, 2=>true]);
        $check('R122-V05', '全頭返す訂正を受け入れる（未変更の再掲）',
            $rst['ok'], true);
        $check('R122-V05', '対象の馬だけ当てる', $rst['applied'], [1]);
        $check('R122-V05', '未変更の再掲は再掲として分ける', $rst['restated'], [2]);
        $apRst = BaganrikiResponse::applyCorrection($first, $fixAll, $rst);
        $check('R122-V05', '対象外の馬は初回のまま',
            ($apRst[2] ?? null) === ($first[2] ?? null), true);
        // 再掲のふりをして中身を変えていたら拒否します
        $fixSneak = $fixAll;
        $fixSneak[2] = ['independent_groups'=>9,'score_state'=>'complete'];
        $check('R122-V05', '対象外の行を本当に変える訂正は拒否',
            BaganrikiResponse::acceptCorrection($first, $fixSneak,
                null, null, [1,2], ['horses'=>[1]], [1=>true,2=>true])['ok'], false);
        // キーの並びが違うだけの再掲は同じ中身として扱います
        $check('R122-V05', 'キーの並びが違うだけなら同じ中身',
            BaganrikiResponse::sameHorseRow(['a'=>1,'b'=>['x'=>1,'y'=>2]],
                                            ['b'=>['y'=>2,'x'=>1],'a'=>1]), true);
        $check('R122-V05', '中身が違えば別物',
            BaganrikiResponse::sameHorseRow(['a'=>1], ['a'=>2]), false);
        // @ANCHOR-20261020-R122-ROWVALIDREQ  row_valid を渡さない呼び方は断る
        $check('R122-V05', 'row_valid を渡さない訂正は採用しない',
            BaganrikiResponse::acceptCorrection($first,
                [1=>['independent_groups'=>2,'score_state'=>'complete']],
                null, null, [1,2], ['horses'=>[1]])['ok'], false);
        // @ANCHOR-20261020-R122-RESCUESCOPE  救済も horses の対象であること
        $check('R122-V05', '救済馬が horses の対象外なら採用しない',
            BaganrikiResponse::acceptCorrection($first,
                [3=>['independent_groups'=>1,'score_state'=>'complete']],
                null, null, [1,2,3], ['horses'=>[1]], [3=>true])['ok'], false);
        // row_valid=false の行は当てない
        $rv = BaganrikiResponse::acceptCorrection($first,
                [1=>['independent_groups'=>2,'score_state'=>'complete'],
                 2=>['independent_groups'=>2,'score_state'=>'complete']],
                null, null, [1,2,3], null, [1=>true, 2=>false]);
        $check('R122-V03', 'row_valid=false は適用しない', $rv['skipped'], [2]);
        $check('R122-V03', 'row_valid=true だけ適用する', $rv['applied'], [1]);
        $apV = BaganrikiResponse::applyCorrection($first,
                [1=>['independent_groups'=>2,'score_state'=>'complete'],
                 2=>['independent_groups'=>9,'score_state'=>'complete']], $rv);
        $check('R122-V03', 'row_valid=false の行は初回のまま',
            $apV[2]['independent_groups'], 1);   // 初回の値（$first[2]）のまま""",
    'R122-V03 の訂正試験')

# ───────────────────────────────────────────────────────────────────────────
# 2k) 小数4桁制限とfloat代替経路（@ANCHOR-20261020-R122-DIGITS）
# ───────────────────────────────────────────────────────────────────────────
# ══════════════════════════════════════════════════════════════════════
# ══════════════════════════════════════════════════════════════════════
# @ANCHOR-20261020-R122-DEC  10月20日006のご指摘6-1（本物の不具合）
# ══════════════════════════════════════════════════════════════════════
#   usableDecimal の4桁制限は外したのに、BaganrikiSnapshot::scale は
#   小数1〜4桁のままでした。1.23456 は取得側を通るのに、
#   凍結順位を作る frozenRank で「読めない」として<b>レースごと止まります。</b>
#   scale は1万倍の整数なので、そもそも桁を増やせません。
#   凍結順位は「大小が分かれば足りる」ので、十進数の文字列のまま比べます。
rep("""    public static function frozenRank(array $win6): array
    {
        $scaled = [];
        foreach ($win6 as $num => $s) {
            $v = self::scale($s);
            if ($v === null) {
                return ['ok' => false, 'code' => 'FREEZE_ODDS_MISSING',
                        'reason' => '6分前の単勝が読めない馬がいる（馬番 ' . $num . '）',
                        'rank' => []];
            }
            $scaled[(int) $num] = $v;
        }""",
    """    public static function frozenRank(array $win6): array
    {
        $scaled = [];
        foreach ($win6 as $num => $s) {
            // @ANCHOR-20261020-R122-DEC  桁数で弾きません（十進数の文字列のまま）
            //   【旧】$v = self::scale($s);  … 小数5桁以上を null にしていました
            $v = self::decOrNull($s);
            if ($v === null) {
                return ['ok' => false, 'code' => 'FREEZE_ODDS_MISSING',
                        'reason' => '6分前の単勝が読めない馬がいる（馬番 ' . $num . '）',
                        'rank' => []];
            }
            $scaled[(int) $num] = $v;
        }""",
    '@ANCHOR-20261020-R122-DEC frozenRank の入口')

rep("""        $nums = array_keys($scaled);
        usort($nums, static function ($a, $b) use ($scaled) {
            if ($scaled[$a] !== $scaled[$b]) { return $scaled[$a] <=> $scaled[$b]; }
            return $a <=> $b;
        });
        $rank = []; $k = 1; $prev = null;
        foreach ($nums as $n) {
            if ($prev !== null && $scaled[$n] < $prev) {""",
    """        $nums = array_keys($scaled);
        usort($nums, static function ($a, $b) use ($scaled) {
            // @ANCHOR-20261020-R122-DEC  十進数の文字列どうしを桁で比べます
            $c = self::cmpDec($scaled[$a], $scaled[$b]);
            if ($c !== 0) { return $c; }
            return $a <=> $b;
        });
        $rank = []; $k = 1; $prev = null;
        foreach ($nums as $n) {
            if ($prev !== null && self::cmpDec($scaled[$n], $prev) < 0) {""",
    '@ANCHOR-20261020-R122-DEC frozenRank の並べ方')

rep("""    /** 十進数文字列を1万倍の整数へ。PHP float を通しません */
    public static function scale($v): ?int
    {""",
    """    /**
     * @ANCHOR-20261020-R122-DEC  正の十進数として読めるときだけ、その文字列を返します
     *
     *   桁数の上限を決めません。前後の空白と、先頭の余分な0だけ整えます。
     *   <b>値は作りません。</b>読めたかどうかと、比べるための形だけを返します。
     */
    public static function decOrNull($v): ?string
    {
        if ($v === null || is_bool($v)) { return null; }
        $s = trim((string) $v);
        if (preg_match('/^(\\\\d{1,128})(?:\\\\.(\\\\d{1,128}))?$/', $s, $m) !== 1) {
            return null;
        }
        $int  = ltrim($m[1], '0');
        $frac = rtrim($m[2] ?? '', '0');
        if ($int === '' && $frac === '') { return null; }   // 0 は受け取りません
        return ($int === '' ? '0' : $int) . ($frac === '' ? '' : '.' . $frac);
    }

    /**
     * @ANCHOR-20261020-R122-DEC  十進数の文字列どうしを、丸めずに比べます
     *   整数部は桁数が多いほうが大きい。同じ桁数なら文字として比べられます。
     *   小数部は短いほうを0で埋めてから比べます。float を通しません。
     */
    public static function cmpDec(string $a, string $b): int
    {
        [$ai, $af] = array_pad(explode('.', $a, 2), 2, '');
        [$bi, $bf] = array_pad(explode('.', $b, 2), 2, '');
        $ai = ltrim($ai, '0'); $bi = ltrim($bi, '0');
        if (strlen($ai) !== strlen($bi)) { return (strlen($ai) < strlen($bi)) ? -1 : 1; }
        if ($ai !== $bi) { return ($ai < $bi) ? -1 : 1; }
        $n = max(strlen($af), strlen($bf));
        $af = str_pad($af, $n, '0');
        $bf = str_pad($bf, $n, '0');
        if ($af === $bf) { return 0; }
        return ($af < $bf) ? -1 : 1;
    }

    /**
     * 十進数文字列を1万倍の整数へ。PHP float を通しません。
     * @ANCHOR-20261020-R122-DEC  <b>判定には使いません。</b>
     *   小数4桁までしか表せないので、凍結順位からは外しました。
     *   既存の呼び出し（表示・近似）のために残します。
     */
    public static function scale($v): ?int
    {""",
    '@ANCHOR-20261020-R122-DEC decOrNull と cmpDec')

rep("""        $check('R122-F01', '5桁の小数は受け取らない',
            BaganrikiSnapshot::scale('2.12345'), null);""",
    """        // @ANCHOR-20261020-R122-DEC  10月20日006のご指摘6-1
        //   scale は1万倍の整数なので5桁を表せません。だから判定から外しました。
        $check('R122-F01', 'scale（表示用）は5桁を表せない',
            BaganrikiSnapshot::scale('2.12345'), null);
        $check('R122-F01', '凍結順位は5桁でも読める',
            BaganrikiSnapshot::decOrNull('2.12345'), '2.12345');
        $check('R122-F01', '20桁の小数でも読める',
            BaganrikiSnapshot::decOrNull('1.12345678901234567890'),
            '1.1234567890123456789');
        $check('R122-F01', '0は受け取らない', BaganrikiSnapshot::decOrNull('0'), null);
        $check('R122-F01', '取消は受け取らない', BaganrikiSnapshot::decOrNull('取消'), null);
        $check('R122-F01', '1.00001 と 1.00000 の大小がつく',
            BaganrikiSnapshot::cmpDec('1.00001', '1.00000'), 1);
        $check('R122-F01', '桁数が違っても正しく比べる',
            BaganrikiSnapshot::cmpDec('9.9', '10'), -1);
        $check('R122-F01', '同じ値は0', BaganrikiSnapshot::cmpDec('2.10', '2.1'), 0);
        $fr5 = BaganrikiSnapshot::frozenRank(
            [1 => '2.12345', 2 => '2.12346', 3 => '2.1234', 4 => '10']);
        $check('R122-F01', '5桁の小数でも凍結順位が出る', $fr5['ok'], true);
        $check('R122-F01', '5桁目の違いで順位がつく', $fr5['rank'],
            [3 => 1, 1 => 2, 2 => 3, 4 => 4]);""",
    '@ANCHOR-20261020-R122-DEC 桁数の受入試験')

# ══════════════════════════════════════════════════════════════════════
# @ANCHOR-20261020-R122-ANCHORMATCH  10月20日005のご指摘2-2・7-4（本物の不具合）
# ══════════════════════════════════════════════════════════════════════
#   acceptBatch は、バッチが自分で申告した slot_scheduled_at を優先し、
#   <b>正本の発走時刻から出した予定と合っているかを見ていませんでした。</b>
#   input_freeze_at も同じで、申告された値をそのまま上限に使っていました。
#   取得側が予定を書き間違えたり、上限を甘く書いたりしても通ってしまいます。
#   発走時刻が渡されているときは、両方を正本から出した値と突き合わせます。
rep("""        // 予定時刻は、与えられていれば使い、無ければ発走時刻から作ります
        $sch = self::us($b['slot_scheduled_at'] ?? null);
        if ($sch === null) {
            if ($anchorUs === null) {
                return ['ok' => false, 'code' => 'TIME_UNREADABLE',
                        'reason' => 'slot_scheduled_at も発走時刻も無い'];
            }
            $sch = self::slotScheduled($anchorUs, $slot);
        }""",
    """        // 予定時刻は、与えられていれば使い、無ければ発走時刻から作ります
        $sch = self::us($b['slot_scheduled_at'] ?? null);
        if ($sch === null) {
            if ($anchorUs === null) {
                return ['ok' => false, 'code' => 'TIME_UNREADABLE',
                        'reason' => 'slot_scheduled_at も発走時刻も無い'];
            }
            $sch = self::slotScheduled($anchorUs, $slot);
        }
        // ══════════════════════════════════════════════════════════════
        // @ANCHOR-20261020-R122-ANCHORMATCH  正本との意味的な一致を検査
        // ══════════════════════════════════════════════════════════════
        //   「RFC3339の形になっているか」と
        //   「正本の発走時刻から出した値と合っているか」は別の検査です。
        //   発走時刻が渡されているときは、後者もここで見ます。
        if ($anchorUs !== null) {
            $want = self::slotScheduled($anchorUs, $slot);
            if ($sch !== $want) {
                return ['ok' => false, 'code' => 'SCHEDULE_MISMATCH',
                        'reason' => 'slot_scheduled_at が正本の発走時刻から出した予定と'
                                  . '合いません（申告 ' . self::toJst($sch)
                                  . '／正本 ' . self::toJst($want) . '）'];
            }
            $wantFz = self::inputFreeze($anchorUs);
            if ($v['input_freeze_at'] !== $wantFz) {
                return ['ok' => false, 'code' => 'FREEZE_MISMATCH',
                        'reason' => 'input_freeze_at が正本の発走時刻から出した情報上限と'
                                  . '合いません（申告 ' . self::toJst($v['input_freeze_at'])
                                  . '／正本 ' . self::toJst($wantFz) . '）'];
            }
        }""",
    '@ANCHOR-20261020-R122-ANCHORMATCH 正本anchorとの一致検査')

# @ANCHOR-20261020-R122-ROLLOVER  10月20日005のご指摘7-4（本物の不具合）
# ══════════════════════════════════════════════════════════════════════
#   BaganrikiTime::us は createFromFormat が false かどうかだけを見ていました。
#   PHP の createFromFormat は「2026-02-30」を 3月2日へ繰り上げて
#   <b>false を返さずに通します</b>。正規表現は \d{2} しか見ないので、
#   02-30 も 13月 も 25時 も素通りしていました。
#   作り直した日時を元の文字列と突き合わせて、ずれたら受け取りません。
rep("""    public static function us(?string $t): ?int
    {
        if ($t === null) { return null; }
        $re = '/^(\\d{4}-\\d{2}-\\d{2})[Tt](\\d{2}:\\d{2}:\\d{2})(\\.\\d{1,6})?([Zz]|[+\\-]\\d{2}:\\d{2})$/';
        if (!preg_match($re, $t, $m)) { return null; }
        $frac = isset($m[3]) ? str_pad(substr($m[3], 1), 6, '0') : '000000';
        $tz   = (strtoupper($m[4]) === 'Z') ? '+00:00' : $m[4];
        $d = \\DateTimeImmutable::createFromFormat('Y-m-d H:i:sP', $m[1] . ' ' . $m[2] . $tz);
        if ($d === false) { return null; }
        return $d->getTimestamp() * self::US + (int) $frac;
    }""",
    """    public static function us(?string $t): ?int
    {
        if ($t === null) { return null; }
        $re = '/^(\\d{4}-\\d{2}-\\d{2})[Tt](\\d{2}:\\d{2}:\\d{2})(\\.\\d{1,6})?([Zz]|[+\\-]\\d{2}:\\d{2})$/';
        if (!preg_match($re, $t, $m)) { return null; }
        $frac = isset($m[3]) ? str_pad(substr($m[3], 1), 6, '0') : '000000';
        $tz   = (strtoupper($m[4]) === 'Z') ? '+00:00' : $m[4];
        $d = \\DateTimeImmutable::createFromFormat('Y-m-d H:i:sP', $m[1] . ' ' . $m[2] . $tz);
        if ($d === false) { return null; }
        // ══════════════════════════════════════════════════════════
        // @ANCHOR-20261020-R122-ROLLOVER  繰上がりを受け取らない
        // ══════════════════════════════════════════════════════════
        //   createFromFormat は 2026-02-30 を 2026-03-02 へ、
        //   25:00 を翌日01:00 へ<b>黙って繰り上げます</b>（false になりません）。
        //   作り直した日付・時刻を元の文字列と突き合わせます。
        //   同時に警告・注意も見ます（どちらか一方では足りません）。
        $err = \\DateTimeImmutable::getLastErrors();
        if (is_array($err)
            && (($err['warning_count'] ?? 0) > 0 || ($err['error_count'] ?? 0) > 0)) {
            return null;
        }
        if ($d->format('Y-m-d') !== $m[1] || $d->format('H:i:s') !== $m[2]) {
            return null;
        }
        return $d->getTimestamp() * self::US + (int) $frac;
    }""",
    '@ANCHOR-20261020-R122-ROLLOVER 日時の繰上がり検査')

# ══════════════════════════════════════════════════════════════════════
# @ANCHOR-20261020-R122-STRICTJSON  10月20日005のご指摘7-3
# ══════════════════════════════════════════════════════════════════════
#   extract は通常の json_decode でした（深さ64だけ）。
#   重複キー・4MiB超・128桁超・指数の範囲外が素通りします。
#   走査は BaganrikiJson::strict が行い、値の作り方は変えません。
rep("""        $body = substr($raw, $i + strlen(self::BEGIN), $j - $i - strlen(self::BEGIN));
        $data = json_decode(trim($body), true, 64);
        if (!is_array($data)) {
            return ['ok' => false, 'code' => 'AI_FAILURE',
                    'reason' => 'JSONとして読めない（' . json_last_error_msg() . '）', 'json' => null];
        }
        return ['ok' => true, 'code' => null, 'reason' => null, 'json' => $data];""",
    """        $body = substr($raw, $i + strlen(self::BEGIN), $j - $i - strlen(self::BEGIN));
        // ══════════════════════════════════════════════════════════════
        // @ANCHOR-20261020-R122-STRICTJSON  読む前に本文そのものを調べます
        // ══════════════════════════════════════════════════════════════
        //   【旧】$data = json_decode(trim($body), true, 64);
        //     深さ64しか見ていませんでした。重複キーは後勝ちで黙って
        //     片方が消え、128桁超は float へ丸まり、1e400 は INF になります。
        //     どれも「読めた」ことになるので、後段の検証では拾えません。
        $st = BaganrikiJson::strict(trim($body));
        if (!$st['ok']) {
            return ['ok' => false, 'code' => 'AI_FAILURE',
                    'reason' => 'JSONとして読めない（' . $st['code'] . '：'
                              . $st['reason'] . '）', 'json' => null];
        }
        $data = $st['value'];
        if (!is_array($data)) {
            return ['ok' => false, 'code' => 'AI_FAILURE',
                    'reason' => 'JSONの最上位がオブジェクトでも配列でもありません',
                    'json' => null];
        }
        // @ANCHOR-20261021-R122-NUMTYPE  JSON上の型の印を後段へ引き継ぎます。
        //   これが無いと、丸まる数を文字列で持ったときに
        //   「数値だったのか、最初から文字列だったのか」が分かりません。
        // ══════════════════════════════════════════════════════════════
        // @ANCHOR-20261021-R122-TYPEMAP  型の地図を後段へ渡します（010の3章）
        // ══════════════════════════════════════════════════════════════
        //   number_paths だけでは、{} と [] の区別や、
        //   {\"0\":\"a\"} と [\"a\"] の区別が残りません（010の3-4）。
        //   obj／arr の種類も一緒にした「地図」を渡します。
        //     保存     BaganrikiJson::encode($json, $map)
        //     読戻し   BaganrikiJson::decode($本文)
        //     比べる   BaganrikiJson::same($a, $mapA, $b, $mapB)
        //   number_paths は、これまでの呼び出し元のために残します。
        return ['ok' => true, 'code' => null, 'reason' => null, 'json' => $data,
                'number_paths' => (array) ($st['number_paths'] ?? []),
                'map' => (array) ($st['map'] ?? BaganrikiJson::emptyMap())];""",
    '@ANCHOR-20261020-R122-STRICTJSON extract を厳密読込へ')

rep("""    public static function usableDecimal($v): bool
    {
        if ($v === null || is_bool($v)) { return false; }
        $s = trim((string) $v);
        if ($s === '' || $s === '取消' || $s === '除外') { return false; }
        if (!preg_match('/^\\d+(?:\\.\\d{1,4})?$/', $s)) { return false; }
        return (ltrim($s, '0.') !== '');   // 0 や 0.0000 は不可
    }""",
    """    public static function usableDecimal($v): bool
    {
        if ($v === null || is_bool($v)) { return false; }
        $s = trim((string) $v);
        if ($s === '' || $s === '取消' || $s === '除外') { return false; }
        // ══════════════════════════════════════════════════════════════
        // @ANCHOR-20261020-R122-DIGITS  10月20日005のご指摘7-1
        // ══════════════════════════════════════════════════════════════
        //   小数4桁までしか受け取らず、5桁以上を黙って欠損にしていました。
        //   契約9章は「整数・小数は最大128桁」です。
        //   【旧】'/^\\d+(?:\\.\\d{1,4})?$/'
        if (!preg_match('/^\\d{1,128}(?:\\.\\d{1,128})?$/', $s)) { return false; }
        return (ltrim($s, '0.') !== '');   // 0 や 0.0000 は不可
    }""",
    'usableDecimal の桁数')


rep("""            $w21 = $pairs[$k]['W'][21] ?? null;
            $w6  = $pairs[$k]['W'][6]  ?? null;
            $p6  = $pairs[$k]['P'][6]  ?? null;""",
    """            // ══════════════════════════════════════════════════════════
            // @ANCHOR-20261020-R122-DIGITS  10月20日005のご指摘7-2
            // ══════════════════════════════════════════════════════════
            //   下の代替比較は float と sprintf を通ります。
            //   <b>本番の入力からは絶対に到達させません。</b>
            //   v04Pairs() が作ったペアには必ず 'raw'（元値）が入るので、
            //   'raw' があるのに 'exact' が無いときは、代替へ落とさず
            //   不明（null）として扱います。代替は、受入試験が手で組み立てた
            //   ペア（'raw' が無いもの）専用です。
            if (isset($pairs[$k]['raw'])) { return null; }
            $w21 = $pairs[$k]['W'][21] ?? null;
            $w6  = $pairs[$k]['W'][6]  ?? null;
            $p6  = $pairs[$k]['P'][6]  ?? null;""",
    'float代替経路の分離')

rep("""        $check('R122-P01', 'coverageは7区分そろえる',""",
    """        // ── @ANCHOR-20261020-R122-DIGITS  桁数と代替経路 ──────────────
        $check('R122-E07', '小数5桁も受け取る',
            BaganrikiAcquisition::usableDecimal('2.12345'), true);
        $check('R122-E07', '小数20桁も受け取る',
            BaganrikiAcquisition::usableDecimal('1.12345678901234567890'), true);
        $check('R122-E07', '129桁の整数は受け取らない',
            BaganrikiAcquisition::usableDecimal(str_repeat('9', 129)), false);
        $check('R122-E07', '0は受け取らない', BaganrikiAcquisition::usableDecimal('0'), false);
        $check('R122-E07', '普通のオッズは数値になる', self::r122NumValue('2.1'), 2.1);
        $check('R122-E07', '整数はintになる', self::r122NumValue('11'), 11);
        $check('R122-E07', '丸めが起きる桁は数値にしない',
            is_string(self::r122NumValue('1.12345678901234567890')), true);
        $check('R122-E07', '19桁の整数は数値にしない',
            is_string(self::r122NumValue('1234567890123456789')), true);
        $check('R122-E07', '本番のペアは代替経路へ落ちない',
            self::v04DeriveFlags(16,
                [1 => ['raw' => ['Wn'=>[],'Wd'=>[],'Pn'=>[],'Pd'=>[]],
                       'W' => [21=>2.5, 6=>2.5], 'P' => [6=>2.5]]],
                [], null)['flags']['Z'], 'UNKNOWN');

        // ── @ANCHOR-20261020-R122-DIGITS2  10月20日006のご指摘6-1 ──────────
        //   PHPの数値で正確に持てない値を、登録から落とさずに
        //   十進数の文字列のまま持てているかを見ます。
        $longDec = '1.99999999999999999999';          // 20桁。floatでは2.0になります
        $check('R122-E08', '20桁の小数はPHPの数値にしない',
            is_string(self::r122NumValue($longDec)), true);
        $check('R122-E08', '20桁の小数は十進数の形として受け取れる',
            BaganrikiSnapshot::decOrNull($longDec), $longDec);
        $check('R122-E08', '20桁の小数は2未満と正しく比べられる（floatなら2.0になる）',
            BaganrikiSnapshot::cmpDec($longDec, '2'), -1);
        //   PHPの表示設定（serialize_precision）に左右されない形で見ます。
        $check('R122-E08', 'floatを通すと2と見分けが付かなくなることの確認',
            ((float) $longDec === 2.0), true);
        // 文字列のまま登録した値を、信号の経路がそのまま受け取れるか
        $regE08 = ['h1_win_odds_6' => [
                       'source_ref' => 'h1_win_odds_6', 'value' => $longDec,
                       'scope' => 'HORSE', 'horse_nos' => [1],
                       'applicable_horse_nos' => [], 'field' => 'win_odds',
                       'slot_offset' => 6]];
        $hE08 = BaganrikiPrompt::horsesForSignals($regE08, [1 => 1]);
        $check('R122-E08', '信号の経路が20桁の小数を桁落ちなく受け取る',
            $hE08[0]['tan_series'][6] ?? null, $longDec);
        $check('R122-E08', '十進数の形でないものは受け取らない',
            BaganrikiSnapshot::decOrNull('2.1e3'), null);
        $check('R122-E08', '129桁は受け取らない',
            BaganrikiSnapshot::decOrNull('1.' . str_repeat('9', 129)), null);
        // 十進数文字列への変換で桁が減らないこと（旧は小数12桁で切れていた）
        $check('R122-E08', '十進数文字列への変換で文字列は素通り',
            BaganrikiPrompt::numToDecimalString('0.1234567890123456'),
            '0.1234567890123456');
        //   PHPの表示設定に左右されない形で見ます。
        //   「戻せること」が確かめたい性質です（旧は12桁で切れて戻せなかった）。
        $check('R122-E08', '13桁目以降を落とさない（floatへ戻して一致する）',
            ((float) BaganrikiPrompt::numToDecimalString(0.1234567890123456)
             === 0.1234567890123456), true);
        $check('R122-E08', '整数はそのまま',
            BaganrikiPrompt::numToDecimalString(11), '11');
        $check('R122-E08', '指数表記は十進数へ直す',
            BaganrikiPrompt::numToDecimalString(1.0E-7), '0.0000001');
        $check('R122-E08', '大きい指数も十進数へ直す',
            BaganrikiPrompt::numToDecimalString(1.0E+20),
            '100000000000000000000');
        $check('R122-E08', '読めない指数表記は作り話をしない',
            BaganrikiPrompt::expToDecimal('abc'), '');
        // scale() が判定経路から消えていること（いまは試験の2か所だけ）
        $srcE08 = (string) file_get_contents(
            (new \ReflectionClass(self::class))->getFileName());
        //   コメント行（【旧】…と書き残した説明）は数えません。
        $check('R122-E08', 'scale() の呼び出しはこの試験の2か所だけ'
                         . '（判定経路からは消しました）',
            preg_match_all(
                '/^(?!\s*(?:\/\/|\*)).*?(?:self|BaganrikiSnapshot)::scale\(/m',
                $srcE08), 2);

        // ── @ANCHOR-20261020-R122-STRICTJSON  JSONの厳密読込（005のご指摘7-3）──
        $J = static fn(string $t) => BaganrikiJson::strict($t);
        $check('R122-J02', '普通のJSONは通る', $J('{"a":1,"b":[1,2]}')['ok'], true);
        $check('R122-J02', '値は json_decode と同じ',
            $J('{"a":1,"b":[1,2,{"c":null}]}')['value'],
            json_decode('{"a":1,"b":[1,2,{"c":null}]}', true));
        $check('R122-J02', '同じ階層の重複キーは拒否',
            $J('{"a":1,"a":2}')['code'], 'JSON_DUPLICATE_KEY');
        $check('R122-J02', '別の階層の同じキーは通る',
            $J('{"h":[{"n":1},{"n":1}]}')['ok'], true);
        $check('R122-J02', '指数が大きすぎる（1e400）',
            $J('{"a":1e400}')['code'], 'JSON_EXPONENT_RANGE');
        $check('R122-J02', '指数が小さすぎる（1e-400）',
            $J('{"a":1e-400}')['code'], 'JSON_EXPONENT_RANGE');
        $check('R122-J02', '指数308ちょうどは通る', $J('{"a":1e308}')['ok'], true);
        $check('R122-J02', '指数-308ちょうどは通る', $J('{"a":1e-308}')['ok'], true);
        $check('R122-J02', '有効桁128はちょうど通る',
            $J('{"a":' . str_repeat('9', 128) . '}')['ok'], true);
        $check('R122-J02', '有効桁129は拒否',
            $J('{"a":' . str_repeat('9', 129) . '}')['code'], 'JSON_TOO_MANY_DIGITS');
        $check('R122-J02', '先頭の0は有効桁に数えない',
            $J('{"a":0.' . str_repeat('0', 20) . '1}')['ok'], true);
        $check('R122-J02', '先頭0の整数（011）は拒否',
            $J('{"a":011}')['code'], 'JSON_INVALID');
        $check('R122-J02', '小数点から始まる数値は拒否',
            $J('{"a":.5}')['code'], 'JSON_INVALID');
        $check('R122-J02', 'NaN は拒否', $J('{"a":NaN}')['code'], 'JSON_INVALID');
        $check('R122-J02', '末尾の読点は拒否', $J('[1,2,]')['code'], 'JSON_INVALID');
        $check('R122-J02', '文字列の中の生の改行は拒否',
            $J("{\\"a\\":\\"x\\ny\\"}")['code'], 'JSON_INVALID');
        $check('R122-J02', '後ろに余分な文字があれば拒否',
            $J('{"a":1} xx')['code'], 'JSON_TRAILING');
        $check('R122-J02', '64階層ちょうどは通る',
            $J(str_repeat('[', 64) . str_repeat(']', 64))['ok'], true);
        $check('R122-J02', '65階層は拒否',
            $J(str_repeat('[', 65) . str_repeat(']', 65))['code'], 'JSON_TOO_DEEP');
        $check('R122-J02', '4MiB超は拒否',
            $J('{"a":"' . str_repeat('x', 4194304) . '"}')['code'], 'JSON_TOO_LARGE');
        $check('R122-J02', 'UTF-8でない本文は拒否',
            $J("\\xff\\xfe")['code'], 'JSON_NOT_UTF8');
        $check('R122-J02', '生の日本語は通る', $J('{"a":"あ"}')['ok'], true);
        // 応答の読込口（extract）が厳密読込を通っていること
        $mkR = static fn(string $body) =>
            BaganrikiResponse::BEGIN . $body . BaganrikiResponse::END;
        $check('R122-J02', 'extract は重複キーを拒否する',
            BaganrikiResponse::extract($mkR('{"a":1,"a":2}'))['ok'], false);
        $check('R122-J02', 'その理由が読める',
            strpos((string) BaganrikiResponse::extract(
                $mkR('{"a":1,"a":2}'))['reason'], 'JSON_DUPLICATE_KEY') !== false, true);
        $check('R122-J02', 'extract は普通の応答を通す',
            BaganrikiResponse::extract($mkR('{"a":1}'))['json'], ['a' => 1]);

        // ── @ANCHOR-20261020-R122-NUMEXACT  10月20日007のご指摘7 ──────────
        //   【方針を直しました】
        //   走査を通った数値は<b>落としません</b>。契約9章は有効桁128桁
        //   まで許しているので、長いだけで拒否すると正しい応答を
        //   落としてしまいます（R122-J02「有効桁128はちょうど通る」）。
        //   そのかわり、PHPの数値では丸まる（または無限大になる）ものは
        //   <b>原表現の十進数文字列のまま持ちます。</b>丸めた別の値に
        //   すり替えない、というのが007のご指摘7の趣旨です。
        //   値の型は使う側が見ます。採点は整数と決まっているので、
        //   文字列で来れば SCORES_RANGE で落ちます（下のJ04で確認）。
        $N3 = static fn(string $t) => BaganrikiJson::strict($t);
        $check('R122-J03', '普通の整数は通る',   $N3('{"a":11}')['ok'], true);
        $check('R122-J03', '普通の小数は通る',   $N3('{"a":2.1}')['ok'], true);
        $check('R122-J03', '0 は通る',            $N3('{"a":0}')['ok'], true);
        $check('R122-J03', '負の小数も通る',     $N3('{"a":-0.25}')['ok'], true);
        $check('R122-J03', '末尾0の小数も通る',  $N3('{"a":2.10}')['ok'], true);
        $check('R122-J03', '指数つきの小さい数も通る',
            $N3('{"a":1.0e-7}')['ok'], true);
        $check('R122-J03', '安全に持てる整数は通る',
            $N3('{"a":9007199254740991}')['ok'], true);
        $check('R122-J03', '1e308 は有限なので通る', $N3('{"a":1e308}')['ok'], true);
        $check('R122-J03', '普通の数はそのまま数値で返る',
            $N3('{"a":2.1,"b":[1,2]}')['value'], ['a' => 2.1, 'b' => [1, 2]]);
        $check('R122-J03', '普通の数は丸め扱いにしない',
            $N3('{"a":2.1,"b":[1,2]}')['stats']['inexact'], 0);
        $check('R122-J03', '数値トークンの数を数えている',
            $N3('{"a":2.1,"b":[1,2]}')['stats']['numbers'], 3);

        // 20桁の小数：通す。ただし値は原表現の文字列。
        $j20 = $N3('{"a":1.99999999999999999999}');
        $check('R122-J04', '20桁の小数は通す', $j20['ok'], true);
        $check('R122-J04', '20桁の小数は原表現の文字列で持つ',
            $j20['value'], ['a' => '1.99999999999999999999']);
        $check('R122-J04', '丸まったことを控えている', $j20['stats']['inexact'], 1);
        $check('R122-J04', 'その原表現も控えている',
            $j20['stats']['inexact_decimals'], ['1.99999999999999999999']);

        // PHP整数を超える整数：通す。値は文字列。
        $j21 = $N3('{"a":12345678901234567890}');
        $check('R122-J04', 'PHP整数を超える整数は通す', $j21['ok'], true);
        $check('R122-J04', 'それも原表現の文字列で持つ',
            $j21['value'], ['a' => '12345678901234567890']);

        // 2e308：倍精度では無限大。無限大にせず、十進数に展開して持つ。
        $j22 = $N3('{"a":2e308}');
        $check('R122-J04', '2e308 も通す', $j22['ok'], true);
        $check('R122-J04', '2e308 を無限大にしない',
            is_string($j22['value']['a'] ?? null), true);
        $check('R122-J04', '2e308 は309桁の十進数になる',
            strlen((string) ($j22['value']['a'] ?? '')), 309);
        $check('R122-J04', '2e308 の先頭は 2',
            substr((string) ($j22['value']['a'] ?? ''), 0, 1), '2');

        // 有効桁128（契約9章の上限）：ちょうど通る。
        $d128 = '1.' . str_repeat('9', 127);
        $j23  = $N3('{"a":' . $d128 . '}');
        $check('R122-J04', '有効桁128は通る', $j23['ok'], true);
        $check('R122-J04', '有効桁128は原表現のまま持つ',
            $j23['value'], ['a' => $d128]);

        // 混在しても、丸まらない数はそのまま数値のまま。
        $j24 = $N3('{"a":11,"b":1.99999999999999999999,"c":2.5}');
        $check('R122-J04', '混在：丸まらない整数は整数のまま',
            $j24['value']['a'] ?? null, 11);
        $check('R122-J04', '混在：丸まらない小数は小数のまま',
            $j24['value']['c'] ?? null, 2.5);
        $check('R122-J04', '混在：丸まる数だけ文字列になる',
            $j24['value']['b'] ?? null, '1.99999999999999999999');
        $check('R122-J04', '混在：ほかの位置はずれていない',
            array_keys((array) $j24['value']), ['a', 'b', 'c']);

        // extract も通す（読めるものは読む）。
        $check('R122-J04', '丸まる数値でも extract は読める',
            BaganrikiResponse::extract($mkR('{"a":1.99999999999999999999}'))['ok'],
            true);
        $check('R122-J04', 'extract も原表現の文字列で渡す',
            BaganrikiResponse::extract(
                $mkR('{"a":1.99999999999999999999}'))['json'],
            ['a' => '1.99999999999999999999']);
        // 採点に来たら、整数でないので採点の検査が落とします。
        //   （$srcE08 はこのファイル自身の中身です。診断の条件そのものを見ます）
        //   2 は「診断の中の1か所」＋「いまのこの行」です。
        //   診断から条件が消えれば 1 になって落ちます。
        $check('R122-J04', '採点は整数しか受け取らない条件が診断に入っている',
            substr_count($srcE08, 'if (!is_int($v) || $v < 0 || $v > $mx)'), 2);

        // ── @ANCHOR-20261021-R122-NUMTYPE / UNESCAPE  10月21日008のご指摘6 ──
        //   (1) 数値と文字列を区別して持ち、再保存でも型が変わらないこと
        //   (2) \\uXXXX を復号してから重複キーを見ること
        $N5 = static fn(string $t) => BaganrikiJson::strict($t);
        $RS = static fn(array $r) => BaganrikiJson::reserialize($r['value'],
                                                                $r['number_paths']);

        $n1 = $N5('{"a":1.99999999999999999999}');      // JSON上は数値
        $n2 = $N5('{"a":"1.99999999999999999999"}');    // JSON上は文字列
        $check('R122-J05', '丸まる数値もそのまま値は読める',
            $n1['value'], ['a' => '1.99999999999999999999']);
        $check('R122-J05', '最初から文字列の方も同じ値に見える',
            $n2['value'], ['a' => '1.99999999999999999999']);
        $check('R122-J05', 'しかし数値だった位置は控えている',
            $n1['stats']['number_paths'], 1);
        $check('R122-J05', '文字列だった位置は控えない',
            $n2['stats']['number_paths'], 0);
        $check('R122-J05', '再保存すると数値は数値に戻る',
            $RS($n1), '{"a":1.99999999999999999999}');
        $check('R122-J05', '再保存しても文字列は文字列のまま',
            $RS($n2), '{"a":"1.99999999999999999999"}');
        $check('R122-J05', 'AIが引用符付きで返した数は数値に変えない',
            $n2['number_paths'], []);

        $n3 = $N5('{"a":11,"b":1.99999999999999999999,"c":"2.5","d":2.5}');
        $check('R122-J05', '混在：再保存で型が入れ替わらない',
            $RS($n3), '{"a":11,"b":1.99999999999999999999,"c":"2.5","d":2.5}');
        $n4 = $N5('{"horses":[{"scores":{"H1":12345678901234567890}}]}');
        $check('R122-J05', '入れ子でも数値の位置が分かる',
            $n4['stats']['number_paths'], 1);
        $check('R122-J05', '入れ子でも再保存で数値に戻る',
            $RS($n4), '{"horses":[{"scores":{"H1":12345678901234567890}}]}');
        $check('R122-J05', '有効桁128も再保存で数値に戻る',
            $RS($N5('{"a":1.' . str_repeat('9', 127) . '}')),
            '{"a":1.' . str_repeat('9', 127) . '}');

        // 閾値の両側（採点は整数だけを受け取ります）
        $n5 = $N5('{"a":18,"b":18.0000000000000000001}');
        $check('R122-J05', '満点ちょうどは整数のまま',
            is_int($n5['value']['a'] ?? null), true);
        $check('R122-J05', '満点をわずかに超える数は整数にならない',
            is_int($n5['value']['b'] ?? null), false);

        // (2) \\uXXXX を復号してから重複キーを見ます
        $check('R122-J05', 'エスケープした同じキーの重複を見つける',
            $N5('{"a":1,"\\u0061":2}')['code'], 'JSON_DUPLICATE_KEY');
        $check('R122-J05', '素のままの重複も、これまでどおり見つける',
            $N5('{"a":1,"a":2}')['code'], 'JSON_DUPLICATE_KEY');
        $check('R122-J05', '違うキーなら通す',
            $N5('{"a":1,"\\u0062":2}')['ok'], true);
        $check('R122-J05', 'エスケープを復号した値になる',
            $N5('{"\\u99ac":1}')['value'], ['馬' => 1]);
        $check('R122-J05', '代理対も組み立てる',
            $N5('{"a":"\\ud83d\\ude00"}')['value'], ['a' => '😀']);
        $check('R122-J05', '上位代理だけなら断る',
            $N5('{"a":"\\ud83d"}')['code'], 'JSON_BAD_SURROGATE');
        $check('R122-J05', '下位代理だけでも断る',
            $N5('{"a":"\\ude00"}')['code'], 'JSON_BAD_SURROGATE');
        // extract も型の印を引き継ぎます
        $ex5 = BaganrikiResponse::extract($mkR('{"a":1.99999999999999999999}'));
        $check('R122-J05', 'extract も型の印を引き継ぐ',
            count((array) ($ex5['number_paths'] ?? [])), 1);
        $check('R122-J05', 'extract の結果も再保存で数値に戻る',
            BaganrikiJson::reserialize($ex5['json'],
                (array) $ex5['number_paths']),
            '{"a":1.99999999999999999999}');

        $check('R122-P01', 'coverageは7区分そろえる',""",
    '桁数と代替経路の受入試験')

# ═══════════════════════════════════════════════════════════════════════════
# @ANCHOR-20261021-R122-PERCAND  10月21日008のご指摘4（取消の採用単位）
# ═══════════════════════════════════════════════════════════════════════════
# 【本物の不具合でした】
#   前処理で「commit済み・時刻適合の候補<b>全部</b>」の取消を合算して
#   活動集合を1つ作り、その同じ集合を<b>各バッチ</b>の6分前全頭検査に
#   使っていました。「採用され得る」は「全頭検査を通った」ではありません。
#
#   例：出馬表が1・2・3番。同じ6分前スロットに
#     A（先に利用可能）：1・2番の単勝あり。3番は単勝も取消も<b>無い</b>
#     B（後に利用可能）：1・2番の単勝あり。3番の<b>正式取消</b>あり
#     両方とも commit済み・時刻適合・hash正常
#   いまの前処理は B の取消で活動集合を1・2番にするので、
#   <b>A が「全頭そろった」として採用できます。</b>
#   ところが採用した A に3番の取消はありません。後段は採用バッチだけから
#   取消を作るので、採用判定と凍結集合が食い違います。
#   有効な B を採るべき場面で A を選び、後段の入力不成立も招きます。
#
# 【いま】全頭検査は<b>その候補自身の取消</b>だけで活動集合を作ります。
#   別の候補の取消を、欠損を救うために流用しません。
#   引数の $activeNums は「正本として確定済みの取消を除いた基礎集合」です。
rep("""            if ($slot === 6) {
                $missing = self::missingWin($b, $activeNums);""",
    """            if ($slot === 6) {
                // @ANCHOR-20261021-R122-PERCAND  その候補自身の取消だけを引きます
                $selfCancel = array_map('intval', (array) ($b['cancelled'] ?? []));
                $activeForB = array_values(array_diff($activeNums, $selfCancel));
                $missing = self::missingWin($b, $activeForB);""",
    '@ANCHOR-20261021-R122-PERCAND 候補ごとの活動集合')

# ───────────────────────────────────────────────────────────────────────────
# 2l) 選出停止の応答を弾いてしまう不具合（@ANCHOR-20261020-R122-NULLQUOTA）
# ───────────────────────────────────────────────────────────────────────────
rep("""        if (array_key_exists('role_quota', $expect)) {
            $rq = $res['role_quota'] ?? null;
            foreach (['A', 'B', 'D'] as $b) {
                if ((int) ($rq[$b] ?? -1) !== (int) ($expect['role_quota'][$b] ?? -2)) {
                    $bad[] = 'role_quota.' . $b;
                }
            }
        }""",
    """        if (array_key_exists('role_quota', $expect)) {
            // ══════════════════════════════════════════════════════════
            // @ANCHOR-20261020-R122-NULLQUOTA  選出停止（UNRESOLVED）の扱い
            // ══════════════════════════════════════════════════════════
            // 【本物の不具合でした】
            //   role_quota が null（選出しない）のとき、
            //   ?? -1 と ?? -2 の既定値が必ず食い違うので、
            //   <b>正しい応答まで不採用になっていました。</b>
            //   UNRESOLVED のレースは全部これに当たります。
            //   10月20日005の異常例試験で、正常出力14本のうち
            //   UNRESOLVED の2本が落ちたことで分かりました。
            $rq = $res['role_quota'] ?? null;
            $eq = $expect['role_quota'];
            if ($eq === null || $rq === null) {
                if ($eq !== $rq) {
                    $bad[] = sprintf('role_quota（期待 %s / 実際 %s）',
                        ($eq === null) ? 'null' : '値あり',
                        ($rq === null) ? 'null' : '値あり');
                }
            } else {
                foreach (['A', 'B', 'D'] as $b) {
                    if ((int) ($rq[$b] ?? -1) !== (int) ($eq[$b] ?? -2)) {
                        $bad[] = 'role_quota.' . $b;
                    }
                }
            }
        }""",
    'checkEnvelope の role_quota=null')

rep("""        $check('R122-V02', '欠落は不足として返す', $iso['missing'], [3]);""",
    """        $check('R122-V02', '欠落は不足として返す', $iso['missing'], [3]);
        // @ANCHOR-20261020-R122-NULLQUOTA  選出停止の応答を弾かないこと
        $expNull = ['prompt_version'=>'baganriki-v041-r12-2-20261020',
                    'schema_version'=>'baganriki-v041-r12-2','race_id'=>'R1',
                    'ai_role'=>'1st','snapshot_hash'=>'h','mode'=>'UNKNOWN',
                    'mode_status'=>'UNRESOLVED','allocation_mode'=>null,
                    'mode_policy_id'=>'BASE_TRI_STATE_V1',
                    'role_cap'=>0,'role_quota'=>null];
        $check('R122-V01', '選出停止（role_quota=null）の応答は採用できる',
            BaganrikiResponse::checkEnvelope($expNull, $expNull)['ok'], true);
        $nq = $expNull; $nq['role_quota'] = ['A'=>3,'B'=>3,'D'=>1];
        $check('R122-V01', '停止なのに枠を返したら不採用',
            BaganrikiResponse::checkEnvelope($nq, $expNull)['ok'], false);
        $nq2 = $expNull; $nq2['role_quota'] = null;
        $exp2 = $expNull; $exp2['role_quota'] = ['A'=>3,'B'=>3,'D'=>1];
        $check('R122-V01', '枠があるのにnullを返したら不採用',
            BaganrikiResponse::checkEnvelope($nq2, $exp2)['ok'], false);""",
    '選出停止の受入試験')

# ───────────────────────────────────────────────────────────────────────────
# @ANCHOR-20261021-R122-READGATE  読取APIに「非公開」の見張りを入れる（010の7章⑤）
#   認証が1つも掛かっていませんでした。画面にも誰にでも見えるボタンが
#   出ているので、旗を上げた瞬間に12レースの予想が一般に見えます。
#   既定は「閉じる」。鍵が合ったときだけ中身を返します。
# ───────────────────────────────────────────────────────────────────────────
rep("""    public function getBaganrikiR122Race(string $race_id)
    {
        $parts = explode('-', $race_id);""",
    """    public function getBaganrikiR122Race(string $race_id)
    {
        // ══════════════════════════════════════════════════════════════
        // @ANCHOR-20261021-R122-READGATE  非公開の読取経路（010の7章⑤）
        // ══════════════════════════════════════════════════════════════
        //   【見つかったこと】この読取APIには<b>認証が1つも掛かって
        //   いませんでした。</b>さらに画面側（Flutter）の
        //   race_content_page に、<b>誰にでも見える「r12.2」のボタン</b>が
        //   出ています（管理者判定も debug 判定もありません）。
        //
        //   いまは記録が1件もないので空が返るだけです。ですが
        //   <b>10月24日に旗を上げた瞬間、その12レースの予想が
        //   一般の利用者に見えます。</b>「非公開の検証」になりません。
        //   race_id は日付と場と番号なので、総当たりも簡単です。
        //
        //   【いま】既定で<b>閉じます。</b>.env の BAGANRIKI_R122_READ が
        //   open のときだけ誰でも見られます。既定（key）では、
        //   BAGANRIKI_R122_READ_KEY と一致する鍵を
        //     ヘッダ  X-R122-Key: <鍵>
        //     クエリ  ?r122_key=<鍵>
        //   のどちらかで渡したときだけ中身を返します。
        //   <b>鍵が未設定なら、誰も中身を見られません。</b>
        //   対象レースの限定（TARGETS が空なら1レースも送らない）と
        //   同じ考え方です。設定を入れ忘れた側が安全に倒れます。
        //
        //   <b>記録が在るかどうかは漏らしません。</b>race_id が何であれ
        //   同じものを返します。
        //
        //   ══════════════════════════════════════════════════════════
        //   @ANCHOR-20261021-R122-READGATE200  HTTPは 200 で返します
        //   ══════════════════════════════════════════════════════════
        //   【画面（Flutter）側の作りを見て決めました】
        //   lib/data/http/client.dart は 2xx 以外を<b>すべて例外</b>に
        //   します（49〜51行）。画面はそれを受けて
        //     「読めませんでした  Exception: http 404 [url=https://…]」
        //   と<b>生のエラー文字列をそのまま出します</b>
        //   （baganriki_r122_display_alert.dart 98行）。
        //   利用者に意味のない文字列とURLを見せることになります。
        //
        //   なので 404 ではなく <b>200</b> で、いつもの形のまま
        //   state=UNAVAILABLE と理由を返します。
        //   画面は diagnostics をそのまま並べるので（同380行）、
        //   「この記録はまだ公開していません」と読める形で出ます。
        //   <b>Flutter は1行も直していません。</b>作り直し不要です。
        //
        //   artisan（コマンド）からは素通りします。外から叩けないので
        //   止める意味がなく、止めると試験が全部落ちます。
        $gate = self::r122ReadGate();
        if (!$gate['ok']) {
            return response()->json(BaganrikiPublicView::build([
                'race_id'     => $race_id,
                'state'       => 'UNAVAILABLE',
                'diagnostics' => [['code' => (string) $gate['code'],
                                   'message' => (string) $gate['reason']]],
            ]), 200);
        }

        $parts = explode('-', $race_id);""",
    '@ANCHOR-20261021-R122-READGATE 読取APIの非公開化')

# ───────────────────────────────────────────────────────────────────────────
# 3) AiController に送信文の組み立て（DBから文脈を集める）を足す
#    クラスの閉じ括弧の直前に入れます。
# ───────────────────────────────────────────────────────────────────────────
methods = io.open(os.path.join(os.path.dirname(os.path.abspath(__file__)),
                               'methods_send.php'), encoding='utf-8').read()
methods += io.open(os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                'methods_freeze.php'), encoding='utf-8').read()
methods += io.open(os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                'methods_extra.php'), encoding='utf-8').read()
# @ANCHOR-20261020-R122-QUEUE  送信の前に枠を予約し、受領で原応答を保存する
methods += io.open(os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                'methods_queuewire.php'), encoding='utf-8').read()
# @ANCHOR-20261020-R122-RESP  応答検証と局所回復の本番接続
methods += io.open(os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                'methods_response.php'), encoding='utf-8').read()
# @ANCHOR-20261020-R122-PUB  統合・公開・intent・revision の本番接続
methods += io.open(os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                'methods_publish.php'), encoding='utf-8').read()
# @ANCHOR-20261020-R122-PAST  過去走を source_registry へ
methods += io.open(os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                'methods_past.php'), encoding='utf-8').read()
# @ANCHOR-20261020-R122-SHADOW  入力だけ作って凍結する（送信は旧本文）
methods += io.open(os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                'methods_shadow.php'), encoding='utf-8').read()
# @ANCHOR-20261020-R122-MARKET  OPI と推定確定オッズを source_registry へ
methods += io.open(os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                'methods_market.php'), encoding='utf-8').read()
# @ANCHOR-20261021-R122-SETTLE  受領の終端と採否の確定を分ける（010の2-4）
methods += io.open(os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                'methods_settle.php'), encoding='utf-8').read()
# @ANCHOR-20261021-R122-JOBWIRE  Job構成の土台（010の2章）
methods += io.open(os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                'methods_jobwire.php'), encoding='utf-8').read()
# @ANCHOR-20261020-R122-WIRE  実送信の後へ検証・訂正・公開を接続する（006の6-4）
methods += io.open(os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                'methods_pipeline.php'), encoding='utf-8').read()
marker = """        ]));
    }

}


/**
 * ═══════════════════════════════════════════════════════════════════════════
 * @ANCHOR-20261020-REFACTOR  v0.4-X / r12.2 の信号判定"""
rep(marker,
    """        ]));
    }
""" + methods + """
}


/**
 * ═══════════════════════════════════════════════════════════════════════════
 * @ANCHOR-20261020-REFACTOR  v0.4-X / r12.2 の信号判定""",
    'AiController クラスへの追加メソッド')

# ───────────────────────────────────────────────────────────────────────────
# 4) 1st AI の送信直前で本文を入れ替える（機能フラグ）
# ───────────────────────────────────────────────────────────────────────────
rep("""        $aiTimeout = self::v04HvPrompt() ? 240 : 90;
        try {
            $aiResponse = $this->anthropic->sendWithRetry(""",
    """        // ══════════════════════════════════════════════════════════════════
        // @ANCHOR-20261020-R122-PROMPT  r12.2 の本文へ全文置換（機能フラグ）
        // ══════════════════════════════════════════════════════════════════
        // 根拠：server_contract_r12.2.txt 6章・9章／prompts/prompt_1st.txt
        //
        //   BAGANRIKI_R122_PROMPT=1 のときだけ、
        //     system … 配布された prompt_1st.txt の全文
        //     user   … Laravel が作る INPUT_JSON 1個
        //   へ入れ替えます。既定（0）ではここを素通りし、1バイトも変わりません。
        //
        //   作れないときは<b>旧本文へ落ちません</b>。送信を止めます。
        //   契約11.2「正本が特定できないレースは公開しない」に合わせます。
        //   （中途半端な入力でAIを呼ぶと、根拠のない候補が出てしまいます）
        // @ANCHOR-20261020-R122-SHADOW  shadow のときは本文を差し替えません。
        //   入力を作って凍結保存だけして、旧本文で送ります。
        if (BaganrikiPrompt::enabled() && !BaganrikiPrompt::sending()) {
            $this->r122ShadowRecord($date, $kaisuu, $basho, $day, $race);
        }
        // ══════════════════════════════════════════════════════════════════
        // @ANCHOR-20261020-R122-WIRE  10月20日006のご指摘6-4（設定の食い違い）
        // ══════════════════════════════════════════════════════════════════
        //   「PROMPT=1だけにしてQUEUE=0のままなら、予約処理をskipし、
        //     新契約の期限・公開を一式で保証できません。」
        //   そのとおりです。本文だけ r12.2 にして、枠・期限・公開が
        //   旧のままという状態を<b>設定で作れないようにします</b>。
        //   旧本文のまま（0）や shadow のときは何も起きません。
        $r122wire = self::r122WireConfig();
        if (!$r122wire['ok']) {
            \\Log::error('[R122-WIRE] 設定が食い違っているので1st AIを呼びません', [
                'date' => $date, 'kaisuu' => $kaisuu, 'basho' => $basho,
                'day'  => $day,  'race'   => $race,
                'code' => $r122wire['code'], 'reason' => $r122wire['reason'],
                'BAGANRIKI_R122_PROMPT' => $r122wire['prompt'],
                'BAGANRIKI_R122_QUEUE'  => $r122wire['queue'],
            ]);
            $this->_saveEmptyFirstAiAnalysis($date, $kaisuu, $basho, $day, $race,
                                             $raceRow, 'r122_config_mismatch');
            return response()->json(['data' => [
                'date' => $date, 'kaisuu' => $kaisuu, 'basho_code' => $basho,
                'day'  => $day,  'race'   => $race, 'analysis_text' => '',
            ]]);
        }
        if ($r122wire['code'] === 'QUEUE_SHADOW') {
            \\Log::error('[R122-WIRE] 枠が shadow の段です（契約10章の停止条件は効きません）', [
                'reason' => $r122wire['reason'],
            ]);
        }
        if (BaganrikiPrompt::sending()) {
            $r122 = $this->r122AssembleSend($date, $kaisuu, $basho, $day, $race, '1st');
            if (!$r122['ok']) {
                \\Log::error('[INPUT_INVALID] r12.2の送信文を作れないため1st AIを呼びません', [
                    'date' => $date, 'kaisuu' => $kaisuu, 'basho' => $basho,
                    'day'  => $day,  'race'   => $race,
                    'code' => $r122['code'], 'reason' => $r122['reason'],
                ]);
                // ══════════════════════════════════════════════════════
                // @ANCHOR-20261020-R122-RESUME  10月20日007のご指摘6-1
                // ══════════════════════════════════════════════════════
                //   情報上限に達していないだけ（TOO_EARLY）のときは、
                //   <b>空回答をキャッシュしません。</b>残してしまうと
                //   次のアクセスがキャッシュ返却で終わり、上限到達後に
                //   やり直せなくなります。「待っているだけ」と
                //   「作れなかった」を分けます。
                if ((string) $r122['code'] === 'TOO_EARLY') {
                    return response()->json(['data' => [
                        'date' => $date, 'kaisuu' => $kaisuu, 'basho_code' => $basho,
                        'day'  => $day,  'race'   => $race, 'analysis_text' => '',
                    ]]);
                }
                $this->_saveEmptyFirstAiAnalysis($date, $kaisuu, $basho, $day, $race,
                                                 $raceRow, 'r122_input_invalid');
                return response()->json(['data' => [
                    'date' => $date, 'kaisuu' => $kaisuu, 'basho_code' => $basho,
                    'day'  => $day,  'race'   => $race, 'analysis_text' => '',
                ]]);
            }
            $prompt              = $r122['user'];
            $firstAiSystemPrompt = $r122['system'];
            self::recordPromptHash('1st_system', $firstAiSystemPrompt);
            self::recordPromptHash('1st', $prompt);
            \\Log::info('[R122-PROMPT] 1st AI へ r12.2 の本文で送ります', [
                'race_id'       => $r122['race_id'],
                'system_sha256' => $r122['system_sha256'],
                'snapshot_hash' => $r122['snapshot_hash'],
                'user_bytes'    => $r122['user_bytes'],
            ]);
        }

        $aiTimeout = self::v04HvPrompt() ? 240 : 90;
        try {
            $aiResponse = $this->anthropic->sendWithRetry(""",
    '1st AI の送信直前')

# ───────────────────────────────────────────────────────────────────────────
# 5) 2nd AI の送信直前で本文を入れ替える（機能フラグ）
# ───────────────────────────────────────────────────────────────────────────
rep("""        for ($attempt = 0; $attempt < $maxRetries; $attempt++) {
            $aiElapsed2ndStart = microtime(true);   // @ANCHOR-20261006-AI-ELAPSED""",
    """        // ══════════════════════════════════════════════════════════════════
        // @ANCHOR-20261020-R122-PROMPT  r12.2 の本文へ全文置換（機能フラグ）
        // ══════════════════════════════════════════════════════════════════
        // 根拠：server_contract_r12.2.txt 6章・9章／prompts/prompt_2nd.txt
        //
        //   1st側と同じ扱いです。system を prompt_2nd.txt の全文、
        //   user を INPUT_JSON 1個へ入れ替えます（role_cap=min(5,C)）。
        //
        //   【ここで入れ替える理由】この手前にある条件B・C・Dの先読みと
        //   配分の読み戻しは、旧本文の文面から読んでいます。送信文だけを
        //   差し替えれば、統合側の既存の流れを壊さずに本文を置換できます。
        //   <b>統合側（_mergeAiResults）を r12.2 の応答キーへ合わせる作業は
        //   まだ残っています</b>（残作業「実AI接続」。14_残作業と日程に記載）。
        // @ANCHOR-20261020-R122-SHADOW  shadow のときは本文を差し替えません
        // ══════════════════════════════════════════════════════════════════
        // @ANCHOR-20261020-R122-WIRE2  10月20日007のご指摘6-4
        // ══════════════════════════════════════════════════════════════════
        //   【旧】旗の食い違いの検査を<b>1stにしか入れていませんでした。</b>
        //     PROMPT=1／QUEUE=0 のまま2ndを直接呼ぶと、予約は skip=true で
        //     返り、本文だけ r12.2 に置き換わったまま送れてしまいます。
        //     「この組み合わせを作れなくした」は1stの話でしかありませんでした。
        //   【いま】両roleの送信入口に同じ検査を置きます。
        $r122wire2 = self::r122WireConfig();
        if (!$r122wire2['ok']) {
            \\Log::error('[R122-WIRE] 設定が食い違っているので2nd AIを呼びません', [
                'date' => $date, 'kaisuu' => $kaisuu, 'basho' => $basho,
                'day'  => $day,  'race'   => $race,
                'code' => $r122wire2['code'], 'reason' => $r122wire2['reason'],
                'BAGANRIKI_R122_PROMPT' => $r122wire2['prompt'],
                'BAGANRIKI_R122_QUEUE'  => $r122wire2['queue'],
            ]);
            return response()->json(['data' => [
                'date'              => $date,
                'kaisuu'            => $kaisuu,
                'basho_code'        => $basho,
                'day'               => $day,
                'race'              => $race,
                'analysis_text'     => '',
                'merged_horses'     => [],
                'upset_race'        => 0,
            ]]);
        }
        if (BaganrikiPrompt::sending()) {
            $r122b = $this->r122AssembleSend($date, $kaisuu, $basho, $day, $race, '2nd');
            if (!$r122b['ok']) {
                \\Log::error('[INPUT_INVALID] r12.2の送信文を作れないため2nd AIを呼びません', [
                    'date' => $date, 'kaisuu' => $kaisuu, 'basho' => $basho,
                    'day'  => $day,  'race'   => $race,
                    'code' => $r122b['code'], 'reason' => $r122b['reason'],
                ]);
                return response()->json(['data' => [
                    'date'              => $date,
                    'kaisuu'            => $kaisuu,
                    'basho_code'        => $basho,
                    'day'               => $day,
                    'race'              => $race,
                    'analysis_text'     => '',
                    'merged_horses'     => [],
                    'upset_race'        => 0,
                    'upset_race_status' => '0',
                    'race_metrics'      => null,
                ]]);
            }
            $oddsData     = $r122b['user'];
            $systemPrompt = $r122b['system'];
            \\Log::info('[R122-PROMPT] 2nd AI へ r12.2 の本文で送ります', [
                'race_id'       => $r122b['race_id'],
                'system_sha256' => $r122b['system_sha256'],
                'snapshot_hash' => $r122b['snapshot_hash'],
                'user_bytes'    => $r122b['user_bytes'],
            ]);
        }

        for ($attempt = 0; $attempt < $maxRetries; $attempt++) {
            $aiElapsed2ndStart = microtime(true);   // @ANCHOR-20261006-AI-ELAPSED""",
    '2nd AI の送信直前')

# ───────────────────────────────────────────────────────────────────────────
# 5b) @ANCHOR-20261020-R122-QUEUE  送信の前に枠を予約し、受領で原応答を保存する
#     .env の BAGANRIKI_R122_QUEUE=0（既定）なら skip=true で素通りします。
# ───────────────────────────────────────────────────────────────────────────

# (1) 1st AI：予約してから送る
rep("""                'user_bytes'    => $r122['user_bytes'],
            ]);
        }
""",
    """                'user_bytes'    => $r122['user_bytes'],
            ]);

            // @ANCHOR-20261020-R122-QUEUE  予約を確定してから送ります。
            //   すでに枠があるとき（前回が途中で落ちた等）は<b>送りません</b>。
            //   契約10章「予約済み枠を重複キュー・期限切れ・再起動で再発行しない」
            $r122q1 = $this->r122QueueReserve($date, $kaisuu, $basho, $day, $race,
                                              '1st', $r122);
            // @ANCHOR-20261020-R122-SHADOW  shadow のときは止めません（記録だけ諦めます）
            if (!$r122q1['skip'] && !$r122q1['ok'] && $r122q1['shadow']) {
                \\Log::error('[R122-QUEUE] 枠を取れませんでした（shadow なので送信は止めません）', [
                    'date' => $date, 'kaisuu' => $kaisuu, 'basho' => $basho,
                    'day'  => $day,  'race'   => $race,
                    'code' => $r122q1['code'], 'reason' => $r122q1['reason'],
                ]);
            }
            if (!$r122q1['skip'] && !$r122q1['ok'] && !$r122q1['shadow']) {
                \\Log::error('[R122-QUEUE] 枠を予約できないため1st AIを呼びません', [
                    'date' => $date, 'kaisuu' => $kaisuu, 'basho' => $basho,
                    'day'  => $day,  'race'   => $race,
                    'code' => $r122q1['code'], 'reason' => $r122q1['reason'],
                ]);
                $this->_saveEmptyFirstAiAnalysis($date, $kaisuu, $basho, $day, $race,
                                                 $raceRow, 'r122_queue_blocked');
                return response()->json(['data' => [
                    'date' => $date, 'kaisuu' => $kaisuu, 'basho_code' => $basho,
                    'day'  => $day,  'race'   => $race, 'analysis_text' => '',
                ]]);
            }
        }
""",
    '1st AI の予約')

# (2) 1st AI：通信が切れた＝結果不明（再送しません）
rep("""            $this->_saveEmptyFirstAiAnalysis($date, $kaisuu, $basho, $day, $race, $raceRow, 'connection_error');""",
    """            // @ANCHOR-20261020-R122-QUEUE  届いたかどうか分からないので結果不明にします
            if (isset($r122q1)) {
                $this->r122QueueFail($r122q1,
                    '1st AI の通信失敗・待ち時間切れ（届いたかどうか分かりません）', true);
            }
            $this->_saveEmptyFirstAiAnalysis($date, $kaisuu, $basho, $day, $race, $raceRow, 'connection_error');""",
    '1st AI の結果不明')

# (3) 1st AI：APIが明確に失敗を返した＝失敗
rep("""            $this->_saveEmptyFirstAiAnalysis($date, $kaisuu, $basho, $day, $race, $raceRow, 'api_error');""",
    """            // @ANCHOR-20261020-R122-QUEUE  明確な失敗が返ったので FAILED にします
            if (isset($r122q1)) {
                $this->r122QueueFail($r122q1,
                    '1st AI の API エラー status=' . $aiResponse->status(), false);
            }
            $this->_saveEmptyFirstAiAnalysis($date, $kaisuu, $basho, $day, $race, $raceRow, 'api_error');""",
    '1st AI の失敗')

# (4) 1st AI：原応答を枠へ保存
rep("""        $rawText = $this->anthropic->extractText($aiResponse);
""",
    """        $rawText = $this->anthropic->extractText($aiResponse);

        // @ANCHOR-20261020-R122-QUEUE  原応答と complete を保存します。
        //   complete は「途中で切れていない」かつ「本文が空でない」ことです。
        //   complete=false の本文はそのまま残しますが、選出には使いません。
        if (isset($r122q1)) {
            $this->r122QueueReceive($r122q1, $rawText,
                ($aiStopReason === null || $aiStopReason === 'end_turn')
                && trim($rawText) !== '');
            // ══════════════════════════════════════════════════════════════
            // @ANCHOR-20261020-R122-WIRE  10月20日006のご指摘6-4
            // ══════════════════════════════════════════════════════════════
            //   ご指摘のとおり、ここから先が繋がっていませんでした。
            //   原応答を保存したあと、検証・訂正・公開を始めます。
            //   ・応答を返したあとに動かします（app()->terminating()）。
            //     画面の待ち時間を増やさないためです。公開期限
            //     （発走120秒前）までには間に合う位置です。
            //   ・2nd AI の先読みより先に登録するので、先に動きます。
            //   ・ここで例外が出ても予想は返します（中で囲んでいます）。
            if (!self::$dryRunNoPersist) {
                $wireSelf = $this;
                $wireQ    = $r122q1;
                $wireD = $date; $wireK = $kaisuu; $wireB = $basho;
                $wireY = $day;  $wireR = $race;
                app()->terminating(function () use ($wireSelf, $wireQ, $wireD,
                                                    $wireK, $wireB, $wireY, $wireR) {
                    $t = microtime(true);
                    $wireSelf->r122AfterReceive($wireD, $wireK, $wireB, $wireY,
                                                $wireR, '1st', $wireQ);
                    \\Log::error('[R122-WIRE] 1st の後処理にかかった時間', [
                        '秒' => round(microtime(true) - $t, 2),
                    ]);
                });
            }
        }
""",
    '1st AI の受領')

# (5) 2nd AI：予約してから送る（保存済み回答を使い回すときは予約しません）
rep("""                'user_bytes'    => $r122b['user_bytes'],
            ]);
        }
""",
    """                'user_bytes'    => $r122b['user_bytes'],
            ]);

            // @ANCHOR-20261020-R122-QUEUE  予約を確定してから送ります。
            //   保存済み回答を使い回すとき（$maxRetries=0）は送らないので
            //   枠も取りません。
            if ($maxRetries > 0) {
                $r122q2 = $this->r122QueueReserve($date, $kaisuu, $basho, $day, $race,
                                                  '2nd', $r122b);
                if (!$r122q2['skip'] && !$r122q2['ok'] && $r122q2['shadow']) {
                    // @ANCHOR-20261020-R122-SHADOW  記録だけ諦めて送ります
                    \\Log::error('[R122-QUEUE] 枠を取れませんでした（shadow なので2nd AIは送ります）', [
                        'date' => $date, 'kaisuu' => $kaisuu, 'basho' => $basho,
                        'day'  => $day,  'race'   => $race,
                        'code' => $r122q2['code'], 'reason' => $r122q2['reason'],
                    ]);
                }
                if (!$r122q2['skip'] && !$r122q2['ok'] && !$r122q2['shadow']) {
                    \\Log::error('[R122-QUEUE] 枠を予約できないため2nd AIを呼びません', [
                        'date' => $date, 'kaisuu' => $kaisuu, 'basho' => $basho,
                        'day'  => $day,  'race'   => $race,
                        'code' => $r122q2['code'], 'reason' => $r122q2['reason'],
                    ]);
                    // 1st AI 単独で続けます（正常な他AIを失わない：契約6章）
                    $maxRetries       = 0;
                    $b7SecondAiFailed = true;
                }
            }
        }
""",
    '2nd AI の予約')

# (6) 2nd AI：APIが失敗を返した
rep("""                // 全リトライ失敗 → 2nd AI失敗確定
                $b7SecondAiFailed = true;""",
    """                // @ANCHOR-20261020-R122-QUEUE  明確な失敗が返ったので FAILED にします
                if (isset($r122q2)) {
                    $this->r122QueueFail($r122q2,
                        '2nd AI の API エラー status=' . $response->status(), false);
                }
                // 全リトライ失敗 → 2nd AI失敗確定
                $b7SecondAiFailed = true;""",
    '2nd AI の失敗')

# (7) 2nd AI：原応答を枠へ保存
rep("""            if ($dsFinish !== null && $dsFinish !== 'stop') {""",
    """            // @ANCHOR-20261020-R122-QUEUE  原応答と complete を保存します
            if (isset($r122q2)) {
                $this->r122QueueReceive($r122q2, $analysisText,
                    ($dsFinish === null || $dsFinish === 'stop')
                    && trim($analysisText) !== '');
                // ══════════════════════════════════════════════════════════
                // @ANCHOR-20261020-R122-WIRE  10月20日006のご指摘6-4
                // ══════════════════════════════════════════════════════════
                //   2nd は<b>その場で</b>通します。ここは先読み（1st の
                //   terminating の中）か、利用者がボタンを押した経路です。
                //   どちらでも、この後に公開期限まで待てる時間はありません。
                //   両roleが終端になっているので、ここで公開まで行きます。
                if (!self::$dryRunNoPersist) {
                    $wire2 = microtime(true);
                    $this->r122AfterReceive($date, $kaisuu, $basho, $day, $race,
                                            '2nd', $r122q2);
                    \\Log::error('[R122-WIRE] 2nd の後処理にかかった時間', [
                        '秒' => round(microtime(true) - $wire2, 2),
                    ]);
                }
            }
            if ($dsFinish !== null && $dsFinish !== 'stop') {""",
    '2nd AI の受領')


# ───────────────────────────────────────────────────────────────────────────
# 5c) @ANCHOR-20261020-R122-API  読取APIの中身
# ───────────────────────────────────────────────────────────────────────────

# (1) 返す形に、足りていなかった項目を足す
rep("""                'live_quota'        => $a['live_quota'] ?? null,
                'effective_publish_deadline' => $a['effective_publish_deadline'] ?? null,
            ],""",
    """                'live_quota'        => $a['live_quota'] ?? null,
                // @ANCHOR-20261020-R122-API  契約8章・11章で返すと決めている項目
                //   3つの版をそろえて返します（state だけでは足りません）。
                //   actual_quota と available_candidate_count は<b>いまの取消</b>を
                //   映します。prediction_* は公開したときの履歴なので動かしません。
                'response_revision'    => $a['response_revision'] ?? null,
                'publication_revision' => $a['publication_revision'] ?? null,
                'latest_publication_id' => $a['latest_publication_id'] ?? null,
                'actual_quota'             => $a['actual_quota'] ?? null,
                'available_candidate_count' => $a['available_candidate_count'] ?? null,
                'live_close'        => $a['live_close'] ?? null,
                'effective_publish_deadline' => $a['effective_publish_deadline'] ?? null,
                'effective_reply_deadline'   => $a['effective_reply_deadline'] ?? null,
            ],
            // @ANCHOR-20261020-R122-API  ワーカーの状態。
            //   予約token と原応答は入れません（契約10章）。
            'worker_state'    => $a['worker_state'] ?? null,""",
    '読取APIの返す形')

# (2) 本番の世代だけを読む（REPLAY を公開APIに出さない）
rep("""        $snap = null; $live = null; $pub = null;
        if (\\Schema::hasTable('baganriki_snapshots')) {
            $snap = \\DB::table('baganriki_snapshots')->where('race_id', $race_id)
                       ->orderByDesc('generation')->first();
        }
        if ($snap !== null && \\Schema::hasTable('baganriki_live_states')) {
            $live = \\DB::table('baganriki_live_states')->where('snapshot_id', $snap->id)->first();
        }
        if ($snap !== null && \\Schema::hasTable('baganriki_publications')) {
            $pub = \\DB::table('baganriki_publications')->where('snapshot_id', $snap->id)
                      ->orderByDesc('published_at')->first();
        }
""",
    """        // ══════════════════════════════════════════════════════════════
        // @ANCHOR-20261020-R122-API  本番の世代（generation=0）だけを読みます
        // ══════════════════════════════════════════════════════════════
        // 【直した中身】
        //   これまで orderByDesc('generation') で読んでいたので、
        //   試験で保存した REPLAY（generation=900）があると
        //   <b>公開APIがその試験用の記録を返してしまいました。</b>
        //   読取APIは本番の世代だけを見ます。
        //
        //   3つの版と公開履歴は<b>ひとつの読取取引</b>でそろえて取ります。
        //   書込ロックは持ちません（契約8章）。
        $snap = null; $live = null; $pub = null; $slots = null;
        if (\\Schema::hasTable('baganriki_snapshots')) {
            [$snap, $live, $pub, $slots] = \\DB::transaction(function () use ($race_id) {
                $s = \\DB::table('baganriki_snapshots')->where('race_id', $race_id)
                       ->where('generation', 0)->first();
                $l = null; $p = null; $w = null;
                if ($s !== null && \\Schema::hasTable('baganriki_live_states')) {
                    $l = \\DB::table('baganriki_live_states')
                           ->where('snapshot_id', $s->id)->first();
                }
                if ($s !== null && \\Schema::hasTable('baganriki_publications')) {
                    $p = \\DB::table('baganriki_publications')
                           ->where('snapshot_id', $s->id)
                           ->orderByDesc('published_at')->first();
                }
                if ($s !== null && \\Schema::hasTable('baganriki_ai_attempts')) {
                    $w = BaganrikiWorker::slots((int) $s->id);
                }
                return [$s, $l, $p, $w];
            });
        }
""",
    '読取APIの読み取り')

# (3) いまの取消を映した枠と候補数、3つの版、ワーカーの状態を返す
rep("""        return response()->json(BaganrikiPublicView::build([
            'race_id'         => $race_id,
            'state'           => $state,
            'mode'            => $snap->mode            ?? null,""",
    """        // @ANCHOR-20261020-R122-API  いまの取消を映した枠と候補数
        //   正式公開のリストは動かしません（取消だけで再選出しません）。
        //   取消になった馬を除いた数だけを、別の欄として返します。
        $actualQuota = null; $availableCount = null;
        if ($pubDto !== null) {
            $cans = (array) ($pubDto['candidates'] ?? []);
            $actualQuota = ['A' => 0, 'B' => 0, 'D' => 0];
            $availableCount = 0;
            foreach ($cans as $c) {
                $no = (int) ($c['horse_no'] ?? 0);
                if (in_array($no, array_map('intval', $cancellations), true)) { continue; }
                $availableCount++;
                $b = (string) ($c['band'] ?? '');
                if (isset($actualQuota[$b])) { $actualQuota[$b]++; }
            }
        }
        // @ANCHOR-20261020-R122-CLOSE  締切の出どころ（凍結のときの監査から）
        $closeSrc = null;
        if (\\Schema::hasTable('baganriki_audit_events') && $snap !== null) {
            $ce = \\DB::table('baganriki_audit_events')
                    ->where('snapshot_id', $snap->id)
                    ->where('kind', 'SALES_CLOSE_SOURCE')
                    ->orderByDesc('id')->first();
            if ($ce !== null) {
                $cd = json_decode((string) $ce->diagnostics, true);
                if (is_array($cd)) { $closeSrc = $cd; }
            }
        }
        $effReply = null;
        if ($salesClose !== null) {
            $sc2 = BaganrikiWorker::dbUs($salesClose);
            if ($sc2 !== null) {
                $lc2 = ($live !== null && $live->live_close !== null)
                    ? BaganrikiWorker::dbUs($live->live_close) : null;
                $eff2 = BaganrikiTime::effectiveDeadlines($sc2, $lc2);
                $effReply = BaganrikiTime::toJst($eff2['reply']);
            }
        }

        return response()->json(BaganrikiPublicView::build([
            'race_id'         => $race_id,
            'state'           => $state,
            'response_revision'     => $live->response_revision ?? null,
            'publication_revision'  => $live->publication_revision ?? null,
            'latest_publication_id' => $live->latest_publication_id ?? null,
            'actual_quota'              => $actualQuota,
            'available_candidate_count' => $availableCount,
            'live_close'              => $live->live_close ?? null,
            'effective_reply_deadline' => $effReply,
            'worker_state'    => $slots,
            'sales_close_at'  => $snap->sales_close_at ?? null,
            'sales_close_source' => $closeSrc,
            'mode'            => $snap->mode            ?? null,""",
    '読取APIの返す中身')


# (4) @ANCHOR-20261020-R122-API  DBの日時を RFC3339 として読んでいた不具合
#     sales_close_at / live_close は DATETIME(6)（'Y-m-d H:i:s.u'）で入っています。
#     BaganrikiTime::us() は RFC3339 しか受け付けないので必ず null になり、
#     実効公開期限が出ず、未公開で期限を過ぎても UNAVAILABLE になりませんでした。
rep("""        $salesClose = $snap->sales_close_at ?? null;
        if ($salesClose !== null) {
            $sc = BaganrikiTime::us((string) $salesClose);
            if ($sc !== null) {
                $lc = ($live !== null && $live->live_close !== null)
                    ? BaganrikiTime::us((string) $live->live_close) : null;""",
    """        $salesClose = $snap->sales_close_at ?? null;
        if ($salesClose !== null) {
            // @ANCHOR-20261020-R122-API  DBの日時はDBの日時として読みます
            $sc = BaganrikiWorker::dbUs($salesClose);
            if ($sc !== null) {
                $lc = ($live !== null && $live->live_close !== null)
                    ? BaganrikiWorker::dbUs($live->live_close) : null;""",
    '読取APIの期限計算')

# ───────────────────────────────────────────────────────────────────────────
# 5d) @ANCHOR-20261020-R122-CLOSE  投票締切の正本
# ───────────────────────────────────────────────────────────────────────────

rep("""    public const REPLY_BEFORE_PUBLISH_SEC = 30;    // reply_before_publish_ms = 30,000""",
    """    public const REPLY_BEFORE_PUBLISH_SEC = 30;    // reply_before_publish_ms = 30,000

    // ══════════════════════════════════════════════════════════════════════
    // @ANCHOR-20261020-R122-CLOSE  投票締切（sales_close_at）の正本
    // ══════════════════════════════════════════════════════════════════════
    // 根拠：JRA公式「発売時間・発売締切時刻」
    //   https://jra.jp/dento/a/instructions/hatsubai/jra.html
    //   当日発売のインターネット投票は<b>各レース発走時刻の1分前</b>。
    //   プッシュホン投票は5分前。WIN5は最初のレースの発走時刻の5分前。
    //
    //   ここで使うのはインターネット投票の締切です。
    //   <b>発走時刻と同一視していません</b>（契約8章）。
    //   公式の表記は「1分前」で、秒の記載はありません。
    //   秒まで決める必要があるため、ここでは1分前の0秒（T−60秒）とします。
    //
    //   .env で動かせます（コードを直さずに変えられるようにしています）。
    //     BAGANRIKI_SALES_CLOSE_OFFSET_SEC  既定 60（発走の何秒前か）
    //     BAGANRIKI_SALES_CLOSE_DERIVE      既定 1（0 にすると導出しない）
    //   導出しない設定では、正本を渡されたときだけ時刻契約を作ります
    //   （これまでの動きです）。
    public const SALES_CLOSE_BEFORE_POST_SEC = 60;
    public const SALES_CLOSE_SOURCE = 'JRA_INTERNET_1MIN_BEFORE_POST';

    /** 導出してよいか（.env で止められます） */
    public static function salesCloseDerive(): bool
    {
        $v = (string) env('BAGANRIKI_SALES_CLOSE_DERIVE', '1');
        return in_array($v, ['1', 'true', 'on', 'yes'], true);
    }

    /** 発走の何秒前が締切か。負の値・数値でない値は既定へ戻します */
    public static function salesCloseOffsetSec(): int
    {
        $v = env('BAGANRIKI_SALES_CLOSE_OFFSET_SEC', null);
        if ($v === null || !is_numeric((string) $v)) {
            return self::SALES_CLOSE_BEFORE_POST_SEC;
        }
        $n = (int) $v;
        return ($n < 0) ? self::SALES_CLOSE_BEFORE_POST_SEC : $n;
    }

    /**
     * 発走時刻から投票締切を出します。
     * 導出が止められているときは null を返します（埋めません）。
     */
    public static function salesCloseFromPost(int $anchorUs): ?int
    {
        if (!self::salesCloseDerive()) { return null; }
        return $anchorUs - self::salesCloseOffsetSec() * self::US;
    }""",
    '投票締切の正本')

rep("""            'sales_close_at'  => $override['sales_close_at'] ?? null,""",
    """            // @ANCHOR-20261020-R122-CLOSE  正本を渡されていなければ、
            //   JRA公式の規則（インターネット投票は発走時刻の1分前）で出します。
            //   発走時刻で代用しているのではありません。公開された規則から
            //   発走時刻を起点に導いた値です。出どころは notes に残します。
            'sales_close_at'  => $override['sales_close_at']
                                 ?? (($d = BaganrikiTime::salesCloseFromPost($anchorUs))
                                     === null ? null : BaganrikiPrompt::rfc3339($d)),""",
    '投票締切の導出')

rep("""        return ['ok' => true, 'ctx' => $ctx, 'code' => null, 'reason' => null,
                'race_id' => $raceId, 'notes' => $notes];""",
    """        // @ANCHOR-20261020-R122-CLOSE  締切の出どころを返します
        //   （INPUT_JSON の time_contract は閉じた形なので、そこには入れません。
        //     凍結のときに監査へ1行残します）
        $closeSrc = isset($override['sales_close_at'])
            ? 'OVERRIDE'
            : (BaganrikiTime::salesCloseDerive()
                ? BaganrikiTime::SALES_CLOSE_SOURCE
                  . '(T-' . BaganrikiTime::salesCloseOffsetSec() . 's)'
                : 'NOT_DERIVED');
        return ['ok' => true, 'ctx' => $ctx, 'code' => null, 'reason' => null,
                'race_id' => $raceId, 'notes' => $notes,
                'sales_close_source' => $closeSrc];""",
    '投票締切の出どころ')

rep("""                'sampling_policy_id'    => 'SLOT_FIRST_VALID_COMMITTED_V1',
            ],
            'diagnostics'     => array_values($a['diagnostics'] ?? []),""",
    """                'sampling_policy_id'    => 'SLOT_FIRST_VALID_COMMITTED_V1',
                // @ANCHOR-20261020-R122-CLOSE  投票締切の出どころ
                'sales_close_at'        => $a['sales_close_at'] ?? null,
                'sales_close_source'    => $a['sales_close_source'] ?? null,
            ],
            'diagnostics'     => array_values($a['diagnostics'] ?? []),""",
    '読取APIに締切の出どころ')

rep("""        $check('R122-P01', '入れていない区分はUNAVAILABLEと理由',
            BaganrikiPrompt::coverageOf(null)['OPI']['status'], 'UNAVAILABLE');""",
    """        $check('R122-P01', '入れていない区分はUNAVAILABLEと理由',
            BaganrikiPrompt::coverageOf(null)['OPI']['status'], 'UNAVAILABLE');

        // ══════════════════════════════════════════════════════════════════
        // @ANCHOR-20261020-R122-CLOSE  投票締切の正本と、そこから出る期限
        // ══════════════════════════════════════════════════════════════════
        //   JRA公式「発売時間・発売締切時刻」の当日インターネット投票は
        //   各レース発走時刻の1分前です（発走時刻と同一視しません）。
        //     sales_close_at   = T − 60秒
        //     publish_deadline = sales_close_at − 60秒 = T − 120秒
        //     reply_deadline   = publish_deadline − 30秒 = T − 150秒
        //   取得の最後（6分前）と入力の凍結（T−330秒）より後に来ることを
        //   ここで確かめます。並びが崩れると送れません。
        $TT = BaganrikiTime::us('2026-10-18T10:05:00+09:00');
        $SC = BaganrikiTime::salesCloseFromPost((int) $TT);
        $check('R122-CL01', '投票締切は発走の60秒前',
            $SC, (int) $TT - 60 * 1000000);
        $check('R122-CL02', '発走時刻と同一視しない', ($SC === (int) $TT), false);
        $check('R122-CL03', '公開期限は発走の120秒前',
            BaganrikiTime::publishDeadline((int) $SC), (int) $TT - 120 * 1000000);
        $check('R122-CL04', '応答期限は発走の150秒前',
            BaganrikiTime::replyDeadline((int) $SC), (int) $TT - 150 * 1000000);
        $check('R122-CL05', '入力の凍結は応答期限より前',
            BaganrikiTime::inputFreeze((int) $TT)
                < BaganrikiTime::replyDeadline((int) $SC), true);
        $check('R122-CL06', '6分前の取得期限は入力の凍結より前',
            BaganrikiTime::slotDeadline((int) $TT, 6)
                <= BaganrikiTime::inputFreeze((int) $TT), true);
        $check('R122-CL07', '既定の前倒しは60秒',
            BaganrikiTime::salesCloseOffsetSec(), 60);
        $check('R122-CL08', '出どころの名前',
            BaganrikiTime::SALES_CLOSE_SOURCE, 'JRA_INTERNET_1MIN_BEFORE_POST');""",
    '投票締切の受入試験')

# @ANCHOR-20261020-R122-DEADLINE  待ち時間を応答期限から決める
rep("""        $aiTimeout = self::v04HvPrompt() ? 240 : 90;""",
    """        // @ANCHOR-20261020-R122-DEADLINE  予約がとれているときは
        //   応答期限まで残っている時間から待ち時間を決めます。
        //   固定の90秒・240秒だと、短すぎて切るか、期限を過ぎてから
        //   返ってきたものを遅着で捨てることになります。
        $aiTimeout = $this->r122AiTimeout(self::v04HvPrompt() ? 240 : 90,
                                          $r122q1 ?? null);""",
    '1st AI の待ち時間')

rep("""            $dsTimeout = 60;
            if (self::v04HvPrompt()) {
                $dsPayload['max_tokens'] = 8192;   // deepseek-chat の上限
                $dsTimeout = 120;                  // 出力が増えるぶん待つ
            }""",
    """            // @ANCHOR-20261020-R122-DEADLINE  2nd AI も応答期限から決めます
            $dsTimeout = $this->r122AiTimeout(60, $r122q2 ?? null);
            if (self::v04HvPrompt()) {
                $dsPayload['max_tokens'] = 8192;   // deepseek-chat の上限
                $dsTimeout = $this->r122AiTimeout(120, $r122q2 ?? null);
            }""",
    '2nd AI の待ち時間')

# ───────────────────────────────────────────────────────────────────────────
# 6) 新しいクラスをファイルの末尾に足す
# ───────────────────────────────────────────────────────────────────────────
cls = io.open(os.path.join(os.path.dirname(os.path.abspath(__file__)),
                           'class_prompt.php'), encoding='utf-8').read()
# @ANCHOR-20261020-R122-QUEUE  永続ワーカー（キューと予約枠）
cls += io.open(os.path.join(os.path.dirname(os.path.abspath(__file__)),
                            'class_worker.php'), encoding='utf-8').read()
# @ANCHOR-20261020-R122-DIAG  応答の診断（inspect と resolve で同じ関数）
cls += io.open(os.path.join(os.path.dirname(os.path.abspath(__file__)),
                            'class_diagnose.php'), encoding='utf-8').read()
# @ANCHOR-20261020-R122-STRICTJSON  JSONの厳密読込（10月20日005のご指摘7-3）
cls += io.open(os.path.join(os.path.dirname(os.path.abspath(__file__)),
                            'class_json.php'), encoding='utf-8').read()
src = src.rstrip('\n') + '\n' + cls

io.open(p, 'w', encoding='utf-8').write(src)
print('当てました: %s  %d行 -> %d行  md5=%s'
      % (p, orig.count('\n') + 1, src.count('\n') + 1,
         hashlib.md5(src.encode('utf-8')).hexdigest()))
