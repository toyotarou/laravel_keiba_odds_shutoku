
    /**
     * ═══════════════════════════════════════════════════════════════════════
     * @ANCHOR-20261020-R122-AUDIT  取得監査の記録の確認（書き込みは残しません）
     * ═══════════════════════════════════════════════════════════════════════
     * 根拠：10月20日003の確認結果①（実物と再現手順）／お願い②A案
     *
     *   ① テーブルの有無と、いま入っている件数
     *   ② 実際に入る値で1行書いてみて、読み戻せるかを確かめる
     *      → <b>必ずロールバックします。</b>1行も残りません。
     *   ③ 保存済みレースのうち、採用できる監査行がそろっているレース数
     *
     * AI呼び出しは0回、DBへ残る書き込みも0件です。
     */
    private function runR122AuditCheck(): void
    {
        self::r122Autoload();
        $T = 'baganriki_acquisition_batches';
        $this->info('════════════════════════════════════════════════════════');
        $this->info(' r12.2 取得監査の記録の確認（DBへ残る書き込みは0件）');
        $this->info('════════════════════════════════════════════════════════');
        $this->line('  実行時刻 : ' . date('c'));
        $this->line('');

        // ── ① テーブル ────────────────────────────────────────────────
        $this->info('── ① テーブル ──');
        if (!\Schema::hasTable($T)) {
            $this->error("  × {$T} がありません。--r122-install で作ってください。");
            return;
        }
        $this->line("  ○ {$T} あり");
        $cols = \Schema::getColumnListing($T);
        $need = ['race_id', 'slot', 'batch_id', 'slot_scheduled_at', 'source_updated_at',
                 'request_started_at', 'response_received_at', 'available_at',
                 'raw_payload', 'payload_hash', 'validation_result', 'rejection_reason',
                 'committed', 'created_at'];
        $lack = array_values(array_diff($need, $cols));
        if ($lack !== []) {
            $this->error('  × 足りない列: ' . implode('・', $lack));
            return;
        }
        $this->line('  ○ 必要な列は全部あります（' . count($need) . '列）');
        $total = \DB::table($T)->count();
        $this->line('  いま入っている件数: ' . $total . ' 件');
        if ($total > 0) {
            foreach (\DB::table($T)->selectRaw('slot, validation_result, committed, COUNT(*) n')
                        ->groupBy('slot', 'validation_result', 'committed')
                        ->orderBy('slot')->get() as $r) {
                $this->line(sprintf('    slot=%-3s %-9s committed=%d  %d 件',
                    $r->slot, (string) $r->validation_result, (int) $r->committed, (int) $r->n));
            }
        }
        $this->line('');

        // ── ② 1行書いて読み戻す（必ずロールバック）────────────────────
        $this->info('── ② 実際に入る値で1行書いて読み戻す（ロールバックします）──');
        $ok = true;
        $batchId = 'AUDITCHECK-' . date('YmdHis') . '-' . substr(bin2hex(random_bytes(4)), 0, 8);
        $raw = json_encode([['num' => 1, 'tan' => '2.1', 'fuku_min' => '1.3', 'fuku_max' => '1.6']],
                           JSON_UNESCAPED_UNICODE);
        $row = [
            'race_id'              => '20261018-4-08-7-9',
            'slot'                 => 6,
            'batch_id'             => $batchId,
            'slot_scheduled_at'    => '2026-10-18 15:04:00.000000',
            'source_updated_at'    => null,
            'request_started_at'   => '2026-10-18 15:04:00.123456',
            'response_received_at' => '2026-10-18 15:04:02.654321',
            'available_at'         => '2026-10-18 15:04:03.000001',
            'raw_payload'          => $raw,
            'payload_hash'         => hash('sha256', $raw),
            'validation_result'    => 'ADOPTED',
            'rejection_reason'     => null,
            'committed'            => 1,
            'created_at'           => date('Y-m-d H:i:s.u'),
        ];
        try {
            \DB::beginTransaction();
            \DB::table($T)->insert($row);
            $back = \DB::table($T)->where('batch_id', $batchId)->first();
            if ($back === null) {
                $this->error('  × 書いた行を読み戻せません');
                $ok = false;
            } else {
                $cmp = [
                    'race_id'              => (string) $back->race_id,
                    'slot'                 => (int) $back->slot,
                    'payload_hash'         => (string) $back->payload_hash,
                    'raw_payload'          => (string) $back->raw_payload,
                    'validation_result'    => (string) $back->validation_result,
                    'committed'            => (int) $back->committed,
                ];
                $exp = [
                    'race_id'              => $row['race_id'],
                    'slot'                 => 6,
                    'payload_hash'         => $row['payload_hash'],
                    'raw_payload'          => $raw,
                    'validation_result'    => 'ADOPTED',
                    'committed'            => 1,
                ];
                foreach ($exp as $k => $want) {
                    $got = $cmp[$k];
                    if ($got === $want) {
                        $this->line(sprintf('  ○ %-20s %s', $k,
                            mb_strimwidth((string) $got, 0, 54, '…')));
                    } else {
                        $ok = false;
                        $this->error(sprintf('  × %-20s 得た値 %s / 期待値 %s', $k,
                            mb_strimwidth((string) $got, 0, 40, '…'),
                            mb_strimwidth((string) $want, 0, 40, '…')));
                    }
                }
                // マイクロ秒が丸められていないこと（DATETIME(6) の確認）
                foreach (['request_started_at' => '.123456',
                          'response_received_at' => '.654321',
                          'available_at' => '.000001'] as $k => $frac) {
                    $v = (string) $back->{$k};
                    if (strpos($v, $frac) !== false) {
                        $this->line(sprintf('  ○ %-20s %s（マイクロ秒が落ちていません）', $k, $v));
                    } else {
                        $ok = false;
                        $this->error(sprintf('  × %-20s %s（マイクロ秒が落ちています）', $k, $v));
                    }
                }
                if ($back->source_updated_at !== null) {
                    $ok = false;
                    $this->error('  × source_updated_at が null ではありません');
                } else {
                    $this->line('  ○ source_updated_at  null（取得元の更新時刻は取れないので埋めません）');
                }
            }
        } catch (\Throwable $e) {
            $ok = false;
            $this->error('  × 書き込みで例外: ' . $e->getMessage());
        } finally {
            \DB::rollBack();
        }
        $after = \DB::table($T)->count();
        if ($after === $total) {
            $this->line('  ○ ロールバック後の件数 ' . $after . ' 件（試し書きは残っていません）');
        } else {
            $ok = false;
            $this->error('  × 件数が変わりました ' . $total . ' → ' . $after);
        }
        $this->line('');

        // ── ③ 保存済みレースの状況 ────────────────────────────────────
        $this->info('── ③ 保存済みレースで採用できる監査行があるか ──');
        $dates = array_values(array_filter(array_map('trim',
            explode(',', (string) ($this->option('date') ?: date('Y-m-d'))))));
        $have = 0; $none = 0;
        foreach ($dates as $date) {
            foreach (\DB::table('t_horse_odds_finder_races')->where('date', $date)
                        ->get(['date', 'kaisuu', 'basho', 'day', 'race']) as $r) {
                $raceId = \App\Http\Controllers\Api\AiController::r122RaceId(
                    $r->date, $r->kaisuu, $r->basho, $r->day, $r->race);
                $n = \DB::table($T)->where('race_id', $raceId)
                        ->where('committed', 1)->whereIn('slot', [21, 18, 15, 12, 9, 6])->count();
                if ($n > 0) $have++; else $none++;
            }
        }
        $this->line('  対象日   : ' . implode(' / ', $dates));
        $this->line('  監査行あり: ' . $have . ' レース');
        $this->line('  監査行なし: ' . $none . ' レース');
        if ($none > 0) {
            $this->warn('  ※ 監査行は、これから取得するレースから貯まります。');
            $this->warn('  　 過去に保存したレースの実時刻は残っていないので、');
            $this->warn('  　 あとから作ることはしません（作り話になるため）。');
        }
        $this->line('');
        $this->info('════════════════════════════════════════════════════════');
        $this->info($ok ? ' 記録の経路は使える状態です（DBへ残る書き込み0件）'
                        : ' 使えない項目があります。上の × をご確認ください');
        $this->info('════════════════════════════════════════════════════════');
    }
