
    /**
     * ═══════════════════════════════════════════════════════════════════════
     * @ANCHOR-20261020-R122-WIRE  実送信の後へ接続します（6-4）
     * ═══════════════════════════════════════════════════════════════════════
     * 根拠：10月20日006のご指摘6-4／server_contract_r12.2.txt 6章・10章・11章
     *
     * ■ ご指摘のとおりでした
     *   r122InspectResponse ／ r122ResolveCorrection ／ r122Publish は
     *   試験Commandからしか呼ばれていませんでした。旗を1にしても、
     *   原応答を保存したあと、誰も検証・訂正・公開を始めませんでした。
     *   「旗を1にすれば完成経路」ではありませんでした。
     *
     * ■ ここで繋ぐもの（呼出経路を1本に決めます）
     *   実ファイル : app/Http/Controllers/Api/AiController.php
     *   呼出元①   : getHorseOddsFinderAiAnalysis()   1st の原応答保存の直後
     *   呼出元②   : getHorseOddsFinderSecondAiOpinion() 2nd の原応答保存の直後
     *   入口       : r122AfterReceive()
     *   流れ       : 検証 → （必要なら）訂正を1回だけ送る → 解決 → 公開
     *   Queue Job  : 作りません。HTTPの中で同期に通します。
     *                理由は時間です。応答期限（発走150秒前）から
     *                公開期限（発走120秒前）まで30秒しかないので、
     *                別プロセスへ渡して待つ余裕がありません。
     *                再起動後のやり直しだけ r122SweepPending() で拾います。
     *
     * ■ 商品を落とさないための決めごと
     *   ・ここで例外が出ても、旧来の予想は返します（全体を try で囲みます）。
     *   ・旗が0のときは1バイトも動きません（BaganrikiWorker::enabled()）。
     *   ・公開は「両roleが終端になってから」です。1stだけで公開しません。
     *     ただし応答期限を過ぎたら、来ないものを待たずに公開します。
     */

    /**
     * @ANCHOR-20261020-R122-WIRE  訂正に使う時間の決めごと
     *
     *   時刻の並びは 発走T → 投票締切 T-60 → 公開期限 T-120
     *   → 応答期限 T-150 → 入力凍結 T-330 → cutoff T-360 です。
     *   訂正は<b>応答期限までに受け取れなければ意味がありません</b>
     *   （過ぎて届いたものは遅着で捨てます）。
     *   残り時間がこれ未満なら、枠を取らずに初回の正常部分で進みます。
     */
    public const R122_FIX_MIN_SEC      = 25;   // これ未満なら訂正を送りません
    public const R122_FIX_MAX_WAIT     = 60;   // 訂正の待ち時間の上限（秒）
    public const R122_SWEEP_GRACE_SEC  = 30;
    // @ANCHOR-20261021-R122-SENDFIRST  初回のやり直しに必要な残り時間
    public const R122_FIRST_MIN_SEC   = 40;   // これ未満なら初回を送りません
    public const R122_FIRST_MAX_WAIT  = 170;  // 初回の待ち時間の上限（秒）   // 受領直後はやり直しで触りません

    /**
     * @ANCHOR-20261020-R122-WIRE  設定の食い違いを送信の前に止めます
     *
     *   006のご指摘：「PROMPT=1だけにしてQUEUE=0のままなら、予約処理を
     *   skipし、新契約の期限・公開を一式で保証できません。」
     *   そのとおりです。r12.2 の本文で送るなら、枠・期限・公開も
     *   r12.2 でなければいけません。片方だけ入れるのを禁じます。
     *
     * @return array ['ok','code','reason','prompt','queue']
     */
    public static function r122WireConfig(): array
    {
        $p = BaganrikiPrompt::mode();      // off / shadow / on
        $q = BaganrikiWorker::mode();      // off / shadow / on
        $o = ['ok' => true, 'code' => 'OK', 'reason' => null,
              'prompt' => $p, 'queue' => $q];
        if ($p !== 'on') { return $o; }    // 旧本文のまま、または shadow なら関係ありません
        if ($q === 'off') {
            $o['ok']     = false;
            $o['code']   = 'QUEUE_REQUIRED';
            $o['reason'] = 'BAGANRIKI_R122_PROMPT=1 のときに '
                         . 'BAGANRIKI_R122_QUEUE=0 は使えません。'
                         . '枠・期限・公開が r12.2 になっていない状態で '
                         . 'r12.2 の本文を送ることになるためです。'
                         . '（QUEUE=1 にしてください）';
            return $o;
        }
        if ($q === 'shadow') {
            $o['code']   = 'QUEUE_SHADOW';
            $o['reason'] = '枠は shadow です。枠が取れなくても送信を止めません。'
                         . '非公開検証の段としては妥当ですが、'
                         . '契約10章の停止条件は効いていません。';
        }
        return $o;
    }

    /**
     * @ANCHOR-20261020-R122-WIRE  訂正依頼に載せる「具体的なエラー一覧」
     *
     *   配布本文の【説明と訂正】は
     *   「初回応答・同一snapshot・repair_scope・具体的なエラー一覧」
     *   を渡すことになっています。診断の findings をそのまま渡します。
     *   こちらの言い換えを混ぜると、直す対象がぶれるためです。
     */
    public static function r122FixErrorList(array $insp): array
    {
        $d = (array) ($insp['diag'] ?? []);
        $errors = [];
        foreach ((array) ($d['findings'] ?? []) as $f) {
            $errors[] = [
                'scope'  => (string) ($f['scope'] ?? ''),
                'target' => $f['target'] ?? null,
                'code'   => (string) ($f['code'] ?? ''),
                'reason' => (string) ($f['reason'] ?? ''),
            ];
        }
        return [
            'errors'          => $errors,
            'missing_horses'  => array_values(array_map('intval',
                                   (array) ($d['missing'] ?? []))),
            'duplicated_horses' => array_values(array_map('intval',
                                   (array) ($d['duplicated'] ?? []))),
            'unknown_horses'  => array_values(array_map('intval',
                                   (array) ($d['unknown'] ?? []))),
            'isolated_horses' => array_values(array_map('intval',
                                   (array) ($d['isolated'] ?? []))),
        ];
    }

    /**
     * @ANCHOR-20261020-R122-WIRE  訂正依頼の本文を組みます
     *
     *   system は初回と同じ本文です（別の本文を送ると別の契約になります）。
     *   user は1個のJSONで、中身は4つだけです。
     *     fix_request … race_id・ai_role・snapshot_hash・repair_scope・エラー一覧
     *     first_response … 当該AIの初回応答の原文（相手AIのものは入れません）
     *     input … 同じ凍結入力（固定後は変えません）
     *   送る前に自分の本文も厳密読込を通します（@ANCHOR-...-STRICTJSON）。
     *
     * @return array ['ok','code','reason','system','user','user_bytes','sha256']
     */
    public function r122AssembleFix(int $snapshotId, string $role, array $insp): array
    {
        $out = ['ok' => false, 'code' => null, 'reason' => null,
                'system' => null, 'user' => null, 'user_bytes' => 0, 'sha256' => null];

        $snap = \DB::table('baganriki_snapshots')->where('id', $snapshotId)->first();
        if ($snap === null) {
            $out['code'] = 'NO_SNAPSHOT'; $out['reason'] = '凍結入力がありません';
            return $out;
        }
        $col = ($role === '2nd') ? 'input_json_2nd' : 'input_json_1st';
        $src = json_decode((string) $snap->{$col}, true);
        if (!is_array($src)) {
            $out['code'] = 'NO_INPUT';
            $out['reason'] = '凍結入力のJSONを読めません（' . $col . '）';
            return $out;
        }

        $a = \DB::table('baganriki_ai_attempts')
               ->where('snapshot_id', $snapshotId)->where('role', $role)
               ->where('attempt_no', BaganrikiWorker::FIRST)->first();
        if ($a === null || (string) $a->status !== BaganrikiWorker::RECEIVED) {
            $out['code'] = 'FIRST_NOT_RECEIVED';
            $out['reason'] = '初回の原応答がありません';
            return $out;
        }

        $sys = BaganrikiPrompt::systemBody($role);
        if (!$sys['ok']) {
            $out['code'] = 'SYSTEM_UNUSABLE';
            $out['reason'] = (string) $sys['reason'];
            return $out;
        }

        $lst = self::r122FixErrorList($insp);
        $body = [
            'fix_request' => [
                'race_id'       => (string) $snap->race_id,
                'ai_role'       => $role,
                'snapshot_hash' => (string) $snap->snapshot_hash,
                'attempt_no'    => BaganrikiWorker::FIX,
                'max_attempts'  => 1,
                'repair_scope'  => (array) ($insp['repair_scope'] ?? []),
                'errors'            => $lst['errors'],
                'missing_horses'    => $lst['missing_horses'],
                'duplicated_horses' => $lst['duplicated_horses'],
                'unknown_horses'    => $lst['unknown_horses'],
                'isolated_horses'   => $lst['isolated_horses'],
            ],
            // 当該AIの初回応答そのもの。原文のまま渡します（要約しません）。
            'first_response' => (string) $a->raw_response,
            // 同じ凍結入力。別の入力を渡すと別のレースになります。
            'input' => $src,
        ];
        $enc = BaganrikiPrompt::encode($body);
        if (!$enc['ok']) {
            $out['code'] = 'ENCODE_FAILED';
            $out['reason'] = (string) $enc['reason'];
            return $out;
        }
        // @ANCHOR-20261020-R122-STRICTJSON  送る前に自分の本文も厳密に読みます
        $st = BaganrikiJson::strict((string) $enc['json']);
        if (!$st['ok']) {
            $out['code'] = 'SELF_JSON_INVALID';
            $out['reason'] = '訂正依頼のJSONが自分の検査を通りません（'
                           . (string) ($st['code'] ?? '') . '）';
            return $out;
        }
        $out['ok']         = true;
        $out['code']       = 'OK';
        $out['system']     = (string) $sys['body'];
        $out['user']       = (string) $enc['json'];
        $out['user_bytes'] = (int) $enc['bytes'];
        $out['sha256']     = hash('sha256', (string) $enc['json']);
        return $out;
    }

    /**
     * @ANCHOR-20261020-R122-WIRE  AIを1回だけ呼びます（roleで送り先が違います）
     *
     *   1st … Anthropic（AnthropicService）
     *   2nd … DeepSeek（HTTP）
     *   自動再試行は0です（契約10章「SDKの自動再試行は0」）。
     *
     * @return array ['ok','raw','complete','code','reason']
     */
    public function r122CallAi(string $role, string $system, string $user,
                               int $timeout): array
    {
        // ══════════════════════════════════════════════════════════════
        // @ANCHOR-20261021-R122-USAGE  実モデルと使用量を残します（010の7章⑤）
        // ══════════════════════════════════════════════════════════════
        //   ご指摘：
        //     「12個のrace_idへの限定、非公開の読取経路、usageと実モデルの
        //       記録、初回24回／最大48回の費用を示すこと。」
        //     「2ndは添付コード上でdeepseek-chat、max_tokens=8,192です。
        //       …2nd自身のトークナイザ、実モデル、finish_reason、usage、
        //       JSON検証結果を揃えてください。」
        //   応答の usage と、API が名乗ったモデル名をそのまま残します。
        //   <b>こちらで決めた名前ではなく、応答に書かれていたもの</b>です。
        //   入れる場所は baganriki_audit_events です（新しい表は作りません）。
        $out = ['ok' => false, 'raw' => '', 'complete' => false,
                'code' => null, 'reason' => null,
                'usage' => null, 'model' => null, 'stop' => null];
        try {
            if ($role === '2nd') {
                $res = \Illuminate\Support\Facades\Http::timeout($timeout)
                    ->withHeaders(['Authorization' => 'Bearer ' . env('DEEPSEEK_API_KEY')])
                    ->post('https://api.deepseek.com/v1/chat/completions', [
                        'model'    => 'deepseek-chat',
                        'messages' => [
                            ['role' => 'system', 'content' => $system],
                            ['role' => 'user',   'content' => $user],
                        ],
                        'max_tokens' => 8192,
                    ]);
                if ($res->failed()) {
                    $out['code']   = 'API_ERROR';
                    $out['reason'] = '2nd AI の API エラー status=' . $res->status();
                    return $out;
                }
                $j   = $res->json();
                $raw = trim((string) ($j['choices'][0]['message']['content'] ?? ''));
                $fin = $j['choices'][0]['finish_reason'] ?? null;
                $out['ok']       = true;
                $out['code']     = 'OK';
                $out['raw']      = $raw;
                $out['complete'] = (($fin === null || $fin === 'stop') && $raw !== '');
                // @ANCHOR-20261021-R122-USAGE  応答が名乗ったモデルと使用量
                $out['model'] = (string) ($j['model'] ?? '');
                $out['stop']  = ($fin === null) ? null : (string) $fin;
                $out['usage'] = is_array($j['usage'] ?? null)
                              ? (array) $j['usage'] : null;
                return $out;
            }
            $res = $this->anthropic->sendWithRetry(
                prompt:      $user,
                system:      $system,
                maxAttempts: 1,     // 仕様: 自動再試行禁止。2以上にしてはいけない
                sleepBase:   2,
                timeout:     $timeout,
            );
            if ($res->failed()) {
                $out['code']   = 'API_ERROR';
                $out['reason'] = '1st AI の API エラー status=' . $res->status();
                return $out;
            }
            $raw  = trim((string) $this->anthropic->extractText($res));
            $stop = $res->json('stop_reason');
            $out['ok']       = true;
            $out['code']     = 'OK';
            $out['raw']      = $raw;
            $out['complete'] = (($stop === null || $stop === 'end_turn') && $raw !== '');
            // @ANCHOR-20261021-R122-USAGE  応答が名乗ったモデルと使用量
            $out['model'] = (string) ($res->json('model') ?? '');
            $out['stop']  = ($stop === null) ? null : (string) $stop;
            $u = $res->json('usage');
            $out['usage'] = is_array($u) ? (array) $u : null;
            return $out;
        } catch (\Illuminate\Http\Client\ConnectionException $e) {
            // 届いたかどうか分からないので「結果不明」にします（再送しません）
            $out['code']   = 'CONNECTION';
            $out['reason'] = $e->getMessage();
            return $out;
        } catch (\Throwable $e) {
            $out['code']   = 'EXCEPTION';
            $out['reason'] = $e->getMessage();
            return $out;
        }
    }

    /**
     * @ANCHOR-20261020-R122-WIRE  訂正を1回だけ送ります
     *
     *   順番を守ります（契約10章）。
     *     ① 初回の原応答と complete が保存済みか（fixAllowed）
     *     ② 枠を予約してから送る（reserve → allowSend → 送信）
     *     ③ 残り時間が無いなら<b>予約しません</b>（空振りの枠を残さないため）
     *   結果不明・失敗でも初回の正常部分は残ります（resolve 側の約束）。
     *
     * @return array ['sent','ok','code','reason']
     */
    public function r122SendFix(int $snapshotId, string $role, array $insp): array
    {
        $out = ['sent' => false, 'ok' => false, 'code' => null, 'reason' => null];

        $fa = BaganrikiWorker::fixAllowed($snapshotId, $role);
        if (!$fa['ok']) {
            $out['code'] = (string) $fa['code']; $out['reason'] = (string) $fa['reason'];
            return $out;
        }

        $snap = \DB::table('baganriki_snapshots')->where('id', $snapshotId)->first();
        $live = \DB::table('baganriki_live_states')
                  ->where('snapshot_id', $snapshotId)->first();
        if ($snap === null) {
            $out['code'] = 'NO_SNAPSHOT'; $out['reason'] = '凍結入力がありません';
            return $out;
        }
        // ══════════════════════════════════════════════════════════════
        // @ANCHOR-20261021-R122-TARGET12  訂正の入口でも対象レースを見ます
        // ══════════════════════════════════════════════════════════════
        //   ご指摘（010の2-5）：
        //     「通常アクセス・キャッシュ後・巡回・訂正の全入口で
        //       対象race_idを確認し、送信許可の直前でも確認します。
        //       1レースの最大4回という制約だけでは、対象レース総数12を
        //       保証できません。」
        //   訂正は1レースあたり最大1回ですが、レースの数は制限されません。
        //   ここでも見ます。判定は全入口で同じ関数（r122TargetCheck）です。
        $tgF = self::r122TargetCheck((string) $snap->race_id);
        if (!$tgF['ok']) {
            $out['code']   = (string) $tgF['code'];
            $out['reason'] = (string) $tgF['reason'];
            return $out;
        }

        $dl = BaganrikiWorker::deadlines($snap, $live);
        if (!$dl['ok']) {
            $out['code'] = (string) $dl['code']; $out['reason'] = (string) $dl['reason'];
            return $out;
        }
        $now  = BaganrikiWorker::nowUs();
        // 送って受け取って公開するのに最低どれだけ要るか。
        //   応答期限までに受領できない見込みなら予約しません。
        $left = (int) floor(($dl['reply'] - $now) / 1000000);
        if ($left < self::R122_FIX_MIN_SEC) {
            $out['code']   = 'NO_TIME_FOR_FIX';
            $out['reason'] = '応答期限まで ' . $left . '秒しかないので訂正を送りません'
                           . '（最低 ' . self::R122_FIX_MIN_SEC . '秒）';
            return $out;
        }

        $asm = $this->r122AssembleFix($snapshotId, $role, $insp);
        if (!$asm['ok']) {
            $out['code'] = (string) $asm['code']; $out['reason'] = (string) $asm['reason'];
            return $out;
        }

        // 版の見張り。応答の版は予約そのもので増えるので入れません。
        $expect = ($live === null) ? [] : [
            'state_revision'       => (int) $live->state_revision,
            'publication_revision' => (int) $live->publication_revision,
        ];
        $r = BaganrikiWorker::reserve($snapshotId, $role, BaganrikiWorker::FIX,
                                      BaganrikiWorker::nowUs(), $expect);
        if (!$r['ok']) {
            $out['code'] = (string) $r['code']; $out['reason'] = (string) $r['reason'];
            return $out;
        }
        $s = BaganrikiWorker::allowSend((string) $r['token'], BaganrikiWorker::nowUs());
        if (!$s['ok']) {
            $out['code'] = (string) $s['code']; $out['reason'] = (string) $s['reason'];
            return $out;
        }

        self::recordPromptHash($role . '_fix', (string) $asm['user']);
        \Log::error('[R122-WIRE] 訂正を送ります', [
            'race_id'      => (string) $snap->race_id,
            'role'         => $role,
            'repair_scope' => (array) ($insp['repair_scope'] ?? []),
            'errors'       => count(self::r122FixErrorList($insp)['errors']),
            'user_bytes'   => (int) $asm['user_bytes'],
            'user_sha256'  => (string) $asm['sha256'],
            '残り秒'       => $left,
        ]);

        $wait = max(20, min(self::R122_FIX_MAX_WAIT, $left - 5));
        $call = $this->r122CallAi($role, (string) $asm['system'], (string) $asm['user'],
                                  $wait);
        $out['sent'] = true;
        // @ANCHOR-20261021-R122-USAGE  実モデルと使用量を残します（010の7章⑤）
        self::r122RecordUsage($snapshotId, $role, BaganrikiWorker::FIX, $call);
        if (!$call['ok']) {
            // 通信失敗・待ち時間切れは「結果不明」。明確な失敗は FAILED。
            $unknown = ($call['code'] === 'CONNECTION' || $call['code'] === 'EXCEPTION');
            BaganrikiWorker::fail((string) $r['token'],
                '訂正の送信が失敗しました（' . (string) $call['code'] . '）'
                . (string) $call['reason'],
                BaganrikiWorker::nowUs(), $unknown);
            $out['code']   = (string) $call['code'];
            $out['reason'] = (string) $call['reason'];
            return $out;
        }
        $rc = BaganrikiWorker::receive((string) $r['token'], (string) $call['raw'],
                                       (bool) $call['complete'],
                                       BaganrikiWorker::nowUs());
        if (!($rc['ok'] ?? false)) {
            $out['code']   = (string) ($rc['code'] ?? 'RECEIVE_FAILED');
            $out['reason'] = (string) ($rc['reason'] ?? '訂正の原応答を保存できません');
            return $out;
        }
        $out['ok']     = true;
        $out['code']   = 'OK';
        $out['reason'] = '訂正の原応答を保存しました（complete='
                       . ((bool) $call['complete'] ? 'true' : 'false') . '）';
        return $out;
    }

    /**
     * ═══════════════════════════════════════════════════════════════════════
     * @ANCHOR-20261021-R122-SENDFIRST  初回をやり直せるようにします（008の5）
     * ═══════════════════════════════════════════════════════════════════════
     * ご指摘：
     *   「r122AfterCached は凍結と公開判定を呼びますが、初回送信を起動しません。
     *     sweep も初回送信をしない設計です。旧キャッシュあり・初回枠なしの
     *     レースが、上限後に凍結できただけで止まらず、両AIの初回送信へ
     *     進む経路を示してください。」
     *
     * そのとおりでした。固定入力ができても、初回の送信を始める者が
     * 誰もいませんでした。<b>画面からの呼び出しがキャッシュで終わる限り、
     * そのレースは永久に送られません。</b>
     *
     * ここが、その経路です。固定入力（generation=0）から
     *   予約（reserve）→ 送信許可（allowSend）→ 送信（r122CallAi）
     *   → 受領（receive）→ 検証・訂正・統合・公開（r122AfterReceive）
     * まで進めます。送信口は訂正と<b>同じ</b>ものを使います。
     *
     * 二重送信はしません。枠は race_id・role・attempt_no で一意なので、
     * 画面側とこちらが同時に動いても、予約できた側だけが送ります。
     *
     * @return array ['sent','ok','code','reason']
     */
    public function r122SendFirst(int $snapshotId, string $role,
                                  array $opt = []): array
    {
        $out = ['sent' => false, 'ok' => false, 'code' => null, 'reason' => null];
        if ($role !== '1st' && $role !== '2nd') {
            $out['code'] = 'ROLE_INVALID'; return $out;
        }
        $cfg = self::r122WireConfig();
        if (!($cfg['ok'] ?? false)) {
            $out['code'] = (string) $cfg['code'];
            $out['reason'] = (string) $cfg['reason'];
            return $out;
        }
        // @ANCHOR-20261021-R122-SENDFIRST  旗の検査
        //   $opt['test_ignore_flags'] は<b>試験からだけ</b>渡します。
        //   送信口を偽物に差し替えた通し試験で、旗が下りている環境でも
        //   経路そのものを通すためのものです。
        //   本番の呼び出し元（r122SweepPending／r122AfterCached）は
        //   渡しません。渡していないことは試験で見張ります。
        if (($opt['test_ignore_flags'] ?? false) !== true
            && (!BaganrikiPrompt::sending() || !BaganrikiWorker::enabled())) {
            $out['code']   = 'FLAG_OFF';
            $out['reason'] = '本文の段か枠の段が上がっていないので初回は送りません';
            return $out;
        }
        $snap = \DB::table('baganriki_snapshots')->where('id', $snapshotId)->first();
        if ($snap === null || (int) $snap->generation !== 0) {
            $out['code'] = 'NO_SNAPSHOT';
            $out['reason'] = '本番の固定入力（generation=0）がありません';
            return $out;
        }
        // すでに枠があれば何もしません（作り直しません）
        $has = \DB::table('baganriki_ai_attempts')
                 ->where('snapshot_id', $snapshotId)->where('role', $role)
                 ->where('attempt_no', BaganrikiWorker::FIRST)->exists();
        if ($has) {
            $out['code'] = 'ALREADY';
            $out['reason'] = 'その role の初回の枠はすでにあります';
            return $out;
        }
        $live = \DB::table('baganriki_live_states')
                  ->where('snapshot_id', $snapshotId)->first();
        $dl = BaganrikiWorker::deadlines($snap, $live);
        if (!$dl['ok']) {
            $out['code'] = (string) $dl['code'];
            $out['reason'] = (string) $dl['reason'];
            return $out;
        }
        // ══════════════════════════════════════════════════════════════
        // @ANCHOR-20261021-R122-TARGET12  初回の送信許可の直前（010の2-5）
        // ══════════════════════════════════════════════════════════════
        //   「送信許可の直前でも確認します」。
        //   巡回や待ち行列から来たときは、拾ってから時間が経っています。
        //   予約（reserve）の前にもう一度見ます。
        $tgS = self::r122TargetCheck((string) $snap->race_id);
        if (!$tgS['ok']) {
            $out['code']   = (string) $tgS['code'];
            $out['reason'] = (string) $tgS['reason'];
            return $out;
        }

        $now  = BaganrikiWorker::nowUs();
        $left = (int) floor(($dl['reply'] - $now) / 1000000);
        if ($left < self::R122_FIRST_MIN_SEC) {
            $out['code']   = 'NO_TIME_FOR_FIRST';
            $out['reason'] = '応答期限まで ' . $left . '秒しかないので初回を送りません'
                           . '（最低 ' . self::R122_FIRST_MIN_SEC . '秒）';
            return $out;
        }

        // ── 保存した本文をそのまま使います（作り直しません）──────────
        $col  = ($role === '2nd') ? 'input_json_2nd' : 'input_json_1st';
        $user = (string) ($snap->{$col} ?? '');
        if ($user === '') {
            $out['code'] = 'NO_SAVED_INPUT';
            $out['reason'] = '固定入力に ' . $role . ' の本文がありません';
            return $out;
        }
        $in = json_decode($user, true);
        if (!is_array($in)
            || (string) ($in['snapshot_hash'] ?? '') !== (string) $snap->snapshot_hash) {
            $out['code'] = 'SAVED_HASH_MISMATCH';
            $out['reason'] = '保存本文の snapshot_hash が列の値と違います';
            return $out;
        }
        $sys = BaganrikiPrompt::systemBody($role);
        if (!$sys['ok']) {
            $out['code'] = 'PROMPT_BODY_INVALID';
            $out['reason'] = (string) $sys['reason'];
            return $out;
        }

        $expect = ($live === null) ? [] : [
            'state_revision'       => (int) $live->state_revision,
            'publication_revision' => (int) $live->publication_revision,
        ];
        $r = BaganrikiWorker::reserve($snapshotId, $role, BaganrikiWorker::FIRST,
                                      BaganrikiWorker::nowUs(), $expect);
        if (!$r['ok']) {
            $out['code'] = (string) $r['code']; $out['reason'] = (string) $r['reason'];
            return $out;
        }
        $a = BaganrikiWorker::allowSend((string) $r['token'], BaganrikiWorker::nowUs());
        if (!$a['ok']) {
            $out['code'] = (string) $a['code']; $out['reason'] = (string) $a['reason'];
            return $out;
        }
        self::recordPromptHash($role . '_first_resume', $user);
        \Log::error('[R122-SENDFIRST] 初回を送ります（やり直し経路）', [
            'race_id'     => (string) $snap->race_id,
            'role'        => $role,
            'user_bytes'  => strlen($user),
            'snapshot_hash' => (string) $snap->snapshot_hash,
            '残り秒'      => $left,
        ]);

        $wait = max(20, min(self::R122_FIRST_MAX_WAIT, $left - 5));
        $call = $this->r122CallAi($role, (string) $sys['body'], $user, $wait);
        $out['sent'] = true;
        // @ANCHOR-20261021-R122-USAGE  実モデルと使用量を残します（010の7章⑤）
        self::r122RecordUsage($snapshotId, $role, BaganrikiWorker::FIRST, $call);
        if (!$call['ok']) {
            $unknown = ($call['code'] === 'CONNECTION' || $call['code'] === 'EXCEPTION');
            BaganrikiWorker::fail((string) $r['token'],
                '初回の送信が失敗しました（' . (string) $call['code'] . '）'
                . (string) $call['reason'],
                BaganrikiWorker::nowUs(), $unknown);
            $out['code'] = (string) $call['code'];
            $out['reason'] = (string) $call['reason'];
            return $out;
        }
        $rc = BaganrikiWorker::receive((string) $r['token'], (string) $call['raw'],
                                       (bool) $call['complete'],
                                       BaganrikiWorker::nowUs());
        if (!($rc['ok'] ?? false)) {
            $out['code'] = (string) ($rc['code'] ?? 'RECEIVE_FAILED');
            $out['reason'] = (string) ($rc['reason'] ?? '初回の原応答を保存できません');
            return $out;
        }
        $out['ok']   = true;
        $out['code'] = 'OK';
        $out['reason'] = '初回の原応答を保存しました（complete='
                       . ((bool) $call['complete'] ? 'true' : 'false') . '）';

        // 受け取ったので、検証→訂正→解決→公開まで続けます
        $rid = (string) $snap->race_id;
        $p = explode('-', $rid);
        if (count($p) === 5) {
            $d = substr($p[0], 0, 4) . '-' . substr($p[0], 4, 2) . '-' . substr($p[0], 6, 2);
            $this->r122AfterReceive($d, $p[1], $p[2], $p[3], (int) $p[4], $role,
                ['skip' => false, 'ok' => true, 'snapshot_id' => $snapshotId]);
        }
        return $out;
    }

    /**
     * @ANCHOR-20261020-R122-WIRE  両roleが終端になってから公開します
     *
     *   1stだけで公開してしまうと、2ndがこれから返ってくるのに
     *   片側だけの統合で出したことになります。
     *   ただし応答期限を過ぎたら、来ないものを待ちません。
     *
     * @return array r122Publish の戻り、または ['ok'=>false,'code'=>'WAITING'…]
     */
    public function r122PublishWhenReady(int $snapshotId, array $opt = []): array
    {
        $snap = \DB::table('baganriki_snapshots')->where('id', $snapshotId)->first();
        if ($snap === null) {
            return ['ok' => false, 'code' => 'NO_SNAPSHOT',
                    'reason' => '凍結入力がありません'];
        }
        $live = \DB::table('baganriki_live_states')
                  ->where('snapshot_id', $snapshotId)->first();
        $dl   = BaganrikiWorker::deadlines($snap, $live);
        $now  = (int) ($opt['now_us'] ?? BaganrikiWorker::nowUs());

        $settled = 0; $waiting = [];
        foreach (['1st', '2nd'] as $role) {
            $f = \DB::table('baganriki_ai_attempts')
                   ->where('snapshot_id', $snapshotId)->where('role', $role)
                   ->where('attempt_no', BaganrikiWorker::FIRST)->first();
            if ($f === null) { $waiting[] = $role . '（枠なし）'; continue; }
            if (in_array((string) $f->status, BaganrikiWorker::TERMINAL, true)) {
                // 訂正の枠が予約済みで未終端なら、まだ待ちます
                $x = \DB::table('baganriki_ai_attempts')
                       ->where('snapshot_id', $snapshotId)->where('role', $role)
                       ->where('attempt_no', BaganrikiWorker::FIX)->first();
                if ($x !== null
                    && !in_array((string) $x->status, BaganrikiWorker::TERMINAL, true)) {
                    $waiting[] = $role . '（訂正中）';
                    continue;
                }
                // ══════════════════════════════════════════════════════════
                // @ANCHOR-20261021-R122-SETTLE  受領の終端≠採否の確定
                // ══════════════════════════════════════════════════════════
                //   ここまでで分かるのは「HTTPが返った」ことだけです。
                //   TERMINAL には RECEIVED が含まれるので、
                //   診断・訂正の要否をまだ判定していない role まで
                //   終端として数えてしまいます（010の2-4）。
                //   採否確定の印（R122_ROLE_SETTLED）を別に見ます。
                $sv = self::r122RoleSettled($snapshotId, $role);
                if (!$sv['settled']) {
                    $waiting[] = $role . '（採否未確定）';
                    continue;
                }
                $settled++;
                continue;
            }
            $waiting[] = $role . '（' . (string) $f->status . '）';
        }
        if ($waiting !== []) {
            // 応答期限を過ぎたら待ちません（もう届いても遅着です）
            // ══════════════════════════════════════════════════════════════
            // @ANCHOR-20261021-R122-ATDEADLINE  期限ぴったりも「過ぎた」と見ます
            // ══════════════════════════════════════════════════════════════
            //   ご指摘（010の2-3 末尾）：
            //     「現行 r122PublishWhenReady は $now > reply の判定なので、
            //       期限ぴったりの1回でWAITINGになって終わらないよう、
            //       期限直後の再判定まで含めて設計してください。」
            //   `>` だと、期限と同じマイクロ秒に来た1回が WAITING で終わり、
            //   その後だれも呼び直さないと公開されないままになります。
            //   `>=` にして、期限に達した時点で待つのをやめます。
            // $late = ($dl['ok'] && $dl['reply'] !== null && $now > $dl['reply']);  // 旧
            $late = ($dl['ok'] && $dl['reply'] !== null && $now >= $dl['reply']);
            if (!$late) {
                return ['ok' => false, 'code' => 'WAITING',
                        'reason' => 'まだ終端でないroleがあります: '
                                  . implode('・', $waiting),
                        'settled' => $settled, 'waiting' => $waiting];
            }
            \Log::error('[R122-WIRE] 応答期限を過ぎたので待たずに公開します', [
                'race_id' => (string) $snap->race_id, 'waiting' => $waiting,
            ]);
        }
        return $this->r122Publish($snapshotId, $opt);
    }

    /**
     * @ANCHOR-20261020-R122-WIRE  原応答を保存した直後に呼ぶ入口
     *
     *   r122QueueReceive() が成功した直後に、roleごとに1回だけ呼びます。
     *   ここから先は商品（旧来の予想）とは独立です。何が起きても
     *   例外を外へ出しません。出すと予想が落ちるためです。
     *
     * @param array $q r122QueueReserve の戻り
     * @return array ['ran','inspect','fix','resolve','publish']
     */
    public function r122AfterReceive($date, $kaisuu, $basho, $day, $race,
                                     string $role, array $q): array
    {
        $out = ['ran' => false, 'inspect' => null, 'fix' => null,
                'resolve' => null, 'publish' => null, 'settled' => null];
        if (($q['skip'] ?? true) || !($q['ok'] ?? false)) { return $out; }
        $sid = (int) ($q['snapshot_id'] ?? 0);
        if ($sid <= 0) { return $out; }
        $raceId = self::r122RaceId($date, $kaisuu, $basho, $day, $race);

        try {
            $out['ran'] = true;

            // ① 初回の検証（局所回復はこの中でやります）
            $insp = $this->r122InspectResponse($sid, $role, BaganrikiWorker::FIRST);
            $out['inspect'] = ['ok' => $insp['ok'], 'code' => $insp['code'],
                               'complete' => $insp['complete'],
                               'needs_fix' => $insp['needs_fix'],
                               'normal' => count((array) $insp['normal']),
                               'kept' => count((array) $insp['normal_kept']),
                               'salvaged' => (array) ($insp['salvaged'] ?? [])];
            \Log::error('[R122-WIRE] 初回を検証しました', [
                'race_id' => $raceId, 'role' => $role,
                'ok' => $insp['ok'], 'code' => $insp['code'],
                'complete' => $insp['complete'], 'needs_fix' => $insp['needs_fix'],
                '採用できた頭数' => count((array) $insp['normal']),
                '保持した頭数'   => count((array) $insp['normal_kept']),
                'reason' => $insp['reason'],
            ]);

            // ② 必要なら訂正を1回だけ（最大1回は fixAllowed が見張ります）
            if ($insp['ok'] && $insp['needs_fix'] && $insp['complete'] === true) {
                $fx = $this->r122SendFix($sid, $role, $insp);
                $out['fix'] = $fx;
                \Log::error('[R122-WIRE] 訂正の結果', [
                    'race_id' => $raceId, 'role' => $role,
                    'sent' => $fx['sent'], 'ok' => $fx['ok'],
                    'code' => $fx['code'], 'reason' => $fx['reason'],
                ]);
            }

            // ③ 解決（訂正が無い・採用できないときは初回の正常部分）
            $rv = $this->r122AcceptedHorses($sid, $role);
            $out['resolve'] = ['ok' => $rv['ok'] ?? false, 'code' => $rv['code'] ?? null,
                               'merged' => count((array) ($rv['merged'] ?? []))];

            // ══════════════════════════════════════════════════════════════
            // @ANCHOR-20261021-R122-SETTLE  ここで採否が確定しました（010の2-4）
            // ══════════════════════════════════════════════════════════════
            //   診断（①）→必要な訂正（②）→採否（③）まで終わったので、
            //   この role の「採否確定」の印を付けます。
            //   印には、いまの応答の版（初回と訂正の状態から作るSHA-256）を
            //   入れます。あとから訂正が届けば版が変わり、印は効きません。
            $mk = self::r122MarkRoleSettled($sid, $role, [
                'resolve_ok'   => (bool) ($rv['ok'] ?? false),
                'resolve_code' => (string) ($rv['code'] ?? ''),
                'merged'       => count((array) ($rv['merged'] ?? [])),
                'fix_sent'     => (bool) ($out['fix']['sent'] ?? false),
                'inspect_code' => (string) ($insp['code'] ?? ''),
            ]);
            $out['settled'] = $mk;
            \Log::error('[R122-WIRE] 採否を確定しました', [
                'race_id' => $raceId, 'role' => $role,
                'marked'  => $mk['marked'], 'already' => $mk['already'],
                'version' => $mk['version'],
            ]);

            // ══════════════════════════════════════════════════════════════
            // @ANCHOR-20261021-R122-JOBHANDOFF  公開は集計Jobへ渡します
            // ══════════════════════════════════════════════════════════════
            //   ご指摘（010の2-2 RunRoleJob）：
            //     「r122AfterReceive末尾の直接公開は、roleの処理完了を
            //       保存してAggregateRaceJobへ渡す形に変更します。」
            //
            //   Jobの段が上がっているときは、ここで公開まで進めません。
            //   ③で採否確定の印を残したので、集計Jobがそれを見ます。
            //   Jobの段が下りているときは、これまでどおりここで進めます
            //   （いまの本番はこちらです。動きは変わりません）。
            if (BaganrikiWorker::jobs()
                && class_exists(\App\Jobs\R122AggregateRaceJob::class)) {
                $out['publish'] = ['ok' => false, 'code' => 'HANDED_TO_AGGREGATE',
                                   'publication_id' => null, 'candidates' => 0,
                                   'reason' => '採否確定の印を残し、集計Jobへ渡しました'];
                \Log::error('[R122-WIRE] 公開は集計Jobへ渡しました', [
                    'race_id' => $raceId, 'role' => $role,
                    'settled' => $mk['marked'] ?? null,
                ]);
                return $out;
            }

            // ④ 公開（両roleの採否が確定してから）
            $pb = $this->r122PublishWhenReady($sid);
            $out['publish'] = ['ok' => $pb['ok'] ?? false, 'code' => $pb['code'] ?? null,
                               'publication_id' => $pb['publication_id'] ?? null,
                               'candidates' => count((array) ($pb['candidates'] ?? [])),
                               'reason' => $pb['reason'] ?? null];
            \Log::error('[R122-WIRE] 公開の結果', [
                'race_id' => $raceId, 'role' => $role,
                'ok' => $pb['ok'] ?? false, 'code' => $pb['code'] ?? null,
                'publication_id' => $pb['publication_id'] ?? null,
                '公開候補' => count((array) ($pb['candidates'] ?? [])),
                'reason' => $pb['reason'] ?? null,
            ]);
            return $out;
        } catch (\Throwable $e) {
            // @ANCHOR-20261005-AUX-NEVER-BREAKS  記録のための処理で予想を殺しません
            \Log::error('[R122-WIRE] 接続で例外（予想は返します）', [
                'race_id' => $raceId, 'role' => $role,
                'message' => $e->getMessage(),
                'at'      => $e->getFile() . ':' . $e->getLine(),
            ]);
            return $out;
        }
    }

    /**
     * ═══════════════════════════════════════════════════════════════════════
     * @ANCHOR-20261020-R122-RESUME  上限到達後にもう一度固定する（007の6-1）
     * ═══════════════════════════════════════════════════════════════════════
     * ご指摘：
     *   「上限前の呼出しで保存を断った後も旧AIが動き、旧予想がキャッシュされます。
     *     次回の通常アクセスは関数冒頭のキャッシュ返却で終わり、
     *     r122ShadowRecord へ届かないことがあります。」
     *
     * そのとおりでした。TOO_EARLY で断ったあと、誰も呼び直していませんでした。
     *
     * ■ いまの形
     *   ・キャッシュを返すときも、<b>固定入力が無ければここで作り直します。</b>
     *     応答を返したあと（terminating）に動かすので、画面は遅くなりません。
     *   ・情報上限に達していなければ、今回も作りません（TOO_EARLY のまま）。
     *     次のアクセスでまた試します。
     *   ・固定済みなら何もしません。
     *   ・TOO_EARLY で止まったときは<b>空回答をキャッシュしません。</b>
     *     空回答を残すと、上のキャッシュ返却で終わってしまい、
     *     上限到達後に作り直せなくなるためです。
     *
     * @return array ['ran','code','reason','snapshot_hash']
     */
    public function r122ResumeFreeze($date, $kaisuu, $basho, $day, $race): array
    {
        $out = ['ran' => false, 'code' => null, 'reason' => null,
                'snapshot_hash' => null];
        try {
            if (!BaganrikiPrompt::enabled()) {
                $out['code'] = 'FLAG_OFF';
                $out['reason'] = '本文の段が 0 なので何もしません';
                return $out;
            }
            if (!\Schema::hasTable('baganriki_snapshots')) {
                $out['code'] = 'TABLE_MISSING';
                return $out;
            }
            $raceId = self::r122RaceId($date, $kaisuu, $basho, $day, $race);
            $snap = \DB::table('baganriki_snapshots')
                      ->where('race_id', $raceId)->where('generation', 0)->first();
            if ($snap !== null) {
                $out['code'] = 'ALREADY';
                $out['reason'] = 'すでに固定済みです（作り直しません）';
                $out['snapshot_hash'] = (string) $snap->snapshot_hash;
                return $out;
            }
            $out['ran'] = true;
            $fz = $this->r122Freeze($date, $kaisuu, $basho, $day, $race,
                                    [], 'PRODUCTION', false);
            $out['code']   = (string) ($fz['code'] ?? ($fz['ok'] ? 'OK' : 'NG'));
            $out['reason'] = (string) ($fz['reason'] ?? '');
            $out['snapshot_hash'] = $fz['snapshot_hash'] ?? null;
            \Log::error('[R122-RESUME] 固定入力をやり直しました', [
                'race_id' => $raceId,
                'ok'      => $fz['ok'] ?? false,
                'code'    => $out['code'],
                'reason'  => $out['reason'],
            ]);
            return $out;
        } catch (\Throwable $e) {
            // ここで落ちても商品は止めません
            \Log::error('[R122-RESUME] やり直しで例外', ['message' => $e->getMessage()]);
            $out['code'] = 'EXCEPTION'; $out['reason'] = $e->getMessage();
            return $out;
        }
    }

    /**
     * @ANCHOR-20261020-R122-RESUME  キャッシュを返すときの後始末
     *   応答を返したあとに、固定のやり直しと公開の起動を1回だけ行います。
     *   画面の待ち時間は増えません。
     */
    /**
     * @ANCHOR-20261021-R122-SENDFIRST  キャッシュを返したあとの初回送信
     *   008のご指摘5。凍結と公開判定だけでは、初回が永久に送られません。
     */
    public function r122AfterCached($date, $kaisuu, $basho, $day, $race): void
    {
        if (!BaganrikiPrompt::enabled() && !BaganrikiWorker::enabled()) { return; }
        if (self::$dryRunNoPersist) { return; }
        $self = $this;
        $d = $date; $k = $kaisuu; $b = $basho; $y = $day; $r = $race;
        app()->terminating(function () use ($self, $d, $k, $b, $y, $r) {
            try {
                $self->r122ResumeFreeze($d, $k, $b, $y, $r);
                // 固定済みなら、期限の中で公開できる状態かどうかも見ます
                $rid = \App\Http\Controllers\Api\AiController::r122RaceId($d, $k, $b, $y, $r);
                $sn = \DB::table('baganriki_snapshots')
                        ->where('race_id', $rid)->where('generation', 0)->first();
                // ══════════════════════════════════════════════════════
                // @ANCHOR-20261021-R122-JOBENTRY  Jobの段なら積むだけです
                // ══════════════════════════════════════════════════════
                //   ご指摘（010の2-3）：
                //     「通常アクセスと r122AfterCached：対象判定後、凍結が
                //       なければFreezeRaceJob、既にあれば不足しているroleの
                //       Jobと集計Jobを投入する短い処理にします。
                //       terminating内で長いAIのHTTP応答を待つ形を
                //       残しません。」
                //   Jobの段が上がっているときは、ここで送りません。
                //   積むだけで、この terminating はすぐ終わります。
                if (BaganrikiWorker::jobs()) {
                    $dp = $self->r122DispatchForRace($d, $k, $b, $y, $r);
                    \Log::error('[R122-JOB] キャッシュ後に積みました', [
                        'race_id' => $rid, 'code' => $dp['code'],
                        'reason' => $dp['reason'], 'dispatched' => $dp['dispatched'],
                    ]);
                    return;
                }
                // ══════════════════════════════════════════════════════
                // @ANCHOR-20261021-R122-TARGET12  キャッシュ後の入口（010の2-5）
                // ══════════════════════════════════════════════════════
                $tgC = \App\Http\Controllers\Api\AiController
                           ::r122TargetCheck($rid);
                if (!$tgC['ok']) {
                    \Log::error('[R122-TARGET] 対象レースではないので送りません', [
                        'race_id' => $rid, 'code' => $tgC['code'],
                        'reason' => $tgC['reason'],
                    ]);
                    return;
                }
                if ($sn !== null && BaganrikiWorker::enabled()) {
                    // @ANCHOR-20261021-R122-SENDFIRST  008のご指摘5
                    //   凍結できただけで止めません。初回の枠が無ければ
                    //   ここから<b>両roleの初回を送ります</b>。
                    //   応答を返したあと（terminating）なので画面は待ちません。
                    foreach (['1st', '2nd'] as $rl) {
                        $ex = \DB::table('baganriki_ai_attempts')
                                ->where('snapshot_id', (int) $sn->id)
                                ->where('role', $rl)
                                ->where('attempt_no', BaganrikiWorker::FIRST)
                                ->exists();
                        if ($ex) { continue; }
                        $fs = $self->r122SendFirst((int) $sn->id, $rl);
                        \Log::error('[R122-SENDFIRST] キャッシュ後の初回送信', [
                            'race_id' => $rid, 'role' => $rl,
                            'sent' => $fs['sent'], 'ok' => $fs['ok'],
                            'code' => $fs['code'], 'reason' => $fs['reason'],
                        ]);
                    }
                    $self->r122PublishWhenReady((int) $sn->id);
                }
            } catch (\Throwable $e) {
                \Log::error('[R122-RESUME] キャッシュ後の後始末で例外',
                    ['message' => $e->getMessage()]);
            }
        });
    }

    /**
     * @ANCHOR-20261020-R122-WIRE  再起動後のやり直し（契約10章）
     *
     *   「初回保存後の停止は再起動で訂正判定を再開できる」への対応です。
     *   HTTPの途中で落ちた場合、訂正も公開も始まっていないことがあります。
     *   まだ期限内の凍結入力を拾って、②③④だけやり直します。
     *   送信の予約はしません（初回はもう終わっているため）。
     *
     *   呼び方（1分おきのcronに入れてよい形にしてあります）
     *     php artisan keiba:ai-analysis-compensate --r122-sweep
     *
     * @return array ['scanned','resumed','published','rows']
     */
    public function r122SweepPending(array $opt = []): array
    {
        $out = ['scanned' => 0, 'resumed' => 0, 'published' => 0, 'rows' => [],
                // @ANCHOR-20261021-R122-SENDFIRST  初回をやり直した件数
                'first_sent' => 0, 'first_codes' => [],
                // @ANCHOR-20261021-R122-JOBSWEEP  Jobを積んだ件数（010の2-3）
                'dispatched' => 0];
        if (!BaganrikiWorker::enabled() || !BaganrikiWorker::ready()) { return $out; }
        $now = (int) ($opt['now_us'] ?? BaganrikiWorker::nowUs());

        // 期限内のものだけ。終わった開催を毎分なめないよう、当日前後に絞ります。
        $snaps = \DB::table('baganriki_snapshots')
                   ->where('generation', 0)
                   ->whereNotNull('sales_close_at')
                   ->whereBetween('sales_close_at', [
                        BaganrikiWorker::toDb($now - 3600 * 1000000),
                        BaganrikiWorker::toDb($now + 6 * 3600 * 1000000),
                   ])
                   ->orderBy('sales_close_at')->get();

        foreach ($snaps as $snap) {
            $out['scanned']++;
            $sid = (int) $snap->id;
            try {
                $live = \DB::table('baganriki_live_states')
                          ->where('snapshot_id', $sid)->first();
                $dl   = BaganrikiWorker::deadlines($snap, $live);
                // ══════════════════════════════════════════════════════
                // いま飛んでいる送信を殺さないための見張り
                // ══════════════════════════════════════════════════════
                //   resume() は status=SENT を「結果不明」にします。
                //   HTTPの中でまだAIを待っている枠も SENT なので、
                //   <b>応答期限を過ぎてからでないと呼べません</b>。
                //   （過ぎていれば、いま届いても遅着で捨てる時刻です）
                if ($dl['ok'] && $dl['reply'] !== null && $now > $dl['reply']) {
                    $rs = BaganrikiWorker::resume($sid, $now);
                    if ((array) ($rs['unknown'] ?? []) !== []) { $out['resumed']++; }
                }

                // ══════════════════════════════════════════════════════
                // @ANCHOR-20261021-R122-TARGET12  巡回の入口（010の2-5）
                // ══════════════════════════════════════════════════════
                //   対象レースでないものは、拾っても何もしません。
                //   送信の手前で断ってもよいのですが、空振りのログが
                //   毎分ぶん増えるので、ここで外します。
                $tgW = self::r122TargetCheck((string) $snap->race_id);
                if (!$tgW['ok']) {
                    $out['rows'][] = (string) $snap->race_id . ':'
                                   . (string) $tgW['code'];
                    continue;
                }

                foreach (['1st', '2nd'] as $role) {
                    // ══════════════════════════════════════════════════
                    // @ANCHOR-20261021-R122-SENDFIRST  008のご指摘5
                    // ══════════════════════════════════════════════════
                    //   【足りませんでした】巡回は訂正と公開だけで、
                    //   <b>初回の送信をする者が誰もいませんでした。</b>
                    //   画面からの呼び出しがキャッシュで終わる限り、
                    //   そのレースは永久に送られません。
                    //   固定入力ができていて初回の枠が無いなら、
                    //   ここから初回を送ります（期限内のときだけ）。
                    //   枠は一意なので、画面側と同時でも二重には送りません。
                    $any = \DB::table('baganriki_ai_attempts')
                             ->where('snapshot_id', $sid)->where('role', $role)
                             ->where('attempt_no', BaganrikiWorker::FIRST)->first();
                    if ($any === null) {
                        // ══════════════════════════════════════════════
                        // @ANCHOR-20261021-R122-JOBSWEEP  010の2-3
                        // ══════════════════════════════════════════════
                        //   ご指摘：
                        //     「r122SweepPending：未処理対象の発見、投入漏れ
                        //       の回復、期限判定、集計の起動に限定し、
                        //       r122SendFirst／r122SendFixを同期実行
                        //       しません。」
                        //   Jobの段が上がっているときは、ここでは送らず、
                        //   <b>積むだけ</b>にします。巡回は1分ごとなので、
                        //   ここでAIを待つと巡回そのものが詰まります。
                        if (BaganrikiWorker::jobs()
                            && class_exists(\App\Jobs\R122RunRoleJob::class)) {
                            \App\Jobs\R122RunRoleJob::dispatch($sid, $role);
                            $out['first_codes'][] = $role . ':JOB_DISPATCHED';
                            $out['dispatched'] = (int) ($out['dispatched'] ?? 0) + 1;
                            continue;
                        }
                        $fs = $this->r122SendFirst($sid, $role);
                        if ($fs['sent']) { $out['first_sent']++; }
                        $out['first_codes'][] = $role . ':' . (string) $fs['code'];
                        continue;
                    }
                    $f = \DB::table('baganriki_ai_attempts')
                           ->where('snapshot_id', $sid)->where('role', $role)
                           ->where('attempt_no', BaganrikiWorker::FIRST)
                           ->where('status', BaganrikiWorker::RECEIVED)->first();
                    if ($f === null) { continue; }
                    // 受領の直後は、HTTPの側がいま訂正を送っている最中かも
                    // しれません。少し間を置いた枠だけを拾います
                    //   （枠の一意キーで二重送信は防げますが、
                    //     空振りのログを増やさないための用心です）。
                    $recv = BaganrikiWorker::dbUs($f->received_at ?? null);
                    if ($recv !== null
                        && ($now - $recv) < self::R122_SWEEP_GRACE_SEC * 1000000) {
                        continue;
                    }
                    // ══════════════════════════════════════════════════
                    // @ANCHOR-20261021-R122-JOBSWEEP  訂正も同期では送りません
                    // ══════════════════════════════════════════════════
                    //   Jobの段が上がっているときは、巡回から訂正を
                    //   送りません。受領まで進んでいて採否が未確定なら、
                    //   そのroleのJobを積み直します（投入漏れの回復）。
                    //   訂正を送るのは RunRoleJob の中だけです。
                    if (BaganrikiWorker::jobs()) {
                        $sv = self::r122RoleSettled($sid, $role);
                        if (!$sv['settled']
                            && class_exists(\App\Jobs\R122RunRoleJob::class)) {
                            \App\Jobs\R122RunRoleJob::dispatch($sid, $role);
                            $out['first_codes'][] = $role . ':JOB_REDISPATCHED';
                            $out['dispatched'] = (int) ($out['dispatched'] ?? 0) + 1;
                        }
                        continue;
                    }
                    $insp = $this->r122InspectResponse($sid, $role,
                                                       BaganrikiWorker::FIRST);
                    if ($insp['ok'] && $insp['needs_fix']
                        && $insp['complete'] === true) {
                        $this->r122SendFix($sid, $role, $insp);
                    }
                }
                // ══════════════════════════════════════════════════
                // @ANCHOR-20261021-R122-NOWFRESH  10月21日009のご指摘3
                // ══════════════════════════════════════════════════
                //   【そのとおりでした】$now は巡回を<b>始めたときの1回だけ</b>
                //   取っていました。この間に訂正の送信でAIを待つので、
                //   長いときは分単位でずれます。期限の判定と公開の起動に
                //   古い時刻を使うと、過ぎている期限を過ぎていないと見ます。
                //   【いま】ここで取り直します。試験用の時計は opt から
                //   渡されたときだけ使い、本番では渡しません。
                $nowPub = isset($opt['now_us'])
                        ? (int) $opt['now_us'] : BaganrikiWorker::nowUs();
                $pb = $this->r122PublishWhenReady($sid, ['now_us' => $nowPub]);
                if ($pb['ok'] ?? false) { $out['published']++; }
                $out['rows'][] = [
                    'race_id' => (string) $snap->race_id,
                    'publish' => (string) ($pb['code'] ?? ''),
                ];
            } catch (\Throwable $e) {
                \Log::error('[R122-WIRE] やり直しで例外', [
                    'race_id' => (string) $snap->race_id,
                    'message' => $e->getMessage(),
                ]);
            }
        }
        return $out;
    }
