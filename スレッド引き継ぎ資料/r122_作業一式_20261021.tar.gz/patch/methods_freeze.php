
    /**
     * ═══════════════════════════════════════════════════════════════════════
     * @ANCHOR-20261020-R122-FREEZE  凍結入力の保存（snapshot）
     * ═══════════════════════════════════════════════════════════════════════
     * 根拠：server_contract_r12.2.txt 2章・3章・5章・11章／詳細設計書 4.4・7.2
     *
     * ■ 何を保存するか
     *   両roleへ渡す共通JSONの原文と SHA-256、1st・2nd それぞれの INPUT_JSON、
     *   凍結出走集合と凍結順位、信号・S・mode一式、配分、取得監査、coverage、
     *   発走時刻・cutoff・input_freeze・投票締切、そして実際に保存した時刻。
     *
     * ■ 決めごと
     *   ・<b>一度固定したら変えません。</b>同じ race_id・generation が既にあれば
     *     何もせず「既存」を返します。上書きしません。
     *   ・generation は期限の延長では増やしません（契約5章）。
     *   ・入力が作れないときは snapshot を作りません。
     *     代わりに baganriki_race_runs へ理由コードつきで1行残します
     *     （「何も起きなかった」と「入力が不正だった」を区別するため）。
     *   ・frozen_at は実際に保存した時刻です。input_freeze_at とは別物で、
     *     予定時刻で埋めません。
     *   ・4つの頭数（entry / acquired / frozen / active）は混ぜずに別々に出します。
     *
     * @param array  $override  投票締切などの差し込み（検証用）
     * @param string $runKind   'PRODUCTION' か 'REPLAY'
     * @param bool   $dryRun    true なら1行も書かずに結果だけ返す
     * @return array ['ok','race_id','code','reason','skipped','snapshot_hash','counts']
     */
    public function r122Freeze($date, $kaisuu, $basho, $day, $race,
                               array $override = [], string $runKind = 'PRODUCTION',
                               bool $dryRun = false): array
    {
        $raceId = self::r122RaceId($date, $kaisuu, $basho, $day, $race);
        $now    = BaganrikiPrompt::rfc3339((int) BaganrikiTime::us(date('c')));
        $nowDb  = (new \DateTimeImmutable('now'))->format('Y-m-d H:i:s.u');
        $runId  = 'run-' . $raceId . '-' . date('YmdHis') . '-'
                . substr(bin2hex(random_bytes(3)), 0, 6);
        $out = ['ok' => false, 'race_id' => $raceId, 'code' => null, 'reason' => null,
                'skipped' => false, 'snapshot_hash' => null, 'counts' => []];

        if (!\Schema::hasTable('baganriki_snapshots')
            || !\Schema::hasTable('baganriki_race_runs')) {
            $out['code']   = 'TABLE_MISSING';
            $out['reason'] = 'r12.2 のテーブルがありません（--r122-install で作ります）';
            return $out;
        }

        // ══════════════════════════════════════════════════════════════
        // @ANCHOR-20261020-R122-SEP  REPLAY と PRODUCTION を混ぜません
        // ══════════════════════════════════════════════════════════════
        // 【10月20日005のご指摘9。そのとおりでした】
        //   snapshot の検索も一意キーも race_id＋generation だけだったので、
        //   仮の監査・締切で保存した REPLAY を、本番の PRODUCTION が
        //   「既存」と見て成功扱いする経路がありました。
        //   <b>REPLAY は generation=900 の別世代に保存</b>し、
        //   PRODUCTION は generation=0 だけを見ます。
        //   仮置き（assume_audit／sales_close_at の差し込み）で作った入力は
        //   PRODUCTION として保存できないようにもしました。
        $isReplay = ($runKind === 'REPLAY');
        $assumed  = (bool) ($override['assume_audit'] ?? false)
                 || array_key_exists('sales_close_at', $override);
        if ($assumed && !$isReplay) {
            $out['code']   = 'REPLAY_ONLY';
            $out['reason'] = '仮の監査・締切で作った入力は PRODUCTION として保存しません';
            return $out;
        }
        $generation = $isReplay ? 900 : 0;

        // ══════════════════════════════════════════════════════════════
        // @ANCHOR-20261020-R122-EARLY  10月20日006のご指摘3-3（本物の不具合）
        // ══════════════════════════════════════════════════════════════
        //   実行時刻は取っていましたが、<b>情報上限に達したかを見ずに
        //   保存していました。</b>6分前のデータがすぐ届いて T−358秒 で
        //   呼ばれると、上限 T−330秒 の前に固定できてしまいます。
        //   そのあと T−340秒 に利用可能になった正式取消は、本来なら
        //   凍結集合へ反映する対象なのに「既存」で取り逃します。
        //   上限に達する前の凍結は、ここで断ります（待つのは呼び出し側です）。
        //   REPLAY（再生）は過去のレースを扱うので、この検査をしません。
        if (!$isReplay) {
            $st = (string) ($override['start_time'] ?? '');
            $anchorAt = null;
            if ($st !== '') {
                if (strlen($st) === 5) { $st .= ':00'; }
                $anchorAt = substr((string) $date, 0, 10) . 'T' . $st . '+09:00';
            } else {
                $rowR = \DB::table('t_horse_odds_finder_races')
                          ->where('date', $date)->where('kaisuu', $kaisuu)
                          ->where('basho', $basho)->where('day', $day)
                          ->where('race', (int) $race)->first();
                if ($rowR !== null && ($rowR->start_time ?? '') !== '') {
                    $s2 = (string) $rowR->start_time;
                    if (strlen($s2) === 5) { $s2 .= ':00'; }
                    $anchorAt = substr((string) $rowR->date, 0, 10) . 'T' . $s2 . '+09:00';
                }
            }
            $anchorUs0 = ($anchorAt === null) ? null : BaganrikiTime::us($anchorAt);
            if ($anchorUs0 !== null) {
                $freezeUs0 = BaganrikiTime::inputFreeze($anchorUs0);
                $nowUs0    = BaganrikiWorker::nowUs();
                if ($nowUs0 < $freezeUs0) {
                    $out['code']   = 'TOO_EARLY';
                    $out['reason'] = '情報上限に達していません（いま '
                                   . BaganrikiTime::toJst($nowUs0) . '／情報上限 '
                                   . BaganrikiTime::toJst($freezeUs0)
                                   . '）。上限到達後に固定します';
                    return $out;
                }
            }
        }

        // ── すでに固定済みなら触りません（同じ世代だけを見ます）──────
        $exists = \DB::table('baganriki_snapshots')
                     ->where('race_id', $raceId)->where('generation', $generation)->first();
        if ($exists !== null) {
            $out['ok'] = true; $out['skipped'] = true;
            $out['snapshot_hash'] = $exists->snapshot_hash;
            $out['reason'] = 'すでに固定済みです（上書きしません）';
            return $out;
        }

        // ── 材料を集めて両roleの入力を作ります ───────────────────────
        $g = self::r122GatherContext($date, $kaisuu, $basho, $day, $race, $override);
        $a1 = null; $a2 = null;
        if ($g['ok']) {
            $a1 = BaganrikiPrompt::assemble($g['ctx'], '1st');
            $a2 = BaganrikiPrompt::assemble($g['ctx'], '2nd');
        }
        $bad = null;
        if (!$g['ok'])                       $bad = [$g['code'], $g['reason']];
        elseif (!$a1['ok'])                  $bad = [$a1['code'], $a1['reason']];
        elseif (!$a2['ok'])                  $bad = [$a2['code'], $a2['reason']];
        elseif ($a1['snapshot_hash'] !== $a2['snapshot_hash'])
            $bad = ['SNAPSHOT_HASH_MISMATCH', '1stと2ndの共通hashが違います'];

        // ── 4つの頭数 ────────────────────────────────────────────────
        $entryCount = ($g['ok'] && isset($g['ctx']['entry_nums']))
                    ? count($g['ctx']['entry_nums']) : null;
        $acquired = \DB::table('t_horse_odds_finder_odds')
            ->where('date', $date)->where('kaisuu', $kaisuu)->where('basho', $basho)
            ->where('day', $day)->where('race', (int) $race)
            ->whereIn('minutes_before_start', BaganrikiTime::INPUT_SLOTS)
            ->distinct()->count('num');
        $frozenCount = ($bad === null) ? (int) $a1['input']['N'] : null;
        $activeCount = null;
        if ($bad === null) {
            $post = (array) ($g['ctx']['cancelled_post'] ?? []);
            $activeCount = max(0, $frozenCount - count($post));
        }
        $out['counts'] = ['entry' => $entryCount, 'acquired' => (int) $acquired,
                          'frozen' => $frozenCount, 'active' => $activeCount];

        if ($dryRun) {
            $out['ok'] = ($bad === null);
            if ($bad !== null) { $out['code'] = $bad[0]; $out['reason'] = $bad[1]; }
            else { $out['snapshot_hash'] = $a1['snapshot_hash']; }
            return $out;
        }

        // ── 入力が作れないとき：race_runs だけ残します ────────────────
        if ($bad !== null) {
            \DB::table('baganriki_race_runs')->insert([
                'run_id' => $runId, 'race_id' => $raceId, 'generation' => $generation,
                'run_kind' => $runKind, 'status' => 'INPUT_INVALID',
                'entry_count' => $entryCount, 'acquired_count' => (int) $acquired,
                'frozen_count' => null, 'active_count' => null,
                'invalid_code' => $bad[0], 'invalid_reason' => $bad[1],
                'release_version' => BaganrikiPrompt::PROMPT_VERSION,
                'created_at' => $nowDb, 'updated_at' => $nowDb,
            ]);
            $out['code'] = $bad[0]; $out['reason'] = $bad[1];
            return $out;
        }

        // ── 固定して保存します ───────────────────────────────────────
        $in   = $a1['input'];
        $hash = BaganrikiPrompt::commonHash($in);
        $frozenRank = [];
        foreach ((array) $in['runners'] as $r) {
            $frozenRank[(string) $r['horse_no']] = (int) $r['win_rank'];
        }
        $toDb = static function ($rfc) {
            $us = BaganrikiTime::us($rfc);
            if ($us === null) return null;
            return (new \DateTimeImmutable('@' . intdiv($us, 1000000)))
                ->setTimezone(new \DateTimeZone('Asia/Tokyo'))
                ->format('Y-m-d H:i:s') . sprintf('.%06d', $us % 1000000);
        };
        $j = static fn($v) => json_encode($v,
            JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PRESERVE_ZERO_FRACTION);

        $closeSrc = (string) ($g['sales_close_source'] ?? 'UNKNOWN');
        \DB::transaction(function () use (
            $raceId, $runId, $runKind, $in, $a1, $a2, $hash, $frozenRank, $nowDb,
            $entryCount, $acquired, $frozenCount, $activeCount, $toDb, $j, $generation,
            $closeSrc
        ) {
            \DB::table('baganriki_race_runs')->insert([
                'run_id' => $runId, 'race_id' => $raceId, 'generation' => $generation,
                'run_kind' => $runKind, 'status' => 'FROZEN',
                'entry_count' => $entryCount, 'acquired_count' => (int) $acquired,
                'frozen_count' => $frozenCount, 'active_count' => $activeCount,
                'invalid_code' => null, 'invalid_reason' => null,
                'release_version' => BaganrikiPrompt::PROMPT_VERSION,
                'created_at' => $nowDb, 'updated_at' => $nowDb,
            ]);
            $snapId = \DB::table('baganriki_snapshots')->insertGetId([
                'race_id' => $raceId, 'generation' => $generation, 'run_id' => $runId,
                'release_version'  => BaganrikiPrompt::PROMPT_VERSION,
                'common_json'      => $hash['json'],
                'input_json_1st'   => $a1['user'],
                'input_json_2nd'   => $a2['user'],
                'snapshot_hash'    => $in['snapshot_hash'],
                'frozen_nums'      => $j(array_map(
                                        static fn($r) => (int) $r['horse_no'],
                                        (array) $in['runners'])),
                'frozen_rank'      => $j($frozenRank),
                'mode'             => $in['mode'],
                'mode_status'      => $in['mode_status'],
                'allocation_mode'  => $in['allocation_mode'],
                'mode_policy_id'   => $in['mode_policy_id'],
                'display_rating'   => $in['display_rating'],
                'signals'          => $j($in['signals']),
                's_min'            => $in['S_min'],
                's_max'            => $in['S_max'],
                's0'               => $in['S'],
                'target_count'     => $in['target_count'],
                'quota_1st'        => $j($a1['input']['role_quota']),
                'quota_2nd'        => $j($a2['input']['role_quota']),
                'quota_adjustments' => $j($in['quota_adjustments']),
                'collection_audit' => $j($in['collection_audit']),
                'coverage'         => $j($in['coverage']),
                'anchor_at'        => $toDb($in['time_contract']['anchor_at']),
                'cutoff_at'        => $toDb($in['cutoff_at']),
                'input_freeze_at'  => $toDb($in['input_freeze_at']),
                'frozen_at'        => $nowDb,
                'sales_close_at'   => $toDb($in['time_contract']['sales_close_at']),
                'input_invalid_code'   => null,
                'input_invalid_reason' => null,
                'created_at'       => $nowDb,
            ]);
            // @ANCHOR-20261020-R122-CLOSE  投票締切の出どころを監査へ残します。
            //   INPUT_JSON の time_contract は閉じた形なので入れられません。
            //   どの規則で締切を決めたかは、ここで必ず追えるようにします。
            if (\Schema::hasTable('baganriki_audit_events')) {
                \DB::table('baganriki_audit_events')->insert([
                    'race_id'     => $raceId,
                    'snapshot_id' => $snapId,
                    'kind'        => 'SALES_CLOSE_SOURCE',
                    'happened_at' => $nowDb,
                    'old_revision' => null, 'new_revision' => null,
                    'diagnostics' => $j([
                        'source'         => $closeSrc,
                        'sales_close_at' => $in['time_contract']['sales_close_at'],
                        'anchor_at'      => $in['time_contract']['anchor_at'],
                        'offset_sec'     => BaganrikiTime::salesCloseOffsetSec(),
                        'rule'           => 'JRA公式 発売時間・発売締切時刻'
                                          . '（当日のインターネット投票は'
                                          . '各レース発走時刻の1分前）',
                        'rule_url'       => 'https://jra.jp/dento/a/instructions'
                                          . '/hatsubai/jra.html',
                    ]),
                    'related_id'  => null,
                ]);
            }
            // @ANCHOR-20261020-R122-QUEUE  ライブ状態の行をここで作ります。
            //   state_revision / response_revision / publication_revision の
            //   置き場所です。キューの予約・終端はここを数えます。
            if (\Schema::hasTable('baganriki_live_states')) {
                \DB::table('baganriki_live_states')->insertOrIgnore([
                    'snapshot_id'           => $snapId,
                    'cancellations'         => $j([]),
                    'active_count'          => $activeCount,
                    'live_target_count'     => $in['target_count'],
                    'live_quota'            => $j($a1['input']['role_quota']),
                    'live_close'            => null,
                    'state_revision'        => 0,
                    'response_revision'     => 0,
                    'publication_revision'  => 0,
                    'latest_publication_id' => null,
                    'updated_at'            => $nowDb,
                ]);
            }
        });

        $out['ok'] = true;
        $out['snapshot_hash'] = $in['snapshot_hash'];
        $out['generation']    = $generation;
        $out['run_kind']      = $runKind;
        return $out;
    }
