
    /**
     * ═══════════════════════════════════════════════════════════════════════
     * @ANCHOR-20261020-R122-MARKETTEST  OPI と推定確定オッズの通し試験
     * ═══════════════════════════════════════════════════════════════════════
     * ■ なぜこの試験が要るか
     *   OPI と推定確定オッズは「集計期間の終わりが対象レースの開催日より前」
     *   のときだけ載せます。DBにある集計は end_date が 2026-10-18 なので、
     *   10/18 のレースでは<b>必ず</b>載りません（当日を含む集計で当日を
     *   評価しないためです）。つまり 10/18 のデータだけでは
     *   <b>載る側（INCLUDED）を一度も通せません。</b>
     *
     *   そこで、実レースの実オッズ・実人気をそのまま使ったまま、
     *   <b>開催日だけを仮に先へ動かして</b>呼び、載る側も通します。
     *   仮に動かすのは開催日と情報上限だけで、オッズ・集計表・式には
     *   一切手を入れません。載った値は SQL から取り直して突き合わせます。
     *
     * ■ 読むだけです。DBへは1行も書きません。
     */
    private function runR122MarketTest(string $root): void
    {
        self::r122Autoload();
        $C  = \App\Http\Controllers\Api\AiController::class;
        $T  = \App\Http\Controllers\Api\BaganrikiTime::class;
        $S  = \App\Http\Controllers\Api\BaganrikiSnapshot::class;
        $A  = \App\Http\Controllers\Api\BaganrikiAcquisition::class;
        $P  = \App\Http\Controllers\Api\BaganrikiPrompt::class;

        $date = (string) ($this->option('date') ?: '2026-10-18');
        $sDir = rtrim($root, '/') . '/schemas';
        $regSchemaPath = $sDir . '/source_registry_schema.json';

        $this->info('════════════════════════════════════════════════════════');
        $this->info(' r12.2 OPI と推定確定オッズの通し試験');
        $this->info('════════════════════════════════════════════════════════');
        $this->line('  実行時刻 : ' . date('c'));
        $this->line('  実レース : ' . $date . ' の先頭1レース');
        $this->warn('  ※ 読むだけです。DBへは1行も書きません');
        $this->line('');

        $pass = 0; $fail = 0;
        $ok = function (string $name, bool $cond, string $note = '') use (&$pass, &$fail) {
            if ($cond) { $pass++; $this->line(sprintf('  ○ %-12s %s', $name, $note)); }
            else       { $fail++; $this->error(sprintf('  × %-12s %s', $name, $note)); }
        };

        // ── ① 集計表はいまどうなっているか ────────────────────────────
        $this->info('── ① 集計表の状態（この集計はいつの開催日から使えるか）──');
        // @ANCHOR-20261020-R122-COVWIN  集計を使う5区分をまとめて並べます。
        //   「集計期間の列を持っているか」「算出時刻の列を持っているか」で
        //   判定できることが変わるので、そこも一緒に出します。
        $tables = [
            'popavg'  => ['t_horse_odds_finder_popularity_rank_average', 'OPI'],
            'fukuavg' => ['t_horse_odds_finder_fuku_popularity_rank_average', 'OPI'],
            'corr'    => ['t_horse_odds_finder_compute_odds_correction', 'estimated_odds'],
            'gaprec'  => ['t_horse_odds_finder_odds_gap_recovery', 'recovery_statistics'],
            'similar' => ['t_horse_odds_finder_similar_race_stats', 'similar_statistics'],
        ];
        $maxEnd = '';
        foreach ($tables as $tag => $pair) {
            [$tbl, $cov] = $pair;
            if (!\Schema::hasTable($tbl)) {
                $this->error('    × ' . $tbl . ' がありません'); $fail++; continue;
            }
            $rows = \DB::table($tbl)->get();
            // @ANCHOR-20261020-R122-REALTIME  列が無いのと値が無いのを区別します
            $hasCol = (\Schema::hasColumn($tbl, 'computed_at')
                       || \Schema::hasColumn($tbl, 'updated_at'));
            $ed = ''; $sd = ''; $cAt = null; $n = 0;
            foreach ($rows as $r) {
                $n++;
                $e = substr(str_replace('/', '-', (string) ($r->end_date ?? '')), 0, 10);
                $s = substr(str_replace('/', '-', (string) ($r->start_date ?? '')), 0, 10);
                if ($e !== '' && strcmp($e, $ed) > 0) { $ed = $e; }
                if ($s !== '' && ($sd === '' || strcmp($s, $sd) < 0)) { $sd = $s; }
                // 過去類似成績の表は updated_at が算出時刻にあたります
                $c = $r->computed_at ?? ($r->updated_at ?? null);
                if ($c !== null && ($cAt === null || strcmp((string) $c, (string) $cAt) > 0)) {
                    $cAt = (string) $c;
                }
            }
            // OPI と推定確定オッズの判定にだけ使う「集計期間の終わり」
            if (in_array($tag, ['popavg', 'fukuavg', 'corr'], true)
                && $ed !== '' && strcmp($ed, $maxEnd) > 0) { $maxEnd = $ed; }
            // 使える最も早い開催日 = end_date の翌日
            $nextDay = ($ed === '')
                     ? '集計期間の列が無いので期間では判定できません'
                     : date('Y-m-d', strtotime($ed . ' +1 day'));
            $cShow = ($cAt !== null) ? $cAt
                   : ($hasCol ? '列はあるが値なし（次に集計が走れば入ります）'
                              : '列なし');
            $this->line(sprintf('    %-8s %2d 件  期間 %s 〜 %s  算出 %s',
                $tag, $n, ($sd === '' ? '列なし' : $sd), ($ed === '' ? '列なし' : $ed),
                $cShow));
            $this->line(sprintf('             └ 使える最も早い開催日 : %s（%s）',
                $nextDay, $cov));
        }
        $this->line('');

        // ── ② 実レースの実オッズから凍結人気を作る ─────────────────────
        $this->info('── ② 実レースの実オッズから凍結人気を作る ──');
        $r = \DB::table('t_horse_odds_finder_races')->where('date', $date)
                ->orderBy('basho')->orderBy('race')->first();
        if ($r === null) {
            $this->error('  × ' . $date . ' のレースがありません');
            return;
        }
        $raceId = $C::r122RaceId($r->date, $r->kaisuu, $r->basho, $r->day, $r->race);
        $st = (string) $r->start_time;
        if (strlen($st) === 5) { $st .= ':00'; }
        $anchorUs = $T::us($r->date . 'T' . $st . '+09:00');
        if ($anchorUs === null) { $this->error('  × 発走時刻を組み立てられません'); return; }

        $slots = $T::INPUT_SLOTS;
        $cells = [];
        foreach (\DB::table('t_horse_odds_finder_odds')
                    ->where('date', $r->date)->where('kaisuu', $r->kaisuu)
                    ->where('basho', $r->basho)->where('day', $r->day)
                    ->where('race', (int) $r->race)
                    ->whereIn('minutes_before_start', $slots)
                    ->get(['num', 'minutes_before_start', 'odds', 'fuku_min', 'fuku_max'])
                 as $o) {
            $n = (int) $o->num;
            $t = (int) $o->minutes_before_start;
            $raw = trim((string) $o->odds);
            if ($raw === '取消' || $raw === '除外') { continue; }
            if ($A::usableDecimal($o->odds))     { $cells[$n][$t]['win_odds']  = trim((string) $o->odds); }
            if ($A::usableDecimal($o->fuku_min)) { $cells[$n][$t]['place_min'] = trim((string) $o->fuku_min); }
            if ($A::usableDecimal($o->fuku_max)) { $cells[$n][$t]['place_max'] = trim((string) $o->fuku_max); }
        }
        $win6 = [];
        foreach ($cells as $n => $byT) {
            if (isset($byT[6]['win_odds'])) { $win6[(int) $n] = $byT[6]['win_odds']; }
        }
        ksort($win6);
        $fr = $S::frozenRank($win6);
        $ok('M-01', ($fr['ok'] ?? false) === true,
            '凍結人気が出る（' . count($fr['rank'] ?? []) . ' 頭）');
        if (($fr['ok'] ?? false) !== true) {
            $this->error('      ' . (string) ($fr['reason'] ?? ''));
            return;
        }
        $rank = $fr['rank'];
        $top = null;
        foreach ($rank as $n => $rk) { if ((int) $rk === 1) { $top = (int) $n; break; } }
        $this->line(sprintf('    %s  N=%d  1番人気=馬番%s（6分前単勝 %s／6分前複勝最小 %s）',
            $raceId, count($rank), (string) $top,
            (string) ($cells[$top][6]['win_odds'] ?? '無し'),
            (string) ($cells[$top][6]['place_min'] ?? '無し')));
        $realFreeze = $P::rfc3339($T::inputFreeze($anchorUs));
        $this->line('    情報上限（実レース）: ' . $realFreeze);
        $this->line('');

        // ── ③ 開催日そのまま（当日を含む集計なので載らないこと）─────────
        $this->info('── ③ 開催日そのまま → 載らないこと（当日を含む集計だから）──');
        $m0 = $C::r122MarketPriorRegistry($raceId, (string) $r->date,
                   $rank, $cells, $realFreeze);
        $c0 = $m0['coverage'];
        $ok('M-02', ($c0['OPI']['status'] ?? '') === 'UNAVAILABLE',
            'OPI は UNAVAILABLE');
        $ok('M-03', ($c0['estimated_odds']['status'] ?? '') === 'UNAVAILABLE',
            'estimated_odds は UNAVAILABLE');
        $ok('M-04', $m0['registry'] === [], 'registry は 0 件');
        $ok('M-05',
            strpos((string) ($c0['OPI']['reason'] ?? ''), (string) substr((string) $r->date, 0, 10)) !== false,
            '理由に開催日が入る');
        foreach (['OPI', 'estimated_odds'] as $k) {
            $this->line(sprintf('      %-15s %s', $k,
                mb_strimwidth((string) ($c0[$k]['reason'] ?? ''), 0, 100, '…')));
        }
        $this->line('');

        // ── ④ 開催日を仮に先へ動かして載る側を通す ─────────────────────
        //   動かすのは開催日と情報上限だけです。
        //   オッズ・集計表・式には手を入れていません。
        $asOf = (string) ($this->option('as-of') ?: '');
        if ($asOf === '') {
            $asOf = ($maxEnd === '')
                  ? date('Y-m-d', strtotime($date . ' +7 day'))
                  : date('Y-m-d', strtotime($maxEnd . ' +7 day'));
        }
        $this->info('── ④ 開催日を仮に ' . $asOf . ' として呼ぶ → 載ること ──');
        $this->warn('    ※ 仮の開催日です。動かすのは開催日と情報上限だけで、');
        $this->warn('       オッズ・集計表・式はそのままです（本番送信には使いません）');
        $asFreeze = $asOf . substr($realFreeze, 10);   // 同じ時刻のまま日付だけ動かす
        $m1 = $C::r122MarketPriorRegistry($raceId, $asOf, $rank, $cells, $asFreeze);
        $c1 = $m1['coverage'];
        $reg = $m1['registry'];
        // ══════════════════════════════════════════════════════════════
        // @ANCHOR-20261020-R122-REALTIME  算出時刻がある表かどうかで期待値が変わります
        // ══════════════════════════════════════════════════════════════
        //   過去平均の2表に computed_at が無い（または NULL）あいだは、
        //   「情報上限より前に利用できた証拠が無い」ので OPI は載せません。
        //   列が入って集計が次に走れば、その日から載ります。
        //   @ANCHOR-20261020-R122-COMPUTEDAT  「夜の集計が1回まわれば」と
        //     書いていましたが、新しいレース結果が無い日は集計が
        //     DBに1行も書かずに終わる作りでした。そちらを直しました。
        $hasPop = \Schema::hasColumn('t_horse_odds_finder_popularity_rank_average',
                                      'computed_at')
               && \Schema::hasColumn('t_horse_odds_finder_fuku_popularity_rank_average',
                                      'computed_at')
               && \DB::table('t_horse_odds_finder_popularity_rank_average')
                     ->whereNotNull('computed_at')->exists()
               && \DB::table('t_horse_odds_finder_fuku_popularity_rank_average')
                     ->whereNotNull('computed_at')->exists();
        $this->line('    過去平均の表に算出時刻があるか : '
                  . ($hasPop ? 'ある（OPIを載せます）'
                             : 'まだ無い（OPIは載せません）'));
        if ($hasPop) {
            $ok('M-06', ($c1['OPI']['status'] ?? '') === 'INCLUDED',
                'OPI は INCLUDED（出典 '
                . count((array) ($c1['OPI']['source_refs'] ?? [])) . ' 件）');
        } else {
            $ok('M-06', ($c1['OPI']['status'] ?? '') === 'UNAVAILABLE'
                && strpos((string) ($c1['OPI']['reason'] ?? ''), 'computed_at') !== false,
                'OPI は算出時刻が無いので UNAVAILABLE（理由も読める）');
        }
        $ok('M-07', ($c1['estimated_odds']['status'] ?? '') === 'INCLUDED',
            'estimated_odds は INCLUDED（出典 '
            . count((array) ($c1['estimated_odds']['source_refs'] ?? [])) . ' 件）');
        $ok('M-08', count($reg) > 0, 'registry は ' . count($reg) . ' 件');
        // @ANCHOR-20261021-R122-OPILINE  OPIが載ったのに「載らないぶん」と
        //   書き続けていました（算出時刻が入る前の文面のままでした）。
        //   読む人に逆の意味で伝わるので、載らなかったときだけ出します。
        if (($c1['OPI']['status'] ?? '') !== 'INCLUDED') {
            $this->line('    （OPIが載らないぶん、件数は少なくなります）');
            $this->error('      ' . (string) ($c1['OPI']['reason'] ?? ''));
        }
        if (($c1['estimated_odds']['status'] ?? '') !== 'INCLUDED') {
            $this->error('      ' . (string) ($c1['estimated_odds']['reason'] ?? ''));
        }
        // 内訳
        $byScope = []; $byKind = [];
        foreach ($reg as $e) {
            $byScope[(string) ($e['scope'] ?? '?')] = ($byScope[(string) ($e['scope'] ?? '?')] ?? 0) + 1;
            $byKind[(string) ($e['source_kind'] ?? '?')] = ($byKind[(string) ($e['source_kind'] ?? '?')] ?? 0) + 1;
        }
        ksort($byScope); ksort($byKind);
        $pp = [];
        foreach ($byScope as $k => $v) { $pp[] = $k . ' ' . $v; }
        $this->line('    scope       : ' . implode('／', $pp));
        $pp = [];
        foreach ($byKind as $k => $v) { $pp[] = $k . ' ' . $v; }
        $this->line('    source_kind : ' . implode('／', $pp));
        $this->line('');

        // ── ⑤ source_registry Schema に当てる ──────────────────────────
        $this->info('── ⑤ 載せた項目を source_registry Schema に当てる ──');
        if (!is_file($regSchemaPath)) {
            $this->error('  × ' . $regSchemaPath . ' がありません');
            $fail++;
        } else {
            $regSchema = json_decode((string) file_get_contents($regSchemaPath), true);
            $errs = self::jsCheck($reg, $regSchema, '');
            $ok('M-09', $errs === [], 'Schema 違反 ' . count($errs) . ' 件');
            foreach (array_slice($errs, 0, 8) as $m) { $this->error('        ' . $m); }
        }
        $this->line('');

        // ── ⑥ 載った値を SQL から取り直して突き合わせる ─────────────────
        //   同じ式を、同じ表から、PHP の外で取り直した値で組み直します。
        $this->info('── ⑥ 1番人気の5つの値を SQL から取り直して突き合わせる ──');
        $pa = \DB::table('t_horse_odds_finder_popularity_rank_average')
                 ->where('popularity_rank', 1)->value('odds_average');
        $fa = \DB::table('t_horse_odds_finder_fuku_popularity_rank_average')
                 ->where('popularity_rank', 1)->value('odds_average');
        $cr = \DB::table('t_horse_odds_finder_compute_odds_correction')
                 ->where('popularity_rank', 1)->value('avg_correction_ratio');
        $w6 = (float) ($cells[$top][6]['win_odds'] ?? 0);
        $p6 = (float) ($cells[$top][6]['place_min'] ?? 0);
        $this->line(sprintf('    材料 : 過去平均単勝 %s／過去平均複勝最小 %s／補正係数 %s',
            (string) $pa, (string) $fa, (string) $cr));
        $this->line(sprintf('           6分前単勝 %s／6分前複勝最小 %s',
            (string) $w6, (string) $p6));
        $estHand = ($w6 > 0 && $cr !== null) ? round($w6 * (float) $cr, 2) : null;
        $want = [
            'opi'                       => ($w6 > 0 && $pa !== null) ? round((float) $pa / $w6, 2) : null,
            'fuku_opi'                  => ($p6 > 0 && $fa !== null) ? round((float) $fa / $p6, 2) : null,
            'estimated_final_odds'      => $estHand,
            'estimated_final_place_min' => ($p6 > 0 && $cr !== null) ? round($p6 * (float) $cr, 2) : null,
            'estimated_opi'             => ($estHand !== null && $estHand > 0 && $pa !== null)
                                         ? round((float) $pa / $estHand, 2) : null,
        ];
        $i = 10;
        // 算出時刻がまだ無い表に頼る項目は、載らないのが正しい動きです
        $needPop = ['opi' => true, 'fuku_opi' => true, 'estimated_opi' => true,
                    'estimated_final_odds' => false, 'estimated_final_place_min' => false];
        foreach ($want as $field => $v) {
            $ref = 'h' . $top . '_' . $field;
            $got = $reg[$ref]['value'] ?? null;
            $name = 'M-' . str_pad((string) $i, 2, '0', STR_PAD_LEFT);
            $i++;
            if (!$hasPop && ($needPop[$field] ?? false)) {
                // $ok は (名前, 真偽, 説明) です。引数を取り違えていました。
                $ok($name, ($got === null),
                    sprintf('%-26s 算出時刻が無いので載せない（正しい動き）', $field));
                continue;
            }
            if ($v === null) {
                $this->line(sprintf('  － %-12s %-26s 材料が足りないので出しません', $name, $field));
                continue;
            }
            $ok($name, ($got !== null && abs((float) $got - (float) $v) < 0.000001),
                sprintf('%-26s 載った %s ／ SQLから %s', $field,
                    ($got === null ? '無し' : (string) $got), (string) $v));
        }
        $this->line('');

        // ── ⑦ 親（parents）が同じ登録の中に居るか ──────────────────────
        $this->info('── ⑦ 親（parents）がちゃんと指せているか ──');
        $miss = [];
        foreach ($reg as $ref => $e) {
            foreach ((array) ($e['parents'] ?? []) as $p2) {
                $p2 = (string) $p2;
                if (isset($reg[$p2])) { continue; }
                // 6分前のオッズは本番ではオッズ側の登録に居ます（この試験には居ません）
                if (preg_match('/^h\d+_(win_odds|place_min)_6$/', $p2)) { continue; }
                $miss[] = $ref . ' → ' . $p2;
            }
        }
        $ok('M-15', $miss === [],
            'この試験の中で行き先の無い親 ' . count($miss) . ' 件'
            . '（6分前オッズは本番のオッズ側に居るので除きます）');
        foreach (array_slice($miss, 0, 8) as $m) { $this->error('        ' . $m); }
        $this->line('');

        // ── ⑧ 旗で止められるか ─────────────────────────────────────────
        $this->info('── ⑧ .env の BAGANRIKI_MARKET_PRIOR=0 で止まるか ──');
        $keep = [getenv('BAGANRIKI_MARKET_PRIOR'),
                 $_ENV['BAGANRIKI_MARKET_PRIOR'] ?? null,
                 $_SERVER['BAGANRIKI_MARKET_PRIOR'] ?? null];
        try {
            putenv('BAGANRIKI_MARKET_PRIOR=0');
            $_ENV['BAGANRIKI_MARKET_PRIOR'] = '0';
            $_SERVER['BAGANRIKI_MARKET_PRIOR'] = '0';
            $m2 = $C::r122MarketPriorRegistry($raceId, $asOf, $rank, $cells, $asFreeze);
            $ok('M-16', $m2['registry'] === [], '0 なら registry は 0 件');
            $ok('M-17', ($m2['coverage']['OPI']['status'] ?? '') === 'UNAVAILABLE',
                '0 なら UNAVAILABLE');
            $ok('M-18',
                strpos((string) ($m2['coverage']['OPI']['reason'] ?? ''), 'BAGANRIKI_MARKET_PRIOR') !== false,
                '止めた理由が読める');
        } finally {
            if ($keep[0] === false) { putenv('BAGANRIKI_MARKET_PRIOR'); }
            else { putenv('BAGANRIKI_MARKET_PRIOR=' . $keep[0]); }
            if ($keep[1] === null) { unset($_ENV['BAGANRIKI_MARKET_PRIOR']); }
            else { $_ENV['BAGANRIKI_MARKET_PRIOR'] = $keep[1]; }
            if ($keep[2] === null) { unset($_SERVER['BAGANRIKI_MARKET_PRIOR']); }
            else { $_SERVER['BAGANRIKI_MARKET_PRIOR'] = $keep[2]; }
        }
        $this->line('');

        $this->line('  判定件数 : ' . ($pass + $fail) . ' 件');
        $this->line('  合格     : ' . $pass . ' 件');
        $this->line('  不合格   : ' . $fail . ' 件');
        $this->line('');
        $this->info('════════════════════════════════════════════════════════');
        $this->info(($fail === 0)
            ? ' OPI と推定確定オッズは契約どおりに載りました（書き込み0件）'
            : ' 合わない箇所があります。上の × をご確認ください');
        $this->info('════════════════════════════════════════════════════════');
    }
