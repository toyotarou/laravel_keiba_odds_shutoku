
    /**
     * ═══════════════════════════════════════════════════════════════════════
     * @ANCHOR-20261020-R122-PUB  統合・公開・intent・revision（本番接続）
     * ═══════════════════════════════════════════════════════════════════════
     * 根拠：server_contract_r12.2.txt 7章・8章・10章・11章
     *
     * ■ 通す順番
     *   ① 読取（書込ロックを持ちません）
     *      3つの版（state／response／publication）と、両roleの検証済み全頭評価。
     *      ここで「検証開始時刻」を取ります。
     *   ② 統合（BaganrikiRanking::merge）
     *      rank_score=100×(K−r+1)/K の max。同点は 両AIの原公開一致あり →
     *      独立根拠群数の多い順 → 馬番昇順。
     *      <b>両AIの検証済み原公開候補だと証明できたときだけ +5。</b>
     *   ③ 枠を先に全帯ぶん予約し、D不足はB、B不足はD、A不足はB→D で埋めます。
     *      馬番は重複させません。
     *   ④ 「検証完了時刻」を取り、intent_hash を作ります。
     *   ⑤ <b>短いトランザクション</b>で live_state と intent をロックし、
     *      3つの版・現在時刻・期限をもう一度見ます。
     *      古い処理は拒否。同じ intent の再実行は同じ publication_id。
     *   ⑥ 「commit直前時刻」を取り、
     *      検証開始 <= 検証完了 <= commit直前 を確かめます。
     *
     * ■ 加点の証明について
     *   訂正版または初回の<b>完全な原応答</b>が、公開に使う全頭の実効内容・
     *   帯順位・公開リスト・馬別フラグ・非選出理由と一致すると確かめられた
     *   ときだけ、その role の証明として使います。
     *   初回と訂正が混ざった行は証明できないので加点しません。
     *
     * @param array $opt ['now_us'=>int, 'job_id'=>string, 'handed'=>array]
     * @return array
     */
    public function r122Publish(int $snapshotId, array $opt = []): array
    {
        $out = ['ok' => false, 'code' => null, 'reason' => null,
                'publication_id' => null, 'reused' => false,
                'candidates' => [], 'quota' => null, 'shortfalls' => [],
                'intent_hash' => null, 'job_id' => null,
                'used' => [], 'proof' => [],
                // @ANCHOR-20261020-R122-BANDKEEP  どの帯の順位をどこから採ったか
                'rank_source' => [], 'rank_fallback' => [], 'rank_notes' => []];

        $t0 = (int) ($opt['now_us'] ?? BaganrikiWorker::nowUs());   // 検証開始時刻

        $snap = \DB::table('baganriki_snapshots')->where('id', $snapshotId)->first();
        if ($snap === null) {
            $out['code'] = 'NO_SNAPSHOT'; $out['reason'] = '凍結入力がありません';
            return $out;
        }
        // 原応答手渡しは、ジャーナルがあるレースでは受け付けません（契約10章）
        if (!empty($opt['handed'])) {
            $hasJournal = \DB::table('baganriki_ai_attempts')
                            ->where('snapshot_id', $snapshotId)->exists();
            if ($hasJournal) {
                $out['code'] = 'HANDED_REFUSED';
                $out['reason'] = 'ジャーナルがあるレースでは原応答の手渡しを受け付けません';
                return $out;
            }
        }

        BaganrikiWorker::ensureLive($snapshotId, $t0);
        $live = \DB::table('baganriki_live_states')
                  ->where('snapshot_id', $snapshotId)->first();      // ロックしません
        $readRev = [
            'state'       => ($live === null) ? 0 : (int) $live->state_revision,
            'response'    => ($live === null) ? 0 : (int) $live->response_revision,
            'publication' => ($live === null) ? 0 : (int) $live->publication_revision,
        ];
        // 呼出側が整合した読取取引で3つの版を取っているときは、その値を使います。
        //   （読取→検証→保存を分けて行う呼び方のためです。保存の直前に
        //     もう一度見比べて、古ければ保存しません）
        if (isset($opt['read_revisions']) && is_array($opt['read_revisions'])) {
            foreach (['state', 'response', 'publication'] as $k) {
                if (array_key_exists($k, $opt['read_revisions'])) {
                    $readRev[$k] = (int) $opt['read_revisions'][$k];
                }
            }
        }
        $out['used'] = $readRev;

        // ── 期限（実効）──────────────────────────────────────────────
        $dl = BaganrikiWorker::deadlines($snap, $live);
        if (!$dl['ok']) {
            $out['code'] = (string) $dl['code']; $out['reason'] = (string) $dl['reason'];
            return $out;
        }
        if ($t0 > $dl['publish']) {
            $out['code'] = 'DEADLINE_PASSED';
            $out['reason'] = '実効の公開期限を過ぎています';
            return $out;
        }

        // ── 全頭取消 ────────────────────────────────────────────────
        $cancelled = (array) json_decode((string) ($live->cancellations ?? '[]'), true);
        $cancelled = array_map('intval', $cancelled);
        $frozenBand = [];
        $src1 = json_decode((string) $snap->input_json_1st, true);
        foreach ((array) ($src1['runners'] ?? []) as $r) {
            $frozenBand[(int) $r['horse_no']] = (string) ($r['band'] ?? '');
        }
        $activeNums = array_values(array_diff(array_keys($frozenBand), $cancelled));
        if ($activeNums === []) {
            $out['code'] = 'ALL_CANCELLED'; $out['reason'] = '全頭取消です';
            return $out;
        }

        // ── ① 両roleの検証済み全頭評価（読取だけ）────────────────────
        $per = []; $proofHash = []; $accepted = [];
        foreach (['1st', '2nd'] as $role) {
            $a = $this->r122AcceptedHorses($snapshotId, $role);
            if (!($a['ok'] ?? false) || ($a['merged'] ?? []) === []) { continue; }
            // @ANCHOR-20261020-R122-COMPLETE  未完了は選出に使いません（契約10章）
            if (($a['complete'] ?? null) === false) { continue; }
            $accepted[$role] = $a;
            $srcCol = ($role === '2nd') ? 'input_json_2nd' : 'input_json_1st';
            $src = json_decode((string) $snap->{$srcCol}, true);
            $resUsed = $this->r122ResponseUsed($snapshotId, $role, $a);
            if ($resUsed['proof'] !== null) { $proofHash[$role] = $resUsed['proof']; }
            // @ANCHOR-20261020-R122-BANDKEEP  帯ごとの順位の出どころを残します
            $out['rank_source'][$role] = (array) ($resUsed['rank_source'] ?? []);
            if ((array) ($resUsed['fallback'] ?? []) !== []) {
                $out['rank_fallback'][$role] = (array) $resUsed['fallback'];
            }
            foreach ((array) ($resUsed['rank_notes'] ?? []) as $rn) {
                $out['rank_notes'][] = $role . '：' . (string) $rn;
            }
            $rows = [];
            foreach ((array) $a['merged'] as $num => $h) {
                $num = (int) $num;
                if (in_array($num, $cancelled, true)) { continue; }   // 取消は入れません
                // ══════════════════════════════════════════════════════
                // @ANCHOR-20261020-R122-ELIG  10月20日006のご指摘2-2
                // ══════════════════════════════════════════════════════
                //   【本物の不具合でした】取消は除いていたのに、
                //   <b>資格の検査がありませんでした。</b>
                //   NO_EVIDENCE や UNVERIFIED の馬も band_ranks に馬番さえ
                //   あれば順位点に入り、「適格馬の数」として不足判定にも
                //   使われていました。全頭 NO_EVIDENCE のレースで
                //   候補7頭が出てしまいます（本来は候補0です）。
                //
                //   ここで見るのは<b>意味検証を通ったあとの資格</b>です。
                //   診断が eligibility と family_review・自分のSIGNALの整合を
                //   見たうえで残した行なので、この値が実効資格になります。
                //   採点が partial でも、個別SIGNALが1系統あれば ELIGIBLE が
                //   立つので落ちません（新しい下限や複数系統必須は足しません）。
                $elig = (string) ($h['eligibility'] ?? '');
                if ($elig !== 'ELIGIBLE') { continue; }
                $band = $frozenBand[$num] ?? ($h['band'] ?? '');
                // ══════════════════════════════════════════════════════
                // @ANCHOR-20261020-R122-FROZENK  10月20日006のご指摘3-4
                // ══════════════════════════════════════════════════════
                //   【本物の不具合でした】Kを残存頭数で数え直し、
                //   順位配列からも取消馬を抜いて r を詰めていました。
                //   凍結A帯6頭の2位は 100×5/6＝83.33点ですが、
                //   上位が取消になると5頭の1位＝100点に変わっていました。
                //   契約7章は「凍結帯頭数Kと帯内順位rで統合し、
                //   統合後に取消馬を除き、最新頭数で公開枠を調整する」です。
                //   <b>Kとrは凍結時のまま。</b>取消で動かすのは公開枠だけです。
                $K = 0;
                foreach ($frozenBand as $n2 => $b2) {
                    if ($b2 === $band) { $K++; }          // 取消で減らしません
                }
                $order = array_map('intval',
                    (array) ($resUsed['band_ranks'][$band] ?? []));
                // 取消馬を抜いて詰め直すことはしません（rは凍結時の位置）
                $r = array_search($num, $order, true);
                if ($r === false) { continue; }    // 順位の分からない馬は入れません
                $sup = 0;
                foreach ((array) ($h['family_review'] ?? []) as $fam) {
                    if (($fam['status'] ?? '') === 'SUPPORTED') { $sup++; }
                }
                $rows[$num] = [
                    'r' => (int) $r + 1, 'K' => max(1, $K),
                    'public' => in_array($num,
                        array_map('intval', (array) ($resUsed['public_candidates'] ?? [])), true),
                    'groups' => $sup,
                ];
            }
            if ($rows !== []) { $per[$role] = $rows; }
        }
        if ($per === []) {
            $out['code'] = 'NO_RESPONSE';
            $out['reason'] = '検証を通った応答がありません';
            return $out;
        }

        // ── ② 統合 ─────────────────────────────────────────────────
        $merged = BaganrikiRanking::merge($per, $proofHash);
        $out['proof'] = array_keys($proofHash);

        // ── ③ 枠（先に全帯ぶん予約し、不足を規則どおりに移す）─────────
        //   構造上の不足（取消で実在しなくなった帯）と、
        //   評価後の適格馬不足は別の規則なので、2段に分けます。
        $q0 = (array) json_decode((string) $snap->quota_1st, true);
        $quota1st = isset($q0[0])
            ? ['A' => (int) $q0[0], 'B' => (int) $q0[1], 'D' => (int) $q0[2]]
            : ['A' => (int) ($q0['A'] ?? 0), 'B' => (int) ($q0['B'] ?? 0),
               'D' => (int) ($q0['D'] ?? 0)];
        $afterC = BaganrikiRanking::afterCancellation($frozenBand, $cancelled,
                      $quota1st, $snap->allocation_mode);
        if (($afterC['all_cancelled'] ?? false) === true) {
            $out['code'] = 'ALL_CANCELLED'; $out['reason'] = '全頭取消です';
            return $out;
        }
        $quota = (array) ($afterC['live_quota'] ?? $quota1st);
        if ($quota === []) { $quota = ['A' => 0, 'B' => 0, 'D' => 0]; }
        if (isset($quota[0])) {
            $quota = ['A' => (int) $quota[0], 'B' => (int) $quota[1], 'D' => (int) $quota[2]];
        }
        // 評価後の適格馬（統合に乗った馬）の帯ごとの数
        $avail = ['A' => 0, 'B' => 0, 'D' => 0];
        foreach ($merged as $m) {
            $b = $frozenBand[$m['num']] ?? '';
            if (isset($avail[$b])) { $avail[$b]++; }
        }
        $fill = BaganrikiRanking::fillShortfall($quota, $avail);
        $quota = (array) $fill['quota'];
        $out['shortfalls'] = array_merge((array) ($afterC['shortfalls'] ?? []),
                                         (array) $fill['shortfalls']);

        $taken = []; $cands = [];
        foreach (['A', 'B', 'D'] as $b) {
            $want = (int) ($quota[$b] ?? 0);
            $got = 0;
            foreach ($merged as $m) {
                if ($got >= $want) { break; }
                $num = (int) $m['num'];
                if (isset($taken[$num])) { continue; }          // 馬番は重複させません
                if (($frozenBand[$num] ?? '') !== $b) { continue; }
                $taken[$num] = true; $got++;
                $cands[] = [
                    'horse_no' => $num, 'band' => $b,
                    'score' => $m['score'], 'bonus' => $m['bonus'],
                    'both_public' => $m['both_public'],
                    'bonus_proven' => $m['bonus_proven'],
                    'independent_groups' => $m['groups'],
                    'public_proof_hash' => $m['public_proof_hash'],
                ];
            }
        }
        $out['candidates'] = $cands;
        $out['quota'] = $quota;

        // ── ④ 検証完了時刻と intent ─────────────────────────────────
        $t1 = BaganrikiWorker::nowUs();                     // 検証完了時刻
        $canon = BaganrikiPrompt::canonical([
            'snapshot_hash' => (string) $snap->snapshot_hash,
            'quota'         => $quota,
            'candidates'    => array_map(static fn($c) => [
                                   'horse_no' => $c['horse_no'],
                                   'band'     => $c['band'],
                                   'bonus'    => $c['bonus'],
                               ], $cands),
            // @ANCHOR-20261020-R122-PUB  intentに入れるのは「読んだもの」だけです。
            //   publication_revision は公開した<b>結果</b>なので入れません。
            //   入れると、同じ計算の再実行が毎回別のintentになり、
            //   「同じintentの再実行は同じpublication_id」が守れません。
            'revisions'     => ['state'    => $readRev['state'],
                                'response' => $readRev['response']],
        ]);
        if ($canon === null) {
            $out['code'] = 'CANON_FAILED'; $out['reason'] = 'intentの正本を作れません';
            return $out;
        }
        $intentHash = hash('sha256', $canon);
        $jobId = (string) ($opt['job_id'] ?? ('job-' . $snapshotId . '-' . $t1 . '-'
                 . substr(bin2hex(random_bytes(3)), 0, 6)));
        $out['intent_hash'] = $intentHash;
        $out['job_id'] = $jobId;

        // ── ⑤ 短いトランザクション（ここだけロックします）─────────────
        try {
            $res = \DB::transaction(function () use ($snapshotId, $snap, $intentHash,
                    $jobId, $readRev, $cands, $quota, $out, $t0, $t1, $cancelled,
                    $activeNums) {
                $live = \DB::table('baganriki_live_states')
                          ->where('snapshot_id', $snapshotId)->lockForUpdate()->first();
                $now = $readRev;
                if ($live !== null) {
                    $now = ['state' => (int) $live->state_revision,
                            'response' => (int) $live->response_revision,
                            'publication' => (int) $live->publication_revision];
                }
                // 同じ intent の再実行は同じ publication_id を返します
                $same = \DB::table('baganriki_publication_intents')
                          ->where('snapshot_id', $snapshotId)
                          ->where('intent_hash', $intentHash)->lockForUpdate()->first();
                if ($same !== null && $same->publication_id !== null) {
                    return ['ok' => true, 'code' => 'ALREADY', 'reused' => true,
                            'publication_id' => (string) $same->publication_id];
                }
                // 読んだあとに版が変わっていたら、古い計算は保存しません
                if ($now !== $readRev) {
                    return ['ok' => false, 'code' => 'STALE',
                            'reason' => '読取のあとに版が変わりました（state '
                                      . $readRev['state'] . '→' . $now['state']
                                      . '／response ' . $readRev['response'] . '→'
                                      . $now['response'] . '／publication '
                                      . $readRev['publication'] . '→'
                                      . $now['publication'] . '）'];
                }
                // 期限と時刻をもう一度
                $dl = BaganrikiWorker::deadlines($snap, $live);
                if (!$dl['ok']) {
                    return ['ok' => false, 'code' => (string) $dl['code'],
                            'reason' => (string) $dl['reason']];
                }
                $t2 = BaganrikiWorker::nowUs();              // commit直前時刻
                if ($t2 > $dl['publish']) {
                    return ['ok' => false, 'code' => 'DEADLINE_PASSED',
                            'reason' => 'commit直前の検査で公開期限を過ぎています'];
                }
                // 検証開始 <= 検証完了 <= commit直前（1マイクロ秒でも逆行なら拒否）
                if (!($t0 <= $t1 && $t1 <= $t2)) {
                    return ['ok' => false, 'code' => 'CLOCK_BACKWARD',
                            'reason' => '時刻が逆行しています'];
                }

                $pubId = 'pub-' . $snap->race_id . '-' . $snap->generation . '-'
                       . substr($intentHash, 0, 12);
                $intentId = \DB::table('baganriki_publication_intents')->insertGetId([
                    'snapshot_id' => $snapshotId, 'job_id' => $jobId,
                    'intent_hash' => $intentHash,
                    'read_state_revision'       => $readRev['state'],
                    'read_response_revision'    => $readRev['response'],
                    'read_publication_revision' => $readRev['publication'],
                    'state' => 'COMMITTED', 'publication_id' => $pubId,
                    'created_at' => BaganrikiWorker::toDb($t2),
                ]);
                $j = static fn($v) => (string) json_encode($v,
                    JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES
                    | JSON_PRESERVE_ZERO_FRACTION);
                $proofs = [];
                foreach ($cands as $c) {
                    if ($c['public_proof_hash'] !== null) {
                        $proofs[(string) $c['horse_no']] = $c['public_proof_hash'];
                    }
                }
                \DB::table('baganriki_publications')->insert([
                    'publication_id' => $pubId, 'snapshot_id' => $snapshotId,
                    'intent_id' => $intentId,
                    'published_at' => BaganrikiWorker::toDb($t2),
                    'prediction_target_count'  => array_sum($quota),
                    'prediction_quota'         => $j($quota),
                    'publication_target_count' => array_sum($quota),
                    'publication_quota'        => $j($quota),
                    'active_count'             => count($activeNums),
                    'candidates' => $j($cands),
                    'evidence'   => $j(['shortfalls' => $out['shortfalls'],
                                        'proof_roles' => $out['proof'],
                                        'cancelled' => $cancelled]),
                    'shortfalls' => $j($out['shortfalls']),
                    'used_state_revision'    => $readRev['state'],
                    'used_response_revision' => $readRev['response'],
                    'public_proof_hash'      => $j($proofs),
                ]);
                \DB::table('baganriki_live_states')->where('snapshot_id', $snapshotId)
                  ->update(['publication_revision' => $readRev['publication'] + 1,
                            'latest_publication_id' => $pubId,
                            'updated_at' => BaganrikiWorker::toDb($t2)]);
                BaganrikiWorker::event((string) $snap->race_id, $snapshotId,
                    'PUBLISHED', $readRev['publication'], $readRev['publication'] + 1,
                    ['publication_id' => $pubId, 'intent_hash' => $intentHash,
                     'job_id' => $jobId, 'candidates' => array_column($cands, 'horse_no'),
                     'verify_started_at'  => BaganrikiTime::toJst($t0),
                     'verify_finished_at' => BaganrikiTime::toJst($t1),
                     'committed_at'       => BaganrikiTime::toJst($t2)],
                    $pubId, $t2);
                return ['ok' => true, 'code' => 'PUBLISHED', 'reused' => false,
                        'publication_id' => $pubId];
            });
        } catch (\Throwable $e) {
            if (BaganrikiWorker::isDup($e)) {
                // 別のintentが先に入った＝こちらは stale
                $out['code'] = 'STALE';
                $out['reason'] = 'ほかの処理が先に保存しました';
                return $out;
            }
            $out['code'] = 'PUBLISH_EXCEPTION'; $out['reason'] = $e->getMessage();
            \Log::error('[R122-PUB] 公開で例外', ['message' => $e->getMessage(),
                'at' => $e->getFile() . ':' . $e->getLine()]);
            return $out;
        }

        $out['ok']     = (bool) ($res['ok'] ?? false);
        $out['code']   = (string) ($res['code'] ?? '');
        $out['reason'] = $res['reason'] ?? null;
        $out['reused'] = (bool) ($res['reused'] ?? false);
        $out['publication_id'] = $res['publication_id'] ?? null;
        return $out;
    }

    /**
     * @ANCHOR-20261020-R122-PUB  公開に使った原応答を特定します
     *   加点の証明は、<b>1本の完全な原応答</b>が公開に使う全頭と
     *   そろっているときだけ出します。初回と訂正が混ざった行は証明しません。
     *
     * @return array ['band_ranks','public_candidates','proof'=>[馬番=>hash]|null,
     *                'attempt_no'=>?int]
     */
    public function r122ResponseUsed(int $snapshotId, string $role, array $accepted): array
    {
        // ══════════════════════════════════════════════════════════════
        // @ANCHOR-20261020-R122-BANDKEEP  10月20日007のご指摘3-1（最優先）
        // ══════════════════════════════════════════════════════════════
        //   【旧】`if (!$inspO['ok'] || $inspO['needs_fix']) { continue; }`
        //     1頭の observed_sum が誤っているだけで、<b>そのAIの全帯の
        //     順位をまとめて捨てて</b>いました。r122Publish は帯順位に
        //     居ない馬を外すので、正常な馬も候補から消えます。
        //     片側しか応答が無ければ NO_RESPONSE、両側に小さな不備が
        //     あれば両側とも消えます。「normalへ残った」と「候補に使える」は
        //     別だ、というご指摘のとおりでした。
        //
        //   【いま】<b>帯ごとに</b>見ます。詳細設計書10.2の縮退の順です。
        //     ① その帯に順位の指摘が無く、馬の集合が凍結入力と合っていれば
        //        応答の順位をそのまま使う（RESPONSE）
        //     ② 使えないときは、同じroleの<b>初回の順位</b>を使う（PREVIOUS）
        //     ③ それも使えないときは、<b>検証済みの予備根拠順位</b>
        //        （evidence_band_ranks）を使う（EVIDENCE_RANK）
        //     ④ それも無ければ<b>明示縮退</b>。独立根拠群数の多い順 →
        //        馬番昇順（EXPLICIT_FALLBACK）。RANK_RECOVERY_FALLBACK を付けます
        //   非適格馬を戻したり、点数の下限を足したりはしていません。
        //   加点の証明（proof）は、これまでどおり<b>直すところが無い
        //   応答で全頭が一致したときだけ</b>です。緩めていません。
        $o = ['band_ranks' => [], 'public_candidates' => [], 'proof' => null,
              'attempt_no' => null,
              // どの帯の順位をどこから採ったか（監査・APIへ出します）
              'rank_source' => [], 'fallback' => [], 'rank_notes' => []];

        $snap = \DB::table('baganriki_snapshots')->where('id', $snapshotId)->first();
        if ($snap === null) { return $o; }

        // 凍結入力の帯（これが正本です）
        $frozenBand = []; $bandMembers = ['A' => [], 'B' => [], 'D' => []];
        $src1 = json_decode((string) $snap->input_json_1st, true);
        foreach ((array) ($src1['runners'] ?? []) as $r) {
            $n = (int) ($r['horse_no'] ?? 0);
            $b = (string) ($r['band'] ?? '');
            if ($n <= 0 || !isset($bandMembers[$b])) { continue; }
            $frozenBand[$n] = $b;
            $bandMembers[$b][] = $n;
        }
        foreach ($bandMembers as $b => $v) { sort($v); $bandMembers[$b] = $v; }

        // 帯の順位として使えるか（集合が凍結入力と同じ・重複なし）
        $usable = static function ($list, array $want): bool {
            if (!is_array($list)) { return false; }
            $g = array_map('intval', array_values($list));
            if (count(array_unique($g)) !== count($g)) { return false; }
            $gs = $g; sort($gs);
            return ($gs === $want);
        };

        $mixed = ((array) ($accepted['applied'] ?? []) !== []
               || (array) ($accepted['rescued'] ?? []) !== [])
               && (string) ($accepted['code'] ?? '') === 'FIX_APPLIED';
        $try = ((string) ($accepted['code'] ?? '') === 'FIX_APPLIED')
             ? [BaganrikiWorker::FIX, BaganrikiWorker::FIRST]
             : [BaganrikiWorker::FIRST];

        // ── ① 使う応答（訂正があれば訂正、無ければ初回）──────────────
        $useNo = null; $useRes = null; $useInsp = null; $useRow = null;
        foreach ($try as $no) {
            $a = \DB::table('baganriki_ai_attempts')
                   ->where('snapshot_id', $snapshotId)->where('role', $role)
                   ->where('attempt_no', $no)
                   ->where('status', BaganrikiWorker::RECEIVED)->first();
            if ($a === null) { continue; }
            // @ANCHOR-20261020-R122-COMPLETE  未完了は順位にも使いません
            if ((int) ($a->complete ?? 0) !== 1) { continue; }
            $ex = BaganrikiResponse::extract((string) $a->raw_response);
            if (!$ex['ok']) { continue; }
            $insp = $this->r122InspectResponse($snapshotId, $role, (int) $no);
            if (!$insp['ok']) { continue; }
            $useNo = (int) $no; $useRes = (array) $ex['json'];
            $useInsp = $insp; $useRow = $a;
            break;
        }
        if ($useNo === null) { return $o; }
        $o['attempt_no'] = $useNo;

        // ── ② 初回の順位（②の縮退と、対象外の帯の保持に使います）────
        // ══════════════════════════════════════════════════════════════
        // @ANCHOR-20261021-R122-BANDSCOPE  10月21日008のご指摘3（後半）
        // ══════════════════════════════════════════════════════════════
        //   【本物の不具合でした】
        //   acceptCorrection は<b>馬の行しか比べていません。</b>
        //   band_ranks のような top の項目は比べていません。
        //   そのため「別の馬を直す訂正」が、初回では正常だった帯の
        //   並びを<b>黙って変えて</b>も通り、FIX_APPLIED なら
        //   その変えた並びが使われていました。
        //   【いま】訂正で直してよい帯（初回の repair_scope.rank_bands）
        //   だけを、訂正の並びで上書きできます。
        //   それ以外の帯は<b>初回の並びを保持</b>します。
        //   変えようとしていた場合は、そのことを記録に残します。
        $prevRanks = [];
        $allowBands = [];      // 訂正で順位を変えてよい帯
        $prevSeen   = false;   // 初回の応答を読めたか
        if ($useNo === BaganrikiWorker::FIX) {
            $p = \DB::table('baganriki_ai_attempts')
                   ->where('snapshot_id', $snapshotId)->where('role', $role)
                   ->where('attempt_no', BaganrikiWorker::FIRST)
                   ->where('status', BaganrikiWorker::RECEIVED)->first();
            if ($p !== null && (int) ($p->complete ?? 0) === 1) {
                $pe = BaganrikiResponse::extract((string) $p->raw_response);
                if ($pe['ok']) {
                    $prevSeen = true;
                    $pi = $this->r122InspectResponse($snapshotId, $role,
                              BaganrikiWorker::FIRST);
                    $pBad = self::r122BadBands($pi['repair_scope'] ?? null);
                    // @ANCHOR-20261021-R122-BANDSCOPE  直してよい帯はこれだけ
                    $allowBands = $pBad;
                    foreach (['A', 'B', 'D'] as $b) {
                        if (in_array($b, $pBad, true)) { continue; }
                        $lst = ((array) $pe['json'])['band_ranks'][$b] ?? null;
                        if ($usable($lst, $bandMembers[$b])) {
                            $prevRanks[$b] = array_map('intval', array_values($lst));
                        }
                    }
                }
            }
        }

        // ── ③ 帯ごとに順位を決めます ─────────────────────────────────
        $badBands = self::r122BadBands($useInsp['repair_scope'] ?? null);
        $resBands = (array) ($useRes['band_ranks'] ?? []);
        $evBands  = (array) ($useRes['evidence_band_ranks'] ?? []);
        $merged   = (array) ($accepted['merged'] ?? []);

        foreach (['A', 'B', 'D'] as $b) {
            if ($bandMembers[$b] === []) { continue; }   // その帯に馬が居ません

            // ══════════════════════════════════════════════════════════
            // @ANCHOR-20261021-R122-BANDSCOPE  訂正で直してよい帯だけ
            // ══════════════════════════════════════════════════════════
            //   訂正を使っていて、その帯が<b>訂正の対象ではない</b>のに
            //   初回の並びが使えるなら、初回の並びを保持します。
            //   訂正が違う並びを返していたら、そのことを残します
            //   （採用はしません）。
            if ($useNo === BaganrikiWorker::FIX && $prevSeen
                && !in_array($b, $allowBands, true)
                && isset($prevRanks[$b])) {
                $o['band_ranks'][$b]  = $prevRanks[$b];
                $o['rank_source'][$b] = 'PREVIOUS_KEPT';
                $rl = $resBands[$b] ?? null;
                if (is_array($rl)
                    && array_map('intval', array_values($rl)) !== $prevRanks[$b]) {
                    $o['rank_notes'][] = $b . '帯は訂正の対象ではないので初回の順位を'
                                       . '保持しました（訂正は違う順位を返していました）';
                } else {
                    $o['rank_notes'][] = $b . '帯は訂正の対象ではないので初回の順位を'
                                       . '保持しました';
                }
                continue;
            }
            // ①応答の順位（指摘が無く、集合が合っているとき）
            if (!in_array($b, $badBands, true)
                && $usable($resBands[$b] ?? null, $bandMembers[$b])) {
                $o['band_ranks'][$b]  = array_map('intval', array_values($resBands[$b]));
                $o['rank_source'][$b] = 'RESPONSE';
                continue;
            }
            // ②初回の順位
            if (isset($prevRanks[$b])) {
                $o['band_ranks'][$b]  = $prevRanks[$b];
                $o['rank_source'][$b] = 'PREVIOUS';
                $o['rank_notes'][]    = $b . '帯は訂正の順位を使えないので初回の順位を保持しました';
                continue;
            }
            // ③検証済みの予備根拠順位
            if ($usable($evBands[$b] ?? null, $bandMembers[$b])) {
                $o['band_ranks'][$b]  = array_map('intval', array_values($evBands[$b]));
                $o['rank_source'][$b] = 'EVIDENCE_RANK';
                $o['rank_notes'][]    = $b . '帯は根拠順位（evidence_band_ranks）へ切り替えました';
                continue;
            }
            // ④明示縮退（独立根拠群数の多い順 → 馬番昇順）
            $rows = [];
            foreach ($bandMembers[$b] as $n) {
                $h = $merged[$n] ?? null;
                if (!is_array($h)) { continue; }
                $sup = 0;
                foreach ((array) ($h['family_review'] ?? []) as $fam) {
                    if (($fam['status'] ?? '') === 'SUPPORTED') { $sup++; }
                }
                $rows[] = ['no' => $n, 'sup' => $sup];
            }
            if ($rows === []) {
                $o['rank_source'][$b] = 'NONE';
                $o['rank_notes'][]    = $b . '帯は使える順位が作れませんでした';
                continue;
            }
            usort($rows, static function ($x, $y) {
                if ($x['sup'] !== $y['sup']) { return $y['sup'] <=> $x['sup']; }
                return $x['no'] <=> $y['no'];
            });
            $o['band_ranks'][$b]  = array_column($rows, 'no');
            $o['rank_source'][$b] = 'EXPLICIT_FALLBACK';
            $o['fallback'][]      = $b;
            $o['rank_notes'][]    = $b . '帯は明示縮退（独立根拠群数の多い順→馬番昇順）です';
        }

        // ── ④ 公開リスト（表示の指摘が無いときだけ採ります）──────────
        $rs = (array) ($useInsp['repair_scope'] ?? []);
        $presOk = (((array) ($rs['presentation_horses'] ?? [])) === [])
               && (($rs['public_candidates'] ?? false) !== true);
        if ($presOk) {
            $o['public_candidates'] = (array) ($useRes['public_candidates'] ?? []);
        } else {
            $o['rank_notes'][] = '公開リストに指摘があるので原公開候補は採りません';
        }

        // ── ⑤ 加点の証明（ここは緩めません）──────────────────────────
        //   complete で、直すところが無く、公開に使う全頭がその応答の
        //   中身と一致しているときだけです。縮退した帯があるときも出しません。
        if (($useInsp['needs_fix'] ?? true) === false
            && $o['fallback'] === []
            && !($mixed && $useNo === BaganrikiWorker::FIRST)) {
            $want = array_keys($merged);
            $got  = array_keys((array) $useInsp['normal']);
            sort($want); sort($got);
            if ($want === $got && $want !== []) {
                $same = true;
                foreach ($want as $num) {
                    if (($merged[$num] ?? null) !== ($useInsp['normal'][$num] ?? null)) {
                        $same = false; break;
                    }
                }
                if ($same) {
                    $proof = [];
                    foreach ($want as $num) {
                        $proof[(int) $num] = (string) $useRow->response_hash;
                    }
                    $o['proof'] = $proof;
                }
            }
        }
        return $o;
    }

    /**
     * @ANCHOR-20261020-R122-BANDKEEP  順位の指摘が付いた帯の名前だけを返します
     *   repair_scope.rank_bands には帯の名前（A/B/D）のほかに、
     *   項目名（band_ranks / evidence_band_ranks）が入ることがあります。
     *   帯の名前だけを取り出します。項目ごと壊れている場合は全帯を
     *   「指摘あり」として扱います（順位そのものが読めないためです）。
     */
    public static function r122BadBands($scope): array
    {
        $t = (array) (((array) $scope)['rank_bands'] ?? []);
        $bands = []; $wholeBroken = false;
        foreach ($t as $x) {
            $x = (string) $x;
            if ($x === 'A' || $x === 'B' || $x === 'D') { $bands[] = $x; continue; }
            if ($x === 'band_ranks' || $x === 'evidence_band_ranks') {
                $wholeBroken = true;
            }
        }
        if ($wholeBroken) { return ['A', 'B', 'D']; }
        return array_values(array_unique($bands));
    }
