
    /**
     * ═══════════════════════════════════════════════════════════════════════
     * @ANCHOR-20261021-R122-JOBTEST  Job構成の通し試験（010の2章）
     * ═══════════════════════════════════════════════════════════════════════
     * 10月21日010（なる）の第2章に対する試験です。
     *
     * ■ worker を立てずに確かめます
     *   dispatch すると jobs 表に1行入ります。<b>その行を読みます。</b>
     *   worker を動かすと実際にAIへ送るので、試験では動かしません。
     *   行の payload から、どのJobがどの待ち行列へ、どの引数で積まれたかを
     *   読み出して突き合わせます。
     *
     * ■ 全部ロールバックします
     *   jobs 表への行も含めて、最後に必ず戻します。DBへ残る書き込みは0件です。
     *
     * ■ 実AIは1回も呼びません
     *   このJobは1本も実行しません。積まれたことだけを見ます。
     */
    private function runR122JobTest(): void
    {
        self::r122Autoload();
        $A = \App\Http\Controllers\Api\AiController::class;
        $W = \App\Http\Controllers\Api\BaganrikiWorker::class;

        $this->info('════════════════════════════════════════════════════════');
        $this->info(' r12.2 Job構成の通し試験（010の2章）');
        $this->info('════════════════════════════════════════════════════════');
        $this->line('  実行時刻 : ' . date('c'));
        $this->warn('  ※ worker は立てません。jobs 表へ積まれた行を読みます');
        $this->warn('  ※ 実AIは1回も呼びません（Jobを1本も実行しません）');
        $this->warn('  ※ 全部ロールバックします。DBへ残る書き込みは0件です');
        $this->line('');

        $pass = 0; $fail = 0;
        $check = function (string $id, string $what, $got, $want) use (&$pass, &$fail) {
            $okk = ($got === $want);
            if ($okk) { $pass++; } else { $fail++; }
            $this->line(sprintf('  %s %-10s %-54s %s',
                $okk ? '○' : '×', $id, $what,
                $okk ? '' : ('得=' . var_export($got, true)
                           . ' 期待=' . var_export($want, true))));
        };

        // ── ① 置かれているか ───────────────────────────────────────
        $this->info('── ① 置かれているか ──');
        $classes = ['\App\Jobs\R122Job', '\App\Jobs\R122FreezeRaceJob',
                    '\App\Jobs\R122RunRoleJob', '\App\Jobs\R122AggregateRaceJob',
                    '\App\Jobs\R122UpdateRaceLiveJob'];
        $missing = [];
        foreach ($classes as $c) {
            if (!class_exists($c)) { $missing[] = $c; }
        }
        $check('J-01', 'Job 5本（土台1＋4本）が置かれている', $missing, []);
        if ($missing !== []) {
            $this->error('  app/Jobs が置かれていないので、ここで止めます');
            return;
        }

        $check('J-02', 'jobs 表がある', \Schema::hasTable('jobs'), true);
        $check('J-03', 'failed_jobs 表がある', \Schema::hasTable('failed_jobs'), true);
        $conn = config('queue.connections.' . \App\Jobs\R122Job::CONN);
        $check('J-04', 'r122 の接続が config/queue.php にある',
               is_array($conn), true);
        if (!is_array($conn) || !\Schema::hasTable('jobs')) {
            $this->error('  待ち行列の受け皿がそろっていないので、ここで止めます');
            $this->line('');
            $this->line('  判定件数 : ' . ($pass + $fail) . ' 件／不合格 ' . $fail . ' 件');
            return;
        }
        $check('J-05', 'r122 の接続は database', (string) ($conn['driver'] ?? ''),
               'database');

        // ── ② 秒数の整合（010の2-1 末尾）────────────────────────────
        $this->info('── ② 秒数の整合（Jobの上限・retry_after）──');
        $retry = (int) ($conn['retry_after'] ?? 0);
        $runJob = new \App\Jobs\R122RunRoleJob(1, '1st');
        $aggJob = new \App\Jobs\R122AggregateRaceJob(1, 'RECEIVED');
        $frzJob = new \App\Jobs\R122FreezeRaceJob('2026-10-24', '5', '05', '1', 1);
        // AnthropicService::TIMEOUT は private const なので、
        // リフレクションで<b>実際の値</b>を読みます（書き写しません）。
        $httpTimeout = null;
        try {
            $rcA = new \ReflectionClass(\App\Services\AnthropicService::class);
            $cs  = $rcA->getConstants();
            if (array_key_exists('TIMEOUT', $cs)) { $httpTimeout = (int) $cs['TIMEOUT']; }
        } catch (\Throwable $e) {
            $httpTimeout = null;
        }
        $this->line('      RunRoleJob の上限   : ' . (int) $runJob->timeout . ' 秒');
        $this->line('      retry_after         : ' . $retry . ' 秒');
        $this->line('      AnthropicService    : '
                  . ($httpTimeout === null ? '（読めません）'
                                           : $httpTimeout . ' 秒'));
        $check('J-06', 'RunRoleJob の上限は 180秒の窓の内側',
               ((int) $runJob->timeout) < 180, true);
        $check('J-07', 'RunRoleJob の上限は HTTP の上限より長い',
               ($httpTimeout !== null)
                   && (((int) $runJob->timeout) > $httpTimeout), true);
        $check('J-08', 'retry_after は Jobの上限より十分長い（+100秒以上）',
               $retry >= ((int) $runJob->timeout) + 100, true);
        $check('J-09', 'RunRoleJob はやり直さない（外部APIへ二度送らない）',
               (int) $runJob->tries, 1);
        $check('J-10', '集計Jobはやり直してよい', ((int) $aggJob->tries) > 1, true);
        $check('J-11', '集計JobはAIを待たないので上限が短い',
               ((int) $aggJob->timeout) <= 60, true);
        $check('J-12', 'AIの待ち行列と期限・統合の待ち行列は別',
               [$runJob->queue, $aggJob->queue],
               [\App\Jobs\R122Job::Q_AI_1ST, \App\Jobs\R122Job::Q_AGG]);
        $check('J-13', '2nd は1st と別の待ち行列',
               (new \App\Jobs\R122RunRoleJob(1, '2nd'))->queue,
               \App\Jobs\R122Job::Q_AI_2ND);
        $check('J-14', '凍結も別の待ち行列', $frzJob->queue,
               \App\Jobs\R122Job::Q_FREEZE);
        $check('J-15', '未commitを読ませない設定（after_commit）',
               (bool) ($conn['after_commit'] ?? false), true);

        // ── ③ 旗（段）───────────────────────────────────────────────
        $this->info('── ③ 旗（段）──');
        $this->line('      本文の段 : ' . \App\Http\Controllers\Api\BaganrikiPrompt::mode()
                  . '／枠の段 : ' . $W::mode()
                  . '／Jobの段 : ' . ($W::jobs() ? 'on' : 'off'));
        $check('J-16', '枠の段が on でなければ Job の段も上がらない',
               ($W::mode() === 'on') || !$W::jobs(), true);

        // ── ④ 対象レースの限定（010の2-5）──────────────────────────
        $this->info('── ④ 対象レースの限定 ──');
        $tgs = $A::r122Targets();
        $this->line('      対象レース : ' . count($tgs) . ' 件'
                  . ($tgs === [] ? '（BAGANRIKI_R122_TARGETS が空です）'
                                 : '：' . implode('・', array_slice($tgs, 0, 3))
                                   . (count($tgs) > 3 ? ' …' : '')));
        $check('J-17', '限定を効かせるかは段で決まる',
               is_bool($W::targetsEnforced()), true);
        if ($W::targetsEnforced()) {
            $check('J-18', '対象に入っていない race_id は断る',
                   $A::r122TargetCheck('20261024-9-99-9-9')['ok'], false);
            if ($tgs !== []) {
                $check('J-19', '対象に入っている race_id は通す',
                       $A::r122TargetCheck((string) $tgs[0])['ok'], true);
            } else {
                $check('J-19', '対象が空なら1レースも送らない',
                       $A::r122TargetCheck('20261024-5-05-1-1')['code'],
                       'NO_TARGETS');
            }
        } else {
            $check('J-18', '限定を効かせていないので素通りする',
                   $A::r122TargetCheck('20261024-9-99-9-9')['code'], 'NOT_ENFORCED');
            $check('J-19', '限定を効かせていないので素通りする（対象側も）',
                   $A::r122TargetCheck('20261024-5-05-1-1')['ok'], true);
        }

        // ── ⑤ ここから先はDBを使います（必ずロールバックします）──────
        $ok = true;
        \DB::beginTransaction();
        try {
            $ctrl = app($A);
            $now  = $W::nowUs();
            $raceId = '20261024-9-99-9-7';   // 場コード99は実在しません

            // 仮の凍結入力（generation=0）を作ります
            $post  = $now + 600 * 1000000;            // 発走は10分後
            $sales = $post - 60 * 1000000;            // 投票締切は発走の60秒前
            $sid = (int) \DB::table('baganriki_snapshots')->insertGetId([
                'race_id' => $raceId, 'generation' => 0,
                'run_id' => 'JT-' . $now, 'release_version' => 'r12.2',
                'common_json' => '{}', 'input_json_1st' => '{}',
                'input_json_2nd' => '{}',
                'snapshot_hash' => hash('sha256', 'jobtest' . $now),
                'frozen_nums' => '[1,2,3,4]', 'frozen_rank' => '[1,2,3,4]',
                'mode' => 'MIXED', 'mode_status' => 'FIXED',
                'anchor_at' => $W::toDb($post),
                'cutoff_at' => $W::toDb($post - 360 * 1000000),
                'input_freeze_at' => $W::toDb($post - 330 * 1000000),
                'frozen_at' => $W::toDb($now),
                'sales_close_at' => $W::toDb($sales),
                'created_at' => $W::toDb($now),
            ]);
            $W::ensureLive($sid, $now);

            // ── 経路の固定（010の2-5）──────────────────────────────
            $this->info('── ⑤ 経路の固定 ──');
            $check('J-20', '固定する前は、どちらでもない',
                   $A::r122PathOf($sid), null);
            $f1 = $A::r122FixPath($sid, 'JOB');
            $check('J-21', 'Job に固定できる',
                   [$f1['fixed'], $f1['path']], [true, 'JOB']);
            $f2 = $A::r122FixPath($sid, 'SYNC');
            $check('J-22', '後から旧経路へ変えられない（先に決めたほうが残る）',
                   [$f2['already'], $f2['path']], [true, 'JOB']);
            $check('J-23', '読み出しても Job のまま', $A::r122PathOf($sid), 'JOB');

            // ── 積まれること ───────────────────────────────────────
            $this->info('── ⑥ 積まれること（worker は動かしません）──');

            // ══════════════════════════════════════════════════════════
            // @ANCHOR-20261021-R122-AFTERCOMMIT  未commitを読ませない
            // ══════════════════════════════════════════════════════════
            //   ご指摘（010の2-2 FreezeRaceJob）：
            //     「トランザクション内で投入する場合は、未commitの
            //       snapshotをworkerが先に読まないようにします。」
            //   r122 の接続は after_commit = true なので、
            //   トランザクションの中で dispatch しても、<b>commit まで
            //   jobs 表には入りません。</b>まずそれを確かめます。
            //   （この試験は最後にロールバックするので、ここで積んだ
            //     ぶんはそのまま消えます）
            $q0 = (int) \DB::table('jobs')->count();
            \App\Jobs\R122RunRoleJob::dispatch($sid, '2nd');
            $check('J-24a', 'commit前は jobs 表に入らない（after_commit）',
                   ((int) \DB::table('jobs')->count()) - $q0, 0);

            //   以降は beforeCommit() で、その場で積ませて中身を見ます。
            //   <b>試験のためだけ</b>です。本番の経路では付けません
            //   （付けると未commitのsnapshotを読まれるおそれがあります）。
            \App\Jobs\R122RunRoleJob::dispatch($sid, '1st')->beforeCommit();
            $q1 = (int) \DB::table('jobs')->count();
            $check('J-24', 'beforeCommit なら その場で1行増える', $q1 - $q0, 1);

            $row = \DB::table('jobs')->orderByDesc('id')->first();
            $check('J-25', '積まれた待ち行列は 1st 用',
                   (string) ($row->queue ?? ''), \App\Jobs\R122Job::Q_AI_1ST);
            $pl = json_decode((string) ($row->payload ?? '{}'), true);
            $check('J-26', '積まれたのは RunRoleJob',
                   (string) ($pl['displayName'] ?? ''),
                   'App\Jobs\R122RunRoleJob');
            // 引数（snapshot_id と role）が payload に入っていること
            $cmd = (string) ($pl['data']['command'] ?? '');
            $check('J-27', '積んだ引数に snapshot_id が入っている',
                   strpos($cmd, (string) $sid) !== false, true);
            $check('J-28', '積んだ引数に role が入っている',
                   strpos($cmd, '1st') !== false, true);
            $check('J-29', '積んだだけでは1本も実行されていない',
                   (int) \DB::table('baganriki_ai_attempts')
                       ->where('snapshot_id', $sid)->count(), 0);

            \App\Jobs\R122AggregateRaceJob::dispatch($sid, 'DEADLINE')
                ->delay(now()->addSeconds(30))->beforeCommit();
            $row2 = \DB::table('jobs')->orderByDesc('id')->first();
            $check('J-30', '遅らせて積んだ集計は、まだ取り出せない時刻',
                   ((int) ($row2->available_at ?? 0)) > time() + 20, true);
            $check('J-31', '集計は期限・統合の待ち行列',
                   (string) ($row2->queue ?? ''), \App\Jobs\R122Job::Q_AGG);

            // ── 入口から積む（010の2-3）────────────────────────────
            $this->info('── ⑦ 入口から積む ──');
            //   入口は本番の経路なので beforeCommit は付きません。
            //   そのため jobs 表の行数では数えられません（commit前です）。
            //   <b>何を積んだか</b>を戻り値で見ます。
            $dp = $ctrl->r122DispatchForRace('2026-10-24', '9', '99', '9', 7);
            if (!$W::jobs()) {
                $check('J-32', 'Jobの段が下りていれば積まない',
                       [(string) $dp['code'], (array) $dp['dispatched']],
                       ['JOBS_OFF', []]);
                $check('J-33', 'Jobの段が下りていれば何も走らせない',
                       (bool) $dp['ran'], false);
            } else {
                $check('J-32', '不足している role と集計を積む',
                       (string) $dp['code'], 'DISPATCHED');
                $check('J-33', '積んだのは role2本＋集計1本',
                       (array) $dp['dispatched'],
                       ['role:1st', 'role:2nd', 'aggregate']);
            }

            // ── 旧経路のレースには積まない ──────────────────────────
            $sid2 = (int) \DB::table('baganriki_snapshots')->insertGetId([
                'race_id' => '20261024-9-99-9-8', 'generation' => 0,
                'run_id' => 'JT2-' . $now, 'release_version' => 'r12.2',
                'common_json' => '{}', 'input_json_1st' => '{}',
                'input_json_2nd' => '{}',
                'snapshot_hash' => hash('sha256', 'jobtest2' . $now),
                'frozen_nums' => '[1,2]', 'frozen_rank' => '[1,2]',
                'mode' => 'MIXED', 'mode_status' => 'FIXED',
                'anchor_at' => $W::toDb($post),
                'cutoff_at' => $W::toDb($post - 360 * 1000000),
                'input_freeze_at' => $W::toDb($post - 330 * 1000000),
                'frozen_at' => $W::toDb($now),
                'sales_close_at' => $W::toDb($sales),
                'created_at' => $W::toDb($now),
            ]);
            $W::ensureLive($sid2, $now);
            $A::r122FixPath($sid2, 'SYNC');
            $dp2 = $ctrl->r122DispatchForRace('2026-10-24', '9', '99', '9', 8);
            if ($W::jobs()) {
                $check('J-34', '旧経路で始まったレースには積まない',
                       [(string) $dp2['code'], (array) $dp2['dispatched']],
                       ['PATH_IS_SYNC', []]);
            } else {
                $check('J-34', 'Jobの段が下りていれば、やはり積まない',
                       (array) $dp2['dispatched'], []);
            }

            // ── ⑧ 実状態の変更（010の2-2 UpdateRaceLiveJob）──────────
            $this->info('── ⑧ 実状態の変更（取消は足すだけ・締切は前倒しだけ）──');
            $before = \DB::table('baganriki_live_states')
                        ->where('snapshot_id', $sid)->first();
            $rev0 = (int) $before->state_revision;

            $a1 = $ctrl->r122ApplyLive($sid, ['cancellations' => [3]]);
            $check('J-35', '取消を入れられる',
                   [(string) $a1['code'], (array) $a1['cancellations']],
                   ['APPLIED', [3]]);
            $check('J-36', '版が1つ増える', (int) $a1['state_revision'], $rev0 + 1);

            $a2 = $ctrl->r122ApplyLive($sid, ['cancellations' => [1]]);
            $check('J-37', '取消は足すだけ（前のものが残る）',
                   (array) $a2['cancellations'], [1, 3]);

            $a3 = $ctrl->r122ApplyLive($sid, ['cancellations' => [3]]);
            $check('J-38', '同じ取消をもう一度入れても版は増えない',
                   [(string) $a3['code'], (int) $a3['state_revision']],
                   ['NO_CHANGE', $rev0 + 2]);

            $early = $sales - 120 * 1000000;     // 投票締切の2分前へ前倒し
            $a4 = $ctrl->r122ApplyLive($sid, ['live_close_us' => $early]);
            $check('J-39', '締切を前倒しできる',
                   (int) $a4['live_close_us'], $early);

            $late = $sales - 10 * 1000000;       // さっきより後ろ（延長）
            $a5 = $ctrl->r122ApplyLive($sid, ['live_close_us' => $late]);
            $check('J-40', '延長は受け付けない',
                   [(string) $a5['code'], (int) $a5['live_close_us']],
                   ['NO_CHANGE', $early]);

            $after = $sales + 60 * 1000000;      // 正本より後ろ
            $a6 = $ctrl->r122ApplyLive($sid, ['live_close_us' => $after]);
            $check('J-41', '正本の投票締切より後ろも受け付けない',
                   (string) $a6['code'], 'NO_CHANGE');

            // 凍結済み本文を触っていないこと
            $snapNow = \DB::table('baganriki_snapshots')->where('id', $sid)->first();
            $check('J-42', '凍結済み本文は1バイトも変わっていない',
                   [(string) $snapNow->input_json_1st,
                    (string) $snapNow->input_json_2nd,
                    (string) $snapNow->sales_close_at],
                   ['{}', '{}', (string) $W::toDb($sales)]);
            $check('J-43', '実状態の変更でAIへは1回も送っていない',
                   (int) \DB::table('baganriki_ai_attempts')
                       ->where('snapshot_id', $sid)->count(), 0);

            // 前倒しで期限が動いたこと
            $liveNow = \DB::table('baganriki_live_states')
                         ->where('snapshot_id', $sid)->first();
            $dlNow = $W::deadlines($snapNow, $liveNow);
            $dlOrig = $W::deadlines($snapNow, $before);
            $check('J-44', '前倒しのぶん応答期限も早くなる',
                   ((int) $dlNow['reply']) < ((int) $dlOrig['reply']), true);
            $this->line('      応答期限 : ' . \App\Http\Controllers\Api\BaganrikiTime
                            ::toJst((int) $dlOrig['reply'])
                      . ' → ' . \App\Http\Controllers\Api\BaganrikiTime
                            ::toJst((int) $dlNow['reply']));

            // ── ⑨ 監査に残っていること ─────────────────────────────
            $this->info('── ⑨ 監査に残っていること ──');
            $check('J-45', '経路の固定が監査に残る',
                   (int) \DB::table('baganriki_audit_events')
                       ->where('snapshot_id', $sid)
                       ->where('kind', $A::R122_PATH_KIND)->count(), 1);
            $check('J-46', '実状態の変更が監査に残る（変わった回数ぶん）',
                   (int) \DB::table('baganriki_audit_events')
                       ->where('snapshot_id', $sid)
                       ->where('kind', 'R122_LIVE_APPLIED')->count(), 3);

            // ── ⑩ 対象レースを「全入口」で見ていること（010の2-5）────
            // ══════════════════════════════════════════════════════════
            // @ANCHOR-20261021-R122-TARGET12  入口を名指しで確かめます
            // ══════════════════════════════════════════════════════════
            //   ご指摘：
            //     「通常アクセス・キャッシュ後・巡回・訂正の全入口で
            //       対象race_idを確認し、送信許可の直前でも確認します。
            //       1レースの最大4回という制約だけでは、対象レース総数12を
            //       保証できません。」
            //   関数の行範囲を取って、その中に判定の呼び出しがあるかを
            //   見ます。判定を書き写していないこと（同じ関数を呼んで
            //   いること）も、これで分かります。
            $this->info('── ⑩ 対象レースを全入口で見ていること ──');
            $rcT  = new \ReflectionClass($A);
            $fileT = (array) file((string) $rcT->getFileName());
            $sliceT = static function (string $m) use ($rcT, $fileT): string {
                if (!$rcT->hasMethod($m)) { return ''; }
                $r = $rcT->getMethod($m);
                return implode('', array_slice($fileT, $r->getStartLine() - 1,
                    $r->getEndLine() - $r->getStartLine() + 1));
            };
            foreach ([
                'J-47' => ['r122SendFirst',      '初回の送信許可の直前'],
                'J-48' => ['r122SendFix',        '訂正の送信許可の直前'],
                'J-49' => ['r122SweepPending',   '巡回'],
                'J-50' => ['r122AfterCached',    'キャッシュ後'],
                'J-51' => ['r122DispatchForRace', 'Jobを積む入口'],
            ] as $idT => $pairT) {
                [$mT, $labelT] = $pairT;
                $bodyT = $sliceT($mT);
                $check($idT, $labelT . 'で対象レースを見ている',
                    (strpos($bodyT, 'r122TargetCheck(') !== false), true);
            }
            $bodyRJ = (string) @file_get_contents(
                base_path('app/Jobs/R122RunRoleJob.php'));
            $check('J-52', '待ち行列から出たときも見ている',
                (strpos($bodyRJ, 'r122TargetCheck(') !== false), true);

            // ── ⑪ 実モデルと使用量が残ること（010の7章⑤）──────────────
            $this->info('── ⑪ 実モデルと使用量（010の7章⑤）──');
            $A::r122RecordUsage($sid, '1st', $W::FIRST, [
                'ok' => true, 'code' => 'OK', 'complete' => true,
                'raw' => str_repeat('x', 1234),
                'model' => 'claude-haiku-4-5',
                'stop'  => 'end_turn',
                'usage' => ['input_tokens' => 160207, 'output_tokens' => 12200],
            ]);
            $A::r122RecordUsage($sid, '2nd', $W::FIRST, [
                'ok' => true, 'code' => 'OK', 'complete' => true,
                'raw' => str_repeat('y', 555),
                'model' => 'deepseek-chat',
                'stop'  => 'stop',
                'usage' => ['prompt_tokens' => 90000, 'completion_tokens' => 4000],
            ]);
            $uz = $A::r122UsageOf($sid);
            $check('J-53', '使用量が2件残る', count((array) $uz['rows']), 2);
            $check('J-54', '応答が名乗ったモデル名で集計される',
                array_keys((array) $uz['by_model']),
                ['claude-haiku-4-5', 'deepseek-chat']);
            $check('J-55', 'Anthropic の数え方（input/output）を読める',
                [(int) $uz['by_model']['claude-haiku-4-5']['in'],
                 (int) $uz['by_model']['claude-haiku-4-5']['out']],
                [160207, 12200]);
            $check('J-56', 'DeepSeek の数え方（prompt/completion）も読める',
                [(int) $uz['by_model']['deepseek-chat']['in'],
                 (int) $uz['by_model']['deepseek-chat']['out']],
                [90000, 4000]);
            $check('J-57', 'finish_reason（stop_reason）も残る',
                [(string) $uz['rows'][0]['stop'], (string) $uz['rows'][1]['stop']],
                ['end_turn', 'stop']);
            $this->line('      内訳 : '
                . json_encode($uz['by_model'], JSON_UNESCAPED_UNICODE));
        } catch (\Throwable $e) {
            $ok = false;
            $this->error('  × 例外 : ' . $e->getMessage());
            $this->error('    ' . $e->getFile() . ':' . $e->getLine());
        } finally {
            \DB::rollBack();
        }

        $n1 = (int) \DB::table('baganriki_snapshots')
                ->where('race_id', 'like', '20261024-9-99-9-%')->count();
        $n2 = (int) \DB::table('jobs')->count();
        $this->line('');
        $this->line(sprintf('  ロールバック後  仮snapshot %d 件／jobs 表 %d 行',
            $n1, $n2));
        $this->line('');
        $this->line('  判定件数 : ' . ($pass + $fail) . ' 件');
        $this->line('  合格     : ' . $pass . ' 件');
        $this->line('  不合格   : ' . $fail . ' 件');
        $this->line('');
        $this->info('════════════════════════════════════════════════════════');
        if ($fail === 0 && $ok) {
            $this->info(' Job構成は契約どおりに積まれました（DBへ残る書き込み0件）');
        } else {
            $this->error(' 通らなかった箇所があります。上の × をご確認ください');
        }
        $this->info('════════════════════════════════════════════════════════');
    }
