
    /**
     * ═══════════════════════════════════════════════════════════════════════
     * @ANCHOR-20261021-R122-SETTLE  受領の終端と、採否の確定を分けます
     * ═══════════════════════════════════════════════════════════════════════
     * ご指摘（010の2-4「並列化で新たに注意が必要な早すぎる公開」）：
     *
     *   「現行 r122PublishWhenReady は、初回statusがTERMINALで、訂正枠が
     *     まだなければ、そのroleを終端として数えます。
     *     TERMINALにはRECEIVEDが含まれます。
     *     一方、初回応答をRECEIVEDにした後に、r122AfterReceiveで診断・
     *     訂正判断が始まります。このため、単純に2roleを並列にすると、
     *     片方が『受領済みだが訂正の要否をまだ判定していない』間に、
     *     もう片方が両role完了とみなして公開へ進む競合が起こり得ます。
     *     HTTP受領の終端と、診断・訂正・採否の確定は別に管理してください。」
     *
     * そのとおりです。いまの数え方は「HTTPが返ってきた」までしか見ていません。
     *
     * ■ 分けたもの
     *   ・<b>受領の終端</b> … baganriki_ai_attempts.status が TERMINAL。
     *                        HTTPが返った（または失敗が確定した）だけです。
     *   ・<b>採否の確定</b> … 診断→必要な訂正→採否（r122AcceptedHorses）まで
     *                        終わった印。baganriki_audit_events に
     *                        kind='R122_ROLE_SETTLED' で1行入れます。
     *
     *   印は「対象snapshot・role・応答の版」と結び付けます。版は、その role の
     *   初回と訂正の (attempt_no, status, response_hash, complete) から作る
     *   SHA-256 です。印を付けたあとに訂正が届けば版が変わるので、
     *   印は自動的に効かなくなり、もう一度待ちに戻ります。
     *
     *   <b>新しい表は作りません。</b>baganriki_audit_events は既にあります。
     *   migration を増やさずに済ませています。
     *
     * ■ 期限との関係
     *   期限前は「両roleの採否確定」まで待ちます。
     *   応答期限に達したら、待つのをやめて保存済みの結果で公開判定へ進みます
     *   （010の2-4 末尾「期限到達時だけ保存済み結果で終了させます」）。
     */

    /**
     * その role の「応答の版」を作ります。
     *
     *   初回と訂正の行を attempt_no 順に並べ、状態の分かる項目だけを
     *   連結して SHA-256 にします。行が無ければ 'none' を混ぜます。
     *   （raw_response そのものは混ぜません。response_hash で足ります）
     *
     * @return string 64文字
     */
    public static function r122RoleVersion(int $snapshotId, string $role): string
    {
        $parts = [];
        $rows = \DB::table('baganriki_ai_attempts')
                  ->where('snapshot_id', $snapshotId)
                  ->where('role', $role)
                  ->orderBy('attempt_no')
                  ->get(['attempt_no', 'status', 'response_hash', 'complete']);
        foreach ($rows as $r) {
            $parts[] = implode("\x1f", [
                (string) (int) $r->attempt_no,
                (string) $r->status,
                (string) ($r->response_hash ?? ''),
                (string) (int) $r->complete,
            ]);
        }
        if ($parts === []) { $parts[] = 'none'; }
        return hash('sha256', $snapshotId . "\x1e" . $role . "\x1e" . implode("\x1e", $parts));
    }

    /**
     * 採否が確定した印を付けます（同じ版に二度は付けません）。
     *
     * @param array $info 印に添える内容（resolve の結果など）
     * @return array ['marked','version','already']
     */
    public static function r122MarkRoleSettled(int $snapshotId, string $role,
                                               array $info = [],
                                               ?int $nowUs = null): array
    {
        $out = ['marked' => false, 'version' => null, 'already' => false];
        if (!\Schema::hasTable('baganriki_audit_events')) { return $out; }

        $ver = self::r122RoleVersion($snapshotId, $role);
        $out['version'] = $ver;

        // すでに同じ版の印があれば足しません
        $cur = self::r122RoleSettled($snapshotId, $role);
        if ($cur['settled']) { $out['already'] = true; return $out; }

        $snap = \DB::table('baganriki_snapshots')->where('id', $snapshotId)->first();
        $live = \DB::table('baganriki_live_states')
                  ->where('snapshot_id', $snapshotId)->first();
        $now  = $nowUs !== null ? $nowUs : BaganrikiWorker::nowUs();

        BaganrikiWorker::event(
            (string) ($snap->race_id ?? ''),
            $snapshotId,
            'R122_ROLE_SETTLED',
            null,
            $live !== null ? (int) $live->response_revision : null,
            ['role' => $role, 'version' => $ver] + $info,
            $role,
            $now
        );
        $out['marked'] = true;
        return $out;
    }

    /**
     * その role の採否が確定しているかを見ます。
     *
     *   いまの版と同じ版の印が1つでもあれば確定です。
     *   版が違う印（訂正が後から届いた等）は確定として数えません。
     *
     * @return array ['settled','version','found','stale']
     */
    public static function r122RoleSettled(int $snapshotId, string $role): array
    {
        $out = ['settled' => false, 'version' => null, 'found' => 0, 'stale' => 0,
                'by' => null];
        if (!\Schema::hasTable('baganriki_audit_events')) {
            // 監査表が無い環境では、印で待たせません（従来どおりの数え方）
            $out['settled'] = true;
            return $out;
        }
        $ver = self::r122RoleVersion($snapshotId, $role);
        $out['version'] = $ver;

        // ══════════════════════════════════════════════════════════════
        // @ANCHOR-20261021-R122-NOTHINGTOADOPT  採るものが無い role
        // ══════════════════════════════════════════════════════════════
        //   初回が FAILED（明確な失敗）か UNKNOWN_RESULT（結果不明）で、
        //   訂正の枠も無い（または終端）なら、その role には
        //   <b>診断も訂正も採否も、やることが残っていません。</b>
        //   印を待っても永久に付きません（印を付けるのは
        //   r122AfterReceive で、それは受領に成功したときだけ動きます）。
        //   ここで待たせると、失敗した役のぶんだけ公開が応答期限まで
        //   遅れます。公開期限は応答期限の30秒後しかありません。
        //   なので「採るものが無い」ことを確定として数えます。
        //   RECEIVED のときは<b>数えません</b>。それが010の2-4です。
        $f = \DB::table('baganriki_ai_attempts')
               ->where('snapshot_id', $snapshotId)->where('role', $role)
               ->where('attempt_no', BaganrikiWorker::FIRST)->first();
        if ($f !== null
            && in_array((string) $f->status,
                        [BaganrikiWorker::FAILED, BaganrikiWorker::UNKNOWN], true)) {
            $x = \DB::table('baganriki_ai_attempts')
                   ->where('snapshot_id', $snapshotId)->where('role', $role)
                   ->where('attempt_no', BaganrikiWorker::FIX)->first();
            if ($x === null
                || in_array((string) $x->status, BaganrikiWorker::TERMINAL, true)) {
                $out['settled'] = true;
                $out['by'] = 'NOTHING_TO_ADOPT';
                $out['first_status'] = (string) $f->status;
                return $out;
            }
        }

        $rows = \DB::table('baganriki_audit_events')
                  ->where('snapshot_id', $snapshotId)
                  ->where('kind', 'R122_ROLE_SETTLED')
                  ->where('related_id', $role)
                  ->orderByDesc('id')
                  ->limit(20)
                  ->get(['diagnostics']);
        foreach ($rows as $r) {
            $out['found']++;
            $d = json_decode((string) $r->diagnostics, true);
            if (is_array($d) && (string) ($d['version'] ?? '') === $ver) {
                $out['settled'] = true;
            } else {
                $out['stale']++;
            }
        }
        return $out;
    }
