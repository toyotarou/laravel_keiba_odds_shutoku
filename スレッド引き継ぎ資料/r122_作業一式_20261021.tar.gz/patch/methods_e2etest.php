
    /**
     * ═══════════════════════════════════════════════════════════════════════
     * @ANCHOR-20261021-R122-E2E  実凍結から一続きの通し試験（010の5章末尾）
     * ═══════════════════════════════════════════════════════════════════════
     * ご指摘（010の5章 末尾）：
     *   「通し試験の$mkはsnapshotを直接INSERTし、締切を既定3,600秒後に置く
     *     形のままです（18242行付近）。出馬表・監査行からの実凍結、
     *     キャッシュ入口、実際の期限幅、Jobの実起動を一続きにした試験は
     *     別途必要です。」
     * ご指摘（009の③）：
     *   「snapshot未作成から通す試験」
     *
     * ■ 何を変えたか
     *   これまでの通し試験は snapshot を手で INSERT し、投票締切を
     *   <b>いまから3,600秒後</b>に置いていました。
     *   期限の幅（応答期限・公開期限・情報上限・入力凍結）は締切から
     *   導出されるので幅そのものは契約どおりでしたが、
     *   「出馬表と監査行から実際に凍結する」経路は通っていませんでした。
     *
     *   いまは
     *     ① 実在のレース（出馬表・オッズのあるもの）を選びます
     *     ② <b>その出馬表とオッズを、まるごと「今日・いまから5分後」へ
     *        写します。</b>値は1つも変えません。日付・場コード・発走時刻
     *        だけを変えます（場98は実在しないので本番と混ざりません）。
     *        ロールバックするので、写しも元の行も残りません。
     *        <b>発走時刻だけ動かしても足りませんでした。</b>
     *        情報上限や応答期限は「日付＋発走時刻」から出すので、
     *        日付が3日前のままだと期限も3日前になり、
     *        監査行の自己申告した予定時刻と合わなくなります。
     *     ③ 監査行を、写した発走時刻から出した予定時刻で作ります
     *     ④ <b>締切は渡しません。</b>発走時刻から導出させます
     *        （BAGANRIKI_SALES_CLOSE_DERIVE／OFFSET_SEC のとおり）
     *     ⑤ r122ResumeFreeze（キャッシュ後の入口が呼ぶもの）で凍結します
     *     ⑥ 期限の幅が契約どおりか、保存された値で1つずつ確かめます
     *     ⑦ 送信口を偽応答に差し替えて、初回→検証→訂正→採否→公開まで
     *        <b>r122SendFirst</b>（本番の関数）で通します
     *
     *   時刻を寄せているのは、過去の開催では残り時間が足りず
     *   「応答期限まで○秒しかないので送りません」で正しく止まるためです。
     *   <b>期限の幅は1つも決め打ちしていません。</b>
     *
     * ■ 実AIは1回も呼びません。全部ロールバックします。
     */
    private function runR122E2eTest(string $root): void
    {
        self::r122Autoload();
        $A = \App\Http\Controllers\Api\AiController::class;
        $W = \App\Http\Controllers\Api\BaganrikiWorker::class;
        $T = \App\Http\Controllers\Api\BaganrikiTime::class;
        $BEGIN = \App\Http\Controllers\Api\BaganrikiResponse::BEGIN;
        $END   = \App\Http\Controllers\Api\BaganrikiResponse::END;
        $HTTP  = \Illuminate\Support\Facades\Http::class;

        $date = (string) ($this->option('date') ?: '2026-10-18');
        $this->info('════════════════════════════════════════════════════════');
        $this->info(' r12.2 実凍結から一続きの通し試験（010の5章末尾・009の③）');
        $this->info('════════════════════════════════════════════════════════');
        $this->line('  実行時刻 : ' . date('c'));
        $this->warn('  ※ 実在のレースの出馬表とオッズを、値を変えずに写します');
        $this->warn('  ※ 日付・場コード・発走時刻だけを「今日・いまから5分後・場98」'
                  . 'へ寄せます（期限の幅は1つも決め打ちしません）');
        $this->warn('  ※ 実AIは1回も呼びません（送信口を偽応答に差し替えます）');
        $this->warn('  ※ 全部ロールバックします。DBへ残る書き込みは0件です');
        $this->line('');

        // ── 偽の送信口（1回だけ登録します。積み重なるためです）──────────
        $calls = []; $doc1 = []; $doc2 = []; $fixDoc = []; $nth = [];
        $HTTP::fake(function ($request) use (&$calls, &$doc1, &$doc2, &$fixDoc,
                                             &$nth, $BEGIN, $END) {
            $url = (string) $request->url();
            $calls[] = $url;
            $isDs = (strpos($url, 'api.deepseek.com') !== false);
            $role = $isDs ? '2nd' : '1st';
            $nth[$role] = (int) ($nth[$role] ?? 0) + 1;
            // 1回目は初回、2回目は訂正の本文を返します
            $body = ($nth[$role] === 1)
                  ? ($isDs ? $doc2 : $doc1)
                  : ($isDs ? $doc2 : $fixDoc);
            $txt = $BEGIN . (string) json_encode($body,
                       JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES
                       | JSON_PRESERVE_ZERO_FRACTION) . $END;
            if ($isDs) {
                return \Illuminate\Support\Facades\Http::response([
                    'model' => 'deepseek-chat',
                    'choices' => [['message' => ['content' => $txt],
                                   'finish_reason' => 'stop']],
                    'usage' => ['prompt_tokens' => 1234, 'completion_tokens' => 567],
                ], 200);
            }
            return \Illuminate\Support\Facades\Http::response([
                'model' => 'claude-haiku-4-5',
                'content' => [['type' => 'text', 'text' => $txt]],
                'stop_reason' => 'end_turn',
                'usage' => ['input_tokens' => 2345, 'output_tokens' => 678],
            ], 200);
        });

        $pass = 0; $fail = 0;
        //   第5引数に true を渡すと「$want と<b>違う</b>こと」を見ます
        $check = function (string $id, string $what, $got, $want,
                           bool $not = false) use (&$pass, &$fail) {
            $okk = $not ? ($got !== $want) : ($got === $want);
            if ($okk) { $pass++; } else { $fail++; }
            $this->line(sprintf('  %s %-10s %-52s %s',
                $okk ? '○' : '×', $id, $what,
                $okk ? '' : ('得=' . var_export($got, true)
                           . ($not ? ' 期待=これ以外' : ' 期待=')
                           . ($not ? '' : var_export($want, true)))));
        };

        // ── ① 実在のレースを選びます ────────────────────────────────
        $race = null;
        foreach (\DB::table('t_horse_odds_finder_races')->where('date', $date)
                    ->orderBy('basho')->orderBy('race')->get() as $r) {
            $n6 = (int) \DB::table('t_horse_odds_finder_odds')
                    ->where('date', $r->date)->where('kaisuu', $r->kaisuu)
                    ->where('basho', $r->basho)->where('day', $r->day)
                    ->where('race', (int) $r->race)
                    ->where('minutes_before_start', 6)->count();
            $nh = (int) \DB::table('t_horse_odds_finder_horses')
                    ->where('date', $r->date)->where('kaisuu', $r->kaisuu)
                    ->where('basho', $r->basho)->where('day', $r->day)
                    ->where('race', (int) $r->race)->count();
            if ($n6 >= 4 && $nh >= 4) { $race = $r; break; }
        }
        if ($race === null) {
            $this->error('  × 出馬表とオッズのそろったレースがありません: ' . $date);
            return;
        }
        $raceId = $A::r122RaceId($race->date, $race->kaisuu, $race->basho,
                                 $race->day, $race->race);
        $this->line('  対象レース : ' . $raceId
                  . '（実在の出馬表・オッズを使います）');

        $ok = true;
        \DB::beginTransaction();
        try {
            $ctrl = app($A);

            // ── ② 出馬表とオッズを「今日・いまから5分後・場98」へ写します ──
            // ══════════════════════════════════════════════════════════
            // @ANCHOR-20261021-R122-E2EDATE  発走時刻だけでは足りません
            // ══════════════════════════════════════════════════════════
            //   情報上限・入力凍結・応答期限・公開期限は、すべて
            //   「日付＋発走時刻」から出します。発走時刻だけを動かしても、
            //   日付が3日前のままなら期限も3日前になります。
            //   そうすると監査行が自己申告した予定時刻と、正本から出した
            //   予定時刻が合わず、バッチが1つも採用されません
            //   （最初に書いたときはここで SOURCE_REGISTRY_EMPTY に
            //     なりました）。
            //   実データを<b>値を変えずに</b>今日へ写します。
            //   場コードは98（実在しません）にして、本番の行と混ざらない
            //   ようにします。ロールバックするので写しも残りません。
            // ══════════════════════════════════════════════════════════
            // @ANCHOR-20261021-R122-E2EWINDOW  寄せ先は「いまから5分後」
            // ══════════════════════════════════════════════════════════
            //   10分後にすると、情報上限（発走の360秒前＝いまから240秒後）が
            //   <b>まだ来ていない</b>ので、凍結が TOO_EARLY で正しく止まります。
            //   凍結できて、かつ初回を送れる窓は次の条件です。
            //     情報上限が過ぎている   発走 − 360 ≦ いま
            //       → 発走 ≦ いま + 360秒
            //     応答期限まで余裕がある 発走 − 150 ≧ いま + 45秒
            //       → 発走 ≧ いま + 195秒
            //   あいだを採って <b>いまから300秒後</b>にします。
            //     情報上限   いま − 60秒（過ぎています）
            //     入力凍結   いま − 30秒（過ぎています）
            //     応答期限   いま + 150秒（間に合います）
            //     公開期限   いま + 180秒
            //     投票締切   いま + 240秒
            //   期限の幅は1つも決め打ちしていません。
            //   いちばん遅い6分前の取得も、入力凍結より前に収まります
            //   （予定 いま−60秒、利用可能 いま−57.5秒 ≦ 入力凍結 いま−30秒）。
            $nowUs   = $W::nowUs();
            $anchorUs = ($nowUs - ($nowUs % 1000000)) + 300 * 1000000;  // 秒に丸めます
            $anchorDt = (new \DateTimeImmutable('@' . intdiv($anchorUs, 1000000)))
                            ->setTimezone(new \DateTimeZone('Asia/Tokyo'));
            $newDate  = $anchorDt->format('Y-m-d');
            $newBasho = '98';
            $newStart = $anchorDt->format('H:i:s');

            // 日付が変わるとき（発走が翌日0時台になるとき）も、
            // 日付と時刻は同じ瞬間から作るのでずれません。
            $copyErr = [];
            $copy = function (string $table, array $set)
                    use ($race, $newDate, $newBasho, &$copyErr) {
                $n = 0;
                foreach (\DB::table($table)
                            ->where('date', $race->date)->where('kaisuu', $race->kaisuu)
                            ->where('basho', $race->basho)->where('day', $race->day)
                            ->where('race', (int) $race->race)->get() as $row) {
                    $a = (array) $row;
                    // 自動連番の列は外します（名前が id でない表もあるので、
                    //   1行目で失敗したらその列名を外してもう一度だけ試します）
                    unset($a['id']);
                    $a['date']  = $newDate;
                    $a['basho'] = $newBasho;
                    foreach ($set as $k => $v) { $a[$k] = $v; }
                    try {
                        \DB::table($table)->insert($a);
                        $n++;
                    } catch (\Throwable $e) {
                        if ($copyErr === []) {
                            $copyErr[] = $table . ': ' . $e->getMessage();
                        }
                        break;
                    }
                }
                return $n;
            };
            $nRace  = $copy('t_horse_odds_finder_races',  ['start_time' => $newStart]);
            $nHorse = $copy('t_horse_odds_finder_horses', []);
            $nOdds  = $copy('t_horse_odds_finder_odds',   []);
            $this->line('  写した行 : レース ' . $nRace . ' 件／出馬表 ' . $nHorse
                      . ' 件／オッズ ' . $nOdds . ' 件（値は変えていません）');
            if ($copyErr !== []) {
                $this->error('  × 写しで失敗しました : ' . implode('／', $copyErr));
            }
            $check('G-00a', 'レースの行を写せた', $nRace, 1);
            $check('G-00b', '出馬表を写せた', $nHorse > 0, true);
            $check('G-00c', 'オッズを写せた', $nOdds > 0, true);
            $this->line('  写し先 : ' . $newDate . ' 場' . $newBasho
                      . ' 発走 ' . $newStart . '（いまから5分後）');

            // 以降は写し先のレースを対象にします
            $raceId = $A::r122RaceId($newDate, $race->kaisuu, $newBasho,
                                     $race->day, (int) $race->race);
            $this->line('  写し先の race_id : ' . $raceId);

            // ── ③ 監査行を、寄せた発走時刻から出した予定時刻で作ります ──
            $toDb = static function (int $us): string {
                return (new \DateTimeImmutable('@' . intdiv($us, 1000000)))
                    ->setTimezone(new \DateTimeZone('Asia/Tokyo'))
                    ->format('Y-m-d H:i:s') . sprintf('.%06d', $us % 1000000);
            };
            $rowsA = [];
            foreach ($T::INPUT_SLOTS as $slot) {
                $pl = [];
                foreach (\DB::table('t_horse_odds_finder_odds')
                            ->where('date', $newDate)->where('kaisuu', $race->kaisuu)
                            ->where('basho', $newBasho)->where('day', $race->day)
                            ->where('race', (int) $race->race)
                            ->where('minutes_before_start', $slot)
                            ->orderBy('num')
                            ->get(['num', 'odds', 'fuku_min', 'fuku_max']) as $o) {
                    $pl[] = ['num' => (int) $o->num, 'tan' => (string) $o->odds,
                             'fuku_min' => (string) $o->fuku_min,
                             'fuku_max' => (string) $o->fuku_max];
                }
                if ($pl === []) { continue; }
                $raw = (string) json_encode($pl, JSON_UNESCAPED_UNICODE);
                $sch = $T::slotScheduled($anchorUs, $slot);
                $rowsA[] = [
                    'race_id' => $raceId, 'slot' => $slot,
                    'batch_id' => 'E2E-' . $raceId . '-' . $slot . '-'
                                . substr(bin2hex(random_bytes(3)), 0, 6),
                    'slot_scheduled_at'    => $toDb($sch),
                    'source_updated_at'    => null,
                    'request_started_at'   => $toDb($sch + 500000),
                    'response_received_at' => $toDb($sch + 1500000),
                    'available_at'         => $toDb($sch + 2500000),
                    'raw_payload'          => $raw,
                    'payload_hash'         => hash('sha256', $raw),
                    'validation_result'    => 'ADOPTED',
                    'rejection_reason'     => null,
                    'committed'            => 1,
                    'created_at'           => $toDb($sch + 2500000),
                ];
            }
            $check('G-01', '監査行を6時点ぶん作れた', count($rowsA), 6);
            \DB::table('baganriki_acquisition_batches')->insert($rowsA);

            // ── ④ キャッシュ後の入口が呼ぶ関数で、実凍結します ──────────
            //   <b>締切は渡しません。</b>発走時刻から導出させます。
            $check('G-02', '凍結の前は snapshot が無い',
                (int) \DB::table('baganriki_snapshots')
                    ->where('race_id', $raceId)->where('generation', 0)->count(), 0);
            $rf = $ctrl->r122ResumeFreeze($newDate, $race->kaisuu, $newBasho,
                                          $race->day, (int) $race->race);
            $this->line('      凍結 : ' . (string) ($rf['code'] ?? '')
                      . '／' . mb_strimwidth((string) ($rf['reason'] ?? ''), 0, 70, '…'));
            $check('G-03', '出馬表と監査行から実際に凍結できた',
                (string) ($rf['code'] ?? ''), 'OK');
            $snap = \DB::table('baganriki_snapshots')
                      ->where('race_id', $raceId)->where('generation', 0)->first();
            $check('G-04', '本番の世代（0）に1件できた', $snap !== null, true);
            if ($snap === null) { throw new \RuntimeException('凍結できていません'); }
            $sid = (int) $snap->id;

            // ── ⑤ 期限の幅が契約どおりか（決め打ちしていないこと）────────
            $this->info('── 期限の幅（正本の発走時刻から導出されたもの）──');
            $aU = $W::dbUs($snap->anchor_at ?? null);
            $cU = $W::dbUs($snap->cutoff_at ?? null);
            $fU = $W::dbUs($snap->input_freeze_at ?? null);
            $sU = $W::dbUs($snap->sales_close_at ?? null);
            $check('G-05', '発走時刻が、寄せた時刻として保存されている',
                (int) $aU, $anchorUs);
            $check('G-06', '投票締切は発走の60秒前（導出。渡していません）',
                (int) ($aU - $sU) / 1000000, 60);
            $check('G-07', '情報上限は発走の360秒前',
                (int) ($aU - $cU) / 1000000, 360);
            $check('G-08', '入力凍結は発走の330秒前',
                (int) ($aU - $fU) / 1000000, 330);
            $live = \DB::table('baganriki_live_states')
                      ->where('snapshot_id', $sid)->first();
            $dl = $W::deadlines($snap, $live);
            $check('G-09', '応答期限は発走の150秒前',
                (int) ($aU - (int) $dl['reply']) / 1000000, 150);
            $check('G-10', '公開期限は発走の120秒前',
                (int) ($aU - (int) $dl['publish']) / 1000000, 120);
            $this->line('      発走 ' . \App\Http\Controllers\Api\BaganrikiTime::toJst($aU));
            $this->line('      情報上限 −360s ／ 入力凍結 −330s ／ 応答期限 −150s');
            $this->line('      公開期限 −120s ／ 投票締切 −60s');
            $this->line('      ※ 3,600秒の決め打ちはありません');

            // ── ⑥ 偽の応答を、この凍結入力に合わせて作ります ─────────────
            //   封筒（prompt_version・race_id・snapshot_hash など）は
            //   保存された本文からそのまま写します。
            $in1 = json_decode((string) $snap->input_json_1st, true);
            $in2 = json_decode((string) $snap->input_json_2nd, true);
            $check('G-11', '1st の本文が保存されている', is_array($in1), true);
            $mkDoc = function (array $in, string $role) use ($root) {
                // 送付資料の正常出力を雛形にし、封筒と馬をこの凍結に合わせます
                $f = rtrim($root, '/') . '/validation/normal/MIXED_N16_'
                   . $role . '_output.json';
                $tpl = is_file($f)
                     ? (array) json_decode((string) file_get_contents($f), true)
                     : [];
                $doc = $tpl;
                foreach (['prompt_version', 'schema_version', 'race_id', 'ai_role',
                          'snapshot_hash', 'mode', 'mode_status', 'allocation_mode',
                          'mode_policy_id', 'role_cap', 'role_quota',
                          'target_count'] as $k) {
                    if (array_key_exists($k, $in)) { $doc[$k] = $in[$k]; }
                }
                $doc['quota'] = $in['quota'] ?? ($doc['quota'] ?? null);
                // 馬は、この凍結の runner にそろえます（雛形の1頭目を使い回します）
                $proto = (array) (($tpl['horses'][0]) ?? []);
                // ══════════════════════════════════════════════════════
                // @ANCHOR-20261021-R122-E2EEVID  根拠の参照は馬ごとに直します
                // ══════════════════════════════════════════════════════
                //   雛形の1頭目をそのまま使い回すと、全頭が
                //   <b>1番の根拠（h1_…）を指します。</b>診断は
                //   「自分のSIGNALが1系統も無い馬」を外すので、
                //   2番以降が全部落ちます。
                //   この凍結入力に実際に在る参照（h{馬番}_win_odds_6）へ
                //   書き替えます。文字列として差し替えるので、入れ子の
                //   どこに在っても追いつきます。
                $reg = (array) ($in['source_registry'] ?? []);
                $rows = []; $bands = ['A' => [], 'B' => [], 'D' => []];
                foreach ((array) ($in['runners'] ?? []) as $rr) {
                    $no = (int) ($rr['horse_no'] ?? 0);
                    $bd = (string) ($rr['band'] ?? 'A');
                    if ($no <= 0) { continue; }
                    // この馬について、凍結入力に在る参照をひとつ選びます
                    $myRef = null;
                    foreach ([6, 9, 12, 15, 18, 21] as $sl) {
                        $cand = 'h' . $no . '_win_odds_' . $sl;
                        if (isset($reg[$cand])) { $myRef = $cand; break; }
                    }
                    $txt = (string) json_encode($proto,
                               JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES
                               | JSON_PRESERVE_ZERO_FRACTION);
                    if ($myRef !== null) {
                        // 雛形が指している参照を、この馬の参照へ置き替えます
                        $txt = str_replace('h1_past_performance_None', $myRef, $txt);
                        $txt = str_replace('"h1_', '"h' . $no . '_', $txt);
                    }
                    $h = (array) json_decode($txt, true);
                    $h['horse_no'] = $no;
                    $h['band'] = $bd;
                    $h['public_candidate'] = false;
                    $h['nonselect_reason'] = 'NOT_SELECTED';
                    $rows[] = $h;
                    if (isset($bands[$bd])) { $bands[$bd][] = $no; }
                }
                $doc['horses'] = $rows;
                foreach ($bands as $b => $v) { sort($v); $bands[$b] = $v; }
                $doc['band_ranks'] = $bands;
                $doc['evidence_band_ranks'] = $bands;
                $doc['public_candidates'] = [];
                $doc['shortfalls'] = [];
                $doc['validation_issues'] = [];
                $doc['selection_enabled'] = false;
                return $doc;
            };
            $doc1 = $mkDoc((array) $in1, '1st');
            $doc2 = $mkDoc((array) $in2, '2nd');
            $fixDoc = $doc1;

            // ── ⑦ 初回→検証→訂正→採否→公開まで、本番の関数で通します ───
            $this->info('── 初回送信から公開まで（本番の関数）──');
            $check('G-12', '送信の前は枠が1つも無い',
                (int) \DB::table('baganriki_ai_attempts')
                    ->where('snapshot_id', $sid)->count(), 0);
            $f1 = $ctrl->r122SendFirst($sid, '1st', ['test_ignore_flags' => true]);
            $this->line('      1st : sent=' . var_export($f1['sent'], true)
                      . ' ok=' . var_export($f1['ok'], true)
                      . ' code=' . (string) $f1['code']
                      . '／' . mb_strimwidth((string) $f1['reason'], 0, 60, '…'));
            $check('G-13', '1st の初回を実際に送った', (bool) $f1['sent'], true);
            $check('G-14', '1st の初回を受け取れた', (bool) $f1['ok'], true);
            $check('G-15', '1st の枠が RECEIVED になった',
                (string) \DB::table('baganriki_ai_attempts')
                    ->where('snapshot_id', $sid)->where('role', '1st')
                    ->where('attempt_no', $W::FIRST)->value('status'), $W::RECEIVED);
            $f2 = $ctrl->r122SendFirst($sid, '2nd', ['test_ignore_flags' => true]);
            $this->line('      2nd : sent=' . var_export($f2['sent'], true)
                      . ' ok=' . var_export($f2['ok'], true)
                      . ' code=' . (string) $f2['code']);
            $check('G-16', '2nd の初回も送った', (bool) $f2['sent'], true);
            $check('G-17', '2nd の枠も RECEIVED',
                (string) \DB::table('baganriki_ai_attempts')
                    ->where('snapshot_id', $sid)->where('role', '2nd')
                    ->where('attempt_no', $W::FIRST)->value('status'), $W::RECEIVED);

            // ── ⑧ 実モデルと使用量が残っていること（010の7章⑤）───────────
            $uz = $A::r122UsageOf($sid);
            // 初回に直すところがあったので、両roleで訂正も飛びます。
            //   role ごとに 初回1件＋訂正1件 ＝ 合計4件になります。
            //   （最初に書いたときは2件と見込んでいました。訂正のぶんを
            //     数えていませんでした）
            $this->line('      使用量 : '
                . json_encode($uz['by_model'], JSON_UNESCAPED_UNICODE));
            $byRole = [];
            foreach ((array) $uz['rows'] as $ur) {
                $byRole[(string) ($ur['role'] ?? '')][] = (int) ($ur['attempt_no'] ?? -1);
            }
            foreach ($byRole as $kR => $vR) { sort($vR); $byRole[$kR] = $vR; }
            ksort($byRole);
            $check('G-18', '使用量は role ごとに初回と訂正の2件ずつ残る',
                $byRole, ['1st' => [0, 1], '2nd' => [0, 1]]);
            $check('G-18b', '合計4件', count((array) $uz['rows']), 4);
            $check('G-19', '応答が名乗ったモデル名で残っている',
                array_keys((array) $uz['by_model']),
                ['claude-haiku-4-5', 'deepseek-chat']);

            // ── ⑨ 採否と公開 ───────────────────────────────────────────
            foreach (['1st', '2nd'] as $role) {
                $sv = $A::r122RoleSettled($sid, $role);
                $check('G-2' . ($role === '1st' ? '0' : '1'),
                    $role . ' の採否が確定している', (bool) $sv['settled'], true);
            }
            $pb = $ctrl->r122PublishWhenReady($sid);
            $this->line('      公開 : ' . (string) ($pb['code'] ?? '')
                      . '／' . mb_strimwidth((string) ($pb['reason'] ?? ''), 0, 70, '…'));
            // ══════════════════════════════════════════════════════════
            // @ANCHOR-20261021-R122-E2ESCOPE  この試験が示す範囲
            // ══════════════════════════════════════════════════════════
            //   この試験の目的は、010の5章末尾でご指摘いただいた
            //     出馬表・監査行からの実凍結／キャッシュ入口／
            //     実際の期限幅／初回送信から採否確定まで
            //   を<b>一続きに通すこと</b>です。
            //
            //   <b>公開の中身（候補の選定・加点・帯順位）は、この試験では
            //   確かめません。</b>偽の応答は、実在のレースの凍結入力に
            //   合わせて組み立てたものなので、送付資料の正常出力のように
            //   採点・根拠・5系統まで整合しているわけではありません。
            //   候補の選定は、資料の正常出力を使う試験
            //   （公開 67件・実経路 E群・応答検証 76件）で確認しています。
            //
            //   ここで確かめるのは
            //     ・公開判定が<b>起動して、待ちではない</b>こと
            //       （両roleの採否が確定しているので待ちにはなりません）
            //     ・採用できた馬の数が出ること（数は判定しません）
            //   です。
            $check('G-22', '公開判定が起動し、待ちにはならない',
                (string) ($pb['code'] ?? ''), 'WAITING', true);
            $okCodes = ['PUBLISHED', 'ALREADY', 'NO_RESPONSE',
                        'ALL_CANCELLED', 'PAST_PUBLISH_DEADLINE'];
            $check('G-23', '公開判定が定義どおりの結果を返した',
                in_array((string) ($pb['code'] ?? ''), $okCodes, true), true);
            $n1v = count((array) ($ctrl->r122AcceptedHorses($sid, '1st')['merged'] ?? []));
            $n2v = count((array) ($ctrl->r122AcceptedHorses($sid, '2nd')['merged'] ?? []));
            $this->line('      この偽応答で採用できた馬 : 1st ' . $n1v
                      . ' 頭／2nd ' . $n2v . ' 頭');
            $this->line('      ※ 候補の選定は、資料の正常出力を使う'
                      . '「公開 67件」「実経路 E群」で確認しています');
            if ((string) ($pb['code'] ?? '') === 'PUBLISHED'
                || (string) ($pb['code'] ?? '') === 'ALREADY') {
                $check('G-23b', '公開が1件できている',
                    ((string) \DB::table('baganriki_live_states')
                        ->where('snapshot_id', $sid)
                        ->value('latest_publication_id')) !== '', true);
            }
            $check('G-24', '実AIへは1回も送っていない（偽の送信口だけ）',
                count(array_filter($calls, static fn($u) =>
                    strpos((string) $u, 'api.anthropic.com') === false
                    && strpos((string) $u, 'api.deepseek.com') === false)), 0);
            $this->line('      送信口が呼ばれた回数 : ' . count($calls) . ' 回');
        } catch (\Throwable $e) {
            $ok = false;
            $this->error('  × 例外 : ' . $e->getMessage());
            $this->error('    ' . $e->getFile() . ':' . $e->getLine());
        } finally {
            \DB::rollBack();
        }

        // ロールバックできていることの確認
        $left1 = (int) \DB::table('baganriki_snapshots')
                   ->where('race_id', $raceId)->where('generation', 0)->count();
        $left2 = (int) \DB::table('baganriki_acquisition_batches')
                   ->where('batch_id', 'like', 'E2E-%')->count();
        $st = (string) \DB::table('t_horse_odds_finder_races')
                ->where('date', $race->date)->where('kaisuu', $race->kaisuu)
                ->where('basho', $race->basho)->where('day', $race->day)
                ->where('race', (int) $race->race)->value('start_time');
        $left3 = (int) \DB::table('t_horse_odds_finder_races')
                   ->where('basho', '98')->count();
        $left4 = (int) \DB::table('t_horse_odds_finder_odds')
                   ->where('basho', '98')->count();
        $this->line('');
        $this->line(sprintf('  ロールバック後  snapshot %d 件／監査行(E2E-) %d 件',
            $left1, $left2));
        $this->line(sprintf('  写した行も消えています  場98のレース %d 件／オッズ %d 件',
            $left3, $left4));
        $this->line('  元のレースの発走時刻は触っていません : ' . $st);
        $this->line('');
        $this->line('  判定件数 : ' . ($pass + $fail) . ' 件');
        $this->line('  合格     : ' . $pass . ' 件');
        $this->line('  不合格   : ' . $fail . ' 件');
        $this->line('');
        $this->info('════════════════════════════════════════════════════════');
        if ($fail === 0 && $ok) {
            $this->info(' 出馬表・監査行からの実凍結から公開まで、一続きに通りました'
                      . '（DBへ残る書き込み0件）');
        } else {
            $this->error(' 通らなかった箇所があります。上の × をご確認ください');
        }
        $this->info('════════════════════════════════════════════════════════');
    }
