
    /**
     * ═══════════════════════════════════════════════════════════════════════
     * @ANCHOR-20261020-R122-RESP  応答検証と局所回復の通し試験
     * ═══════════════════════════════════════════════════════════════════════
     * ■ 何を確かめるか
     *   1. 正常出力14本が、本番の経路（extract→封筒→隔離→診断）を
     *      <b>直すところなし</b>で通ること（誤検出0）
     *   2. 馬番欠落・重複・未知馬・局所の項目不正で、その範囲だけ隔離され、
     *      正常な他馬が残ること
     *   3. 公開リストとフラグの不一致だけでは、評価行を訂正対象に広げないこと
     *   4. 訂正は最大1回。初回の正常部分は、訂正が採用できなくても残ること
     *   5. 対象外を変える訂正・初回の根拠を全部失う訂正を採用しないこと
     *   6. 検証の結果が baganriki_validation_results に残ること
     *
     * ■ 書き込みについて
     *   全部ひとつのトランザクションで行い、最後に必ずロールバックします。
     */
    private function runR122ResponseTest(string $root): void
    {
        self::r122Autoload();
        $vDir = rtrim($root, '/') . '/validation';
        $this->info('════════════════════════════════════════════════════════');
        $this->info(' r12.2 応答検証と局所回復の通し試験');
        $this->info('════════════════════════════════════════════════════════');
        $this->line('  実行時刻 : ' . date('c'));
        $this->line('  資料     : ' . $vDir);
        $this->warn('  ※ 全部ロールバックします。DBへ残る書き込みは0件です');
        $this->line('');
        if (!is_dir($vDir . '/normal')) {
            $this->error('  × ' . $vDir . '/normal がありません');
            return;
        }

        $pass = 0; $fail = 0;
        $check = function (string $id, string $what, $got, $want) use (&$pass, &$fail) {
            $okk = ($got === $want);
            if ($okk) { $pass++; } else { $fail++; }
            $this->line(sprintf('  %s %-10s %-50s %s',
                $okk ? '○' : '×', $id, $what,
                $okk ? '' : ('得=' . var_export($got, true) . ' 期待=' . var_export($want, true))));
        };
        $j = static fn($v) => (string) json_encode($v,
            JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PRESERVE_ZERO_FRACTION);
        $BEGIN = \App\Http\Controllers\Api\BaganrikiResponse::BEGIN;
        $END   = \App\Http\Controllers\Api\BaganrikiResponse::END;

        // 凍結入力と枠を1組だけ作る道具（generation=900 の試験用）
        $seq = 0;
        $mk = function (array $in, array $out1, ?array $out2 = null,
                        ?int $firstUs = null, ?int $fixUs = null, string $role = '1st')
              use ($j, $BEGIN, $END, &$seq): array {
            $seq++;
            $now = \App\Http\Controllers\Api\BaganrikiWorker::nowUs();
            $nums = [];
            foreach ((array) $in['runners'] as $r) { $nums[] = (int) $r['horse_no']; }
            $sid = \DB::table('baganriki_snapshots')->insertGetId([
                'race_id' => 'RT-' . $seq, 'generation' => 900, 'run_id' => 'RT',
                'snapshot_hash' => (string) ($in['snapshot_hash'] ?? ''),
                'input_json_1st' => $j($in), 'input_json_2nd' => $j($in),
                'frozen_nums' => $j($nums),
                'created_at' => \App\Http\Controllers\Api\BaganrikiWorker::toDb($now),
            ]);
            $mkA = function (int $no, array $doc, int $at)
                   use ($sid, $j, $BEGIN, $END, &$seq, $role) {
                \DB::table('baganriki_ai_attempts')->insert([
                    'snapshot_id' => $sid, 'role' => $role, 'attempt_no' => $no,
                    'token' => hash('sha256', 'RT' . $sid . '-' . $no . '-' . $seq),
                    'status' => \App\Http\Controllers\Api\BaganrikiWorker::RECEIVED,
                    'reserved_at' => \App\Http\Controllers\Api\BaganrikiWorker::toDb($at),
                    'received_at' => \App\Http\Controllers\Api\BaganrikiWorker::toDb($at),
                    'complete' => 1,
                    'raw_response' => $BEGIN . $j($doc) . $END,
                    'response_hash' => hash('sha256', $j($doc)),
                ]);
            };
            $mkA(0, $out1, $firstUs ?? $now);
            if ($out2 !== null) { $mkA(1, $out2, $fixUs ?? ($now + 1000)); }
            return ['sid' => (int) $sid, 'nums' => $nums];
        };

        $ok = true;
        \DB::beginTransaction();
        try {
            $ctrl = app(\App\Http\Controllers\Api\AiController::class);

            // ── ① 正常出力14本を本番の経路へ通す ────────────────────
            $this->info('── ① 正常出力を本番の経路へ通す（誤検出0であること）──');
            $files = glob($vDir . '/normal/*_output.json');
            sort($files);
            $ng = 0; $n = 0; $base = null;
            foreach ($files as $f) {
                $inF = str_replace('_output', '_input', $f);
                if (!is_file($inF)) { continue; }
                $in  = json_decode((string) file_get_contents($inF), true);
                $out = json_decode((string) file_get_contents($f), true);
                if (!is_array($in) || !is_array($out)) { continue; }
                $role = (strpos(basename($f), '_2nd_') !== false) ? '2nd' : '1st';
                $m = $mk($in, $out, null, null, null, $role);
                $r = $ctrl->r122InspectResponse($m['sid'], $role, 0);
                $n++;
                if (!$r['ok'] || $r['needs_fix']
                    || count($r['normal']) !== count($m['nums'])) {
                    $ng++;
                    $this->line(sprintf('  × %-40s %s／%s  %s',
                        basename($f), $r['stage'], (string) $r['code'],
                        mb_strimwidth((string) $r['reason'], 0, 60, '…')));
                } else {
                    $this->line(sprintf('  ○ %-40s 全%d頭が残り、直すところなし',
                        basename($f), count($r['normal'])));
                }
                if ($base === null && count($in['runners']) >= 16) {
                    $base = ['in' => $in, 'out' => $out];
                }
            }
            $check('R-01', '正常出力を通した本数', $n, 14);
            $check('R-02', '正常出力の誤検出', $ng, 0);
            if ($base === null) {
                $this->error('  × 16頭の正常例が見つかりません'); $ok = false;
                throw new \RuntimeException('base なし');
            }
            $N = count($base['in']['runners']);

            // ── ② 局所回復（その範囲だけ隔離し、他馬を残す）──────────
            $this->info('── ② 局所回復（正常な他馬を残す）──');
            // 馬番欠落
            $o = $base['out']; $gone = (int) $o['horses'][2]['horse_no'];
            array_splice($o['horses'], 2, 1);
            $m = $mk($base['in'], $o);
            $r = $ctrl->r122InspectResponse($m['sid'], '1st', 0);
            $check('R-03', '欠落しても他馬は残る', count($r['normal']), $N - 1);
            $check('R-04', '欠落馬は直す範囲に入る',
                   in_array($gone, (array) $r['repair_scope']['horses'], true), true);

            // 未知馬
            $o = $base['out'];
            $x = $o['horses'][0]; $x['horse_no'] = 99; $o['horses'][] = $x;
            $m = $mk($base['in'], $o);
            $r = $ctrl->r122InspectResponse($m['sid'], '1st', 0);
            $check('R-05', '未知馬を混ぜても他馬は残る', count($r['normal']), $N);
            $check('R-06', '未知馬は隔離される',
                   in_array(99, (array) $r['diag']['unknown'], true), true);

            // 重複
            $o = $base['out'];
            $o['horses'][] = $o['horses'][0];
            $m = $mk($base['in'], $o);
            $r = $ctrl->r122InspectResponse($m['sid'], '1st', 0);
            $check('R-07', '重複しても他馬は残る', count($r['normal']), $N);
            $check('R-08', '重複は記録される', count((array) $r['diag']['duplicated']), 1);

            // 局所の項目不正
            // @ANCHOR-20261020-R122-SALVAGE  10月20日006のご指摘5-2で期待値を直しました
            //   【旧】採点集計が合わないだけで「1頭まるごと落ちる」を正としていました。
            //     契約は「不正な得点項目だけを直し、正常根拠は保持する」です。
            //     落とす側の経路は、帯の食い違い（採点以外）で見ます。
            $o = $base['out'];
            $bad = (int) $o['horses'][1]['horse_no'];
            $o['horses'][1]['band'] = ($o['horses'][1]['band'] === 'D') ? 'A' : 'D';
            $m = $mk($base['in'], $o);
            $r = $ctrl->r122InspectResponse($m['sid'], '1st', 0);
            $check('R-09', '壊れた1頭だけ落ちる', count($r['normal']), $N - 1);
            $check('R-10', '壊れた行は row_valid=false', $r['row_valid'][$bad], false);
            $check('R-11', '他の行は row_valid=true',
                   $r['row_valid'][(int) $base['out']['horses'][0]['horse_no']], true);

            // ── ③ 公開リストの不一致で評価行を広げない ────────────────
            $this->info('── ③ 公開リストの不一致で評価行を広げない ──');
            $o = $base['out'];
            if (!empty($o['public_candidates'])) {
                array_pop($o['public_candidates']);
            }
            $m = $mk($base['in'], $o);
            $r = $ctrl->r122InspectResponse($m['sid'], '1st', 0);
            $check('R-12', '直す範囲に公開リストが入る',
                   $r['repair_scope']['public_candidates'], true);
            $check('R-13', '評価行は広がらない',
                   (array) $r['repair_scope']['horses'], []);
            $check('R-14', '全頭そのまま残る', count($r['normal']), $N);

            // ══════════════════════════════════════════════════════════
            // @ANCHOR-20261020-R122-REFCHECK  参照根拠の意味検証
            // ══════════════════════════════════════════════════════════
            $this->info('── ③-2 参照根拠の意味検証（実在・所有馬・SIGNAL）──');

            // 参照IDを作り話に差し替える（実在しないID）
            $o = $base['out'];
            $no0 = (int) $o['horses'][0]['horse_no'];
            $o['horses'][0] = self::rtSwapRefs($o['horses'][0], 'SONZAI_SHINAI_REF');
            $m = $mk($base['in'], $o);
            $r = $ctrl->r122InspectResponse($m['sid'], '1st', 0);
            $codes = array_column((array) $r['diag']['findings'], 'code');
            $check('R-26', '実在しない参照IDを見つける',
                   in_array('EVIDENCE_REF_UNKNOWN', $codes, true), true);
            $check('R-27', 'その馬が直す範囲に入る',
                   in_array($no0, (array) $r['repair_scope']['horses'], true), true);
            $check('R-28', '他の馬はそのまま残る', count($r['normal']), $N - 1);
            $check('R-29', '自分のSIGNALが無くなるので行は落ちる',
                   $r['row_valid'][$no0], false);

            // 他の馬の参照IDを混ぜる（実在はするが所有が違う）
            $o = $base['out'];
            $other = (int) $o['horses'][1]['horse_no'];
            $borrow = null;
            foreach ((array) $base['in']['source_registry'] as $rf => $e) {
                if (($e['scope'] ?? '') === 'HORSE'
                    && in_array($other, array_map('intval', (array) ($e['horse_nos'] ?? [])), true)) {
                    $borrow = (string) $rf; break;
                }
            }
            if ($borrow !== null) {
                // 自分のSIGNALは残したまま、他馬の参照を1件足します
                $o['horses'][0] = self::rtAddRef($o['horses'][0], $borrow);
                $m = $mk($base['in'], $o);
                $r = $ctrl->r122InspectResponse($m['sid'], '1st', 0);
                $codes = array_column((array) $r['diag']['findings'], 'code');
                $check('R-30', '他の馬の参照IDを見つける',
                       in_array('EVIDENCE_REF_NOT_OWNED', $codes, true), true);
                $check('R-31', '自分のSIGNALが残っていれば行は落とさない',
                       $r['row_valid'][$no0], true);
                $check('R-32', '全頭そのまま残る', count($r['normal']), $N);
            }

            // 正常出力は何も出ないこと（誤検出0）
            $m = $mk($base['in'], $base['out']);
            $r = $ctrl->r122InspectResponse($m['sid'], '1st', 0);
            $codes = array_column((array) $r['diag']['findings'], 'code');
            $check('R-33', '正常出力では参照の指摘が出ない',
                   count(array_intersect($codes,
                       ['EVIDENCE_REF_UNKNOWN', 'EVIDENCE_REF_NOT_OWNED',
                        'EVIDENCE_NO_OWN_SIGNAL'])), 0);
            $st = (array) ($r['diag']['ref_stats'] ?? []);
            $check('R-34', '馬ごとの参照の内訳を残す', count($st), $N);
            $own = 0;
            foreach ($st as $v) { if ((int) ($v['own_signal'] ?? 0) > 0) { $own++; } }
            $check('R-35', '全頭に自分のSIGNALがある', $own, $N);

            // ══════════════════════════════════════════════════════════
            // @ANCHOR-20261020-R122-SCOREEV  採点と出典の結びつき
            // ══════════════════════════════════════════════════════════
            $this->info('── ③-3 採点と出典の結びつき ──');

            // 点が付いているのに出典が空
            $o = $base['out'];
            $o['horses'][0]['scores']['H1']       = 5;
            $o['horses'][0]['observed_sum']       = 5;
            $o['horses'][0]['observed_cap']       = 18;
            $o['horses'][0]['score_evidence']['H1']['source_refs'] = [];
            $m = $mk($base['in'], $o);
            $r = $ctrl->r122InspectResponse($m['sid'], '1st', 0);
            $codes = array_column((array) $r['diag']['findings'], 'code');
            $check('R-36', '点が付いているのに出典が空なら見つける',
                   in_array('SCORE_WITHOUT_EVIDENCE', $codes, true), true);
            $check('R-37', 'その行は落ちる', $r['row_valid'][$no0], false);

            // 採点していないのに理由が空
            $o = $base['out'];
            $o['horses'][0]['score_evidence']['H2']['reason'] = '';
            $m = $mk($base['in'], $o);
            $r = $ctrl->r122InspectResponse($m['sid'], '1st', 0);
            $codes = array_column((array) $r['diag']['findings'], 'code');
            $check('R-38', '採点していないのに理由が空なら見つける',
                   in_array('SCORE_NULL_WITHOUT_REASON', $codes, true), true);

            // 採点の出典が実在しない
            $o = $base['out'];
            $o['horses'][0]['score_evidence']['H1']['source_refs'] = ['SONZAI_SHINAI_REF'];
            $m = $mk($base['in'], $o);
            $r = $ctrl->r122InspectResponse($m['sid'], '1st', 0);
            $codes = array_column((array) $r['diag']['findings'], 'code');
            $check('R-39', '採点の出典が実在しなければ見つける',
                   in_array('SCORE_EVIDENCE_REF_UNKNOWN', $codes, true), true);
            $check('R-40', '実在しないだけなら行は落とさない',
                   $r['row_valid'][$no0], true);

            // 採点の出典欄そのものが欠けている
            $o = $base['out'];
            unset($o['horses'][0]['score_evidence']['V5']);
            $m = $mk($base['in'], $o);
            $r = $ctrl->r122InspectResponse($m['sid'], '1st', 0);
            $codes = array_column((array) $r['diag']['findings'], 'code');
            $check('R-41', '採点の出典欄の欠けを見つける',
                   in_array('SCORE_EVIDENCE_MISSING', $codes, true), true);

            // 正常出力では何も出ないこと（誤検出0）
            $m = $mk($base['in'], $base['out']);
            $r = $ctrl->r122InspectResponse($m['sid'], '1st', 0);
            $codes = array_column((array) $r['diag']['findings'], 'code');
            $check('R-42', '正常出力では採点の指摘が出ない',
                   count(array_intersect($codes,
                       ['SCORE_WITHOUT_EVIDENCE', 'SCORE_NULL_WITHOUT_REASON',
                        'SCORE_EVIDENCE_REF_UNKNOWN', 'SCORE_EVIDENCE_REF_NOT_OWNED',
                        'SCORE_EVIDENCE_MISSING', 'SCORE_EVIDENCE_TYPE',
                        'SCORE_EVIDENCE_UNKNOWN_KEY'])), 0);

            // ══════════════════════════════════════════════════════════
            // @ANCHOR-20261020-R122-SALVAGE  採点欄だけの誤りで馬を落とさない
            // ══════════════════════════════════════════════════════════
            $this->info('── ③-4 採点欄だけの誤りで正常根拠を落とさない ──');
            $o = $base['out'];
            $tgt = (int) $o['horses'][1]['horse_no'];
            $o['horses'][1]['observed_sum'] = 999;      // 集計だけを壊します
            $m = $mk($base['in'], $o);
            $r = $ctrl->r122InspectResponse($m['sid'], '1st', 0);
            $codes = [];
            foreach ((array) $r['diag']['findings'] as $fd) {
                if ((int) ($fd['target'] ?? 0) === $tgt) { $codes[] = $fd['code']; }
            }
            $check('R-43', '採点集計の誤りを見つける',
                   in_array('OBSERVED_SUM', array_unique($codes), true), true);
            $check('R-44', 'その馬は summary_horses に入る',
                   in_array($tgt, (array) $r['repair_scope']['summary_horses'], true), true);
            $check('R-45', 'horses には入れない（行ごとは直さない）',
                   in_array($tgt, (array) $r['repair_scope']['horses'], true), false);
            $check('R-46', '行は落とさず残す（全頭そろう）', count($r['normal']), $N);
            $check('R-47', '採点欄を落とした印が残る',
                   in_array($tgt, (array) $r['diag']['salvaged'], true), true);
            // ?? は null も「無い」と見なすので、キーの有無で見ます
            $check('R-48', '採点は空にする',
                   array_key_exists('H1', (array) ($r['normal'][$tgt]['scores'] ?? []))
                   && ($r['normal'][$tgt]['scores']['H1'] === null), true);
            $check('R-49', '採点の状態は partial',
                   ($r['normal'][$tgt]['score_status'] ?? null), 'partial');
            $check('R-50', '根拠はそのまま残す',
                   ($r['normal'][$tgt]['evidence'] ?? null),
                   ($base['out']['horses'][1]['evidence'] ?? null));

            // 根拠側の指摘が混ざっていたら残しません
            $o = $base['out'];
            $o['horses'][1]['observed_sum'] = 999;
            $o['horses'][1]['band'] = 'D';              // 帯は凍結入力が正
            $m = $mk($base['in'], $o);
            $r = $ctrl->r122InspectResponse($m['sid'], '1st', 0);
            $check('R-51', '採点以外の指摘が混ざれば残さない',
                   count($r['normal']), $N - 1);

            // ── ④ 訂正（最大1回）──────────────────────────────────
            $this->info('── ④ 訂正 ──');
            // 欠落を訂正で埋める（救済）
            $o1 = $base['out']; $gone = (int) $o1['horses'][3]['horse_no'];
            array_splice($o1['horses'], 3, 1);
            $o2 = $base['out'];
            $keep = [];
            foreach ($o2['horses'] as $h) {
                if ((int) $h['horse_no'] === $gone) { $keep[] = $h; }
            }
            $o2['horses'] = $keep;
            $m = $mk($base['in'], $o1, $o2);
            $r = $ctrl->r122ResolveCorrection($m['sid'], '1st');
            $check('R-15', '訂正を反映した', $r['code'], 'FIX_APPLIED');
            $check('R-16', '欠落した馬を救済した', (array) $r['rescued'], [$gone]);
            $check('R-17', '全頭そろう', count($r['merged']), $N);

            // ══════════════════════════════════════════════════════════
            // @ANCHOR-20261020-R122-RESTATE  10月20日007のご指摘4
            // ══════════════════════════════════════════════════════════
            //   【前回の試験が間違っていました】R-18 は、対象外の馬を
            //   <b>初回と同じ中身のまま</b>返す訂正を「対象外を変えようと
            //   している」として不採用にする動きを合格にしていました。
            //   訂正は常に全頭を返すのが契約なので、未変更の再掲は
            //   通さなければいけません。期待値のほうを直し、
            //   <b>本当に中身を変える</b>訂正に差し替えます。
            // ══════════════════════════════════════════════════════════
            // @ANCHOR-20261021-R122-METASPLIT  この試験の作り方を直しました
            // ══════════════════════════════════════════════════════════
            //   【前のやり方が間違っていました】
            //   対象外の馬の observed_sum を 777 にして「中身を変えた訂正」
            //   としていました。ところが observed_sum は<b>集計欄</b>なので、
            //   こちらの救済が勝手に計算し直して元の値へ戻します。
            //   つまり比べる時点では<b>初回と同じ中身</b>になっていました。
            //   それでも不採用になっていたのは、救済の印（r122_salvage）が
            //   行の中に残っていて、その差で弾いていたからです。
            //   つまり<b>10月21日008でご指摘を受けた不具合そのもの</b>に
            //   助けられて合格していました。
            //   【いま】救済が触らない項目（explanation）を書き換えます。
            //   訂正は契約どおり<b>全頭返し</b>ます。
            $o1 = $base['out']; $gone = (int) $o1['horses'][3]['horse_no'];
            array_splice($o1['horses'], 3, 1);
            $o2 = $base['out'];                       // 全頭返す（契約どおり）
            $chgNo = null;
            foreach ($o2['horses'] as $hi => $h) {
                if ((int) $h['horse_no'] !== $gone) {
                    $chgNo = (int) $h['horse_no'];
                    $o2['horses'][$hi]['explanation'] =
                        '対象外なのに書き換えた説明（この訂正は採用されません）';
                    break;
                }
            }
            $m = $mk($base['in'], $o1, $o2);
            $r = $ctrl->r122ResolveCorrection($m['sid'], '1st');
            $check('R-18', '対象外の馬を本当に変える訂正は採用しない',
                   $r['code'], 'FIX_REJECTED');
            $check('R-18b', 'その理由にその馬番が出る',
                   strpos((string) ($r['reason'] ?? ''), (string) $chgNo) !== false,
                   true);

            $check('R-19', '初回の正常部分は残る', count($r['merged']), $N - 1);

            // ── 全頭を返す正常な訂正（10月20日007のご指摘4）──────────────
            //   欠落した馬を直し、他の馬は初回と同じものを再掲します。
            //   これが配布本文どおりの訂正の形です（常に全頭を返す）。
            $o1 = $base['out']; $gone = (int) $o1['horses'][3]['horse_no'];
            array_splice($o1['horses'], 3, 1);
            $o2 = $base['out'];                       // 全頭そのまま（再掲）
            $m  = $mk($base['in'], $o1, $o2);
            $r  = $ctrl->r122ResolveCorrection($m['sid'], '1st');
            $check('R-52', '全頭を返す訂正を受け入れる', $r['code'], 'FIX_APPLIED');
            $check('R-53', '欠落していた馬を救済する', (array) $r['rescued'], [$gone]);
            $check('R-54', '全頭そろう', count($r['merged']), $N);
            $check('R-55', '当てたのは救済した馬だけ',
                   array_values(array_diff((array) $r['applied'], [$gone])), []);
            // 未変更の馬は初回の中身のままであること
            $keepNo = null; $firstRow = null;
            foreach ($o1['horses'] as $h0) {
                if ((int) $h0['horse_no'] !== $gone) {
                    $keepNo = (int) $h0['horse_no']; $firstRow = $h0; break;
                }
            }
            $keepRow = (array) (($r['merged'][$keepNo]) ?? []);
            $check('R-56', '未変更の馬の帯・資格・Tierが初回のまま',
                   [(string) ($keepRow['band'] ?? ''),
                    (string) ($keepRow['eligibility'] ?? ''),
                    (string) ($keepRow['tier'] ?? '')],
                   [(string) ($firstRow['band'] ?? ''),
                    (string) ($firstRow['eligibility'] ?? ''),
                    (string) ($firstRow['tier'] ?? '')]);
            $check('R-57', '未変更の馬の根拠の数も初回のまま',
                   count((array) ($keepRow['evidence'] ?? [])),
                   count((array) ($firstRow['evidence'] ?? [])));

            // ══════════════════════════════════════════════════════════
            // @ANCHOR-20261021-R122-METASPLIT  10月21日008のご指摘3
            // ══════════════════════════════════════════════════════════
            //   「採点の救済」と「全頭を返す正常な訂正」を<b>同じ経路で</b>
            //   通します。別々に試していたので、組み合わせたときに
            //   落ちることに気づけませんでした。
            //   原因は、救済の明細（内部の監査項目）を馬の行に足していて、
            //   それが訂正の比較対象に入っていたことです。
            $this->info('── ④-2 採点を救済した馬の正常な全頭訂正 ──');

            // (a) 合計欄（observed_sum）だけが誤っている初回
            $oA = $base['out'];
            $tA = (int) $oA['horses'][1]['horse_no'];
            $oA['horses'][1]['observed_sum'] = 999;
            $mA = $mk($base['in'], $oA, $base['out']);
            $iA = $ctrl->r122InspectResponse($mA['sid'], '1st', 0);
            $check('R-58', '初回は救済される（行は落ちない）',
                   count($iA['normal']), $N);
            $check('R-59', '救済の明細は馬の行に入れない',
                   array_key_exists('r122_salvage',
                       (array) ($iA['normal'][$tA] ?? [])), false);
            $check('R-60', '救済の明細は別の入れ物に出す',
                   array_key_exists($tA, (array) ($iA['salvage_detail'] ?? [])), true);
            $aA = $ctrl->r122AcceptedHorses($mA['sid'], '1st');
            $check('R-61', '正常な全頭訂正を採用する',
                   (string) ($aA['code'] ?? ''), 'FIX_APPLIED');
            $check('R-62', '全頭そろう', count((array) $aA['merged']), $N);
            $check('R-63', '当てたのは合計欄が誤っていた馬だけ',
                   array_map('intval', (array) $aA['applied']), [$tA]);
            $kA = (array) ($aA['merged'][(int) $base['out']['horses'][0]['horse_no']] ?? []);
            $fA = (array) $base['out']['horses'][0];
            $check('R-64', '他の馬の帯は初回のまま',
                   ($kA['band'] ?? null), ($fA['band'] ?? null));
            $check('R-65', '他の馬の根拠の数も初回のまま',
                   count((array) ($kA['evidence'] ?? [])),
                   count((array) ($fA['evidence'] ?? [])));
            $check('R-66', '当てた馬の採点は訂正の値に戻る',
                   ($aA['merged'][$tA]['observed_sum'] ?? null),
                   ($base['out']['horses'][1]['observed_sum'] ?? null));

            // (b) 得点1項目だけが不正な初回（満点超え）
            $oB = $base['out'];
            $tB = (int) $oB['horses'][2]['horse_no'];
            $oB['horses'][2]['scores']['H1'] = 999;     // 満点18を超えます
            $mB = $mk($base['in'], $oB, $base['out']);
            $iB = $ctrl->r122InspectResponse($mB['sid'], '1st', 0);
            $check('R-67', '得点1項目の不正でも行は落ちない',
                   count($iB['normal']), $N);
            // ?? は null も「無い」と見なすので、キーの有無で見ます
            //   （この資料の正常出力は、採点がもともと全部 null です）
            $scB = (array) ($iB['normal'][$tB]['scores'] ?? []);
            $check('R-68', 'おかしい項目の欄は残したまま空にする',
                   array_key_exists('H1', $scB) && $scB['H1'] === null, true);
            //   右側でも同じ罠を踏んでいました。初回の H2 が null のとき
            //   `?? 'y'` が 'y' を返すので、null === 'y' で落ちます。
            //   両側ともキーの有無で見ます。
            $scBase = (array) ($base['out']['horses'][2]['scores'] ?? []);
            $check('R-69', '他の項目は初回のまま',
                   array_key_exists('H2', $scB) && array_key_exists('H2', $scBase)
                   && $scB['H2'] === $scBase['H2'], true);
            $aB = $ctrl->r122AcceptedHorses($mB['sid'], '1st');
            $check('R-70', '得点1項目の不正でも全頭訂正を採用する',
                   (string) ($aB['code'] ?? ''), 'FIX_APPLIED');
            $check('R-71', '全頭そろう', count((array) $aB['merged']), $N);
            $check('R-72', '当てたのはその馬だけ',
                   array_map('intval', (array) $aB['applied']), [$tB]);
            $check('R-73', '当てた馬の得点は訂正の値に戻る',
                   ($aB['merged'][$tB]['scores']['H1'] ?? null),
                   ($base['out']['horses'][2]['scores']['H1'] ?? null));

            // (c) 内部の監査項目を訂正に入れてきたら断ります
            $oC = $base['out'];
            $oC['horses'][1]['observed_sum'] = 999;
            $fC = $base['out'];
            $fC['horses'][1]['r122_salvage'] = ['nulled_scores' => []];
            $mC = $mk($base['in'], $oC, $fC);
            $aC = $ctrl->r122AcceptedHorses($mC['sid'], '1st');
            $check('R-74', '内部の監査項目を返す訂正は採用しない',
                   (string) ($aC['code'] ?? ''), 'FIX_REJECTED');
            $check('R-75', 'それでも初回の正常部分は残る',
                   count((array) $aC['merged']), $N);

            // 訂正の受領が初回より前
            $now = \App\Http\Controllers\Api\BaganrikiWorker::nowUs();
            $o1 = $base['out']; $gone = (int) $o1['horses'][3]['horse_no'];
            array_splice($o1['horses'], 3, 1);
            $o2 = $base['out'];
            $keep = [];
            foreach ($o2['horses'] as $h) {
                if ((int) $h['horse_no'] === $gone) { $keep[] = $h; }
            }
            $o2['horses'] = $keep;
            $m = $mk($base['in'], $o1, $o2, $now, $now - 5000000);
            $r = $ctrl->r122ResolveCorrection($m['sid'], '1st');
            $check('R-20', '訂正が初回より前なら採用しない', $r['code'], 'FIX_REJECTED');

            // 直すところが無ければ訂正しない
            $m = $mk($base['in'], $base['out'], $base['out']);
            $r = $ctrl->r122ResolveCorrection($m['sid'], '1st');
            $check('R-21', '直すところが無ければ訂正しない', $r['code'], 'NO_FIX_NEEDED');

            // ── ⑤ 検証の結果が残る ────────────────────────────────
            $this->info('── ⑤ 検証の結果が残る ──');
            $vr = \DB::table('baganriki_validation_results')
                    ->where('attempt_id', \DB::table('baganriki_ai_attempts')
                        ->where('snapshot_id', $m['sid'])->where('attempt_no', 0)
                        ->value('id'))->first();
            $check('R-22', '検証の結果が1行残る', ($vr !== null), true);
            if ($vr !== null) {
                $check('R-23', '診断の版が入る', (string) $vr->validator_version,
                       \App\Http\Controllers\Api\BaganrikiDiagnose::VERSION);
                $fs = json_decode((string) $vr->field_sources, true);
                $check('R-24', '事実出典hashを全頭ぶん残す',
                       is_array($fs) ? count($fs) : 0, $N);
                $rs = json_decode((string) $vr->rank_sources, true);
                $check('R-25', '順位の出どころを残す',
                       is_array($rs) && isset($rs['band_ranks']), true);
            }

        } catch (\Throwable $e) {
            $ok = false; $fail++;
            $this->error('  × 例外: ' . $e->getMessage());
            $this->error('     ' . $e->getFile() . ':' . $e->getLine());
        } finally {
            \DB::rollBack();
        }

        $this->line('');
        $this->line(sprintf('  ロールバック後  snapshot %d／attempts %d／検証 %d',
            \DB::table('baganriki_snapshots')->count(),
            \DB::table('baganriki_ai_attempts')->count(),
            \DB::table('baganriki_validation_results')->count()));
        $this->line('');
        $this->line('  判定件数 : ' . ($pass + $fail) . ' 件');
        $this->line('  合格     : ' . $pass . ' 件');
        $this->line('  不合格   : ' . $fail . ' 件');
        $this->line('');
        $this->info('════════════════════════════════════════════════════════');
        $this->info(($fail === 0 && $ok)
            ? ' 応答検証と局所回復は契約どおりに動きました（DBへ残る書き込み0件）'
            : ' 通らなかった箇所があります。上の × をご確認ください');
        $this->info('════════════════════════════════════════════════════════');
    
    }

    /**
     * @ANCHOR-20261020-R122-REFCHECK  試験用。参照IDを全部1つの値へ差し替えます
     */
    private static function rtSwapRefs(array $h, string $to): array
    {
        $walk = static function ($n, $to) use (&$walk) {
            if (!is_array($n)) { return $n; }
            $out = [];
            foreach ($n as $k => $v) {
                if ($k === 'source_ref' && is_string($v))  { $out[$k] = $to; continue; }
                if ($k === 'source_refs' && is_array($v))  { $out[$k] = [$to]; continue; }
                $out[$k] = $walk($v, $to);
            }
            return $out;
        };
        return $walk($h, $to);
    }

    /** @ANCHOR-20261020-R122-REFCHECK  試験用。参照IDを1件だけ足します */
    private static function rtAddRef(array $h, string $ref): array
    {
        if (isset($h['evidence'][0]['source_refs'])
            && is_array($h['evidence'][0]['source_refs'])) {
            $h['evidence'][0]['source_refs'][] = $ref;
        }
        return $h;
    }
