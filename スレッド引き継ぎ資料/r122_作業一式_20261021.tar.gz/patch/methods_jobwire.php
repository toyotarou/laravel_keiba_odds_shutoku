
    /**
     * ═══════════════════════════════════════════════════════════════════════
     * @ANCHOR-20261021-R122-JOBWIRE  Job構成の土台（010の2章）
     * ═══════════════════════════════════════════════════════════════════════
     * app/Jobs の4本から呼ぶものを、ここに置きます。
     * Jobの段（BAGANRIKI_R122_JOBS）が下りているあいだ、
     * これらは<b>どこからも呼ばれません。</b>いまの経路は変わりません。
     */

    /** このレースで使う経路（JOB／SYNC）を記録する監査の種別 */
    public const R122_PATH_KIND = 'R122_PATH_FIXED';

    /**
     * レースの処理開始時に使う経路を固定します（010の2-5）。
     *
     *   「旧経路を残す場合も、レースの処理開始時に使う経路を固定します。
     *     Job失敗を理由に、送信済み・結果不明の同じ枠を旧経路から
     *     再送してはいけません。」
     *
     *   すでに固定されていれば<b>上書きしません。</b>先に決めたほうが勝ちです。
     *
     * @return array ['path','fixed','already']
     */
    public static function r122FixPath(int $snapshotId, string $path): array
    {
        $out = ['path' => null, 'fixed' => false, 'already' => false];
        if ($path !== 'JOB' && $path !== 'SYNC') { return $out; }
        if (!\Schema::hasTable('baganriki_audit_events')) {
            $out['path'] = $path;   // 監査表が無ければ記録できません
            return $out;
        }
        $cur = self::r122PathOf($snapshotId);
        if ($cur !== null) {
            $out['path'] = $cur;
            $out['already'] = true;
            return $out;
        }
        $snap = \DB::table('baganriki_snapshots')->where('id', $snapshotId)->first();
        BaganrikiWorker::event(
            (string) ($snap->race_id ?? ''), $snapshotId, self::R122_PATH_KIND,
            null, null, ['path' => $path], $path, BaganrikiWorker::nowUs()
        );
        $out['path'] = $path;
        $out['fixed'] = true;
        return $out;
    }

    /**
     * そのレースに固定された経路を返します。
     *   固定されていなければ null（＝まだどちらでもない）です。
     */
    public static function r122PathOf(int $snapshotId): ?string
    {
        if (!\Schema::hasTable('baganriki_audit_events')) { return null; }
        $r = \DB::table('baganriki_audit_events')
               ->where('snapshot_id', $snapshotId)
               ->where('kind', self::R122_PATH_KIND)
               ->orderBy('id')->first(['diagnostics', 'related_id']);
        if ($r === null) { return null; }
        $d = json_decode((string) $r->diagnostics, true);
        $p = is_array($d) ? (string) ($d['path'] ?? '') : '';
        if ($p === '') { $p = (string) ($r->related_id ?? ''); }
        return ($p === 'JOB' || $p === 'SYNC') ? $p : null;
    }

    /**
     * ═══════════════════════════════════════════════════════════════════════
     * @ANCHOR-20261021-R122-TARGET12  10月24日の非公開12レースだけに限る
     * ═══════════════════════════════════════════════════════════════════════
     * ご指摘（010の2-5・7章⑤）：
     *   「10月24日の非公開12レースについては、通常アクセス・キャッシュ後・
     *     巡回・訂正の全入口で対象race_idを確認し、送信許可の直前でも
     *     確認します。1レースの最大4回という制約だけでは、対象レース
     *     総数12を保証できません。」
     *
     * ■ 決め方
     *   .env の BAGANRIKI_R122_TARGETS に race_id を読点（,）で並べます。
     *     BAGANRIKI_R122_TARGETS=20261024-5-05-1-1,20261024-5-05-1-2,…
     *   <b>空のときは1つも送りません。</b>「指定が無ければ全部送る」に
     *   しません。逆にしておくと、設定を入れ忘れた日に全レースへ
     *   送ってしまいます。
     *
     * ■ どこで見るか
     *   ・r122SendFirst（初回の送信許可の直前）
     *   ・r122SendFix（訂正の送信許可の直前）
     *   ・r122SweepPending（巡回が拾ったとき）
     *   ・r122AfterCached（キャッシュ後の後始末）
     *   ・R122RunRoleJob（待ち行列から出たとき。積まれてから時間が経つため）
     *   同じ関数を全部から呼びます。判定を書き写しません。
     *
     * @return array ['ok','code','reason','count','targets']
     */
    public static function r122Targets(): array
    {
        $raw = (string) env('BAGANRIKI_R122_TARGETS', '');
        $out = [];
        foreach (explode(',', $raw) as $t) {
            $t = trim($t);
            if ($t === '') { continue; }
            $out[$t] = true;
        }
        return array_keys($out);
    }

    public static function r122TargetCheck(string $raceId): array
    {
        $t = self::r122Targets();
        $out = ['ok' => false, 'code' => null, 'reason' => null,
                'count' => count($t), 'targets' => $t];

        // 段が下りていれば、この見張りは使いません（いまの経路のまま）
        if (!BaganrikiWorker::targetsEnforced()) {
            $out['ok'] = true;
            $out['code'] = 'NOT_ENFORCED';
            $out['reason'] = '対象レースの限定は効かせていません';
            return $out;
        }
        if ($t === []) {
            $out['code'] = 'NO_TARGETS';
            $out['reason'] = 'BAGANRIKI_R122_TARGETS が空なので1レースも送りません';
            return $out;
        }
        if (!in_array($raceId, $t, true)) {
            $out['code'] = 'NOT_TARGET';
            $out['reason'] = $raceId . ' は検証の対象レース（' . count($t)
                           . '件）に入っていません';
            return $out;
        }
        $out['ok'] = true;
        $out['code'] = 'TARGET';
        $out['reason'] = $raceId . ' は検証の対象レースです';
        return $out;
    }

    /**
     * ═══════════════════════════════════════════════════════════════════════
     * @ANCHOR-20261021-R122-JOBDISPATCH  Jobを積む唯一の入口
     * ═══════════════════════════════════════════════════════════════════════
     * ご指摘（010の2-3）：
     *   「通常アクセスと r122AfterCached：対象判定後、凍結がなければ
     *     FreezeRaceJob、既にあれば不足しているroleのJobと集計Jobを
     *     投入する短い処理にします。terminating内で長いAIのHTTP応答を
     *     待つ形を残しません。」
     *
     *   ここは<b>短い処理だけ</b>です。AIのHTTP応答は待ちません。
     *   Jobの段が下りているときは何もせず、呼び出し元は従来の経路へ進みます。
     *
     * @return array ['ran','code','reason','dispatched'=>[…]]
     */
    public function r122DispatchForRace($date, $kaisuu, $basho, $day, $race): array
    {
        $out = ['ran' => false, 'code' => null, 'reason' => null, 'dispatched' => []];
        try {
            if (!BaganrikiWorker::jobs()) {
                $out['code'] = 'JOBS_OFF';
                $out['reason'] = 'Jobの段が下りているので積みません';
                return $out;
            }
            if (!class_exists(\App\Jobs\R122FreezeRaceJob::class)) {
                $out['code'] = 'JOBS_MISSING';
                $out['reason'] = 'app/Jobs が配置されていません';
                return $out;
            }
            if (!\App\Jobs\R122Job::ready()) {
                $out['code'] = 'QUEUE_TABLE_MISSING';
                $out['reason'] = 'jobs 表がありません';
                return $out;
            }
            $raceId = self::r122RaceId($date, $kaisuu, $basho, $day, $race);

            // ── 対象レースの確認（ここでも見ます）────────────────────
            $tg = self::r122TargetCheck($raceId);
            if (!$tg['ok']) {
                $out['code'] = (string) $tg['code'];
                $out['reason'] = (string) $tg['reason'];
                return $out;
            }
            $out['ran'] = true;

            $snap = \DB::table('baganriki_snapshots')
                      ->where('race_id', $raceId)->where('generation', 0)->first();

            // ── 凍結がまだなら、凍結のJobだけ積みます ────────────────
            if ($snap === null) {
                \App\Jobs\R122FreezeRaceJob::dispatch(
                    (string) $date, (string) $kaisuu, (string) $basho,
                    (string) $day, (int) $race);
                $out['code'] = 'FREEZE_DISPATCHED';
                $out['dispatched'][] = 'freeze';
                return $out;
            }

            $sid = (int) $snap->id;

            // ── 旧経路で始まったレースには触りません（010の2-5）──────
            $path = self::r122PathOf($sid);
            if ($path === 'SYNC') {
                $out['code'] = 'PATH_IS_SYNC';
                $out['reason'] = 'このレースは旧経路で始まっているので積みません';
                return $out;
            }
            self::r122FixPath($sid, 'JOB');

            // ── 足りない role のJobを積みます ───────────────────────
            foreach (['1st', '2nd'] as $role) {
                $has = \DB::table('baganriki_ai_attempts')
                         ->where('snapshot_id', $sid)->where('role', $role)
                         ->where('attempt_no', BaganrikiWorker::FIRST)->exists();
                if ($has) { continue; }
                \App\Jobs\R122RunRoleJob::dispatch($sid, $role);
                $out['dispatched'][] = 'role:' . $role;
            }

            // ── 集計も積みます（受領を待たずに期限で動く側）──────────
            \App\Jobs\R122AggregateRaceJob::dispatch($sid, 'ENTRY');
            $out['dispatched'][] = 'aggregate';
            $out['code'] = 'DISPATCHED';
            return $out;
        } catch (\Throwable $e) {
            // @ANCHOR-20261005-AUX-NEVER-BREAKS  記録のための処理で予想を殺しません
            \Log::error('[R122-JOB] 積むところで例外（予想は返します）',
                ['message' => $e->getMessage(),
                 'at' => $e->getFile() . ':' . $e->getLine()]);
            $out['code'] = 'EXCEPTION';
            $out['reason'] = $e->getMessage();
            return $out;
        }
    }

    /**
     * ═══════════════════════════════════════════════════════════════════════
     * @ANCHOR-20261021-R122-APPLYLIVE  実状態の変更を既存の版管理へ入れます
     * ═══════════════════════════════════════════════════════════════════════
     * ご指摘（010の2-2 UpdateRaceLiveJob）：
     *   「正式取消・発走時刻等の実状態変更を既存の版管理に接続し、
     *     必要な再判定を起動します。AIの新規送信や、凍結済み本文の
     *     無断変更は担当させません。」
     *
     * ■ 入れるもの
     *   cancellations  正式取消の馬番。<b>足すだけです。</b>
     *                  一度取消になった馬は戻しません。消す指示は受けません。
     *   live_close     締切の前倒し。<b>延長はしません。</b>
     *                  （表の注記「締切の前倒し。延長はしない」のとおり）
     *
     * ■ 入れないもの
     *   ・凍結済み本文（input_json_1st／input_json_2nd）は1バイトも触りません。
     *   ・anchor_at・cutoff_at・sales_close_at も触りません。これは正本です。
     *     発走時刻が変わったときは、前倒しのぶんを live_close で表します。
     *   ・AIへの送信はしません。
     *
     * ■ 版
     *   実際に変わったときだけ state_revision を1つ増やし、
     *   baganriki_audit_events に1行残します。
     *   何も変わらなければ版も増やしません（毎回増やすと版の意味が薄れます）。
     *
     * @param array $change ['cancellations'=>int[], 'live_close_us'=>?int]
     * @return array ['ok','code','reason','changed','state_revision',
     *                'cancellations','live_close_us']
     */
    public function r122ApplyLive(int $snapshotId, array $change): array
    {
        $out = ['ok' => false, 'code' => null, 'reason' => null, 'changed' => [],
                'state_revision' => null, 'cancellations' => [],
                'live_close_us' => null];
        try {
            $snap = \DB::table('baganriki_snapshots')->where('id', $snapshotId)->first();
            if ($snap === null) {
                $out['code'] = 'NO_SNAPSHOT';
                $out['reason'] = '凍結入力がありません';
                return $out;
            }
            BaganrikiWorker::ensureLive($snapshotId, BaganrikiWorker::nowUs());

            $res = \DB::transaction(function () use ($snapshotId, $change, $snap) {
                $live = \DB::table('baganriki_live_states')
                          ->where('snapshot_id', $snapshotId)
                          ->lockForUpdate()->first();
                if ($live === null) {
                    return ['ok' => false, 'code' => 'NO_LIVE',
                            'reason' => 'ライブ状態の行がありません', 'changed' => []];
                }
                $changed = [];

                // ── ① 正式取消（足すだけ）────────────────────────────
                $cur = (array) json_decode((string) ($live->cancellations ?? '[]'), true);
                $cur = array_values(array_unique(array_map('intval', $cur)));
                sort($cur);
                $add = array_values(array_unique(array_map('intval',
                           (array) ($change['cancellations'] ?? []))));
                $new = $cur;
                foreach ($add as $n) {
                    if ($n > 0 && !in_array($n, $new, true)) { $new[] = $n; }
                }
                sort($new);
                if ($new !== $cur) {
                    $changed['cancellations'] = ['前' => $cur, '後' => $new];
                }

                // ── ② 締切の前倒し（延長はしません）──────────────────
                $curClose = BaganrikiWorker::dbUs($live->live_close ?? null);
                $want = $change['live_close_us'] ?? null;
                $newClose = $curClose;
                if ($want !== null) {
                    $want = (int) $want;
                    $sales = BaganrikiWorker::dbUs($snap->sales_close_at ?? null);
                    if ($sales !== null && $want >= $sales) {
                        // 正本より後ろへは動かしません（延長になります）
                        $changed['live_close_rejected'] =
                            '正本の投票締切より後ろなので入れません';
                    } elseif ($curClose === null || $want < $curClose) {
                        $newClose = $want;
                        $changed['live_close'] = ['前' => $curClose, '後' => $newClose];
                    } else {
                        $changed['live_close_rejected'] =
                            'いまの前倒しより後ろなので入れません（延長はしません）';
                    }
                }

                // ── ③ 実際に変わったときだけ版を増やします ────────────
                $realChange = isset($changed['cancellations'])
                           || isset($changed['live_close']);
                $rev = (int) $live->state_revision;
                if ($realChange) {
                    $rev = $rev + 1;
                    $upd = ['state_revision' => $rev,
                            'updated_at' => BaganrikiWorker::toDb(
                                                BaganrikiWorker::nowUs())];
                    if (isset($changed['cancellations'])) {
                        $upd['cancellations'] = self::r122Json($new);
                        // 有効頭数は集合矛盾のときNULLにする列です。
                        // ここでは触りません（既存の計算に任せます）。
                    }
                    if (isset($changed['live_close'])) {
                        $upd['live_close'] = BaganrikiWorker::toDb($newClose);
                    }
                    \DB::table('baganriki_live_states')
                      ->where('snapshot_id', $snapshotId)
                      ->where('state_revision', (int) $live->state_revision)
                      ->update($upd);

                    BaganrikiWorker::event(
                        (string) $snap->race_id, $snapshotId, 'R122_LIVE_APPLIED',
                        (int) $live->state_revision, $rev, $changed, null,
                        BaganrikiWorker::nowUs()
                    );
                }
                return ['ok' => true, 'code' => $realChange ? 'APPLIED' : 'NO_CHANGE',
                        'reason' => $realChange ? '実状態を入れました'
                                                : '変わるところがありません',
                        'changed' => $changed, 'state_revision' => $rev,
                        'cancellations' => $new, 'live_close_us' => $newClose];
            });

            $out['ok']     = (bool) ($res['ok'] ?? false);
            $out['code']   = (string) ($res['code'] ?? '');
            $out['reason'] = $res['reason'] ?? null;
            $out['changed'] = (array) ($res['changed'] ?? []);
            $out['state_revision'] = $res['state_revision'] ?? null;
            $out['cancellations']  = (array) ($res['cancellations'] ?? []);
            $out['live_close_us']  = $res['live_close_us'] ?? null;
            return $out;
        } catch (\Throwable $e) {
            \Log::error('[R122-LIVE] 実状態を入れるところで例外',
                ['message' => $e->getMessage(),
                 'at' => $e->getFile() . ':' . $e->getLine()]);
            $out['code'] = 'EXCEPTION';
            $out['reason'] = $e->getMessage();
            return $out;
        }
    }

    /** JSONへ（既存の書き方にそろえます） */
    private static function r122Json($v): string
    {
        return (string) json_encode($v,
            JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PRESERVE_ZERO_FRACTION);
    }

    /**
     * ═══════════════════════════════════════════════════════════════════════
     * @ANCHOR-20261021-R122-USAGE  実モデルと使用量を残します（010の7章⑤）
     * ═══════════════════════════════════════════════════════════════════════
     * ご指摘：
     *   「usageと実モデルの記録、初回24回／最大48回の費用を示すこと。」
     *   「2nd自身のトークナイザ、実モデル、finish_reason、usage、
     *     JSON検証結果を揃えてください。」
     *
     *   こちらで決めた名前ではなく、<b>応答に書かれていたモデル名</b>と
     *   使用量をそのまま残します。
     *   新しい表は作りません。baganriki_audit_events に1行入れます。
     *     kind       R122_USAGE
     *     related_id role#attempt_no
     *     diagnostics {model, stop, usage, bytes, complete}
     *
     * @param array $call r122CallAi の戻り
     */
    public static function r122RecordUsage(int $snapshotId, string $role,
                                           int $attemptNo, array $call): void
    {
        try {
            if (!\Schema::hasTable('baganriki_audit_events')) { return; }
            $snap = \DB::table('baganriki_snapshots')->where('id', $snapshotId)->first();
            $u = $call['usage'] ?? null;
            BaganrikiWorker::event(
                (string) ($snap->race_id ?? ''), $snapshotId, 'R122_USAGE',
                null, null,
                [
                    'role'        => $role,
                    'attempt_no'  => $attemptNo,
                    // 応答が名乗ったモデル（設定値ではありません）
                    'model'       => (string) ($call['model'] ?? ''),
                    'stop'        => $call['stop'] ?? null,
                    'usage'       => is_array($u) ? $u : null,
                    'raw_bytes'   => strlen((string) ($call['raw'] ?? '')),
                    'complete'    => (bool) ($call['complete'] ?? false),
                    'code'        => (string) ($call['code'] ?? ''),
                ],
                $role . '#' . $attemptNo,
                BaganrikiWorker::nowUs()
            );
        } catch (\Throwable $e) {
            // 記録で落ちても送信は止めません
            \Log::error('[R122-USAGE] 使用量を残せません',
                ['message' => $e->getMessage()]);
        }
    }

    /**
     * @ANCHOR-20261021-R122-USAGE  そのレースの使用量をまとめて返します
     *
     *   なるへ出す「初回24回／最大48回の費用」は、ここの実測から出します。
     *   単価は資料に書くので、ここでは<b>トークン数と実モデル</b>だけです。
     *
     * @return array ['rows'=>[…], 'by_model'=>[model=>['in','out','calls']]]
     */
    public static function r122UsageOf(int $snapshotId): array
    {
        $out = ['rows' => [], 'by_model' => []];
        if (!\Schema::hasTable('baganriki_audit_events')) { return $out; }
        $rows = \DB::table('baganriki_audit_events')
                  ->where('snapshot_id', $snapshotId)
                  ->where('kind', 'R122_USAGE')
                  ->orderBy('id')->get(['diagnostics', 'happened_at']);
        foreach ($rows as $r) {
            $d = json_decode((string) $r->diagnostics, true);
            if (!is_array($d)) { continue; }
            $m = (string) ($d['model'] ?? '');
            $u = (array) ($d['usage'] ?? []);
            // Anthropic は input_tokens／output_tokens、
            // DeepSeek は prompt_tokens／completion_tokens です。
            $in  = (int) ($u['input_tokens']  ?? ($u['prompt_tokens']     ?? 0));
            $o   = (int) ($u['output_tokens'] ?? ($u['completion_tokens'] ?? 0));
            $d['in'] = $in; $d['out'] = $o;
            $d['at'] = (string) $r->happened_at;
            $out['rows'][] = $d;
            if (!isset($out['by_model'][$m])) {
                $out['by_model'][$m] = ['in' => 0, 'out' => 0, 'calls' => 0];
            }
            $out['by_model'][$m]['in']    += $in;
            $out['by_model'][$m]['out']   += $o;
            $out['by_model'][$m]['calls'] += 1;
        }
        return $out;
    }

    /**
     * ═══════════════════════════════════════════════════════════════════════
     * @ANCHOR-20261021-R122-READGATE  非公開の読取経路（010の7章⑤）
     * ═══════════════════════════════════════════════════════════════════════
     * ご指摘（010の7章⑤）：
     *   「12個のrace_idへの限定、<b>非公開の読取経路</b>、usageと実モデルの
     *     記録、初回24回／最大48回の費用を示すこと。」
     *
     * ■ 見つかったこと
     *   読取API（GET /api/baganriki/r12-2/races/{race_id}）に
     *   <b>認証が1つも掛かっていませんでした。</b>
     *   さらに画面側（Flutter）の race_content_page に、
     *   <b>誰にでも見える「r12.2」のボタン</b>が出ています。
     *   条件で隠していません（管理者判定も debug 判定もありません）。
     *
     *   いまは記録が1件もないので空が返るだけです。ですが
     *   <b>10月24日に旗を上げた瞬間、その12レースの予想が
     *   一般の利用者に見えます。</b>「非公開の検証」になりません。
     *   race_id は日付と場と番号なので、総当たりも簡単です。
     *
     * ■ 塞ぎ方（既定は閉じる）
     *   .env の BAGANRIKI_R122_READ で決めます。
     *     （未設定・key） 鍵が合ったときだけ中身を返します【既定】
     *     open           誰でも見られます
     *     off            誰にも見せません（鍵があっても）
     *   鍵は BAGANRIKI_R122_READ_KEY に入れ、
     *     ヘッダ  X-R122-Key: <鍵>
     *     クエリ  ?r122_key=<鍵>
     *   のどちらかで渡します。
     *   <b>鍵が未設定なら、誰も中身を見られません。</b>
     *   対象レースの限定（TARGETS が空なら1レースも送らない）と
     *   同じ考え方です。設定を入れ忘れた側が安全に倒れます。
     *
     * ■ 画面（Flutter）は作り直しません
     *   鍵を渡さないので「まだありません」と出るだけです。
     *   検証する側は、鍵を付けてURLを直接開けば中身を読めます。
     *     https://…/api/baganriki/r12-2/races/20261024-5-05-1-1?r122_key=<鍵>
     *   PWAの再ビルドを24日までに挟まずに済みます。
     *
     * ■ artisan（コマンド）からは素通りします
     *   試験はコマンドから呼びます。コマンドは外から叩けないので、
     *   ここで止める意味がありません。止めると試験が全部落ちます。
     *
     * @param array $opt 試験用。force_web=true で web とみなし、key で鍵を渡す
     * @return array ['ok','code','reason','mode']
     */
    public static function r122ReadGate(array $opt = []): array
    {
        $mode = strtolower(trim((string) env('BAGANRIKI_R122_READ', 'key')));
        if (!in_array($mode, ['key', 'open', 'off'], true)) { $mode = 'key'; }
        $out = ['ok' => false, 'code' => null, 'reason' => null, 'mode' => $mode];

        // コマンドからの呼び出しは素通りします（外から叩けないため）
        $isWeb = (bool) ($opt['force_web'] ?? false);
        if (!$isWeb) {
            try {
                if (app()->runningInConsole()) {
                    $out['ok'] = true; $out['code'] = 'CONSOLE';
                    return $out;
                }
            } catch (\Throwable $e) {
                // 判定できないときは web とみなします（安全側）
            }
        }

        if ($mode === 'open') {
            $out['ok'] = true; $out['code'] = 'OPEN';
            return $out;
        }
        if ($mode === 'off') {
            $out['code'] = 'NOT_PUBLIC';
            $out['reason'] = 'この記録はまだ公開していません';
            return $out;
        }

        $want = (string) env('BAGANRIKI_R122_READ_KEY', '');
        if ($want === '') {
            // 鍵が未設定なら、誰にも見せません
            $out['code'] = 'NOT_PUBLIC';
            $out['reason'] = 'この記録はまだ公開していません';
            return $out;
        }

        $got = (string) ($opt['key'] ?? '');
        if ($got === '' && !array_key_exists('key', $opt)) {
            try {
                $req = request();
                $got = (string) ($req->header('X-R122-Key') ?? '');
                if ($got === '') { $got = (string) ($req->query('r122_key') ?? ''); }
            } catch (\Throwable $e) {
                $got = '';
            }
        }
        if ($got === '' || !hash_equals($want, $got)) {
            $out['code'] = 'NOT_PUBLIC';
            $out['reason'] = 'この記録はまだ公開していません';
            return $out;
        }
        $out['ok'] = true; $out['code'] = 'KEY';
        return $out;
    }
