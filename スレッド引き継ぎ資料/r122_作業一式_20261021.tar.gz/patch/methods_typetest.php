
    /**
     * ═══════════════════════════════════════════════════════════════════════
     * @ANCHOR-20261021-R122-TYPETEST  型保持の通し試験（010の3章）
     * ═══════════════════════════════════════════════════════════════════════
     * 10月21日010（なる）の第3章ぜんぶに対する試験です。
     *
     * ご指摘（3-5 最低限確認する例）：
     *   「・数値1.99999999999999999999と、同じ内容の文字列。
     *     ・整数1、小数1.0、指数1e0と、整数必須フィールドの判定。
     *     ・[]、{}、数値キーを持つオブジェクト。
     *     ・馬行の並べ替え、値を変更した後の保存。
     *     ・5,001個目の長い数値。
     *     ・同じ値の別インスタンスを使った正常な訂正。
     *     これらをextractだけで終わらせず、診断→訂正比較→保存→読戻しまで
     *     通します。」
     *
     * ■ 2段に分けています
     *   ①（T群）  読み・書き・比べの単体。6例そのものをここで通します。
     *   ②（P群）  <b>本番の関数で</b>診断→訂正比較→保存→読戻しまで通します。
     *             r122InspectResponse ／ r122AcceptedHorses ／
     *             r122SaveValidation ／ r122NormalPart を実際に呼びます。
     *
     * ■ 「地図なし」との対比を出します
     *   型の地図を渡さないと何を見逃すかを、同じ材料で並べて出します。
     *   PHPの === では
     *     ・2e0 と 2.0        どちらも float(2.0) なので<b>同じ</b>に見えます
     *     ・{} と []          どちらも空配列なので<b>同じ</b>に見えます
     *     ・1.999…（数値）と "1.999…"（文字列）
     *                         どちらもPHP文字列なので<b>同じ</b>に見えます
     *   地図を渡すと、どれも別物として見ます。
     *
     * ■ 実AIは1回も呼びません。全部ロールバックします。
     */
    private function runR122TypeTest(string $root): void
    {
        self::r122Autoload();
        $A = \App\Http\Controllers\Api\AiController::class;
        $W = \App\Http\Controllers\Api\BaganrikiWorker::class;
        $R = \App\Http\Controllers\Api\BaganrikiResponse::class;
        $J = \App\Http\Controllers\Api\BaganrikiJson::class;
        $BEGIN = \App\Http\Controllers\Api\BaganrikiResponse::BEGIN;
        $END   = \App\Http\Controllers\Api\BaganrikiResponse::END;

        $vDir = rtrim($root, '/') . '/validation/normal';
        $this->info('════════════════════════════════════════════════════════');
        $this->info(' r12.2 型保持の通し試験（010の3章）');
        $this->info('════════════════════════════════════════════════════════');
        $this->line('  実行時刻 : ' . date('c'));
        $this->line('  資料     : ' . $vDir);
        $this->warn('  ※ 実AIは1回も呼びません');
        $this->warn('  ※ 全部ロールバックします。DBへ残る書き込みは0件です');
        $this->line('');

        foreach (['MIXED_N16_1st_input.json', 'MIXED_N16_1st_output.json',
                  'MIXED_N16_2nd_input.json', 'MIXED_N16_2nd_output.json'] as $fN) {
            if (!is_file($vDir . '/' . $fN)) {
                $this->error('  資料がありません: ' . $vDir . '/' . $fN);
                return;
            }
        }

        $pass = 0; $fail = 0;
        $check = function (string $id, string $what, $got, $want) use (&$pass, &$fail) {
            $okk = ($got === $want);
            if ($okk) { $pass++; } else { $fail++; }
            $this->line(sprintf('  %s %-10s %-54s %s',
                $okk ? '○' : '×', $id, $what,
                $okk ? '' : ('得=' . var_export($got, true)
                           . ' 期待=' . var_export($want, true))));
        };

        // ═══════════════════════════════════════════════════════════════
        // ① 読み・書き・比べの単体（3-5 の6例）
        // ═══════════════════════════════════════════════════════════════
        $this->info('── ① 3-5 の6例（読み・書き・比べ）──');

        // 例1 数値 1.99999999999999999999 と、同じ内容の文字列
        $aTxt = '{"x":1.99999999999999999999}';
        $bTxt = '{"x":"1.99999999999999999999"}';
        $da = $J::decode($aTxt); $db = $J::decode($bTxt);
        $check('T-01', 'どちらも走査を通る', [$da['ok'], $db['ok']], [true, true]);
        $check('T-02', '数値と数値文字列を別物と見る',
            $J::same($da['value'], $da['map'], $db['value'], $db['map'])['same'], false);
        $check('T-03', '数値の側は引用符なしで書き戻る',
            $J::encode($da['value'], $da['map']), '{"x":1.99999999999999999999}');
        $check('T-04', '文字列の側は文字列のまま',
            $J::encode($db['value'], $db['map']), '{"x":"1.99999999999999999999"}');
        $check('T-05', '往復しても型も値も残る',
            $J::sameJson($aTxt, $J::encode($da['value'], $da['map']))['same'], true);
        $check('T-06', '【参考】PHPの === では見分けられない',
            ($da['value'] === $db['value']), true);

        // 例2 整数1・小数1.0・指数1e0 と、整数必須の判定
        $i1 = $J::decode('{"v":1}'); $d1 = $J::decode('{"v":1.0}');
        $e1 = $J::decode('{"v":1e0}');
        $check('T-07', '1 と 1.0 は別物',
            $J::same($i1['value'], $i1['map'], $d1['value'], $d1['map'])['same'], false);
        $check('T-08', '1 と 1e0 も別物',
            $J::same($i1['value'], $i1['map'], $e1['value'], $e1['map'])['same'], false);
        $check('T-09', '1.0 と 1e0 も別物（表記が違う）',
            $J::same($d1['value'], $d1['map'], $e1['value'], $e1['map'])['same'], false);
        $check('T-10', '表記を無視すれば同じ値と見られる',
            $J::same($i1['value'], $i1['map'], $d1['value'], $d1['map'], false)['same'],
            true);
        $check('T-11', '1.0 を書き戻すと 1.0（1 に丸めない）',
            $J::encode($d1['value'], $d1['map']), '{"v":1.0}');
        $check('T-12', '1e0 を書き戻すと 1e0',
            $J::encode($e1['value'], $e1['map']), '{"v":1e0}');
        $check('T-13', '整数は PHP の int のまま（is_int が通る）',
            is_int($i1['value']['v']), true);
        $check('T-14', '1.0 は PHP の float（整数必須の検査が落とせる）',
            is_float($d1['value']['v']), true);
        $check('T-15', '1e0 も PHP の float', is_float($e1['value']['v']), true);
        $check('T-16', '【参考】1.0 と 1e0 は === では同じ',
            ($d1['value'] === $e1['value']), true);

        // 例3 []・{}・数値キーを持つオブジェクト
        $ar = $J::decode('{"a":[]}'); $ob = $J::decode('{"a":{}}');
        $check('T-17', '[] と {} を別物と見る',
            $J::same($ar['value'], $ar['map'], $ob['value'], $ob['map'])['same'], false);
        $check('T-18', '[] は [] のまま書き戻る',
            $J::encode($ar['value'], $ar['map']), '{"a":[]}');
        $check('T-19', '{} は {} のまま書き戻る',
            $J::encode($ob['value'], $ob['map']), '{"a":{}}');
        $check('T-20', '【参考】PHPでは空配列どちらも同じ',
            ($ar['value'] === $ob['value']), true);
        $nk = $J::decode('{"a":{"0":"x","1":"y"}}');
        $ls = $J::decode('{"a":["x","y"]}');
        $check('T-21', '数値キーのオブジェクトと配列を別物と見る',
            $J::same($nk['value'], $nk['map'], $ls['value'], $ls['map'])['same'], false);
        $check('T-22', '数値キーのオブジェクトは {} のまま書き戻る',
            $J::encode($nk['value'], $nk['map']), '{"a":{"0":"x","1":"y"}}');
        $check('T-23', '配列は [] のまま', $J::encode($ls['value'], $ls['map']),
            '{"a":["x","y"]}');
        $check('T-24', '【参考】PHPでは数値キーのオブジェクトと配列が同じ',
            ($nk['value'] === $ls['value']), true);

        // 例4 馬行の並べ替えと、値を変更した後の保存
        $srcT = '{"horses":[{"horse_no":3,"s":1.0},{"horse_no":1,"s":2e0},'
              . '{"horse_no":2,"s":3}]}';
        $dT = $J::decode($srcT);
        $vT = $dT['value'];
        $ordT = array_column($vT['horses'], 'horse_no');
        asort($ordT);
        $newH = []; $newM = $J::mapWithKind($J::emptyMap(), [], 'obj');
        $newM = $J::mapWithKind($newM, ['horses'], 'arr');
        $ixT = 0;
        foreach (array_keys($ordT) as $fromT) {
            $newH[] = $vT['horses'][$fromT];
            $newM = $J::mapMerge($newM,
                $J::mapMove($dT['map'], ['horses', (int) $fromT], ['horses', $ixT]));
            $ixT++;
        }
        $sortedT = ['horses' => $newH];
        $encT = $J::encode($sortedT, $newM);
        $check('T-25', '並べ替えても表記が付いてくる', $encT,
            '{"horses":[{"horse_no":1,"s":2e0},{"horse_no":2,"s":3},'
            . '{"horse_no":3,"s":1.0}]}');
        $check('T-26', '並べ替えた本文も走査を通る', $J::decode($encT)['ok'], true);
        $sortedT['horses'][1]['s'] = 9.5;
        $check('T-27', '値を変えたら、その値が数値として入る',
            $J::encode($sortedT, $newM),
            '{"horses":[{"horse_no":1,"s":2e0},{"horse_no":2,"s":9.5},'
            . '{"horse_no":3,"s":1.0}]}');
        $check('T-28', '変えていない位置の表記は残る',
            (strpos($J::encode($sortedT, $newM), '"s":2e0') !== false)
            && (strpos($J::encode($sortedT, $newM), '"s":1.0') !== false), true);

        // 例5 5,001個目の長い数値
        $bigT = '1.' . str_repeat('9', 40);
        $rowsT = [];
        for ($iT = 0; $iT < 5002; $iT++) { $rowsT[] = '{"n":' . $bigT . '}'; }
        $manyT = '{"rows":[' . implode(',', $rowsT) . ']}';
        $dmT = $J::decode($manyT);
        $check('T-29', '5,002件でも走査を通る', $dmT['ok'], true);
        $check('T-30', '型の地図は監査の5,000件で切れない（010の3-1）',
            (int) $dmT['stats']['number_paths'], 5002);
        $check('T-31', '監査に残す一覧は5,000件のまま',
            (int) $dmT['stats']['numbers'], 5000);
        $encM = $J::encode($dmT['value'], $dmT['map']);
        $check('T-32', '5,001個目も数値として書き戻る（文字列へ化けない）',
            substr_count($encM, '"n":"'), 0);
        $dm2T = $J::decode($encM);
        $check('T-33', '往復しても全件が同じ',
            $J::same($dmT['value'], $dmT['map'], $dm2T['value'], $dm2T['map'])['same'],
            true);
        $lastT = $dmT['value']['rows'][5001]['n'];
        $check('T-34', '5,001個目も丸まっていない',
            is_string($lastT) ? $lastT : 'not-string', $bigT);

        // 例6 同じ値の別インスタンスを使った正常な訂正
        $r1T = $J::decode('{"v":1.50}'); $r2T = $J::decode('{"v":1.50}');
        $check('T-35', '別に読んだ同じ本文は同じと見る（別インスタンス問題なし）',
            $J::same($r1T['value'], $r1T['map'], $r2T['value'], $r2T['map'])['same'],
            true);
        $check('T-36', '1.50 と 1 は別物（整数と小数の区別は残る）',
            $J::same($r1T['value'], $r1T['map'],
                     $J::decode('{"v":1}')['value'],
                     $J::decode('{"v":1}')['map'])['same'], false);
        $check('T-37', '1.50 は 1.50 のまま保存される（丸めない）',
            $J::encode($r1T['value'], $r1T['map']), '{"v":1.50}');

        // 比べ方の細かいところ
        $k1T = $J::decode('{"a":1,"b":2}'); $k2T = $J::decode('{"b":2,"a":1}');
        $check('T-38', 'オブジェクトのキー順は無視する',
            $J::same($k1T['value'], $k1T['map'], $k2T['value'], $k2T['map'])['same'],
            true);
        $l1T = $J::decode('{"a":[1,2]}'); $l2T = $J::decode('{"a":[2,1]}');
        $check('T-39', '配列の順序は保持する（違えば別物）',
            $J::same($l1T['value'], $l1T['map'], $l2T['value'], $l2T['map'])['same'],
            false);
        $check('T-40', '食い違った経路を返す',
            (string) $J::same($l1T['value'], $l1T['map'],
                              $l2T['value'], $l2T['map'])['where'], '["a",0]');
        $n1T = $J::decode('{"a":null}'); $s1T = $J::decode('{"a":"null"}');
        $check('T-41', 'null と "null" を別物と見る',
            $J::same($n1T['value'], $n1T['map'], $s1T['value'], $s1T['map'])['same'],
            false);
        $b1T = $J::decode('{"a":true}'); $t1T = $J::decode('{"a":1}');
        $check('T-42', 'true と 1 を別物と見る',
            $J::same($b1T['value'], $b1T['map'], $t1T['value'], $t1T['map'])['same'],
            false);

        // ═══════════════════════════════════════════════════════════════
        // ② 本番の関数で 診断→訂正比較→保存→読戻し まで通します
        // ═══════════════════════════════════════════════════════════════
        $this->info('');
        $this->info('── ② 本番の関数で 診断→訂正比較→保存→読戻し ──');

        $rd = static fn(string $fN) => (string) file_get_contents($vDir . '/' . $fN);
        $in1  = json_decode($rd('MIXED_N16_1st_input.json'), true);
        $in2  = json_decode($rd('MIXED_N16_2nd_input.json'), true);
        $out2 = json_decode($rd('MIXED_N16_2nd_output.json'), true);
        $baseTxt = $rd('MIXED_N16_1st_output.json');
        $jj = static fn($v) => (string) json_encode($v,
            JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PRESERVE_ZERO_FRACTION);

        $this->line('      資料の value の書き方 : '
            . (string) (preg_match('/"value":[^,}]*/', $baseTxt, $mTmp) ? $mTmp[0] : '（無し）'));

        $ok = true;
        \DB::beginTransaction();
        try {
            $ctrl = app($A);
            $seqT = 0;
            // 凍結入力と枠を本番の3段（reserve→allowSend→receive）で作ります
            $mk = function (string $raw1, ?string $raw2 = null)
                  use ($in1, $in2, $jj, $BEGIN, $END, &$seqT, $W): array {
                $seqT++;
                $now   = $W::nowUs();
                $sales = $now + 3600 * 1000000;
                $nums  = [];
                foreach ((array) $in1['runners'] as $rr) { $nums[] = (int) $rr['horse_no']; }
                $sid = \DB::table('baganriki_snapshots')->insertGetId([
                    'race_id' => '20261018-9-98-9-' . $seqT,   // 場98は実在しません
                    'generation' => 900,
                    'run_id' => 'TT',
                    'snapshot_hash'   => (string) $in1['snapshot_hash'],
                    'input_json_1st'  => $jj($in1), 'input_json_2nd' => $jj($in2),
                    'frozen_nums'     => $jj($nums),
                    'allocation_mode' => (string) $in1['allocation_mode'],
                    'mode'            => (string) $in1['mode'],
                    'mode_status'     => (string) $in1['mode_status'],
                    'target_count'    => (int) $in1['target_count'],
                    'quota_1st'       => $jj($in1['quota']),
                    'sales_close_at'  => $W::toDb($sales),
                    'created_at'      => $W::toDb($now),
                ]);
                \DB::table('baganriki_live_states')->insert([
                    'snapshot_id' => $sid, 'cancellations' => $jj([]),
                    'active_count' => count($nums),
                    'live_target_count' => (int) $in1['target_count'],
                    'live_quota' => $jj($in1['quota']), 'live_close' => null,
                    'state_revision' => 0, 'response_revision' => 0,
                    'publication_revision' => 0, 'latest_publication_id' => null,
                    'updated_at' => $W::toDb($now),
                ]);
                $put = function (string $role, int $no, string $body)
                       use ($sid, $BEGIN, $END, $W): void {
                    $r = $W::reserve((int) $sid, $role, $no, $W::nowUs());
                    if (!$r['ok']) { return; }
                    $W::allowSend((string) $r['token'], $W::nowUs());
                    $W::receive((string) $r['token'], $BEGIN . $body . $END,
                                true, $W::nowUs());
                };
                $put('1st', $W::FIRST, $raw1);
                if ($raw2 !== null) { $put('1st', $W::FIX, $raw2); }
                return ['sid' => (int) $sid, 'nums' => $nums];
            };

            // ── 初回：1頭落とし、1頭目の value を指数（2e0）にします ──
            //   指数は「値は同じで表記だけ違う」ので、PHPの === では
            //   小数（2.0）と見分けが付きません。
            $fa = json_decode($baseTxt, true);
            $goneNo = (int) $fa['horses'][2]['horse_no'];
            array_splice($fa['horses'], 2, 1);
            $firstTxt = preg_replace('/"value":2\.0/', '"value":2e0', $jj($fa), 1);
            $check('P-01', '初回の本文に指数の表記が入っている',
                strpos((string) $firstTxt, '"value":2e0') !== false, true);

            // ── 訂正：全頭そろえ、1頭目の value は小数（2.0）のまま ──
            $fixTxt = $jj(json_decode($baseTxt, true));
            $m1 = $mk((string) $firstTxt, (string) $fixTxt);

            $i1R = $ctrl->r122InspectResponse($m1['sid'], '1st', $W::FIRST);
            $check('P-02', '初回を診断できた', (bool) $i1R['ok'], true);
            $check('P-03', '直すところがある', (bool) $i1R['needs_fix'], true);
            $check('P-04', '型の地図が返っている',
                is_array($i1R['normal_map'] ?? null), true);
            $kP = $J::pathKey(['1', 'evidence', 0, 'facts', 0, 'value']);
            $check('P-05', '1頭目の value は指数の表記で控えられている',
                (string) ((($i1R['normal_map']['num'][$kP] ?? [])['form']) ?? ''), 'exp');

            $i2R = $ctrl->r122InspectResponse($m1['sid'], '1st', $W::FIX);
            $check('P-06', '訂正を診断できた', (bool) $i2R['ok'], true);
            $check('P-07', '訂正側の value は小数の表記',
                (string) ((($i2R['normal_map']['num'][$kP] ?? [])['form']) ?? ''), 'dec');

            // 地図なし＝これまでの比べ方では見逃します
            $accOld = $R::acceptCorrection($i1R['normal'], $i2R['normal'], null, null,
                $m1['nums'], $i1R['repair_scope'], $i2R['row_valid']);
            $check('P-08', '【地図なし】表記だけの差を見逃して採用してしまう',
                (bool) $accOld['ok'], true);
            // 地図あり＝型まで見ます
            $accNew = $R::acceptCorrection($i1R['normal'], $i2R['normal'], null, null,
                $m1['nums'], $i1R['repair_scope'], $i2R['row_valid'],
                (array) $i1R['normal_map'], (array) $i2R['normal_map']);
            $check('P-09', '【地図あり】範囲外を変えているので採用しない',
                (bool) $accNew['ok'], false);
            $check('P-10', '理由に「対象外」が出る',
                strpos((string) ($accNew['reason'] ?? ''), '対象外') !== false, true);

            // 本番の採否（r122AcceptedHorses）も同じ判断になること
            $accR = $ctrl->r122AcceptedHorses($m1['sid'], '1st');
            $check('P-11', '本番の採否でも訂正を採用しない',
                (string) ($accR['code'] ?? ''), 'FIX_REJECTED');
            $check('P-12', '初回の正常部分は残る（15頭）',
                count((array) ($accR['merged'] ?? [])), 15);

            // ── ② {} と [] の違い ────────────────────────────────────
            $this->info('   ── {} と [] の違い（PHPでは同じ空配列）──');
            $fc = json_decode($baseTxt, true);
            array_splice($fc['horses'], 2, 1);
            $t3 = preg_replace('/"counterevidence":\[\]/', '"counterevidence":{}',
                               $jj($fc), 1);
            $check('P-13', '初回の本文に {} が入っている',
                strpos((string) $t3, '"counterevidence":{}') !== false, true);
            $m2 = $mk((string) $t3, (string) $jj(json_decode($baseTxt, true)));
            $j1R = $ctrl->r122InspectResponse($m2['sid'], '1st', $W::FIRST);
            $j2R = $ctrl->r122InspectResponse($m2['sid'], '1st', $W::FIX);
            $kK = $J::pathKey(['1', 'counterevidence']);
            $check('P-14', '1頭目の counterevidence は obj と控えられている',
                (string) (($j1R['normal_map']['kind'][$kK]) ?? ''), 'obj');
            $check('P-15', '訂正側は arr',
                (string) (($j2R['normal_map']['kind'][$kK]) ?? ''), 'arr');
            $a2Old = $R::acceptCorrection($j1R['normal'], $j2R['normal'], null, null,
                $m2['nums'], $j1R['repair_scope'], $j2R['row_valid']);
            $check('P-16', '【地図なし】{} と [] の差を見逃して採用してしまう',
                (bool) $a2Old['ok'], true);
            $a2New = $R::acceptCorrection($j1R['normal'], $j2R['normal'], null, null,
                $m2['nums'], $j1R['repair_scope'], $j2R['row_valid'],
                (array) $j1R['normal_map'], (array) $j2R['normal_map']);
            $check('P-17', '【地図あり】採用しない', (bool) $a2New['ok'], false);

            // ── ③ 正しい全頭訂正は、型を見ても通ること ───────────────
            $this->info('   ── 正しい全頭訂正は通ること ──');
            $fixSame = preg_replace('/"value":2\.0/', '"value":2e0',
                                    $jj(json_decode($baseTxt, true)), 1);
            $m3 = $mk((string) $firstTxt, (string) $fixSame);
            $accG = $ctrl->r122AcceptedHorses($m3['sid'], '1st');
            $check('P-18', '正しい全頭訂正は採用する',
                (string) ($accG['code'] ?? ''), 'FIX_APPLIED');
            $check('P-19', '欠けていた馬が救済される',
                in_array($goneNo, array_map('intval',
                    (array) ($accG['rescued'] ?? [])), true), true);
            $check('P-20', '全16頭そろう',
                count((array) ($accG['merged'] ?? [])), 16);
            $check('P-21', '当てた行の地図も返ってくる',
                is_array($accG['merged_map'] ?? null), true);

            // ── ④ 保存 → 読戻し ─────────────────────────────────────
            $this->info('   ── 保存 → 読戻し（専用シリアライザと専用パーサ）──');
            $aid = (int) \DB::table('baganriki_ai_attempts')
                     ->where('snapshot_id', $m3['sid'])->where('role', '1st')
                     ->where('attempt_no', $W::FIRST)->value('id');
            $rdN = $ctrl->r122NormalPart($aid);
            $check('P-22', '保存した正常部分を専用パーサで読み戻せる',
                (bool) $rdN['ok'], true);
            $check('P-23', '保存本文に指数の表記が残っている',
                strpos((string) ($rdN['raw'] ?? ''), '"value":2e0') !== false, true);
            $i3R = $ctrl->r122InspectResponse($m3['sid'], '1st', $W::FIRST);
            $rt = $ctrl->r122NormalRoundTrip($aid, (array) $i3R['normal'],
                                             (array) $i3R['normal_map']);
            $check('P-24', '読み戻した値と型が、保存前と一致する',
                [(bool) $rt['ok'], (bool) $rt['same']], [true, true]);
            $check('P-25', '【参考】通常の json_encode では表記が落ちる',
                strpos((string) json_encode($i3R['normal']), '"value":2e0') !== false,
                false);

            // 40桁の数値が、引用符なしで保存されること
            $bigTxt = preg_replace('/"value":2\.0/',
                '"value":1.' . str_repeat('9', 40), $jj(json_decode($baseTxt, true)), 1);
            $m4 = $mk((string) $bigTxt);
            $i4R = $ctrl->r122InspectResponse($m4['sid'], '1st', $W::FIRST);
            $check('P-26', '40桁の数値でも診断できた', (bool) $i4R['ok'], true);
            $aid4 = (int) \DB::table('baganriki_ai_attempts')
                      ->where('snapshot_id', $m4['sid'])->where('role', '1st')
                      ->where('attempt_no', $W::FIRST)->value('id');
            $rd4 = $ctrl->r122NormalPart($aid4);
            $check('P-27', '40桁の数値は引用符なしで保存されている',
                strpos((string) ($rd4['raw'] ?? ''),
                       '"value":1.' . str_repeat('9', 40)) !== false, true);
            $check('P-28', '【参考】通常の json_encode では引用符が付く',
                strpos((string) json_encode($i4R['normal']),
                       '"value":"1.' . str_repeat('9', 40) . '"') !== false, true);
            $rt4 = $ctrl->r122NormalRoundTrip($aid4, (array) $i4R['normal'],
                                              (array) $i4R['normal_map']);
            $check('P-29', '40桁でも読み戻して一致する',
                [(bool) $rt4['ok'], (bool) $rt4['same']], [true, true]);
            $check('P-30', '読み戻した値は丸まっていない',
                (string) (($rd4['value'][1]['evidence'][0]['facts'][0]['value']) ?? ''),
                '1.' . str_repeat('9', 40));
        } catch (\Throwable $e) {
            $ok = false;
            $this->error('  × 例外 : ' . $e->getMessage());
            $this->error('    ' . $e->getFile() . ':' . $e->getLine());
        } finally {
            \DB::rollBack();
        }

        $left = (int) \DB::table('baganriki_snapshots')
                  ->where('race_id', 'like', '20261018-9-98-9-%')->count();
        $this->line('');
        $this->line('  ロールバック後  仮snapshot ' . $left . ' 件');
        $this->line('');
        $this->line('  判定件数 : ' . ($pass + $fail) . ' 件');
        $this->line('  合格     : ' . $pass . ' 件');
        $this->line('  不合格   : ' . $fail . ' 件');
        $this->line('');
        $this->info('════════════════════════════════════════════════════════');
        if ($fail === 0 && $ok) {
            $this->info(' 型保持は診断→訂正比較→保存→読戻しまで通りました'
                      . '（DBへ残る書き込み0件）');
        } else {
            $this->error(' 通らなかった箇所があります。上の × をご確認ください');
        }
        $this->info('════════════════════════════════════════════════════════');
    }
