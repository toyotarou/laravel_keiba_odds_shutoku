
    /**
     * ═══════════════════════════════════════════════════════════════════════
     * @ANCHOR-20261020-R122-RESP  応答検証と局所回復（本番接続）
     * ═══════════════════════════════════════════════════════════════════════
     * 根拠：server_contract_r12.2.txt 6章・7章・10章
     *
     * ■ 通す順番（本番と同じ）
     *   extract → checkEnvelope → isolateHorses → BaganrikiDiagnose::run
     *
     * ■ 何を正とするか
     *   凍結入力（snapshot）と、予約済みの role を正とします。
     *   <b>応答が名乗る役は照合相手を選ぶのに使いません。</b>
     *   封筒照合は、予約した role の固定入力に対してだけ行います。
     *
     * ■ 局所回復
     *   馬番欠落・重複・未知馬・局所の項目不正は、その範囲だけ隔離します。
     *   正常な他馬はそのまま残します。
     *   直してよい範囲は repair_scope として baganriki_validation_results に残します。
     *
     * @return array ['ok','stage','code','reason','accepted','needs_fix',
     *                'repair_scope','normal','row_valid','diag']
     */
    /**
     * @ANCHOR-20261020-R122-SALVAGE  採点まわりだけの指摘コード
     *   この範囲の指摘しか無い馬は、採点欄だけを落として行は残します。
     *   根拠・5系統・帯・順位・資格の指摘が混ざっていたら残しません。
     */
    public const R122_SCORE_ONLY_CODES = [
        'SCORES_TYPE', 'SCORES_UNKNOWN_KEY', 'SCORES_MISSING', 'SCORES_RANGE',
        'OBSERVED_SUM', 'OBSERVED_CAP', 'TOTAL_SCORE',
        'SCORE_EVIDENCE_TYPE', 'SCORE_EVIDENCE_UNKNOWN_KEY',
        'SCORE_EVIDENCE_MISSING', 'SCORE_WITHOUT_EVIDENCE',
        'SCORE_NULL_WITHOUT_REASON', 'SCORE_EVIDENCE_REF_UNKNOWN',
        'SCORE_EVIDENCE_REF_NOT_OWNED',
    ];

    public function r122InspectResponse(int $snapshotId, string $role,
                                        int $attemptNo = 0): array
    {
        $out = ['ok' => false, 'stage' => 'start', 'code' => null, 'reason' => null,
                'accepted' => false, 'needs_fix' => false,
                'repair_scope' => null, 'normal' => [], 'row_valid' => [],
                'diag' => null, 'attempt_id' => null,
                // @ANCHOR-20261020-R122-COMPLETE  既定は「未完了あつかい」
                'complete' => false, 'normal_kept' => [], 'salvaged' => []];

        $snap = \DB::table('baganriki_snapshots')->where('id', $snapshotId)->first();
        if ($snap === null) {
            $out['stage'] = 'snapshot'; $out['code'] = 'NO_SNAPSHOT';
            $out['reason'] = '凍結入力がありません';
            return $out;
        }
        $a = \DB::table('baganriki_ai_attempts')
               ->where('snapshot_id', $snapshotId)->where('role', $role)
               ->where('attempt_no', $attemptNo)->first();
        if ($a === null) {
            $out['stage'] = 'attempt'; $out['code'] = 'NO_ATTEMPT';
            $out['reason'] = 'その枠がありません';
            return $out;
        }
        $out['attempt_id'] = (int) $a->id;
        // ══════════════════════════════════════════════════════════════
        // @ANCHOR-20261020-R122-COMPLETE  10月20日006のご指摘2-1（本物の不具合）
        // ══════════════════════════════════════════════════════════════
        //   status=RECEIVED は見ていましたが、<b>complete を見ていませんでした。</b>
        //   契約10章は「未完了の本文は保持するが、選出へは使わない」です。
        //   「加点しない」だけでは足りず、順位点にも候補にも入れてはいけません。
        //   ここでは本文の検証は続け（保持するため）、
        //   選出に使ってよいかの印だけを別に返します。
        $out['complete'] = ((int) ($a->complete ?? 0) === 1);
        if ((string) $a->status !== BaganrikiWorker::RECEIVED) {
            $out['stage'] = 'attempt'; $out['code'] = 'NOT_RECEIVED';
            $out['reason'] = '原応答を受け取っていません（' . $a->status . '）';
            return $out;
        }

        $col = ($role === '2nd') ? 'input_json_2nd' : 'input_json_1st';
        $src = json_decode((string) $snap->{$col}, true);
        if (!is_array($src)) {
            $out['stage'] = 'snapshot'; $out['code'] = 'NO_INPUT';
            $out['reason'] = '固定入力（' . $col . '）を読めません';
            return $out;
        }

        // ── ① 原文から封筒を取り出す ────────────────────────────────
        $ex = BaganrikiResponse::extract((string) $a->raw_response);
        if (!$ex['ok']) {
            $out['stage'] = 'extract';
            $out['code']  = (string) ($ex['code'] ?? 'AI_FAILURE');
            $out['reason'] = (string) ($ex['reason'] ?? '');
            $this->r122SaveValidation((int) $a->id, null, $out, null, null, null);
            return $out;
        }
        $res = (array) $ex['json'];

        // ── ② 封筒照合（予約した role の固定入力だけが相手）──────────
        $env = BaganrikiResponse::checkEnvelope($res, [
            'prompt_version'  => $src['prompt_version']  ?? null,
            'schema_version'  => $src['schema_version']  ?? null,
            'race_id'         => $src['race_id']         ?? null,
            'ai_role'         => $src['ai_role']         ?? null,
            'snapshot_hash'   => $src['snapshot_hash']   ?? null,
            'mode'            => $src['mode']            ?? null,
            'mode_status'     => $src['mode_status']     ?? null,
            'allocation_mode' => $src['allocation_mode'] ?? null,
            'mode_policy_id'  => $src['mode_policy_id']  ?? null,
            'role_cap'        => $src['role_cap']        ?? null,
            'role_quota'      => $src['role_quota']      ?? null,
        ]);
        if (!$env['ok']) {
            $out['stage'] = 'envelope';
            $out['code']  = (string) ($env['code'] ?? 'ENVELOPE');
            $out['reason'] = (string) ($env['reason'] ?? '');
            $this->r122SaveValidation((int) $a->id, null, $out, null, null, null);
            return $out;
        }

        // ── ③ 馬ごとの隔離（正常な他馬を残す）───────────────────────
        $frozen = [];
        foreach ((array) ($src['runners'] ?? []) as $r) {
            $frozen[] = (int) ($r['horse_no'] ?? 0);
        }
        $iso = BaganrikiResponse::isolateHorses((array) ($res['horses'] ?? []), $frozen);

        // ── ④ 診断（inspect と resolve で同じ関数）──────────────────
        $d = BaganrikiDiagnose::run($res, $src);

        // 正常部分＝隔離に残り、かつ row_valid が true の行
        // ══════════════════════════════════════════════════════════════
        // @ANCHOR-20261020-R122-SALVAGE  10月20日006のご指摘5-2
        // ══════════════════════════════════════════════════════════════
        //   【直した中身】row_valid=false の行を<b>まるごと</b>外していました。
        //   そのため、採点の集計だけがおかしい馬（observed_sum が合わない等）も
        //   正常な根拠ごと落ち、候補から消えていました。
        //   契約は「不正な得点項目だけを null にして、正常根拠は保持する」です。
        //
        //   そこで、その馬の指摘が<b>採点まわりだけ</b>のときは、
        //   採点欄だけを落として行は残します（score_status は partial）。
        //   根拠・5系統・帯・順位の指摘がある行は、これまでどおり外します。
        $bad = [];                       // 馬番 => その馬に付いた指摘コード
        foreach ((array) $d['findings'] as $fd) {
            $t = $fd['target'] ?? null;
            if (!is_int($t) && !(is_string($t) && ctype_digit($t))) { continue; }
            $bad[(int) $t][] = (string) ($fd['code'] ?? '');
        }
        $salvaged = []; $salvageDetail = [];
        $normal = [];
        // ══════════════════════════════════════════════════════════════
        // @ANCHOR-20261021-R122-TYPEMAP  並べ替えに型の地図を追従させます
        // ══════════════════════════════════════════════════════════════
        //   ご指摘（010の3-4）：
        //     「並べ替え後のnormalにも種類が追従することが条件です。」
        //   応答の馬の行は ["horses", 3] の位置にあります。
        //   normal は<b>馬番をキーにしたオブジェクト</b>に組み替えるので、
        //   位置が ["7"] に変わります。地図の経路もそのとおりに
        //   付け替えないと、再保存で {} が [] に化けたり、
        //   数値が文字列に化けたりします。
        //   先に「馬番 → 応答での位置」を控えておきます。
        $idxOf = [];
        foreach (array_values((array) ($res['horses'] ?? [])) as $iH => $rowH) {
            $nH = (int) (((array) $rowH)['horse_no'] ?? 0);
            if ($nH > 0 && !isset($idxOf[$nH])) { $idxOf[$nH] = (int) $iH; }
        }
        $resMap = (array) ($ex['map'] ?? BaganrikiJson::emptyMap());
        foreach ((array) $iso['kept'] as $k => $h) {
            $no = is_int($k) ? $k : (int) ($h['horse_no'] ?? 0);
            if ($no <= 0) { continue; }
            if (($d['row_valid'][$no] ?? true) !== true) {
                $codes = array_values(array_unique($bad[$no] ?? []));
                $only  = ($codes !== [])
                      && array_diff($codes, self::R122_SCORE_ONLY_CODES) === [];
                // 自分のSIGNALが1系統も無い馬は、採点を外しても資格が立ちません
                $own = (int) (($d['ref_stats'][$no]['own_signal'] ?? 0));
                if (!$only || $own <= 0) { continue; }
                // ══════════════════════════════════════════════════
                // @ANCHOR-20261020-R122-SCOREKEY  10月20日007のご指摘3-2
                // ══════════════════════════════════════════════════
                //   【旧】observed_sum だけの誤りでも H1〜V5 を<b>全部</b>
                //     null にし、observed_sum・observed_cap を 0 にして
                //     いました。正常な採点項目まで消えます。
                //     契約6章は「不正項目だけ null、合計等を再計算」です。
                //   【いま】診断が印を付けた項目だけ null にし、
                //     <b>残った項目から合計を計算し直します。</b>
                //     集計欄だけの誤り（observed_sum が合わない等）なら、
                //     採点は1項目も消えません。計算し直すだけです。
                $badKeys = (array) (($d['bad_scores'][$no]) ?? []);
                if (!is_array($h['scores'] ?? null)) { $h['scores'] = []; }
                // 採点辞書に無い項目は落とします（残すと再計算が狂います）
                foreach (array_keys($h['scores']) as $sk) {
                    if (!array_key_exists($sk, BaganrikiDiagnose::SCORE_CAP)) {
                        unset($h['scores'][$sk]);
                    }
                }
                foreach ($badKeys as $sk) {
                    if (array_key_exists($sk, BaganrikiDiagnose::SCORE_CAP)) {
                        $h['scores'][$sk] = null;
                    }
                }
                // 残った項目から合計を出し直します
                $sumS = 0; $capS = 0; $nNull = 0;
                foreach (BaganrikiDiagnose::SCORE_CAP as $sk => $mxS) {
                    $vS = $h['scores'][$sk] ?? null;
                    if (!array_key_exists($sk, $h['scores'])) {
                        $h['scores'][$sk] = null;      // 欄は残します
                        $nNull++;
                        continue;
                    }
                    if ($vS === null) { $nNull++; continue; }
                    if (!is_int($vS) || $vS < 0 || $vS > $mxS) {
                        $h['scores'][$sk] = null; $nNull++; continue;
                    }
                    $sumS += $vS; $capS += $mxS;
                }
                $h['observed_sum'] = $sumS;
                $h['observed_cap'] = $capS;
                $h['total_score']  = ($nNull === 0) ? $sumS : null;
                $h['score_status'] = ($nNull === 0) ? 'complete' : 'partial';
                // ══════════════════════════════════════════════════════
                // @ANCHOR-20261021-R122-METASPLIT  10月21日008のご指摘3
                // ══════════════════════════════════════════════════════
                //   【本物の不具合でした】
                //   直した中身を <b>馬の行の中に</b> r122_salvage として
                //   足していました。これは内部の監査項目で、AIの業務項目
                //   ではありません。ところが、この行がそのまま
                //   $first['normal'] に入り、acceptCorrection の
                //   「範囲外の項目を変えていないか」の比較対象になります。
                //   正しい全頭訂正に r122_salvage は入っていないので、
                //     初回 = 配列 ／ 訂正 = 無い
                //   となり「その範囲で直してよい項目の外を変えている」と
                //   判定され、<b>正しい訂正が FIX_REJECTED になります。</b>
                //   つまり「採点の救済」と「全頭訂正」を両方通すと落ちます。
                //   別々に試していたので気づきませんでした。
                //
                //   【いま】馬の行には入れません。<b>別の入れ物</b>に出します。
                //   AIが返すべき項目だけが訂正の比較対象になります。
                //   AIに r122_salvage を返させる解決はしません（それは
                //   内部の監査項目をAIに書かせることになります）。
                $salvageDetail[$no] = [
                    'nulled_scores' => array_values($badKeys),
                    'recomputed'    => ['observed_sum' => $sumS,
                                        'observed_cap' => $capS,
                                        'total_score'  => $h['total_score'],
                                        'score_status' => $h['score_status']],
                ];
                $salvaged[] = $no;
            }
            $normal[$no] = $h;
        }
        ksort($normal);
        sort($salvaged);

        $out['ok']           = true;
        $out['stage']        = 'ok';
        $out['code']         = $d['ok'] ? 'OK' : 'REPAIRABLE';
        $out['reason']       = BaganrikiDiagnose::summary($d);
        $out['accepted']     = ($normal !== []);
        $out['needs_fix']    = !$d['ok'];
        $out['repair_scope'] = $d['repair_scope'];
        // @ANCHOR-20261020-R122-COMPLETE  未完了は選出に使いません（本文は残します）
        $out['normal']       = ($out['complete'] === true) ? $normal : [];
        $out['normal_kept']  = $normal;      // 保持はします（監査・訂正の材料）
        // @ANCHOR-20261021-R122-METASPLIT  内部の監査項目はここに出します
        //   （馬の行には入れません。訂正の比較対象にしないためです）
        $out['salvage_detail'] = $salvageDetail;
        if ($out['complete'] !== true) {
            $out['reason'] = '未完了（complete=false）なので選出に使いません。'
                           . '本文は保持しています。／' . $out['reason'];
        }
        $out['row_valid']    = $d['row_valid'];
        $out['salvaged']     = $salvaged;
        $out['diag']         = [
            'findings'   => $d['findings'],
            'missing'    => $d['missing'],
            'duplicated' => $d['duplicated'],
            'unknown'    => $d['unknown'],
            'isolated'   => array_keys((array) $iso['isolated']),
            'iso_missing' => (array) $iso['missing'],
            // @ANCHOR-20261020-R122-REFCHECK  馬ごとの参照の内訳も外へ出します
            //   （どの馬に自分のSIGNALが何件あったかを、後から数えられるように）
            'ref_stats'  => (array) ($d['ref_stats'] ?? []),
            // @ANCHOR-20261020-R122-SALVAGE  採点欄だけ落として残した馬
            'salvaged'   => $salvaged,
            // @ANCHOR-20261020-R122-SCOREKEY  馬ごとの「おかしい採点項目」
            'bad_scores' => (array) ($d['bad_scores'] ?? []),
        ];
        // ══════════════════════════════════════════════════════════════
        // @ANCHOR-20261021-R122-TYPEMAP  normal の型の地図（010の3-1・3-4）
        // ══════════════════════════════════════════════════════════════
        //   normal は馬番をキーにしたオブジェクトです。
        //   最上位を obj と印し、各馬の枝を応答の位置から付け替えます。
        //   救済で計算し直した欄（observed_sum など）は、こちらで
        //   作ったPHPの整数です。地図に載っていた古い印をそのまま使うと
        //   「原トークンを書き戻す」ことになって値が戻ってしまうので、
        //   encode は<b>値が地図と食い違えばいまの値を書きます</b>
        //   （@ANCHOR-20261021-R122-TYPEMAP の sameNumberValue）。
        $normalMap = BaganrikiJson::mapWithKind(
            BaganrikiJson::emptyMap(), [], 'obj');
        foreach (array_keys($normal) as $noN) {
            if (!isset($idxOf[(int) $noN])) { continue; }
            $normalMap = BaganrikiJson::mapMerge($normalMap,
                BaganrikiJson::mapMove($resMap,
                    ['horses', (int) $idxOf[(int) $noN]], [(string) $noN]));
        }
        $out['map']        = $resMap;        // 応答そのものの地図
        $out['normal_map'] = $normalMap;     // 正常部分の地図（並べ替え後）

        $this->r122SaveValidation((int) $a->id, $normal, $out,
            $d['repair_scope'], self::r122FieldSources($normal),
            self::r122RankSources($res), $normalMap);
        return $out;
    }

    /**
     * @ANCHOR-20261020-R122-RESP  訂正を解決します（最大1回）
     *   初回の原応答と complete を保存してからでないと動きません。
     *   直してよい範囲は<b>初回の診断</b>から取ります（同じ診断関数です）。
     *   採用できない訂正では、初回の正常部分をそのまま残します。
     */
    public function r122ResolveCorrection(int $snapshotId, string $role): array
    {
        $out = ['ok' => false, 'code' => null, 'reason' => null,
                'merged' => [], 'applied' => [], 'rescued' => [], 'skipped' => []];

        $first = $this->r122InspectResponse($snapshotId, $role, BaganrikiWorker::FIRST);
        if (!$first['ok']) {
            $out['code'] = 'FIRST_NOT_USABLE';
            $out['reason'] = '初回が採用できません（' . $first['stage'] . '／'
                           . $first['code'] . '）';
            return $out;
        }
        $out['merged'] = $first['normal'];        // 何があっても初回の正常部分は残します
        if (!$first['needs_fix']) {
            $out['ok'] = true; $out['code'] = 'NO_FIX_NEEDED';
            $out['reason'] = '初回に直すところがないので訂正しません';
            return $out;
        }

        $fix = $this->r122InspectResponse($snapshotId, $role, BaganrikiWorker::FIX);
        if (!$fix['ok']) {
            $out['ok'] = true; $out['code'] = 'FIX_NOT_USABLE';
            $out['reason'] = '訂正が採用できないので初回の正常部分を残します（'
                           . $fix['stage'] . '／' . $fix['code'] . '）';
            return $out;
        }

        $rowsA = \DB::table('baganriki_ai_attempts')
                   ->where('snapshot_id', $snapshotId)->where('role', $role)
                   ->whereIn('attempt_no', [BaganrikiWorker::FIRST, BaganrikiWorker::FIX])
                   ->get()->keyBy('attempt_no');
        $firstAt = self::r122DbRfc3339($rowsA[BaganrikiWorker::FIRST]->received_at ?? null);
        $fixAt   = self::r122DbRfc3339($rowsA[BaganrikiWorker::FIX]->received_at ?? null);

        $snap = \DB::table('baganriki_snapshots')->where('id', $snapshotId)->first();
        $frozen = [];
        foreach ((array) json_decode((string) ($snap->frozen_nums ?? '[]'), true) as $n) {
            $frozen[] = (int) $n;
        }

        // @ANCHOR-20261021-R122-TYPEMAP  型の地図も渡します（010の3-2）
        //   どちらも「馬番をキーにした入れ物」の地図なので、
        //   経路の先頭が馬番でそろいます。
        $acc = BaganrikiResponse::acceptCorrection(
            $first['normal'], $fix['normal'], $firstAt, $fixAt,
            $frozen, $first['repair_scope'], $fix['row_valid'],
            (array) ($first['normal_map'] ?? BaganrikiJson::emptyMap()),
            (array) ($fix['normal_map']   ?? BaganrikiJson::emptyMap()));
        if (($acc['ok'] ?? false) !== true) {
            $out['ok'] = true; $out['code'] = 'FIX_REJECTED';
            $out['reason'] = '訂正を採用しません（' . (string) ($acc['reason'] ?? '')
                           . '）。初回の正常部分を残します';
            return $out;
        }
        $out['merged']  = BaganrikiResponse::applyCorrection(
                              $first['normal'], $fix['normal'], $acc);
        // ══════════════════════════════════════════════════════════════
        // @ANCHOR-20261021-R122-TYPEMAP  当てた行だけ地図も差し替えます
        // ══════════════════════════════════════════════════════════════
        //   merged は「初回の行＋当てた行」です。地図も同じ組み方に
        //   しないと、当てた行の型が初回のものに戻ってしまいます。
        $mergedMap = (array) ($first['normal_map'] ?? BaganrikiJson::emptyMap());
        $fixMapAll = (array) ($fix['normal_map']   ?? BaganrikiJson::emptyMap());
        foreach (array_merge((array) ($acc['applied'] ?? []),
                             (array) ($acc['rescued'] ?? [])) as $noM) {
            $mergedMap = BaganrikiJson::mapMerge($mergedMap,
                BaganrikiJson::mapMove($fixMapAll,
                    [(string) (int) $noM], [(string) (int) $noM]));
        }
        $out['merged_map'] = $mergedMap;
        $out['applied'] = (array) ($acc['applied'] ?? []);
        $out['rescued'] = (array) ($acc['rescued'] ?? []);
        $out['skipped'] = (array) ($acc['skipped'] ?? []);
        $out['ok']   = true;
        $out['code'] = 'FIX_APPLIED';
        $out['reason'] = '訂正を反映しました（適用 ' . count($out['applied'])
                       . '頭・救済 ' . count($out['rescued'])
                       . '頭・飛ばし ' . count($out['skipped']) . '頭）';
        return $out;
    }

    /**
     * @ANCHOR-20261020-R122-RESP  選出に渡す馬（訂正があればそれを使う）
     */
    public function r122AcceptedHorses(int $snapshotId, string $role): array
    {
        $has = \DB::table('baganriki_ai_attempts')
                 ->where('snapshot_id', $snapshotId)->where('role', $role)
                 ->where('attempt_no', BaganrikiWorker::FIX)
                 ->where('status', BaganrikiWorker::RECEIVED)->exists();
        if ($has) { return $this->r122ResolveCorrection($snapshotId, $role); }
        $f = $this->r122InspectResponse($snapshotId, $role, BaganrikiWorker::FIRST);
        return ['ok' => $f['ok'], 'code' => $f['code'], 'reason' => $f['reason'],
                // @ANCHOR-20261020-R122-COMPLETE  未完了なら選出へ渡しません
                'merged' => $f['normal'], 'applied' => [], 'rescued' => [],
                'skipped' => [], 'needs_fix' => $f['needs_fix'],
                'complete' => ($f['complete'] ?? null),
                'repair_scope' => $f['repair_scope']];
    }

    /** @ANCHOR-20261020-R122-RESP  各馬の事実出典hash（加点の証明とは別に残します） */
    public static function r122FieldSources(array $horses): array
    {
        $o = [];
        foreach ($horses as $no => $h) {
            $refs = [];
            foreach ((array) ($h['evidence'] ?? []) as $e) {
                foreach ((array) ($e['source_refs'] ?? []) as $r) { $refs[] = (string) $r; }
            }
            foreach ((array) ($h['family_review'] ?? []) as $fam) {
                foreach ((array) ($fam['source_refs'] ?? []) as $r) { $refs[] = (string) $r; }
            }
            $refs = array_values(array_unique($refs));
            sort($refs, SORT_STRING);
            $o[(string) $no] = ['refs' => $refs,
                                'hash' => hash('sha256', implode("\n", $refs))];
        }
        return $o;
    }

    /** @ANCHOR-20261020-R122-RESP  順位の出どころ（帯ごとの方式と並び） */
    public static function r122RankSources(array $res): array
    {
        return [
            'band_ranks'          => (array) ($res['band_ranks'] ?? []),
            'evidence_band_ranks' => (array) ($res['evidence_band_ranks'] ?? []),
            'public_candidates'   => (array) ($res['public_candidates'] ?? []),
        ];
    }

    /** @ANCHOR-20261020-R122-RESP  検証の結果を残します（表が無ければ何もしません） */
    private function r122SaveValidation(int $attemptId, ?array $normal, array $out,
                                        ?array $scope, ?array $fieldSources,
                                        ?array $rankSources,
                                        ?array $normalMap = null): void
    {
        if (!\Schema::hasTable('baganriki_validation_results')) { return; }
        $j = static fn($v) => ($v === null) ? null : (string) json_encode($v,
            JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PRESERVE_ZERO_FRACTION);
        // ══════════════════════════════════════════════════════════════
        // @ANCHOR-20261021-R122-TYPEMAP  正常部分は専用シリアライザで書きます
        // ══════════════════════════════════════════════════════════════
        //   ご指摘（010の3-1）：
        //     「提示された jsonSerialize() は string型のdecimalを返します。
        //       これを通常のjson_encodeで保存すると、JSONの数値ではなく
        //       引用符付き文字列になります。現行 r122SaveValidation も
        //       通常のjson_encodeです。クラスを追加するだけでは009の
        //       問題は解消しません。」
        //   そのとおりでした。ここが通常の json_encode のままだと、
        //   丸まる数値（文字列で持っているもの）が<b>引用符付きで
        //   保存されて、読み戻すと文字列になります。</b>
        //   【いま】型の地図があるときは encode で書きます。
        //   数値だった位置は引用符なし、{} と [] の種類もそのままです。
        //   JSON_NUMERIC_CHECK も float への変換も使っていません。
        //   読み戻しは BaganrikiJson::decode です（r122NormalPart）。
        $jn = static function ($v) use ($normalMap, $j) {
            if ($v === null) { return null; }
            if ($normalMap === null) { return $j($v); }
            return BaganrikiJson::encode($v, $normalMap);
        };
        try {
            \DB::table('baganriki_validation_results')->insert([
                'attempt_id'        => $attemptId,
                'validator_version' => BaganrikiDiagnose::VERSION,
                'normal_part'       => $jn($normal),
                'diagnostics'       => $j(['stage' => $out['stage'], 'code' => $out['code'],
                                           'reason' => $out['reason'],
                                           'diag' => $out['diag'] ?? null]),
                'repair_scope'      => $j($scope),
                'field_sources'     => $j($fieldSources),
                'rank_sources'      => $j($rankSources),
                'created_at'        => BaganrikiWorker::toDb(BaganrikiWorker::nowUs()),
            ]);
        } catch (\Throwable $e) {
            \Log::error('[R122-RESP] 検証結果を残せません', ['message' => $e->getMessage()]);
        }
    }

    /**
     * ═══════════════════════════════════════════════════════════════════════
     * @ANCHOR-20261021-R122-TYPEREAD  保存した正常部分を読み戻します（010の3-3）
     * ═══════════════════════════════════════════════════════════════════════
     * ご指摘：
     *   「保存後も通常のjson_decodeで読み戻せば、長い数値が再びfloatに
     *     なります。診断、訂正比較、normal保存、再読込、公開用の一致確認まで
     *     同じ型保持方式を通してください。」
     *
     *   そのとおりです。保存を専用シリアライザにしても、読むほうが
     *   json_decode なら、そこで型が落ちます。
     *   <b>読み戻しも専用パーサ（BaganrikiJson::decode）に統一します。</b>
     *   返すのは「値」と「型の地図」の両方です。
     *
     * @return array ['ok','code','reason','value','map','raw']
     */
    public function r122NormalPart(int $attemptId): array
    {
        $out = ['ok' => false, 'code' => null, 'reason' => null,
                'value' => null, 'map' => BaganrikiJson::emptyMap(), 'raw' => null];
        if (!\Schema::hasTable('baganriki_validation_results')) {
            $out['code'] = 'TABLE_MISSING';
            return $out;
        }
        $r = \DB::table('baganriki_validation_results')
               ->where('attempt_id', $attemptId)
               ->orderByDesc('id')->first(['normal_part']);
        if ($r === null) {
            $out['code'] = 'NO_ROW';
            $out['reason'] = 'その枠の検証結果がありません';
            return $out;
        }
        $raw = $r->normal_part;
        if ($raw === null || (string) $raw === '') {
            $out['code'] = 'NO_NORMAL';
            $out['reason'] = '正常部分が保存されていません';
            return $out;
        }
        $out['raw'] = (string) $raw;
        // @ANCHOR-20261021-R122-TYPEREAD  json_decode は使いません
        $d = BaganrikiJson::decode((string) $raw);
        if (!$d['ok']) {
            $out['code'] = (string) $d['code'];
            $out['reason'] = (string) $d['reason'];
            return $out;
        }
        $out['ok'] = true;
        $out['code'] = 'OK';
        $out['value'] = $d['value'];
        $out['map'] = (array) $d['map'];
        return $out;
    }

    /**
     * @ANCHOR-20261021-R122-TYPEREAD  保存した正常部分が、いまの値と同じか
     *
     *   保存 → 読戻し で型も値も落ちていないことを、その場で確かめます。
     *   「公開用の一致確認」までこの比較1本で通します（010の3-3）。
     *
     * @return array ['ok','same','where','reason']
     */
    public function r122NormalRoundTrip(int $attemptId, array $normal,
                                        array $normalMap): array
    {
        $rd = $this->r122NormalPart($attemptId);
        if (!$rd['ok']) {
            return ['ok' => false, 'same' => false, 'where' => null,
                    'reason' => '読み戻せません（' . (string) $rd['code'] . '）'];
        }
        $r = BaganrikiJson::same($normal, $normalMap,
                                 $rd['value'], $rd['map'], true);
        return ['ok' => true, 'same' => (bool) $r['same'],
                'where' => $r['where'], 'reason' => $r['reason']];
    }
