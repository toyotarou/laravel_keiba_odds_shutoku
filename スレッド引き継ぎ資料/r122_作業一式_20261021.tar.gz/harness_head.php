<?php
namespace App\Http\Controllers\Api;
if (!function_exists('App\Http\Controllers\Api\env')) {
    function env($k, $d = null) { $v = getenv($k); return ($v === false) ? $d : $v; }
    function storage_path($p = '') { return '/home/claude/r122/storage/' . ltrim($p, '/'); }
    function app($x = null) { return null; }
}
class AiController
{
    public const V04_THRESHOLDS = [
        'win_wall' => 2.00, 'place_wall' => 1.50,
        'win_wall_shrink_fraction' => 0.20, 'middle_close_upper_bound' => 1.50,
        'place_shorten_21_to_6_fraction' => 0.05, 'place_shorten_9_to_6_fraction' => 0.03,
        'similar_min_races' => 50, 'similar_3in_delta_pp' => 10.0,
    ];
    public const V04_SIGNAL_WEIGHTS = ['X1'=>2,'X2'=>1,'X3'=>1,'X4'=>1,'X5'=>1,'X6'=>1,'Z'=>-2];
    public const V04_MODE_FIRM_MAX = 1;
    public const V04_MODE_MIXED_MAX = 3;
    public const V04_UNKNOWN_COUNT_AT_LEAST = 3;
    public const V04_QUOTA_BY_TARGET = [
        7 => ['FIRM' => [5,2,0], 'MIXED' => [3,3,1], 'VOLATILE' => [3,3,1]],
        6 => ['FIRM' => [4,2,0], 'MIXED' => [3,2,1], 'VOLATILE' => [3,2,1]],
        5 => ['FIRM' => [4,1,0], 'MIXED' => [3,2,0], 'VOLATILE' => [2,2,1]],
        4 => ['FIRM' => [3,1,0], 'MIXED' => [2,2,0], 'VOLATILE' => [2,1,1]],
    ];
    public const V04_QUOTA_EXTREME = [7 => ['EXTREME' => [2,3,2]]];
    public const B12_RECOVERY_LOW_THRESH = 40.0;
    public const V04_X6_BASELINE = null;
}
