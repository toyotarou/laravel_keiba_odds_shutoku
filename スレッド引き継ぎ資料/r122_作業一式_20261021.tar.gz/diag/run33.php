<?php
require __DIR__ . '/const.php';
require __DIR__ . '/stub.php';

$declared = []; $entry = [];
foreach (file(__DIR__ . '/races.txt', FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES) as $l) {
    [$k, $nh] = explode('|', $l);
    $declared[$k] = ($nh === '') ? null : (int) $nh;
}
$series = [];
foreach (file(__DIR__ . '/rows.txt', FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES) as $l) {
    $p = explode('|', $l);
    $k = $p[0]; $n = (int) $p[1];
    [$t6, $t21, $f6, $f21, $f9, $can] = [$p[2], $p[3], $p[4], $p[5], $p[6], $p[7]];
    $entry[$k][$n] = true;
    if ($can !== '' || $t6 === '取消' || $t21 === '取消') {
        $series[$k][$n]['cancel'] = '取消';
        $series[$k][$n]['cancel_slots'] = [21, 18, 15, 12, 9, 6, 3];
        continue;
    }
    foreach ([[6, $t6], [21, $t21]] as [$t, $raw]) {
        $v = S::decScale($raw);
        if ($v !== null) { $series[$k][$n]['t'][$t] = $v; $series[$k][$n]['ts'][$t] = $raw; }
    }
    foreach ([[6, $f6], [21, $f21], [9, $f9]] as [$t, $raw]) {
        $v = S::decScale($raw);
        if ($v !== null) { $series[$k][$n]['f'][$t] = $v; $series[$k][$n]['fs'][$t] = $raw; }
    }
}
$zen = json_decode(file_get_contents(__DIR__ . '/zen.json'), true);

$band = static fn(int $p) => ($p >= 1 && $p <= 6) ? 'A' : (($p >= 7 && $p <= 10) ? 'B' : 'D');
$rows = []; $nSame = 0; $nDiff = 0; $nShort = 0;

foreach ($series as $k => $sr) {
    $res = S::modeCheckOne($sr, $entry[$k] ?? null, $declared[$k] ?? null);
    if (($res['状態'] ?? '') === '計算不能') continue;
    $N = (int) $res['N'];
    $dec = S::r122Decide([
        'X1' => $res['X1'], 'X2' => $res['X2'], 'X3' => $res['X3'],
        'X4' => $res['X4'], 'X5' => $res['X5'], 'Z' => $res['Z'],
        'X6' => (($N >= 7) ? null : false),
    ]);
    if ($dec['mode_status'] !== 'PROVISIONAL') continue;
    $useMode = (string) $dec['allocation_mode'];
    $cmpMode = S::modeOfS((int) $dec['S_min']);
    $qCmp = S::r122StructuralQuota($N, $cmpMode)['quota'];
    $qUse = S::r122StructuralQuota($N, $useMode)['quota'];

    $all = $zen[$k] ?? null;
    if (!is_array($all) || $all === []) {
        $rows[] = [$k, $N, $dec['S0'], $cmpMode, $useMode, S::r122Fmt($qCmp), S::r122Fmt($qUse),
                   '', '', '', '保存済み全頭評価がありません']; continue;
    }
    $horses = [];
    foreach ($all as $num => $h) {
        $n = (int) $num;
        $pop = $res['frozen'][$n] ?? null;
        if ($pop === null) continue;
        $g = (int) ($h['独立根拠']['独立群数'] ?? 0);
        $horses[$n] = ['num' => $n, 'pop' => (int) $pop, 'band' => $band((int) $pop),
                       'score' => $h['統合点'] ?? null, 'groups' => $g,
                       'eligible' => ($g >= 1 && $h['統合点'] !== null)];
    }
    $pick = static function (array $q) use ($horses) {
        $idx = ['A' => 0, 'B' => 1, 'D' => 2];
        $by = ['A' => [], 'B' => [], 'D' => []];
        foreach ($horses as $h) { if ($h['eligible']) $by[$h['band']][] = $h; }
        foreach ($by as $b => $L) {
            usort($L, static function ($x, $y) {
                if ($x['score'] !== $y['score']) return ($y['score'] <=> $x['score']);
                if ($x['groups'] !== $y['groups']) return ($y['groups'] <=> $x['groups']);
                return ($x['num'] <=> $y['num']);
            });
            $by[$b] = $L;
        }
        $o = []; $s = [];
        foreach (['A', 'B', 'D'] as $b) {
            $w = (int) ($q[$idx[$b]] ?? 0); $have = count($by[$b]); $t = min($w, $have);
            for ($i = 0; $i < $t; $i++) $o[] = $by[$b][$i]['num'];
            if ($w > $have) $s[] = $b . '帯 要求' . $w . '・適格' . $have . '・不足' . ($w - $have);
        }
        return ['nums' => $o, 'short' => $s];
    };
    $pC = $pick((array) $qCmp); $pU = $pick((array) $qUse);
    $same = ($pC['nums'] === $pU['nums']);
    $same ? $nSame++ : $nDiff++;
    $sh = array_values(array_unique(array_merge($pC['short'], $pU['short'])));
    if ($sh !== []) { $nShort++; $sh[] = '当時の保存は' . $N . '頭のうち' . count($horses) . '頭ぶんです'; }
    $rows[] = [$k, $N, $dec['S0'], $cmpMode, $useMode, S::r122Fmt($qCmp), S::r122Fmt($qUse),
               implode('-', $pC['nums']), implode('-', $pU['nums']), $same ? '同じ' : '違う',
               implode('／', $sh)];
}
foreach ($rows as $r) {
    printf("%-22s N=%2d S0=%d %-8s %-7s → %-8s %-7s %s  cmp=[%s] use=[%s] %s\n",
        $r[0], $r[1], $r[2], $r[3], $r[5], $r[4], $r[6], $r[9], $r[7], $r[8], $r[10]);
}
echo "\n対象 " . count($rows) . " / 違う $nDiff / 同じ $nSame / 枠が埋まらない $nShort\n";
