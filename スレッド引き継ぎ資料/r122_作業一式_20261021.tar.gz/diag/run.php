<?php
require __DIR__ . '/const.php';
require __DIR__ . '/stub.php';

$declared = []; $entry = [];
foreach (file(__DIR__ . '/races.txt', FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES) as $l) {
    [$k, $nh] = explode('|', $l);
    $declared[$k] = ($nh === '') ? null : (int) $nh;
}
$series = [];
foreach (file(__DIR__ . '/rows.txt', FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES) as $l) {
    $p = explode('|', $l);
    $k = $p[0]; $n = (int) $p[1];
    [$t6, $t21, $f6, $f21, $f9, $can] = [$p[2], $p[3], $p[4], $p[5], $p[6], $p[7]];
    $entry[$k][$n] = true;
    if ($t6 === '取消' || $t6 === '除外' || $t21 === '取消' || $t21 === '除外' || $can !== '') {
        $series[$k][$n]['cancel'] = '取消';
        $series[$k][$n]['cancel_slots'] = [21, 18, 15, 12, 9, 6, 3];
        continue;
    }
    foreach ([[6, $t6, 't', 'ts'], [21, $t21, 't', 'ts']] as [$t, $raw, $a, $b]) {
        $v = S::decScale($raw);
        if ($v !== null) { $series[$k][$n][$a][$t] = $v; $series[$k][$n][$b][$t] = $raw; }
    }
    foreach ([[6, $f6], [21, $f21], [9, $f9]] as [$t, $raw]) {
        $v = S::decScale($raw);
        if ($v !== null) { $series[$k][$n]['f'][$t] = $v; $series[$k][$n]['fs'][$t] = $raw; }
    }
}

$st = ['CONFIRMED' => 0, 'PROVISIONAL' => 0, 'UNRESOLVED' => 0];
$ng = 0; $s0hist = []; $prov = []; $unres = [];
foreach ($series as $k => $sr) {
    $es  = $entry[$k] ?? null;
    $res = S::modeCheckOne($sr, $es, $declared[$k] ?? null);
    if (($res['状態'] ?? '') === '計算不能') {
        $ng++; echo "計算不能 $k : " . ($res['理由'] ?? '') . "\n"; continue;
    }
    $N   = (int) $res['N'];
    $dec = S::r122Decide([
        'X1' => $res['X1'], 'X2' => $res['X2'], 'X3' => $res['X3'],
        'X4' => $res['X4'], 'X5' => $res['X5'], 'Z' => $res['Z'],
        'X6' => (($N >= 7) ? null : false),
    ]);
    $st[$dec['mode_status']]++;
    $key = 'S0=' . var_export($dec['S0'], true);
    $s0hist[$key] = ($s0hist[$key] ?? 0) + 1;
    if ($dec['mode_status'] === 'PROVISIONAL') {
        $prov[] = [$k, $N, $dec['S0'], S::modeOfS((int) $dec['S_min']), $dec['allocation_mode']];
    }
    if ($dec['mode_status'] === 'UNRESOLVED') {
        $unres[] = [$k, $N, $dec['S_min'], $dec['S_max'], implode(',', $dec['unknown_keys'])];
    }
}
echo "\n=== レース数 " . count($series) . " / 計算不能 $ng ===\n";
print_r($st);
ksort($s0hist); print_r($s0hist);
echo "\n--- PROVISIONAL (" . count($prov) . ") ---\n";
foreach ($prov as $p) echo implode('  ', array_map('strval', $p)) . "\n";
echo "\n--- UNRESOLVED (" . count($unres) . ") ---\n";
foreach ($unres as $p) echo implode('  ', array_map('strval', $p)) . "\n";
