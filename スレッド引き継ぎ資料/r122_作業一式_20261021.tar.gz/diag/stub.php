<?php
class S {
    public static function modeOfS(int $s): string
    {
        return ($s <= 1) ? 'FIRM' : (($s <= 3) ? 'MIXED' : 'VOLATILE');
    }

    /** @ANCHOR-20261018-MODECHECK  Sの値から星を返す（1〜5） */
    public static function starOfS(int $s): int
    {
        if ($s <= 0) return 1;
        if ($s === 1) return 2;
        if ($s <= 3) return 3;
        if ($s <= 5) return 4;
        return 5;
    }
    public const R122_W = ['X1'=>2,'X2'=>1,'X3'=>1,'X4'=>1,'X5'=>1,'X6'=>1,'Z'=>-2];
    public static function r122Decide(array $sig): array
    {
        $keys = array_keys(self::R122_W);
        $unknown = [];
        foreach ($keys as $k) {
            if (!array_key_exists($k, $sig)) { $sig[$k] = null; }
            if ($sig[$k] === null) { $unknown[] = $k; }
        }

        // 不明を 0/1 の全組合せで評価し、取り得る S を全部出します
        $svals = [];
        $u = count($unknown);
        for ($m = 0; $m < (1 << $u); $m++) {
            $sv = 0;
            foreach ($keys as $k) {
                $v = $sig[$k];
                if ($v === null) {
                    $i = array_search($k, $unknown, true);
                    $v = (bool) (($m >> $i) & 1);
                }
                if ($v) { $sv += self::R122_W[$k]; }
            }
            $svals[$sv] = true;
        }
        $svals = array_keys($svals);
        sort($svals);
        $sMin = $svals[0];
        $sMax = $svals[count($svals) - 1];

        $modes = []; $stars = [];
        foreach ($svals as $sv) {
            $modes[self::modeOfS($sv)] = true;
            $stars[self::starOfS($sv)] = true;
        }
        $modes = array_keys($modes);

        // S は不明が1つでもあれば null（S_min／S_max は残します）
        $S = empty($unknown) ? $sMin : null;

        // S0 = X6 を除いた重み付き合計。X6以外が全部確定しているときだけ出ます
        $s0 = 0; $s0ok = true;
        foreach ($keys as $k) {
            if ($k === 'X6') continue;
            if ($sig[$k] === null) { $s0ok = false; break; }
            if ($sig[$k]) { $s0 += self::R122_W[$k]; }
        }
        $S0 = $s0ok ? $s0 : null;

        $onlyX6 = (count($unknown) === 1 && $unknown[0] === 'X6');

        if (count($modes) === 1) {
            return [
                'mode'              => $modes[0],
                'mode_status'       => 'CONFIRMED',
                'allocation_mode'   => $modes[0],
                'mode_policy_id'    => 'BASE_TRI_STATE_V1',
                'selection_enabled' => true,
                'S' => $S, 'S_min' => $sMin, 'S_max' => $sMax, 'S0' => $S0,
                'display_rating'    => (count($stars) === 1) ? array_keys($stars)[0] : null,
                'unknown_keys'      => $unknown,
            ];
        }
        if ($onlyX6 && ($S0 === 1 || $S0 === 3)) {
            return [
                'mode'              => 'UNKNOWN',
                'mode_status'       => 'PROVISIONAL',
                'allocation_mode'   => ($S0 === 1) ? 'MIXED' : 'VOLATILE',
                'mode_policy_id'    => 'X6_ONLY_UPPER_MODE_V1',
                'selection_enabled' => true,
                'S' => $S, 'S_min' => $sMin, 'S_max' => $sMax, 'S0' => $S0,
                'display_rating'    => null,
                'unknown_keys'      => $unknown,
            ];
        }
        return [
            'mode'              => 'UNKNOWN',
            'mode_status'       => 'UNRESOLVED',
            'allocation_mode'   => null,
            'mode_policy_id'    => 'BASE_TRI_STATE_V1',
            'selection_enabled' => false,
            'S' => $S, 'S_min' => $sMin, 'S_max' => $sMax, 'S0' => $S0,
            'display_rating'    => null,
            'unknown_keys'      => $unknown,
        ];
    }

    public static function r122TargetCount(int $n): int
    {
        if ($n <= 0)  return 0;
        if ($n <= 3)  return $n;
        if ($n <= 8)  return 4;
        if ($n <= 13) return 5;
        if ($n <= 15) return 6;
        return 7;
    }

    /** 基本配分 A/B/D（config/r122_contract.json の base_quota と同じ値） */
    public static function r122BaseQuota(int $c, string $mode): ?array
    {
        if ($c <= 0) return [0, 0, 0];
        if ($c <= 3) return [$c, 0, 0];
        $t = [
            4 => ['FIRM'=>[3,1,0], 'MIXED'=>[2,2,0], 'VOLATILE'=>[2,1,1]],
            5 => ['FIRM'=>[4,1,0], 'MIXED'=>[3,2,0], 'VOLATILE'=>[2,2,1]],
            6 => ['FIRM'=>[4,2,0], 'MIXED'=>[3,2,1], 'VOLATILE'=>[3,2,1]],
            7 => ['FIRM'=>[5,2,0], 'MIXED'=>[3,3,1], 'VOLATILE'=>[3,3,1]],
        ];
        return $t[$c][$mode] ?? null;
    }

    /** 帯ごとの実在頭数（A=1〜6人気、B=7〜10人気、D=11人気以下） */
    public static function r122BandCapacity(int $n): array
    {
        return [max(0, min(6, $n)), max(0, min(10, $n) - 6), max(0, $n - 10)];
    }

    /**
     * 構造上の実在馬不足だけを調整します（評価後の適格馬不足は別の規則）。
     * 不足帯を D → B → A の順に処理し、D は B→A、B は D→A、A は B→D へ移します。
     * 移動は quota_adjustments として理由つきで返します（reason は省略しません）。
     */
    public static function r122StructuralQuota(int $n, ?string $allocMode): array
    {
        if ($allocMode === null) { return ['quota'=>null, 'moves'=>[]]; }
        $c = self::r122TargetCount($n);
        $q = self::r122BaseQuota($c, $allocMode);
        if ($q === null) { return ['quota'=>null, 'moves'=>[]]; }
        $cap = self::r122BandCapacity($n);
        $idx = ['A'=>0, 'B'=>1, 'D'=>2];
        $moves = [];
        foreach ([['D', ['B','A']], ['B', ['D','A']], ['A', ['B','D']]] as $pair) {
            [$from, $tos] = $pair;
            $i = $idx[$from];
            while ($q[$i] > $cap[$i]) {
                $moved = false;
                foreach ($tos as $to) {
                    $j = $idx[$to];
                    if ($q[$j] < $cap[$j]) {
                        $q[$i]--; $q[$j]++;
                        $moves[] = ['requested_band'=>$from, 'actual_band'=>$to,
                                    'count'=>1, 'reason'=>'BAND_CAPACITY'];
                        $moved = true;
                        break;
                    }
                }
                if (!$moved) {
                    $q[$i]--;
                    $moves[] = ['requested_band'=>$from, 'actual_band'=>null,
                                'count'=>1, 'reason'=>'BAND_CAPACITY'];
                }
            }
        }
        return ['quota'=>$q, 'moves'=>$moves];
    }

    /** 2ndの配分：C<=5は1stと同じ。C>5は B・D を保ったまま A=5−B−D、cap=5 */
    public static function r122SecondQuota(int $n, array $q1): array
    {
        if (self::r122TargetCount($n) <= 5) { return $q1; }
        $a = 5 - $q1[1] - $q1[2];
        if ($a < 0) { $a = 0; }
        return [$a, $q1[1], $q1[2]];
    }

    /** 配分を "A/B/D" の形に */
    public static function r122Fmt(?array $q): string
    {
        return ($q === null) ? '—' : sprintf('%d/%d/%d', $q[0], $q[1], $q[2]);
    }

    // ── 取得時刻（server_contract_r12.2 4章／詳細設計書 4.3）────────
    public static function modeCheckOne(array $sr, ?array $entrySet = null, ?int $declaredCount = null): array
    {
        /* ──────────────────────────────────────────────────────────────
         * @ANCHOR-20261019-EXACT  10月19日001のご指摘1・2で全面的に差し替え
         *
         *   旧実装には2つの誤りがありました。
         *     (1) オッズを float で比較していた（境界判定が誤差で変わり得る）
         *     (2) 欠損を UNKNOWN にせず「条件不成立（FALSE）」に落としていた
         *   消さずに下へ残します。使っていません。
         *
         *         $tan6 = []; $tan21 = []; $fuku6 = []; $fuku21 = []; $fuku9 = [];
         *         foreach ($sr as $n => $o) {
         *             if (isset($o['t'][6]))  $tan6[$n]   = $o['t'][6];
         *             if (isset($o['t'][21])) $tan21[$n]  = $o['t'][21];
         *             if (isset($o['f'][6]))  $fuku6[$n]  = $o['f'][6];
         *             if (isset($o['f'][21])) $fuku21[$n] = $o['f'][21];
         *             if (isset($o['f'][9]))  $fuku9[$n]  = $o['f'][9];
         *         }
         *         $N = count($tan6);
         *         if ($N < 2) {
         *             return ['N' => $N, '状態' => '計算不能', '理由' => '6分前の単勝オッズが足りない'];
         *         }
         * 
         *         // 凍結順位（6分前の単勝 昇順・同値は馬番昇順）
         *         $order = array_keys($tan6);
         *         usort($order, static function ($a, $b) use ($tan6) {
         *             if ($tan6[$a] === $tan6[$b]) return $a <=> $b;
         *             return ($tan6[$a] < $tan6[$b]) ? -1 : 1;
         *         });
         * 
         *         // 必要な時点がそろっているか
         *         $need21 = 0;
         *         foreach ($order as $n) { if (isset($tan21[$n])) $need21++; }
         *         if ($need21 < $N) {
         *             return ['N' => $N, '状態' => '計算不能', '理由' => '21分前の単勝オッズが欠けている'];
         *         }
         *         $needF = 0;
         *         foreach ($order as $n) { if (isset($fuku6[$n])) $needF++; }
         *         if ($needF < $N) {
         *             return ['N' => $N, '状態' => '計算不能', '理由' => '6分前の複勝オッズが欠けている'];
         *         }
         * 
         *         // ── 境界 k（上側 order[k-1]、下側 order[k]）──────────────────
         *         $up = static fn(int $k) => $order[$k - 1];
         *         $dn = static fn(int $k) => $order[$k];
         * 
         *         // W6>=2  ⇔  tan6[下] >= 2 × tan6[上]
         *         $w6ge2 = static fn(int $k) => ($tan6[$dn($k)] >= 2.0 * $tan6[$up($k)]);
         *         // W6<1.50 ⇔ tan6[下] < 1.5 × tan6[上]
         *         $w6lt150 = static fn(int $k) => ($tan6[$dn($k)] <  1.5 * $tan6[$up($k)]);
         *         // W21>=2 ⇔ tan21[下] >= 2 × tan21[上]
         *         $w21ge2 = static fn(int $k) => ($tan21[$dn($k)] >= 2.0 * $tan21[$up($k)]);
         *         // W6<2   ⇔ tan6[下] < 2 × tan6[上]
         *         $w6lt2 = static fn(int $k) => ($tan6[$dn($k)] <  2.0 * $tan6[$up($k)]);
         *         // P6<1.50 ⇔ fuku6[下] < 1.5 × fuku6[上]
         *         $p6lt150 = static fn(int $k) => ($fuku6[$dn($k)] <  1.5 * $fuku6[$up($k)]);
         *         // P6>=1.50 ⇔ fuku6[下] >= 1.5 × fuku6[上]
         *         $p6ge150 = static fn(int $k) => ($fuku6[$dn($k)] >= 1.5 * $fuku6[$up($k)]);
         *         // Wの21→6短縮率>=0.20 ⇔ W6 <= 0.8 × W21
         *         //   ⇔ tan6[下]×tan21[上] <= 0.8 × tan21[下]×tan6[上]
         *         $wShrink20 = static fn(int $k) =>
         *             ($tan6[$dn($k)] * $tan21[$up($k)] <= 0.8 * $tan21[$dn($k)] * $tan6[$up($k)]);
         * 
         *         // ── X1 ──────────────────────────────────────────────────────
         *         $x1 = false;
         *         for ($k = 1; $k <= min(6, $N - 1); $k++) {
         *             if ($w21ge2($k) && ($w6lt2($k) || $wShrink20($k))) { $x1 = true; break; }
         *         }
         *         // ── X2 ──────────────────────────────────────────────────────
         *         $x2 = false;
         *         for ($k = 1; $k <= min(10, $N - 1); $k++) {
         *             if ($w6ge2($k) && $p6lt150($k)) { $x2 = true; break; }
         *         }
         *         // ── X3 ──────────────────────────────────────────────────────
         *         $x3 = false;
         *         if ($N >= 7) {
         *             $x3 = true;
         *             foreach ([3, 4, 5, 6] as $k) {
         *                 if ($k > $N - 1) { $x3 = false; break; }
         *                 if (!$w6lt150($k)) { $x3 = false; break; }
         *             }
         *         }
         *         // ── X4（凍結7番人気以下の異なる2頭以上）─────────────────────
         *         $x4cnt = 0;
         *         for ($rank = 7; $rank <= $N; $rank++) {
         *             $n = $order[$rank - 1];
         *             $ok = false;
         *             if (isset($fuku21[$n], $fuku6[$n]) && $fuku6[$n] <= 0.95 * $fuku21[$n]) $ok = true;
         *             if (!$ok && isset($fuku9[$n], $fuku6[$n]) && $fuku6[$n] <= 0.97 * $fuku9[$n]) $ok = true;
         *             if ($ok) $x4cnt++;
         *         }
         *         $x4 = ($x4cnt >= 2);
         *         // ── X5 ──────────────────────────────────────────────────────
         *         $x5 = false;
         *         for ($k = 7; $k <= min(10, $N - 1); $k++) {
         *             if ($w6ge2($k)) { $x5 = true; break; }
         *         }
         *         // ── Z（k=1〜5 の異なる2境界以上）─────────────────────────────
         *         $zcnt = 0;
         *         for ($k = 1; $k <= min(5, $N - 1); $k++) {
         *             if ($w21ge2($k) && $w6ge2($k) && $p6ge150($k)) $zcnt++;
         *         }
         *         $z = ($zcnt >= 2);
         * 
         *         // ── S0 と mode ──────────────────────────────────────────────
         *         $s0 = 2 * ($x1 ? 1 : 0) + ($x2 ? 1 : 0) + ($x3 ? 1 : 0)
         *             + ($x4 ? 1 : 0) + ($x5 ? 1 : 0) - 2 * ($z ? 1 : 0);
         * 
         *         // X6: N>=7 で UNKNOWN、N<7 で FALSE
         *         if ($N >= 7) { $sMin = $s0; $sMax = $s0 + 1; }
         *         else         { $sMin = $s0; $sMax = $s0; }
         * 
         *         $mA = self::modeOfS($sMin); $mB = self::modeOfS($sMax);
         *         $out = ['N' => $N, 'X1' => $x1, 'X2' => $x2, 'X3' => $x3,
         *                 'X4' => $x4, 'X5' => $x5, 'Z' => $z,
         *                 'S0' => $s0, 'Smin' => $sMin, 'Smax' => $sMax];
         *         if ($mA !== $mB) {
         *             $out['状態'] = '判定不能';
         *             $out['mode'] = 'UNKNOWN';
         *             $out['星']   = '';
         *             return $out;
         *         }
         *         $out['状態'] = '確定';
         *         $out['mode'] = $mA;
         *         $stA = self::starOfS($sMin); $stB = self::starOfS($sMax);
         *         $out['星'] = ($stA === $stB) ? (string) $stA : '';   // 星が割れたら出さない
         *         return $out;
         *     }
         * ────────────────────────────────────────────────────────────── */
        // 入力は self::decScale() で 1万倍した整数です（['ts']['fs'] は元の文字列）。
        $t6 = []; $t21 = []; $f6 = []; $f21 = []; $f9 = [];
        foreach ($sr as $n => $o) {
            if (isset($o['t'][6]))  $t6[$n]  = $o['t'][6];
            if (isset($o['t'][21])) $t21[$n] = $o['t'][21];
            if (isset($o['f'][6]))  $f6[$n]  = $o['f'][6];
            if (isset($o['f'][21])) $f21[$n] = $o['f'][21];
            if (isset($o['f'][9]))  $f9[$n]  = $o['f'][9];
        }
        $N = count($t6);

        // ─────────────────────────────────────────────────────────────
        // @ANCHOR-20261019-ENTRYSET  10月19日003のご指摘2
        //   出馬表の馬番一覧を正として照合します。
        //   オッズ行がまるごと無い馬は $sr に現れないので、
        //   @ANCHOR-20261019-NSET のチェックだけでは素通りしてしまいます。
        // ─────────────────────────────────────────────────────────────
        // ─────────────────────────────────────────────────────────────
        // @ANCHOR-20261019-FROZEN  10月19日005のご指摘3
        //   正本の契約で、凍結後の取消の扱いが決まっていました。
        //     config.json  : after_cutoff_band_policy = 'frozen_win_rank'
        //                    cancellation_policy =
        //                      'immutable_prediction_snapshot_and_versioned_live_overlay'
        //     server_contract.txt 75行:
        //       「取消馬を統合後に除き、残存馬の凍結帯とactive_countから
        //         公開quotaを調整。取消で人気を詰め直さない。」
        //     同 86行: 「期限後の取消はlive_stateへ反映し、
        //                正式publicationは上書きしない。」
        //     同117行: 「取消だけで正式予想を再選出しない。」
        //
        //   つまり凍結の時点（6分前）で線を引きます。
        //     ・6分前の単勝が「取消」＝凍結前の取消
        //         → 出走馬集合から外して凍結順位を作る
        //     ・6分前に実オッズがあり、そのあとで「取消」＝凍結後の取消
        //         → 凍結順位・帯・信号・modeは作り直さない。
        //           ライブ側の情報として別に記録するだけ。
        //
        //   前の版は時点を問わず外して信号を計算し直していました。誤りです。
        // ─────────────────────────────────────────────────────────────
        // ─────────────────────────────────────────────────────────────
        // @ANCHOR-20261019-SLOTS  10月19日006のご指摘2
        //   前の版は「6分前の数値オッズが無い＝凍結前の取消」としていました。
        //   これは誤りです。6分前が欠損しているだけで、取消の根拠が
        //   3分前にしか無い馬まで出走集合から外してしまい、
        //   「欠損馬が頭数から消える」問題が再発していました。
        //
        //   正しくは、取消が記録された時点で分けます。
        //     ・取消が6分前以前の時点にある        → 凍結前の取消（外す）
        //     ・取消が3分前・発走時にしかない
        //         かつ6分前に実数値がある          → 凍結後の取消（残す）
        //         かつ6分前が欠損                  → 取消へ振り替えない。
        //                                            欠損として扱い、頭数も保つ
        //     ・取消の時点より後に実数値がある      → 入力不整合として止める
        //
        //   時点の前後は self::slotOrd() で比べます（999=30分前、−999=発走時）。
        // ─────────────────────────────────────────────────────────────
        $FREEZE = 6;                 // 凍結は6分前
        $cancelPre  = [];            // 凍結前の取消（出走馬集合から外す）
        $cancelPost = [];            // 凍結後の取消（凍結集合はそのまま）
        $cancelLate = [];            // 6分前が欠損で、取消が凍結後にしかない馬
        $conflict   = [];            // 取消の時点より後に実数値がある馬
        foreach ($sr as $hn => $ho) {
            if (!isset($ho['cancel'])) continue;
            $slots = $ho['cancel_slots'] ?? [];
            $cOrd = null;
            foreach ($slots as $t) {
                $o = self::slotOrd($t);
                if ($cOrd === null || $o > $cOrd) $cOrd = $o;   // いちばん早い取消
            }
            if ($cOrd === null) { $cancelLate[] = $hn; continue; }

            // 取消の時点より後（発走に近い側）に実数値が残っていないか
            foreach (array_keys($ho['t'] ?? []) as $t) {
                if (self::slotOrd($t) < $cOrd) { $conflict[] = $hn; break; }
            }
            if (in_array($hn, $conflict, true)) continue;

            if ($cOrd >= $FREEZE) {
                $cancelPre[] = $hn;                      // 凍結前に取消が確認できた
            } elseif (isset($ho['t'][$FREEZE])) {
                $cancelPost[] = $hn;                     // 6分前は数値、そのあと取消
            } else {
                $cancelLate[] = $hn;                     // 6分前が欠損・根拠は凍結後だけ
            }
        }
        sort($cancelPre); sort($cancelPost); sort($cancelLate); sort($conflict);

        if (!empty($conflict)) {
            // ─────────────────────────────────────────────────────────
            // @ANCHOR-20261019-NREPORT  10月19日007のご指摘3
            //   入力不整合で早く止めるときも、頭数は出馬表を正として返します。
            //   以前は count($sr)（オッズが取れた馬の数）を返していたので、
            //   馬番の欠落が重なると出馬表と頭数がずれていました。
            //   出馬表の頭数・実出走頭数・オッズが取れた馬数は別物なので、
            //   それぞれ別のキーで返します。
            // ─────────────────────────────────────────────────────────
            $hasEntry = ($entrySet !== null && !empty($entrySet));
            return ['N' => $hasEntry ? count($entrySet) : count($sr),
                    'entry_count'    => $hasEntry ? count($entrySet) : null,
                    'acquired_count' => count($sr),
                    'active_count'   => null,   // 矛盾した取消情報からは確定できません
                    '状態' => '計算不能', 'frozen' => [],
                    'cancelled' => $cancelPre, 'cancelled_post' => $cancelPost,
                    'cancelled_late' => $cancelLate,
                    '理由' => '取消の時点より後に実オッズがある（入力不整合・馬番 '
                              . implode('・', $conflict) . '）'
                              . ($hasEntry ? '／出馬表 ' . count($entrySet)
                                             . '頭・オッズが取れた馬 ' . count($sr) . '頭' : '')];
        }
        $cancelled = $cancelPre;   // 以降の「外す対象」は凍結前のぶんだけ

        if ($entrySet !== null) {
            if (empty($entrySet)) {
                // @ANCHOR-20261019-ENTRYREQ  10月19日008のご指摘2
                //   出馬表が無いレースは、取得できたオッズの頭数で代用しません。
                //   既知の宣言頭数・取得できた馬数・不明な実出走頭数を分けて返します。
                return ['N' => ($declaredCount !== null) ? $declaredCount : count($sr),
                        'entry_count'    => 0,
                        'acquired_count' => count($sr),
                        'active_count'   => null,   // 出馬表が無いので確定できません
                        '状態' => '計算不能', 'frozen' => [],
                        'cancelled' => $cancelPre, 'cancelled_post' => $cancelPost,
                        'cancelled_late' => $cancelLate,
                        '理由' => '出馬表が欠損している（出馬表 0頭'
                                  . ($declaredCount !== null
                                     ? '・レース情報の出走頭数 ' . $declaredCount . '頭' : '')
                                  . '・オッズが取れた馬 ' . count($sr) . '頭）'];
            }
            $entryNums = array_keys($entrySet);
            sort($entryNums);

            // 宣言頭数は「取消を含む出馬表の頭数」と比べます
            if ($declaredCount !== null && $declaredCount !== count($entryNums)) {
                return ['N' => count($entryNums), '状態' => '計算不能', 'frozen' => [],
                        'cancelled' => $cancelPre, 'cancelled_post' => $cancelPost,
                        'cancelled_late' => $cancelLate,
                        '理由' => 'レース情報の出走頭数（' . $declaredCount
                                  . '頭）と出馬表の頭数（' . count($entryNums) . '頭）が合わない'];
            }
            $extra = array_values(array_diff(array_keys($sr), $entryNums));
            if (!empty($extra)) {
                sort($extra);
                return ['N' => count($entryNums), '状態' => '計算不能', 'frozen' => [],
                        'cancelled' => $cancelPre, 'cancelled_post' => $cancelPost,
                        'cancelled_late' => $cancelLate,
                        '理由' => '出馬表に無い馬番のオッズがある（馬番 '
                                  . implode('・', $extra) . '）'];
            }

            // 取消・除外を外した馬が実出走馬です
            $active = array_values(array_diff($entryNums, $cancelled));
            sort($active);
            if (count($active) < 2) {
                return ['N' => count($active), '状態' => '計算不能', 'frozen' => [],
                        'cancelled' => $cancelPre, 'cancelled_post' => $cancelPost,
                        'cancelled_late' => $cancelLate,
                        '理由' => '取消を除いた出走馬が' . count($active) . '頭しかいない'];
            }
            // 実出走馬の6分前単勝がそろっているかを見ます（取消馬は対象外）
            $lack = [];
            foreach ($active as $hn) {
                if (!isset($sr[$hn]['t'][6])) $lack[] = $hn;
            }
            if (!empty($lack)) {
                return ['N' => count($active), '状態' => '計算不能', 'frozen' => [],
                        'cancelled' => $cancelPre, 'cancelled_post' => $cancelPost,
                        'cancelled_late' => $cancelLate,
                        '理由' => '出走馬の6分前単勝が無い（馬番 '
                                  . implode('・', $lack) . ' / 出馬表 '
                                  . count($entryNums) . '頭・取消 '
                                  . count($cancelled) . '頭）'
                                  . (empty($cancelLate) ? ''
                                     : '／うち、取消の記録が3分前以降にしかない馬 '
                                       . implode('・', $cancelLate)
                                       . '（凍結前の取消として外しません）')];
            }
            // 取消馬が $t6 等に紛れていないことを確かめます
            foreach ($cancelled as $hn) {
                unset($t6[$hn], $t21[$hn], $f6[$hn], $f21[$hn], $f9[$hn]);
            }
            $N = count($t6);
        }

        // ─────────────────────────────────────────────────────────────
        // @ANCHOR-20261019-NSET  10月19日002のご指摘1
        //   6分前の単勝が欠けた馬を黙って外すと、頭数Nが縮みます。
        //   Nが縮むと目標頭数（target_count）も境界kの本数も変わるので、
        //   「判定不能」が「堅い」に化けることがあります。
        //   外さずに、計算不能として止めます。どの馬かも理由に出します。
        //
        //   注意：オッズだけでは「取消馬」と「データ欠落」を見分けられません。
        //   出馬表（t_horse_odds_finder_horses）を見る作りにするのが本筋で、
        //   そこは本番移植のときに入れます（V06）。
        // ─────────────────────────────────────────────────────────────
        $missing6 = [];
        foreach ($sr as $hn => $ho) {
            // @ANCHOR-20261019-SLOTS  取消として確定した馬だけ対象外にします。
            //   cancelLate（6分前が欠損で、取消の根拠が凍結後にしかない馬）は
            //   取消に振り替えないので、欠損として検出します（ご指摘006-2）。
            if (in_array($hn, $cancelPre, true) || in_array($hn, $cancelPost, true)) continue;
            if (!isset($ho['t'][6])) $missing6[] = $hn;
        }
        if (!empty($missing6)) {
            sort($missing6);
            return ['N' => count($sr) - count($cancelled), '状態' => '計算不能',
                    'frozen' => [], 'cancelled' => $cancelPre, 'cancelled_post' => $cancelPost,
                        'cancelled_late' => $cancelLate,
                    '理由' => '6分前の単勝オッズが欠けた馬がある（馬番 '
                              . implode('・', $missing6) . '）'
                              . (empty($cancelLate) ? ''
                                 : '／うち、取消の記録が3分前以降にしかない馬 '
                                   . implode('・', $cancelLate)
                                   . '（凍結前の取消として外しません）')];
        }

        if ($N < 2) {
            return ['N' => $N, '状態' => '計算不能', 'frozen' => [],
                    '理由' => '6分前の単勝オッズが足りない（凍結順位が作れない）'];
        }

        // 凍結順位（6分前の単勝 昇順・同値は馬番昇順）
        $order = array_keys($t6);
        usort($order, static function ($a, $b) use ($t6) {
            if ($t6[$a] === $t6[$b]) return $a <=> $b;
            return ($t6[$a] < $t6[$b]) ? -1 : 1;
        });
        $frozen = [];
        $bands  = [];
        foreach ($order as $idx => $n) {
            $frozen[$n] = $idx + 1;
            // @ANCHOR-20261019-SLOTS  帯（A=1〜6／B=7〜10／D=11以下）も返します
            $bands[$n] = ($frozen[$n] <= 6) ? 'A' : (($frozen[$n] <= 10) ? 'B' : 'D');
        }

        // 21分前と複勝の欠損は「計算不能」にせず、UNKNOWN として伝播させます。
        // （6分前の単勝だけは凍結順位の土台なので必須です）
        $up = static fn(int $k) => $order[$k - 1];
        $dn = static fn(int $k) => $order[$k];

        // 比較はすべて整数の掛け算と大小比較だけです（丸めが一度も入りません）。
        //   a >= 2b   → a >= 2*b
        //   a <  2b   → a <  2*b
        //   a <  1.5b → 2a < 3b
        //   a >= 1.5b → 2a >= 3b
        $ge2 = static function (array $m, int $k) use ($up, $dn): ?bool {
            $a = $m[$dn($k)] ?? null; $b = $m[$up($k)] ?? null;
            return ($a === null || $b === null) ? null : ($a >= 2 * $b);
        };
        $lt2 = static function (array $m, int $k) use ($up, $dn): ?bool {
            $a = $m[$dn($k)] ?? null; $b = $m[$up($k)] ?? null;
            return ($a === null || $b === null) ? null : ($a < 2 * $b);
        };
        $lt150 = static function (array $m, int $k) use ($up, $dn): ?bool {
            $a = $m[$dn($k)] ?? null; $b = $m[$up($k)] ?? null;
            return ($a === null || $b === null) ? null : (2 * $a < 3 * $b);
        };
        $ge150 = static function (array $m, int $k) use ($up, $dn): ?bool {
            $a = $m[$dn($k)] ?? null; $b = $m[$up($k)] ?? null;
            return ($a === null || $b === null) ? null : (2 * $a >= 3 * $b);
        };
        // 単勝の 21→6 短縮率 >= 0.20  ⇔  W6 <= 0.8 × W21
        //   ⇔ t6[下] × t21[上] × 10 <= t21[下] × t6[上] × 8
        $wShrink20 = static function (int $k) use ($up, $dn, $t6, $t21): ?bool {
            $a = $t6[$dn($k)]  ?? null; $b = $t21[$up($k)] ?? null;
            $c = $t21[$dn($k)] ?? null; $d = $t6[$up($k)]  ?? null;
            if ($a === null || $b === null || $c === null || $d === null) return null;
            return (10 * $a * $b <= 8 * $c * $d);
        };
        // 複勝の短縮率 >= (100-$keep)/100  ⇔  後 × 100 <= 前 × $keep
        $pShrink = static function (?int $after, ?int $before, int $keep): ?bool {
            if ($after === null || $before === null) return null;
            return (100 * $after <= $keep * $before);
        };

        // ── X1：k=1〜min(6,N-1) のどれかで W21>=2 かつ（W6<2 または 21→6短縮>=0.20）
        $v = [];
        for ($k = 1; $k <= min(6, $N - 1); $k++) {
            $v[] = self::triAnd([$ge2($t21, $k), self::triOr([$lt2($t6, $k), $wShrink20($k)])]);
        }
        $x1 = self::atLeast($v, 1);

        // ── X2：k=1〜min(10,N-1) のどれかで W6>=2 かつ P6<1.50
        $v = [];
        for ($k = 1; $k <= min(10, $N - 1); $k++) {
            $v[] = self::triAnd([$ge2($t6, $k), $lt150($f6, $k)]);
        }
        $x2 = self::atLeast($v, 1);

        // ── X3：N<7 は FALSE。N>=7 で k=3,4,5,6 の W6<1.50 が全成立
        if ($N < 7) {
            $x3 = false;
        } else {
            $v = [];
            foreach ([3, 4, 5, 6] as $k) {
                $v[] = ($k > $N - 1) ? null : $lt150($t6, $k);
            }
            $x3 = self::triAnd($v);
        }

        // ── X4：凍結7番人気以下の異なる2頭以上で、複勝 21→6>=0.05 または 9→6>=0.03
        $v = [];
        for ($rank = 7; $rank <= $N; $rank++) {
            $n = $order[$rank - 1];
            $v[] = self::triOr([
                $pShrink($f6[$n] ?? null, $f21[$n] ?? null, 95),
                $pShrink($f6[$n] ?? null, $f9[$n]  ?? null, 97),
            ]);
        }
        $x4 = self::atLeast($v, 2);

        // ── X5：k=7〜min(10,N-1) のどれかで W6>=2
        $v = [];
        for ($k = 7; $k <= min(10, $N - 1); $k++) { $v[] = $ge2($t6, $k); }
        $x5 = self::atLeast($v, 1);

        // ── Z：k=1〜min(5,N-1) の異なる2境界以上で W21>=2・W6>=2・P6>=1.50
        $v = [];
        for ($k = 1; $k <= min(5, $N - 1); $k++) {
            $v[] = self::triAnd([$ge2($t21, $k), $ge2($t6, $k), $ge150($f6, $k)]);
        }
        $z = self::atLeast($v, 2);

        // ── S の範囲（UNKNOWN は幅になります）
        //   S = 2×X1 + X2 + X3 + X4 + X5 + X6 − 2×Z
        //   X1 が UNKNOWN なら [0,2]、Z が UNKNOWN なら [−2,0] の幅です。
        $rng = static function (?bool $b, int $w): array {
            if ($b === null) return ($w >= 0) ? [0, $w] : [$w, 0];
            return $b ? [$w, $w] : [0, 0];
        };
        $s0min = 0; $s0max = 0;
        foreach ([[$x1, 2], [$x2, 1], [$x3, 1], [$x4, 1], [$x5, 1], [$z, -2]] as $pair) {
            $r = $rng($pair[0], $pair[1]);
            $s0min += $r[0]; $s0max += $r[1];
        }
        // X6：N>=7 で UNKNOWN（[0,1]）、N<7 で FALSE（[0,0]）
        $sMin = $s0min;
        $sMax = $s0max + (($N >= 7) ? 1 : 0);

        $out = ['N' => $N, 'X1' => $x1, 'X2' => $x2, 'X3' => $x3,
                'X4' => $x4, 'X5' => $x5, 'Z' => $z,
                'S0min' => $s0min, 'S0max' => $s0max,
                'S0' => ($s0min === $s0max) ? $s0min : null,
                'Smin' => $sMin, 'Smax' => $sMax, 'frozen' => $frozen,
                'bands' => $bands,
                'cancelled' => $cancelPre, 'cancelled_post' => $cancelPost,
                'cancelled_late' => $cancelLate];

        $mA = self::modeOfS($sMin); $mB = self::modeOfS($sMax);
        if ($mA !== $mB) {
            $out['状態'] = '判定不能';
            $out['mode'] = 'UNKNOWN';
            $out['星']   = '';
            return $out;
        }
        $out['状態'] = '確定';
        $out['mode'] = $mA;
        $stA = self::starOfS($sMin); $stB = self::starOfS($sMax);
        $out['星'] = ($stA === $stB) ? (string) $stA : '';   // 星が割れたら出さない
        return $out;
    }

    /**
     * @ANCHOR-20261019-EXACT  十進数文字列を 1万倍した整数にします（ご指摘1）
     *
     * JRAのオッズは小数1桁なので、1万倍なら余裕があります。
     * 掛け算をしても 1e8 × 1e8 × 10 = 1e17 で64bit整数に収まります。
     * 数字以外・小数5桁以上・0以下は null（欠損扱い）を返します。
     */
    public static function decScale($v): ?int
    {
        if ($v === null) return null;
        $s = trim((string) $v);
        if ($s === '' || !preg_match('/^(\d+)(?:\.(\d{1,4}))?$/', $s, $m)) return null;
        $frac = str_pad(isset($m[2]) ? $m[2] : '', 4, '0');
        $i = ((int) $m[1]) * 10000 + ((int) $frac);
        return ($i > 0) ? $i : null;
    }

    /**
     * @ANCHOR-20261019-SLOTS  時点を「発走までの分」に直します
     *
     * DBの timing は 999=30分前、−999=発走時、ほかはそのままの分数です。
     * この値が大きいほど発走から遠い（早い時点）という意味になります。
     */
    public static function slotOrd(int $t): int
    {
        if ($t === \App\Constants\Constants::ODDS_DB_FIRST) return 30;
        if ($t === \App\Constants\Constants::ODDS_DB_LAST)  return 0;
        return $t;
    }

    /** @ANCHOR-20261019-EXACT  三値のAND（FALSEが1つでもFALSE／UNKNOWNがあればUNKNOWN） */
    public static function triAnd(array $v): ?bool
    {
        $unk = false;
        foreach ($v as $b) {
            if ($b === false) return false;
            if ($b === null)  $unk = true;
        }
        return $unk ? null : true;
    }

    /** @ANCHOR-20261019-EXACT  三値のOR（TRUEが1つでもTRUE／UNKNOWNがあればUNKNOWN） */
    public static function triOr(array $v): ?bool
    {
        $unk = false;
        foreach ($v as $b) {
            if ($b === true) return true;
            if ($b === null) $unk = true;
        }
        return $unk ? null : false;
    }

    /**
     * @ANCHOR-20261019-EXACT  三値の「$k個以上成立」（reference.py の at_least と同じ）
     *
     *   TRUEが$k個以上           → TRUE
     *   TRUE＋UNKNOWNが$k個未満  → FALSE
     *   それ以外                 → UNKNOWN
     */
    public static function atLeast(array $v, int $k): ?bool
    {
        $t = 0; $u = 0;
        foreach ($v as $b) {
            if ($b === true)      $t++;
            elseif ($b === null)  $u++;
        }
        if ($t >= $k)       return true;
        if ($t + $u < $k)   return false;
        return null;
    }

    /**
     * ═════════════════════════════════════════════════════════════════════════
     * @ANCHOR-20261015-DIFF-SPLIT  送信文の差がどこから来ているかを切り分ける
     * ═════════════════════════════════════════════════════════════════════════
     * 10月15日（3回目）02.txtへの対応です。
     *   「prompt_verifyの72レース中37レースで送信文の文字数に差があります。
     *     この差が改行・空白・ログ保存形式によるものか、
     *     AIへの指示内容の差なのかを切り分けてください」
     *
     * ■ 先に結論から（できることとできないこと）
     *   ・ログ保存形式の影響は【ゼロ】です。本文は保存していませんでした。
     *     残していたのはSHA-256と文字数だけなので、保存形式で差は出ません。
     *   ・改行・空白の影響も【ありません】。組み直しは本番とまったく同じ関数
     *     （_getAiAnalysisPrompt）を通しています。同じレースを2回組み直すと
     *     SHA-256が一致することを下の「決定性の確認」で示します。
     *   ・残る候補は2つで、どちらも【AIへ渡す数値の中身】です。
     *       候補1  注目馬番①②（アプリが計算して渡す値か、PHPが再計算した値か）
     *       候補2  各馬の過去回収率・類似レース統計（レース後の集計で変わる値）
     *     それぞれのブロックの文字数を実測して、観測された差と並べます。
     *
     * ■ 候補1について（第45章では触れていませんでした。こちらの不備です）
     *   お願い文には「①オッズ間断層の調査から絞り込んだ馬番」
     *   「②期待数値の調査から絞り込んだ馬番」が入ります。
     *   本番ではアプリ（Flutter）が計算して渡します。
     *   組み直しでは渡す値が無いので、PHPが同じ計算をやり直します
     *   （_calcHintHorseNums）。DartとPHPは別の実装なので、
     *   同値の並び順やデータ欠損の扱いで馬番が変わり得ます。
     *   馬番リストの桁が1つ変わるだけで文字数が1〜4文字動くので、
     *   観測された差（最小0・中央1・最大192文字）とよく合います。
     *
     * ■ 候補2について
     *   1頭ごとに「乖離帯別回収率」「OPI別回収率」「フェーズパターン別回収率」
     *   「類似レース統計」の4行が入ります。16頭なら64行です。
     *   これらはレース結果が入るたびに集計バッチで作り直されるので、
     *   「45.2%」が「45.3%」になるような違いが生まれます。
     *
     * ■ 10月17日以降は、この切り分けが要らなくなります
     *   送信直前に本文そのものを残すようにしました（46-9）。
     *   実際に送った本文と組み直した本文を行単位で比べられるので、
     *   推し量る必要がありません（--prompt-diff）。
     *
     * @return array 切り分けの材料（1レースぶん）
     */
}
