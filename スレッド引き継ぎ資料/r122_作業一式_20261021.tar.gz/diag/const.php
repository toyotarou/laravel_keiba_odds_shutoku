<?php
namespace App\Constants;
class Constants { const ODDS_DB_FIRST = 999; const ODDS_DB_LAST = -999; }
