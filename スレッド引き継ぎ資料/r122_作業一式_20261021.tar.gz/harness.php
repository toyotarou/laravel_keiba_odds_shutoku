<?php
namespace App\Http\Controllers\Api;
if (!function_exists('App\Http\Controllers\Api\env')) {
    function env($k, $d = null) { $v = getenv($k); return ($v === false) ? $d : $v; }
    function storage_path($p = '') { return '/home/claude/r122/storage/' . ltrim($p, '/'); }
    function app($x = null) { return null; }
}
class AiController
{
    public const V04_THRESHOLDS = [
        'win_wall' => 2.00, 'place_wall' => 1.50,
        'win_wall_shrink_fraction' => 0.20, 'middle_close_upper_bound' => 1.50,
        'place_shorten_21_to_6_fraction' => 0.05, 'place_shorten_9_to_6_fraction' => 0.03,
        'similar_min_races' => 50, 'similar_3in_delta_pp' => 10.0,
    ];
    public const V04_SIGNAL_WEIGHTS = ['X1'=>2,'X2'=>1,'X3'=>1,'X4'=>1,'X5'=>1,'X6'=>1,'Z'=>-2];
    public const V04_MODE_FIRM_MAX = 1;
    public const V04_MODE_MIXED_MAX = 3;
    public const V04_UNKNOWN_COUNT_AT_LEAST = 3;
    public const V04_QUOTA_BY_TARGET = [
        7 => ['FIRM' => [5,2,0], 'MIXED' => [3,3,1], 'VOLATILE' => [3,3,1]],
        6 => ['FIRM' => [4,2,0], 'MIXED' => [3,2,1], 'VOLATILE' => [3,2,1]],
        5 => ['FIRM' => [4,1,0], 'MIXED' => [3,2,0], 'VOLATILE' => [2,2,1]],
        4 => ['FIRM' => [3,1,0], 'MIXED' => [2,2,0], 'VOLATILE' => [2,1,1]],
    ];
    public const V04_QUOTA_EXTREME = [7 => ['EXTREME' => [2,3,2]]];
    public const B12_RECOVERY_LOW_THRESH = 40.0;
    public const V04_X6_BASELINE = null;
}
final class BaganrikiSignals
{

    // ═════════════════════════════════════════════════════════════════════
    // @ANCHOR-20261020-R122-EXACT  任意精度の十進数で、丸めずに比べます
    // ═════════════════════════════════════════════════════════════════════
    // 根拠：server_contract_r12.2.txt 2章・12章／詳細設計書8章
    //
    //   【直した理由】
    //     これまで W（単勝比）と P（複勝比）を PHP の float で割り算し、
    //     小数4桁に丸めてから閾値と比べていました。
    //     「元値の正確な分数で比較し、表示用に丸めた比率を使用しない」
    //     という契約に反します。境界ちょうどの馬で判定が変わり得ます。
    //
    //   【直し方】
    //     割り算も float も使いません。十進数の文字列のまま、
    //     たすき掛け（分子×相手の分母）を多倍長整数で比べます。
    //     桁数の上限を固定していないので、小数第5位以上の値が来ても
    //     切り捨てたり拒否したりしません。
    //     W や P の数値は画面と監査のために今までどおり残しますが、
    //     判定には使いません。

    /** 十進数の文字列を ['d'=>数字だけの文字列, 'sc'=>小数桁数] へ。読めなければ null */
    public static function decNorm($v): ?array
    {
        if ($v === null || is_bool($v)) { return null; }
        $s = trim((string) $v);
        if ($s === '') { return null; }
        if (!preg_match('/^(\d{1,128})(?:\.(\d{1,128}))?$/', $s, $m)) { return null; }
        $int  = $m[1];
        $frac = $m[2] ?? '';
        $d = ltrim($int . $frac, '0');
        if ($d === '') { $d = '0'; }
        if (strlen($d) > 128) { return null; }   // 契約の128桁上限
        return ['d' => $d, 'sc' => strlen($frac)];
    }

    /** 数字列どうしの掛け算（多倍長。筆算と同じやり方） */
    public static function bigMul(string $a, string $b): string
    {
        if ($a === '0' || $b === '0') { return '0'; }
        $la = strlen($a); $lb = strlen($b);
        $r = array_fill(0, $la + $lb, 0);
        for ($i = $la - 1; $i >= 0; $i--) {
            $ai = (int) $a[$i];
            if ($ai === 0) { continue; }
            $carry = 0;
            for ($j = $lb - 1; $j >= 0; $j--) {
                $t = $r[$i + $j + 1] + $ai * (int) $b[$j] + $carry;
                $r[$i + $j + 1] = $t % 10;
                $carry = intdiv($t, 10);
            }
            $r[$i] += $carry;
        }
        $s = ltrim(implode('', $r), '0');
        return ($s === '') ? '0' : $s;
    }

    /** 数字列どうしの大小（-1 / 0 / 1） */
    public static function bigCmp(string $a, string $b): int
    {
        $a = ltrim($a, '0'); $b = ltrim($b, '0');
        if ($a === '') { $a = '0'; }
        if ($b === '') { $b = '0'; }
        if (strlen($a) !== strlen($b)) { return (strlen($a) < strlen($b)) ? -1 : 1; }
        return strcmp($a, $b) <=> 0;
    }

    /**
     * 項の積どうしを比べます。各項は十進数の文字列、k は整数の係数。
     * 返りは -1 / 0 / 1。読めない値が混ざれば null。
     *   例：4×W21 と 5×W6 を比べる → cmpProd(4,[l21,u6], 5,[l6,u21])
     */
    public static function cmpProd(int $kl, array $left, int $kr, array $right): ?int
    {
        $build = static function (int $k, array $xs): ?array {
            $d = (string) abs($k); $sc = 0;
            foreach ($xs as $x) {
                $n = self::decNorm($x);
                if ($n === null) { return null; }
                $d = self::bigMul($d, $n['d']);
                $sc += $n['sc'];
            }
            return ['d' => $d, 'sc' => $sc];
        };
        $L = $build($kl, $left);
        $R = $build($kr, $right);
        if ($L === null || $R === null) { return null; }
        // 小数桁をそろえてから比べます（10の冪を掛けるだけ＝0を足すだけ）
        $diff = $L['sc'] - $R['sc'];
        if ($diff > 0)      { $R['d'] = ($R['d'] === '0') ? '0' : $R['d'] . str_repeat('0', $diff); }
        elseif ($diff < 0)  { $L['d'] = ($L['d'] === '0') ? '0' : $L['d'] . str_repeat('0', -$diff); }
        return self::bigCmp($L['d'], $R['d']);
    }

    /**
     * 比 (num/den) と有理数 (p/q) の大小。num/den は十進数の文字列。
     * num/den >= p/q ⇔ num×q >= den×p（den>0・q>0 のとき）
     */
    public static function cmpRatio($num, $den, int $p, int $q): ?int
    {
        return self::cmpProd($q, [$num], $p, [$den]);
    }

    /** @ANCHOR-20261013-V04-CORE  有効な観測値か（0・負・欠損・真偽値は不可） */
    public static function v04Valid($x): bool
    {
        if (is_bool($x) || $x === null) return false;
        if (!is_numeric($x)) return false;
        return ((float) $x) > 0;
    }

    /**
     * @ANCHOR-20261013-V04-CORE  三値のOR集約（付録F tri_any と同一）
     *   1つでも成立 → TRUE。成立し得る未観測が残る → UNKNOWN。
     *   対象が空（構造的非該当）→ FALSE。
     * @param array $conditions true / false / null の列
     */
    public static function v04TriAny(array $conditions): string
    {
        $unknown = false;
        foreach ($conditions as $v) {
            if ($v === true)  return 'TRUE';
            if ($v === null)  $unknown = true;
        }
        return $unknown ? 'UNKNOWN' : 'FALSE';
    }

    /**
     * @ANCHOR-20261013-V04-CORE  三値の件数集約（付録F tri_at_least と同一）
     *   成立数が n 以上 → TRUE
     *   成立数＋不明数が n に届かない → FALSE（欠損を自動でFALSEにするのではなく、
     *     「どう転んでも届かない」と断定できる場合だけFALSE）
     *   それ以外 → UNKNOWN
     */
    public static function v04TriAtLeast(array $conditions, int $n): string
    {
        $t = 0; $u = 0;
        foreach ($conditions as $v) {
            if ($v === true) $t++;
            elseif ($v === null) $u++;
        }
        if ($t >= $n)      return 'TRUE';
        if ($t + $u < $n)  return 'FALSE';
        return 'UNKNOWN';
    }

    /**
     * @ANCHOR-20261013-V04-CORE  6分前人気で固定した隣接馬番ペアの W(k,t) / P(k,t)
     *
     * 02-1「6分前人気で h[k],h[k+1] の隣接馬番ペアを固定。各時点では順位k/k+1の
     *   別の馬へ差し替えず、同じh番号のオッズで比率を計算する」
     *   W(k,t)=win(h[k+1],t)/win(h[k],t)、P(k,t)=place_min(h[k+1],t)/place_min(h[k],t)
     *   0・負・欠損・取消は計算不可（null）。
     *   21分前に順位が入れ替わっていてW<1になっても、同じ馬の実測が有効なら
     *   比率は残し rank_crossed=true を別記する（別の馬に差し替えない）。
     *
     * @param array $pHorses 6分前単勝人気の昇順に並んだ出走馬
     * @return array k（1..N-1）=> ペア情報
     */
    public static function v04Pairs(array $pHorses): array
    {
        $T = [21, 18, 15, 12, 9, 6];

        $ratio = static function (array $u, array $l, string $key, int $t): ?float {
            $uv = $u[$key][$t] ?? null;
            $lv = $l[$key][$t] ?? null;
            if (!self::v04Valid($uv) || !self::v04Valid($lv)) return null;
            return (float) $lv / (float) $uv;          // 下側 ÷ 上側
        };

        $pairs = [];
        $cnt   = count($pHorses);
        for ($i = 0; $i < $cnt - 1; $i++) {
            $u = $pHorses[$i];
            $l = $pHorses[$i + 1];
            $k = $i + 1;                               // 位置番号（付録Fのkと同じ）

            $W = []; $P = [];
            // @ANCHOR-20261020-R122-EXACT  元値（十進数の文字列）をそのまま持ちます。
            //   判定はこの元値で行い、$W/$P の数値は画面と監査だけに使います。
            $raw = ['Wn' => [], 'Wd' => [], 'Pn' => [], 'Pd' => []];
            foreach ($T as $t) {
                $W[$t] = $ratio($u, $l, 'tan_series',      $t);
                $P[$t] = $ratio($u, $l, 'fuku_min_series', $t);
                $raw['Wd'][$t] = $u['tan_series'][$t]      ?? null;   // 上側＝分母
                $raw['Wn'][$t] = $l['tan_series'][$t]      ?? null;   // 下側＝分子
                $raw['Pd'][$t] = $u['fuku_min_series'][$t] ?? null;
                $raw['Pn'][$t] = $l['fuku_min_series'][$t] ?? null;
            }

            $w21 = $W[21]; $w6 = $W[6]; $p6 = $P[6];

            // ─────────────────────────────────────────────────────────
            // @ANCHOR-20261020-R122-EXACT  判定はすべて元値のたすき掛けで行います
            //   【旧】float で割った比を 2.0 や 1.5 と比べていました。
            //   W>=2    ⇔ 下側 >= 2×上側
            //   W<1.50  ⇔ 2×下側 <  3×上側
            //   P>=1.50 ⇔ 2×下側 >= 3×上側
            //   縮小率>=0.20 ⇔ 4×W21 >= 5×W6 ⇔ 4×下21×上6 >= 5×下6×上21
            // ─────────────────────────────────────────────────────────
            $cw = static function (int $t, int $p, int $q) use ($raw): ?int {
                return self::cmpRatio($raw['Wn'][$t] ?? null, $raw['Wd'][$t] ?? null, $p, $q);
            };
            $cp = static function (int $t, int $p, int $q) use ($raw): ?int {
                return self::cmpRatio($raw['Pn'][$t] ?? null, $raw['Pd'][$t] ?? null, $p, $q);
            };
            $t1 = $cw(21, 2, 1); $w21Ge2 = ($t1 === null) ? null : ($t1 >= 0);
            $t2 = $cw(6,  2, 1); $w6Ge2  = ($t2 === null) ? null : ($t2 >= 0);
            $t3 = $cw(6,  3, 2); $w6Lt15 = ($t3 === null) ? null : ($t3 <  0);
            $t4 = $cp(6,  3, 2); $p6Ge15 = ($t4 === null) ? null : ($t4 >= 0);
            $t5 = $cw(21, 1, 1); $crossed = ($t5 === null) ? null : ($t5 < 0);
            $t6 = self::cmpProd(4, [$raw['Wn'][21] ?? null, $raw['Wd'][6]  ?? null],
                                5, [$raw['Wn'][6]  ?? null, $raw['Wd'][21] ?? null]);
            $shrink20 = ($t6 === null) ? null : ($t6 >= 0);
            $t7 = self::cmpProd(1, [$raw['Wn'][6]  ?? null, $raw['Wd'][21] ?? null],
                                1, [$raw['Wn'][21] ?? null, $raw['Wd'][6]  ?? null]);

            // 壁の出現／消滅／拡大／縮小（欠損は不明のまま）
            $appear = $vanish = $expand = $shrink = null;
            $shrinkRate = null;
            if ($w21Ge2 !== null && $w6Ge2 !== null) {
                $appear = (!$w21Ge2 && $w6Ge2);
                $vanish = ($w21Ge2 && !$w6Ge2);
            }
            if ($t7 !== null) { $expand = ($t7 > 0); $shrink = ($t7 < 0); }
            // 縮小率の数値は画面と監査のためだけに残します（判定には使いません）
            if ($w21 !== null && $w6 !== null && $w21 > 0) { $shrinkRate = ($w21 - $w6) / $w21; }
            // 単複の一致／不一致（単勝壁 W>=2.00、複勝補強 P>=1.50）
            $agree = ($w6Ge2 !== null && $p6Ge15 !== null) ? ($w6Ge2 === $p6Ge15) : null;

            $missing = [];
            foreach ($T as $t) {
                if ($W[$t] === null) $missing[] = "W{$t}";
                if ($P[$t] === null) $missing[] = "P{$t}";
            }

            $pairs[$k] = [
                'k'            => $k,
                'upper_num'    => (int) ($u['num'] ?? 0),
                'lower_num'    => (int) ($l['num'] ?? 0),
                'upper_pop'    => (int) ($u['popularity'] ?? 0),
                'lower_pop'    => (int) ($l['popularity'] ?? 0),
                'W'            => array_map(static fn($v) => $v === null ? null : round($v, 4), $W),
                'P'            => array_map(static fn($v) => $v === null ? null : round($v, 4), $P),
                '出現'         => $appear,
                '消滅'         => $vanish,
                '拡大'         => $expand,
                '縮小'         => $shrink,
                '縮小率'       => $shrinkRate === null ? null : round($shrinkRate, 4),
                '単複一致'     => $agree,
                '単勝壁6分'    => $w6Ge2,
                '単勝壁21分'   => $w21Ge2,
                '複勝補強6分'  => $p6Ge15,
                'rank_crossed' => $crossed,
                'missing'      => $missing,
                // @ANCHOR-20261020-R122-EXACT  元値と、元値で出した判定
                'raw'          => $raw,
                'exact'        => ['W21>=2' => $w21Ge2, 'W6>=2' => $w6Ge2,
                                   'W6<1.50' => $w6Lt15, 'P6>=1.50' => $p6Ge15,
                                   '21→6短縮>=0.20' => $shrink20],
            ];
        }
        return $pairs;
    }

    /**
     * @ANCHOR-20261013-V04-CORE  X1〜X6・Z の三値判定（付録F derive_flags と同一）
     *
     * 02-2 の表。閾値はすべて研究初期値であり検証済みの本番値ではない。
     *   X1 境界弱化(+2)   k<=6 で W(k,21)>=2.00 かつ（W(k,6)<2.00 または 縮小20%以上）
     *   X2 単複乖離(+1)   k<=10 で W(k,6)>=2.00 かつ P(k,6)<1.50
     *   X3 中位接近(+1)   k=3,4,5,6 が全て有効で max W(k,6) < 1.50。N<7 は構造的非該当
     *   X4 穴側の絶対支持(+1) 7番人気以下の異なる2頭以上で複勝最小が
     *                      21→6分に5%以上短縮、または9→6分に3%以上短縮
     *   X5 中穴の壁(+1)   k=7..min(10,N-1) で W(k,6)>=2.00。該当境界が無ければFALSE
     *   X6 類似統計(+1)   有効50レース以上かつ基準率より10pp以上高い。
     *                      基準率が未定義・未提供なら必ずUNKNOWN（0%で埋めない）
     *   Z  安定上位(-2)   k=1..min(5,N-1) の異なる2境界以上で
     *                      W(k,21)>=2.00 かつ W(k,6)>=2.00 かつ P(k,6)>=1.50
     *
     * @param  int        $N        取消を反映した実出走頭数
     * @param  array      $pairs    v04Pairs() の戻り
     * @param  array      $pHorses  出走馬（popularity / fuku_min_series を持つ）
     * @param  array|null $similar  ['sample_size'=>int|null, 'delta_pp'=>float|null]
     * @return array      ['flags'=>[X1..Z=>'TRUE'|'FALSE'|'UNKNOWN'], 'evidence'=>[...]]
     */
    public static function v04DeriveFlags(int $N, array $pairs, array $pHorses, ?array $similar = null): array
    {
        $thr  = AiController::V04_THRESHOLDS;
        $maxK = max(0, $N - 1);
        $at   = static fn(int $k, int $t, string $v) => $pairs[$k][$v][$t] ?? null;

        // ── X1 境界弱化 ─────────────────────────────────────────────────────
        //   上側の21分前が有効で壁未満なら、6分前が欠損でもFALSEと断定できる。
        // ─────────────────────────────────────────────────────────────
        // @ANCHOR-20261020-R122-EXACT  判定は $pairs[k]['exact']（元値で出した結果）
        //   【旧】丸めた $W[$t] を 2.0 と比べ、割り算で短縮率を出していました。
        //
        //   受入試験は $pairs を手で組み立てて渡すので 'exact' がありません。
        //   その場合は、渡された比の値そのものを十進数の文字列として
        //   たすき掛けで比べます（ここでも float の比較はしません）。
        // ─────────────────────────────────────────────────────────────
        $ex = static function (int $k, string $key) use ($pairs) {
            if (isset($pairs[$k]['exact']) && array_key_exists($key, $pairs[$k]['exact'])) {
                return $pairs[$k]['exact'][$key];
            }
            // ══════════════════════════════════════════════════════════
            // @ANCHOR-20261020-R122-DIGITS  10月20日005のご指摘7-2
            // ══════════════════════════════════════════════════════════
            //   下の代替比較は float と sprintf を通ります。
            //   <b>本番の入力からは絶対に到達させません。</b>
            //   v04Pairs() が作ったペアには必ず 'raw'（元値）が入るので、
            //   'raw' があるのに 'exact' が無いときは、代替へ落とさず
            //   不明（null）として扱います。代替は、受入試験が手で組み立てた
            //   ペア（'raw' が無いもの）専用です。
            if (isset($pairs[$k]['raw'])) { return null; }
            $w21 = $pairs[$k]['W'][21] ?? null;
            $w6  = $pairs[$k]['W'][6]  ?? null;
            $p6  = $pairs[$k]['P'][6]  ?? null;
            $cmp = static function ($v, int $p, int $q) {
                if (!self::v04Valid($v)) { return null; }
                return self::cmpRatio(rtrim(rtrim(sprintf('%.12F', (float) $v), '0'), '.') ?: '0',
                                      '1', $p, $q);
            };
            switch ($key) {
                case 'W21>=2':
                    $c = $cmp($w21, 2, 1); return ($c === null) ? null : ($c >= 0);
                case 'W6>=2':
                    $c = $cmp($w6, 2, 1);  return ($c === null) ? null : ($c >= 0);
                case 'W6<1.50':
                    $c = $cmp($w6, 3, 2);  return ($c === null) ? null : ($c < 0);
                case 'P6>=1.50':
                    $c = $cmp($p6, 3, 2);  return ($c === null) ? null : ($c >= 0);
                case '21→6短縮>=0.20':
                    // (W21−W6)/W21 >= 0.20 ⇔ 4×W21 >= 5×W6
                    if (!self::v04Valid($w21) || !self::v04Valid($w6)) { return null; }
                    $f = static fn($v) => rtrim(rtrim(sprintf('%.12F', (float) $v), '0'), '.') ?: '0';
                    $c = self::cmpProd(4, [$f($w21)], 5, [$f($w6)]);
                    return ($c === null) ? null : ($c >= 0);
            }
            return null;
        };
        $x1 = static function (int $k) use ($ex) {
            $w21Ge2 = $ex($k, 'W21>=2');
            $w6Ge2  = $ex($k, 'W6>=2');
            $shrink = $ex($k, '21→6短縮>=0.20');
            if ($w21Ge2 === false) return false;          // 21分前が壁未満なら確定でFALSE
            if ($w21Ge2 === null)  return null;
            if ($w6Ge2 === false)  return true;           // 壁が消えた
            if ($w6Ge2 === null || $shrink === null) return null;
            return $shrink;                               // 壁は残るが20%以上縮んだか
        };
        $x1Each = []; $x1Ev = [];
        for ($k = 1; $k <= min($maxK, 6); $k++) {
            $x1Each[$k] = $x1($k);
            if ($x1Each[$k] === true) {
                $x1Ev[] = ['k' => $k, 'W21' => $at($k, 21, 'W'), 'W6' => $at($k, 6, 'W'),
                           '縮小率' => $pairs[$k]['縮小率'] ?? null,
                           '馬番' => [$pairs[$k]['upper_num'] ?? null, $pairs[$k]['lower_num'] ?? null]];
            }
        }
        $X1 = self::v04TriAny($x1Each);

        // ── X2 単複乖離 ─────────────────────────────────────────────────────
        //   単勝が壁未満と分かる、または複勝が補強済みと分かる時点でFALSE。
        $x2 = static function (int $k) use ($ex) {
            $w = $ex($k, 'W6>=2'); $p = $ex($k, 'P6>=1.50');
            if ($w === false) return false;
            if ($p === true)  return false;
            if ($w === null || $p === null) return null;
            return ($w && !$p);
        };
        $x2Each = []; $x2Ev = [];
        for ($k = 1; $k <= min($maxK, 10); $k++) {
            $x2Each[$k] = $x2($k);
            if ($x2Each[$k] === true) {
                $x2Ev[] = ['k' => $k, 'W6' => $at($k, 6, 'W'), 'P6' => $at($k, 6, 'P'),
                           '馬番' => [$pairs[$k]['upper_num'] ?? null, $pairs[$k]['lower_num'] ?? null]];
            }
        }
        $X2 = self::v04TriAny($x2Each);

        // ── X3 中位接近 ─────────────────────────────────────────────────────
        //   AND条件なので、1つでも「有効かつ1.50以上」ならFALSE、
        //   4つとも有効で全て1.50未満ならTRUE、残りはUNKNOWN。
        //   N<7 は k=3..6 の境界が揃わないので構造的非該当＝FALSE。
        $x3Vals = [];
        if ($N < 7) {
            $X3 = 'FALSE';
            $x3Note = "N={$N}（<7）のため k=3..6 の境界が成立せず構造的非該当";
        } else {
            $anyOver = false; $allValid = true;
            foreach ([3, 4, 5, 6] as $k) {
                $x3Vals[$k] = $at($k, 6, 'W');            // 表示用
                $lt = $ex($k, 'W6<1.50');                 // 判定は元値から
                if ($lt === false) $anyOver = true;
                if ($lt === null)  $allValid = false;
            }
            $X3    = $anyOver ? 'FALSE' : ($allValid ? 'TRUE' : 'UNKNOWN');
            $x3Note = $anyOver ? 'k=3..6のいずれかが1.50以上' : ($allValid ? '4境界すべて1.50未満' : '欠損あり');
        }

        // ── X4 穴側の絶対支持 ────────────────────────────────────────────────
        //   相対的な流入順位は証拠にしない。各馬の複勝最小の絶対短縮率だけで見る。
        // @ANCHOR-20261020-R122-EXACT  短縮率も割り算せずに比べます。
        //   (前−後)/前 >= 0.05 ⇔ 19×前 >= 20×後
        //   (前−後)/前 >= 0.03 ⇔ 97×前 >= 100×後
        $x4Runner = static function (array $r) {
            $p21 = $r['fuku_min_series'][21] ?? null;
            $p9  = $r['fuku_min_series'][9]  ?? null;
            $p6  = $r['fuku_min_series'][6]  ?? null;
            if (!self::v04Valid($p6)) return null;
            $c21 = self::cmpProd(19, [$p21], 20,  [$p6]);
            $c9  = self::cmpProd(97, [$p9],  100, [$p6]);
            $v21 = ($c21 === null) ? null : ($c21 >= 0);
            $v9  = ($c9  === null) ? null : ($c9  >= 0);
            if ($v21 === true || $v9 === true) return true;
            if ($v21 === null || $v9 === null) return null;
            return false;
        };
        $x4Each = []; $x4Ev = []; $x4Unknown = [];
        foreach ($pHorses as $h) {
            if ((int) ($h['popularity'] ?? 10000) < 7) continue;
            $v = $x4Runner($h);
            $x4Each[] = $v;
            $p21 = $h['fuku_min_series'][21] ?? null;
            $p9  = $h['fuku_min_series'][9]  ?? null;
            $p6  = $h['fuku_min_series'][6]  ?? null;
            $row = ['num' => (int) ($h['num'] ?? 0), '人気' => (int) ($h['popularity'] ?? 0),
                    '複勝21' => $p21, '複勝9' => $p9, '複勝6' => $p6,
                    '21→6短縮率' => (self::v04Valid($p21) && self::v04Valid($p6)) ? round(($p21 - $p6) / $p21, 4) : null,
                    '9→6短縮率'  => (self::v04Valid($p9)  && self::v04Valid($p6)) ? round(($p9  - $p6) / $p9,  4) : null];
            if ($v === true)      $x4Ev[] = $row;
            elseif ($v === null)  $x4Unknown[] = $row;
        }
        $X4 = self::v04TriAtLeast($x4Each, 2);

        // ── X5 中穴の壁 ─────────────────────────────────────────────────────
        //   k=7..min(10,N-1)。該当境界自体が存在しなければ（空集合）FALSE。
        $x5Each = []; $x5Ev = [];
        for ($k = 7; $k <= min($maxK, 10); $k++) {
            $w = $at($k, 6, 'W');                      // 表示用
            $x5Each[$k] = $ex($k, 'W6>=2');            // 判定は元値から
            if ($x5Each[$k] === true) {
                $x5Ev[] = ['k' => $k, 'W6' => $w,
                           '馬番' => [$pairs[$k]['upper_num'] ?? null, $pairs[$k]['lower_num'] ?? null]];
            }
        }
        $X5 = self::v04TriAny($x5Each);

        // ── X6 類似統計 ─────────────────────────────────────────────────────
        //   基準率（X6_baseline）が未合意のため、通常は $similar=null で UNKNOWN。
        //   07章Bでよっしーに確認中の未決事項。0%で埋めてはいけない。
        // ══════════════════════════════════════════════════════════════
        // @ANCHOR-20261020-R122-PROMPT  N<7 は構造的非該当で FALSE
        // ══════════════════════════════════════════════════════════════
        // 【直した中身】決着事項①（B案）は「N>=7 で null、N<7 で false」です。
        //   X6 は「7番人気以下の3着内進入率」を見る信号なので、
        //   7番人気以下が存在しない N<7 では成立しません（X3 と同じ扱い）。
        //   検証側（SummaryAiAnalysisCompensate::modeCheckOne）は前から
        //   この扱いでしたが、<b>本番側のここが抜けていました</b>。
        //   X6 は --r122-exact-check の突き合わせ対象（X1〜X5・Z）に
        //   入っていなかったため、これまで見つかっていませんでした。
        //   先方の参照入力 normal/FIRM_N4_1st_input.json の X6=false と
        //   一致しなかったことで分かりました。
        if ($N < 7) {
            $X6 = 'FALSE';
            $x6Note = 'N<7 のため7番人気以下が存在せず構造的に非該当（決着事項①B案）';
        } elseif (AiController::V04_X6_BASELINE === null) {
            // ══════════════════════════════════════════════════════════
            // @ANCHOR-20261020-R122-X6  B案の経路をここで閉じます
            // ══════════════════════════════════════════════════════════
            // 【10月20日004のご指摘（2）】
            //   「類似統計を渡すと旧TRUE/FALSE判定へ進む処理が残っている」
            //   そのとおりでした。本番では V04_X6_BASELINE が null なので
            //   $similar=null で呼ばれ、到達しない経路でしたが、
            //   <b>経路として閉じていませんでした</b>。
            //   基準率（07章B）が未合意のあいだは、類似統計を渡されても
            //   必ず UNKNOWN にします。下の TRUE/FALSE の表は、
            //   基準率が決まって V04_X6_BASELINE に値が入ってから使います。
            $X6 = 'UNKNOWN';
            $x6Note = 'B案：同条件比較基準率（07章B）が未合意のため、'
                    . '類似統計を渡されても TRUE/FALSE にしません';
        } elseif ($similar === null
            || ($similar['sample_size'] ?? null) === null
            || ($similar['delta_pp']    ?? null) === null) {
            $X6 = 'UNKNOWN';
            $x6Note = '同条件比較基準率が未定義・未提供（07章B）のため不明。0%で埋めない';
        } elseif ((int) $similar['sample_size'] < $thr['similar_min_races']) {
            $X6 = 'FALSE';
            $x6Note = "有効母数 {$similar['sample_size']} レースが最低条件 {$thr['similar_min_races']} に未達";
        } else {
            $X6 = ((float) $similar['delta_pp'] >= $thr['similar_3in_delta_pp']) ? 'TRUE' : 'FALSE';
            $x6Note = "有効母数 {$similar['sample_size']} / 基準率との差 {$similar['delta_pp']}pp";
        }

        // ── Z 安定上位 ──────────────────────────────────────────────────────
        // ══════════════════════════════════════════════════════════════
        // @ANCHOR-20261020-R122-Z  Z も元値のたすき掛けで判定します
        // ══════════════════════════════════════════════════════════════
        // 【10月20日005のご指摘3。本物の不具合でした】
        //   X1〜X5 は $ex（元値の比較）へ置き換えたのに、<b>Zだけ $at
        //   （round(...,4) した表示用の値）を見たままでした。</b>
        //   そのため 19.9999/10 = 1.99999 が 2.0000 に丸められて
        //   「壁あり」と判定され、16頭の例で
        //   混戦 3/3/1 が 堅い 5/2/0 に変わっていました。
        //   穴側が4枠から2枠、大穴側が1枠から0枠に減ります。
        //
        //   【旧コード】消さずに残します。使っていません。
        //     $z = static function (int $k) use ($at, $thr) {
        //         $w21 = $at($k, 21, 'W'); $w6 = $at($k, 6, 'W'); $p6 = $at($k, 6, 'P');
        //         if (self::v04Valid($w21) && $w21 < $thr['win_wall'])   return false;
        //         …（丸めた値と閾値を比べていました）
        //     };
        $z = static function (int $k) use ($ex) {
            $w21 = $ex($k, 'W21>=2');
            $w6  = $ex($k, 'W6>=2');
            $p6  = $ex($k, 'P6>=1.50');
            // 三値のAND。1つでもFALSEならFALSE、不明が混ざればUNKNOWN。
            if ($w21 === false || $w6 === false || $p6 === false) { return false; }
            if ($w21 === null  || $w6 === null  || $p6 === null)  { return null; }
            return true;
        };
        $zEach = []; $zEv = [];
        for ($k = 1; $k <= min($maxK, 5); $k++) {
            $zEach[$k] = $z($k);
            if ($zEach[$k] === true) {
                $zEv[] = ['k' => $k, 'W21' => $at($k, 21, 'W'), 'W6' => $at($k, 6, 'W'), 'P6' => $at($k, 6, 'P'),
                          '馬番' => [$pairs[$k]['upper_num'] ?? null, $pairs[$k]['lower_num'] ?? null]];
            }
        }
        $Z = self::v04TriAtLeast($zEach, 2);

        return [
            'flags'    => ['X1' => $X1, 'X2' => $X2, 'X3' => $X3, 'X4' => $X4,
                           'X5' => $X5, 'X6' => $X6, 'Z'  => $Z],
            'evidence' => [
                'X1' => ['value' => $X1, '対象k' => array_keys($x1Each), '成立' => $x1Ev,
                         'missing_reason' => self::v04MissingReason($x1Each)],
                'X2' => ['value' => $X2, '対象k' => array_keys($x2Each), '成立' => $x2Ev,
                         'missing_reason' => self::v04MissingReason($x2Each)],
                'X3' => ['value' => $X3, 'W6' => $x3Vals, 'note' => $x3Note],
                'X4' => ['value' => $X4, '成立頭数' => count($x4Ev), '成立' => $x4Ev,
                         '不明' => $x4Unknown, '必要件数' => 2],
                'X5' => ['value' => $X5, '対象k' => array_keys($x5Each), '成立' => $x5Ev,
                         'missing_reason' => self::v04MissingReason($x5Each)],
                'X6' => ['value' => $X6, 'note' => $x6Note, 'similar' => $similar],
                'Z'  => ['value' => $Z, '対象k' => array_keys($zEach), '成立' => $zEv,
                         '必要件数' => 2, 'missing_reason' => self::v04MissingReason($zEach)],
            ],
        ];
    }

    /** @ANCHOR-20261013-V04-CORE  三値列のうち不明だった位置を記録する */
    public static function v04MissingReason(array $each): array
    {
        $out = [];
        foreach ($each as $k => $v) { if ($v === null) $out[] = $k; }
        return empty($out) ? [] : ['不明だったk' => $out, '理由' => 'オッズ欠損・取消・0以下のため比率が計算不可'];
    }

    /** @ANCHOR-20261013-V04-CORE  Sからモードへ（付録F score_mode と同一） */
    public static function v04ScoreMode(int $s): string
    {
        if ($s <= AiController::V04_MODE_FIRM_MAX)  return 'FIRM';
        if ($s <= AiController::V04_MODE_MIXED_MAX) return 'MIXED';
        return 'VOLATILE';
    }

    /**
     * @ANCHOR-20261013-V04-CORE  S・S_min・S_max と mode（付録F classify と同一）
     *
     * S = 2*X1 + X2 + X3 + X4 + X5 + X6 - 2*Z（既知TRUE=1、FALSE=0）。
     *   これは確率ではなく研究用の離散指数。
     * 不明がある場合は各不明を0/1に振った全組合せを数え上げ、
     *   ・不明が3信号以上
     *   ・不明の振り方でFIRM/MIXED/VOLATILEの境界をまたぐ
     * のいずれかなら mode=UNKNOWN。不明が1〜2で全組合せが同じモードなら
     * そのモードを付し、mode_has_unknown=true を必ず立てる。
     */
    public static function v04Classify(array $flags): array
    {
        $w = AiController::V04_SIGNAL_WEIGHTS;
        if (array_keys($w) !== array_keys($flags)) {
            // 付録Fの assert 相当。信号キーの取り違えを早い段階で落とす。
            $flags = array_merge(array_fill_keys(array_keys($w), 'UNKNOWN'),
                                 array_intersect_key($flags, $w));
        }
        // ══════════════════════════════════════════════════════════════════
        // @ANCHOR-20261014-ABNORMAL-INPUT  知らない値で例外を投げない
        // ══════════════════════════════════════════════════════════════════
        // 【旧実装の問題】
        //   TRUE / FALSE / UNKNOWN 以外の値が1つでも入ると
        //   InvalidArgumentException を投げていました。
        //   10月14日（5回目）のご指摘で追加した異常入力試験（AB-T02）で
        //   見つかりました。信号は v04DeriveFlags() が作るので通常は
        //   3値しか入りませんが、例外が外へ出るとレースが止まります。
        //   「候補不足や欠損でレースを止めない」という方針
        //   （@ANCHOR-20260928-NO-RACE-STOP）に反します。
        // 【この変更】
        //   知らない値は【不明（UNKNOWN）】に倒し、\Log::error で必ず表に出します。
        //   仕様の禁止事項「不明値を0点・不振・条件未達として扱うこと」を守るため、
        //   FALSE には倒しません。例外は投げません。
        $badTri = [];
        foreach ($flags as $k => $v) {
            if (!in_array($v, ['TRUE', 'FALSE', 'UNKNOWN'], true)) {
                $badTri[$k] = var_export($v, true);
                $flags[$k]  = 'UNKNOWN';
            }
        }
        if (!empty($badTri)) {
            \Log::error('[V04_CLASSIFY] 知らない信号値を不明として扱った（@ANCHOR-20261014-ABNORMAL-INPUT）', [
                '対象'   => $badTri,
                '対処'   => 'UNKNOWNへ倒した（FALSEには倒さない）',
                // @ANCHOR-20261020-R122-MODE  r12.2：不明が増えると UNRESOLVED になり、
                //   配分を作りません（MIXEDの流用は廃止）。
                '影響'   => '不明が増え、mode_status=UNRESOLVED で選出しない可能性がある',
            ]);
        }

        $unknown = [];
        $fixed   = 0;
        foreach ($flags as $k => $v) {
            if ($v === 'UNKNOWN') { $unknown[] = $k; continue; }
            if ($v === 'TRUE')    $fixed += $w[$k];
        }

        $sMin = $fixed; $sMax = $fixed;
        foreach ($unknown as $k) {
            // ZのUNKNOWNはマイナス方向に作用する → S_min では Z=1、S_max では Z=0
            $sMin += min(0, $w[$k]);
            $sMax += max(0, $w[$k]);
        }

        // 不明の全組合せ（2^u、u<=7なので最大128通り）で判定が揺れるか確認する
        $modes = [];
        $u     = count($unknown);
        for ($mask = 0; $mask < (1 << $u); $mask++) {
            $val = $fixed;
            foreach ($unknown as $i => $k) { if ($mask & (1 << $i)) $val += $w[$k]; }
            $modes[self::v04ScoreMode((int) $val)] = true;
        }

        // ══════════════════════════════════════════════════════════════════
        // @ANCHOR-20261020-R122-MODE  r12.2 の mode 判定（2026-10-20 受領の指定）
        // ══════════════════════════════════════════════════════════════════
        // 【旧実装】
        //   $mode = ($u >= AiController::V04_UNKNOWN_COUNT_AT_LEAST || count($modes) > 1)
        //       ? 'UNKNOWN' : array_key_first($modes);
        //   'allocation_mode' => ($mode === 'UNKNOWN') ? 'MIXED_PROVISIONAL' : $mode,
        //
        //   ①「不明が3信号以上なら UNKNOWN」は r12.2 の条件にありません。
        //   ②「UNKNOWN なら配分は MIXED を流用」は r12.2 が明確に禁止しています。
        //      配分用modeを使えるのは、不明がX6だけで S0 が 1 か 3 のときだけです。
        //      それ以外の UNKNOWN は allocation_mode=null・選出しない（UNRESOLVED）。
        //
        // 【r12.2 の規則】server_contract_r12.2 5章／詳細設計書5.2
        //   可能なmodeが一つ            → そのmode / CONFIRMED   / 配分も同じmode
        //   不明がX6だけで S0=1         → UNKNOWN  / PROVISIONAL / 配分MIXED
        //   不明がX6だけで S0=3         → UNKNOWN  / PROVISIONAL / 配分VOLATILE
        //   それ以外で複数modeにまたがる → UNKNOWN  / UNRESOLVED  / 配分なし・選出しない
        //
        //   S0 は X6 を除いた重み付き合計。X6以外が全部確定しているときだけ出せます。
        //   PROVISIONAL では星（display_rating）を出しません。
        $mode = (count($modes) === 1) ? array_key_first($modes) : 'UNKNOWN';

        // S0 … X6 以外が全部確定しているときだけ値になります
        $s0 = 0; $s0ok = true;
        foreach ($flags as $k => $v) {
            if ($k === 'X6') continue;
            if ($v === 'UNKNOWN') { $s0ok = false; break; }
            if ($v === 'TRUE')    $s0 += $w[$k];
        }
        $S0 = $s0ok ? $s0 : null;

        $onlyX6 = (count($unknown) === 1 && $unknown[0] === 'X6');

        if (count($modes) === 1) {
            $modeStatus = 'CONFIRMED';
            $allocMode  = $mode;
            $policyId   = 'BASE_TRI_STATE_V1';
            $selEnabled = true;
        } elseif ($onlyX6 && ($S0 === 1 || $S0 === 3)) {
            $modeStatus = 'PROVISIONAL';
            $allocMode  = ($S0 === 1) ? 'MIXED' : 'VOLATILE';
            $policyId   = 'X6_ONLY_UPPER_MODE_V1';
            $selEnabled = true;
        } else {
            $modeStatus = 'UNRESOLVED';
            $allocMode  = null;
            $policyId   = 'BASE_TRI_STATE_V1';
            $selEnabled = false;
        }

        // 星は、取り得る S が全部同じ星になるときだけ出します。
        // PROVISIONAL は契約で null 固定です。
        $stars = [];
        for ($mask = 0; $mask < (1 << $u); $mask++) {
            $val = $fixed;
            foreach ($unknown as $i => $k) { if ($mask & (1 << $i)) $val += $w[$k]; }
            $stars[self::v04StarOfS((int) $val)] = true;
        }
        $displayRating = ($modeStatus === 'CONFIRMED' && count($stars) === 1)
            ? array_key_first($stars) : null;

        return [
            'mode'             => $mode,
            'S'               => empty($unknown) ? $fixed : null,
            'S_min'            => $sMin,
            'S_max'            => $sMax,
            'S0'               => $S0,
            'unknown_features' => $unknown,
            'mode_has_unknown' => !empty($unknown),
            // @ANCHOR-20261020-R122-MODE  配分に使うmode。停止時は null です。
            'allocation_mode'  => $allocMode,
            'mode_status'      => $modeStatus,
            'mode_policy_id'   => $policyId,
            'selection_enabled' => $selEnabled,
            'display_rating'   => $displayRating,
            '取り得るmode'     => array_keys($modes),
        ];
    }

    /**
     * @ANCHOR-20261020-R122-MODE  S の値から星（1〜5）
     *   r12.1 の検証経路（SummaryAiAnalysisCompensate::starOfS）と同じ対応です。
     */
    public static function v04StarOfS(int $s): int
    {
        if ($s <= 0)  return 1;
        if ($s === 1) return 2;
        if ($s <= 3)  return 3;
        if ($s <= 5)  return 4;
        return 5;
    }
}

/**
 * ═══════════════════════════════════════════════════════════════════════════
 * @ANCHOR-20261020-REFACTOR  v0.4-X / r12.2 の配分
 * ═══════════════════════════════════════════════════════════════════════════
 * ここに入っているもの
 *   ・目標頭数 C（N から決まる）
 *   ・3帯 quota(A/B/D) と、r12.2 の構造調整（実在しない帯の枠を移す）
 *   ・2nd の配分
 *   ・6分前人気から帯（A=1〜6／B=7〜10／D=11以下）
 */
final class BaganrikiAllocation
{
    /** @ANCHOR-20261013-V04-CORE  候補数（付録F target_count と同一） */
    public static function v04TargetCount(int $N): int
    {
        // @ANCHOR-20261014-ABNORMAL-INPUT  負の頭数で例外を投げない
        //   異常入力試験（AB-T05）で見つかりました。出走頭数は呼び出し側で
        //   DB照合済みですが、例外が外へ出るとレースが止まります。
        //   0頭として扱い、\Log::error で表に出します。
        if ($N < 0) {
            \Log::error('[V04_TARGET] 出走頭数が負（@ANCHOR-20261014-ABNORMAL-INPUT）', [
                'N' => $N, '対処' => '0頭として扱う（目標数0・候補を作らない）',
            ]);
            return 0;
        }
        if ($N <= 8) return min($N, 4);
        if ($N <= 13) return 5;
        if ($N <= 15) return 6;
        return 7;
    }

    /**
     * @ANCHOR-20261013-V04-CORE  3帯 quota(A,B,D)（付録F allocation と同一）
     *
     * ═══════════════════════════════════════════════════════════════════════
     * @ANCHOR-20261020-R122-ALLOC  r12.2（2026-10-20 受領）で足したこと
     * ═══════════════════════════════════════════════════════════════════════
     * ①<b>allocation_mode が null（UNRESOLVED）なら配分を作りません。</b>
     *   【旧】MIXED_PROVISIONAL を MIXED に読み替えて配分表を引いていました。
     *   r12.2 は「その他の複数modeは UNRESOLVED、allocation_mode=null、
     *   selection_enabled=false」です。MIXEDの流用は禁止されました。
     * ②<b>構造上いない帯の枠を移します（構造調整）。</b>
     *   A=1〜6人気、B=7〜10、D=11以下。N が小さいと B や D に馬がいません。
     *   不足帯を D → B → A の順に処理し、D は B→A、B は D→A、A は B→D へ移します。
     *   移動は quota_adjustments に requested_band／actual_band／count／reason で残し、
     *   <b>reason=BAND_CAPACITY を省略しません</b>（契約5章）。
     *   例：N=10・VOLATILE なら C5 の基本 2/2/1 から D が無いので 2/3/0。
     * ③<b>2nd の配分を出します。</b>
     *   C<=5 は 1st と同じ。C>5 は B・D を保ったまま A=5−B−D、cap=5。
     *   （C7混戦・波乱の2ndが 1/3/1 になります）
     * ④N<=3 でも C/0/0 を返します（詳細設計書6章の表）。
     *   旧実装は quota=null でした。A帯の実在頭数が C なので意味は同じですが、
     *   表に合わせて値を返します。
     */
    public static function v04Allocation(int $N, array $classification): array
    {
        $cap  = self::v04TargetCount($N);
        $mode = $classification['allocation_mode'] ?? null;

        // ① 選出しない状態では配分を作りません
        if ($mode === null) {
            // @ANCHOR-20261020-R122-PROMPT  base_quota は INPUT_JSON の必須キー
            return ['target_count' => $cap, 'quota' => null, 'quota_2nd' => null,
                    'base_quota' => null,
                    'quota_adjustments' => [],
                    'quota_note'   => 'allocation_mode=null（UNRESOLVED）のため配分を作りません'
                                    . '（@ANCHOR-20261020-R122-ALLOC）',
                    '使用配分モード' => null];
        }
        if ($cap <= 0) {
            return ['target_count' => 0, 'quota' => null, 'quota_2nd' => null,
                    'base_quota' => null,
                    'quota_adjustments' => [],
                    'quota_note'   => 'N=0（全頭取消）のため候補を作りません',
                    '使用配分モード' => $mode];
        }
        if ($cap <= 3) {
            // ④ N<=3 は C/0/0
            $q3 = ['A' => $cap, 'B' => 0, 'D' => 0];
            return ['target_count' => $cap, 'quota' => $q3, 'quota_2nd' => $q3,
                    'base_quota' => $q3,
                    'quota_adjustments' => [],
                    'quota_note'   => 'N<=3: 実在馬の帯（A）だけで目標数まで',
                    '使用配分モード' => $mode];
        }
        $q = AiController::V04_QUOTA_BY_TARGET[$cap][$mode] ?? null;
        if ($q === null) {
            return ['target_count' => $cap, 'quota' => null, 'quota_2nd' => null,
                    'base_quota' => null,
                    'quota_adjustments' => [],
                    'quota_note'   => "配分表に target_count={$cap} / mode={$mode} が無い",
                    '使用配分モード' => $mode];
        }
        if (array_sum($q) !== $cap) {
            throw new \RuntimeException("quota sum mismatch: {$cap} vs " . array_sum($q));
        }
        // @ANCHOR-20261020-R122-PROMPT  構造調整の前の表の値を base_quota として残す
        $qBase = ['A' => $q[0], 'B' => $q[1], 'D' => $q[2]];

        // ② 構造調整（実在しない帯の枠を移す）
        [$q, $moves] = self::v04StructuralAdjust($N, $q);

        // ③ 2nd の配分
        $q2 = self::v04SecondQuota($N, $q);

        return [
            'target_count' => $cap,
            'quota'        => ['A' => $q[0], 'B' => $q[1], 'D' => $q[2]],
            'quota_2nd'    => ['A' => $q2[0], 'B' => $q2[1], 'D' => $q2[2]],
            'base_quota'   => $qBase,
            'quota_adjustments' => $moves,
            'quota_note'   => 'SHADOW ONLY; do not force Tier-C to fill physically impossible bands',
            '使用配分モード' => $mode,
        ];
    }

    /**
     * @ANCHOR-20261020-R122-ALLOC  帯ごとの実在頭数（A=1〜6人気／B=7〜10／D=11以下）
     */
    public static function v04BandCapacity(int $N): array
    {
        return [max(0, min(6, $N)), max(0, min(10, $N) - 6), max(0, $N - 10)];
    }

    /**
     * @ANCHOR-20261020-R122-ALLOC  構造上の実在馬不足だけを調整します。
     *   評価後の適格馬不足（D は B のみ、B は D のみ、A は B→D）は別の規則で、
     *   応答検証のあとに行います。ここでは混ぜません。
     *
     * @return array [調整後の[A,B,D], 移動の記録]
     */
    public static function v04StructuralAdjust(int $N, array $q): array
    {
        $cap   = self::v04BandCapacity($N);
        $idx   = ['A' => 0, 'B' => 1, 'D' => 2];
        $moves = [];
        foreach ([['D', ['B', 'A']], ['B', ['D', 'A']], ['A', ['B', 'D']]] as $pair) {
            [$from, $tos] = $pair;
            $i = $idx[$from];
            while ($q[$i] > $cap[$i]) {
                $moved = false;
                foreach ($tos as $to) {
                    $j = $idx[$to];
                    if ($q[$j] < $cap[$j]) {
                        $q[$i]--; $q[$j]++;
                        $moves[] = ['requested_band' => $from, 'actual_band' => $to,
                                    'count' => 1, 'reason' => 'BAND_CAPACITY'];
                        $moved = true;
                        break;
                    }
                }
                if (!$moved) {
                    // 移す先も無い（全体の実在頭数が目標数に届かない）
                    $q[$i]--;
                    $moves[] = ['requested_band' => $from, 'actual_band' => null,
                                'count' => 1, 'reason' => 'BAND_CAPACITY'];
                }
            }
        }
        return [$q, $moves];
    }

    /**
     * @ANCHOR-20261020-R122-ALLOC  2ndの配分
     *   C<=5 は 1st と同じ。C>5 は B・D を保ったまま A=5−B−D、cap=5。
     */
    public static function v04SecondQuota(int $N, array $q1): array
    {
        if (self::v04TargetCount($N) <= 5) { return $q1; }
        $a = 5 - $q1[1] - $q1[2];
        if ($a < 0) { $a = 0; }
        return [$a, $q1[1], $q1[2]];
    }

    /** @ANCHOR-20261013-V04-CORE  6分前人気 → 帯（A=1〜6／B=7〜10／D=11以下） */
    public static function v04Band(int $pop): string
    {
        if ($pop >= 1 && $pop <= 6)  return 'A';
        if ($pop >= 7 && $pop <= 10) return 'B';
        return 'D';
    }
}

/**
 * ═══════════════════════════════════════════════════════════════════════════
 * @ANCHOR-20261020-R122-TIME  r12.2 の時刻契約
 * ═══════════════════════════════════════════════════════════════════════════
 * 根拠：server_contract_r12.2.txt 4章・8章／詳細設計書 4.3・11.2
 *
 * 基準は発走時刻 T（anchor_kind=POST_TIME）。
 *   slot_scheduled_at = T − スロット分
 *   slot_deadline     = slot_scheduled_at + 取得猶予（6分前30秒／他120秒）
 *   cutoff_at         = T − 360秒
 *   input_freeze_at   = cutoff_at + 30秒  … 利用できる情報の上限
 *   frozen_at         … 実際に保存した時刻。input_freeze_at とは別物
 *
 * 公開まわりは投票締切 sales_close_at が基準。発走時刻と同一視しません。
 *   publish_deadline           = sales_close_at − 60秒
 *   reply_deadline             = publish_deadline − 30秒
 *   effective_publish_deadline = min(publish_deadline, live_close − 60秒)
 *   effective_reply_deadline   = min(reply_deadline, effective_publish_deadline − 30秒)
 *
 * 日時は「秒必須・小数秒0〜6桁・タイムゾーン必須」のRFC3339だけを受け取り、
 * マイクロ秒の整数で比較します。7桁以上や独自形式は切り捨てず拒否します。
 */
final class BaganrikiTime
{
    /** スロットごとの取得猶予（ミリ秒）。ここに無い時点は予想入力に使いません */
    public const GRACE_MS = [21 => 120000, 18 => 120000, 15 => 120000,
                             12 => 120000,  9 => 120000,  6 =>  30000];

    /** 予想入力に使うスロット（30分前・3分前・発走時は入りません） */
    public const INPUT_SLOTS = [21, 18, 15, 12, 9, 6];

    /** 取消の監視だけに読むスロット（数値は信号へ入れません） */
    public const WATCH_SLOTS = [3, 0];

    public const CUTOFF_OFFSET_SEC       = -360;   // T − 360秒
    public const INPUT_FREEZE_OFFSET_SEC = -330;   // T − 330秒
    public const SAFETY_MARGIN_SEC       = 60;     // safety_margin_ms = 60,000
    public const REPLY_BEFORE_PUBLISH_SEC = 30;    // reply_before_publish_ms = 30,000

    private const US = 1000000;

    /**
     * RFC3339 をマイクロ秒の整数へ。読めなければ null。
     * 小数秒は0〜6桁だけ。7桁以上は切り捨てずに拒否します（契約12章）。
     */
    public static function us(?string $t): ?int
    {
        if ($t === null) { return null; }
        $re = '/^(\d{4}-\d{2}-\d{2})[Tt](\d{2}:\d{2}:\d{2})(\.\d{1,6})?([Zz]|[+\-]\d{2}:\d{2})$/';
        if (!preg_match($re, $t, $m)) { return null; }
        $frac = isset($m[3]) ? str_pad(substr($m[3], 1), 6, '0') : '000000';
        $tz   = (strtoupper($m[4]) === 'Z') ? '+00:00' : $m[4];
        $d = \DateTimeImmutable::createFromFormat('Y-m-d H:i:sP', $m[1] . ' ' . $m[2] . $tz);
        if ($d === false) { return null; }
        return $d->getTimestamp() * self::US + (int) $frac;
    }

    /** マイクロ秒の整数を日本時間のRFC3339へ（表示・監査用） */
    public static function toJst(int $us): string
    {
        $d = (new \DateTimeImmutable('@' . intdiv($us, self::US)))
                ->setTimezone(new \DateTimeZone('Asia/Tokyo'));
        $f = $us % self::US;
        if ($f < 0) { $f += self::US; }
        return $d->format('Y-m-d\TH:i:s') . sprintf('.%06d', $f) . $d->format('P');
    }

    public static function slotScheduled(int $anchorUs, int $slotMin): int
    { return $anchorUs - $slotMin * 60 * self::US; }

    public static function slotDeadline(int $anchorUs, int $slotMin): ?int
    {
        if (!isset(self::GRACE_MS[$slotMin])) { return null; }
        return self::slotScheduled($anchorUs, $slotMin) + self::GRACE_MS[$slotMin] * 1000;
    }

    public static function cutoff(int $anchorUs): int
    { return $anchorUs + self::CUTOFF_OFFSET_SEC * self::US; }

    public static function inputFreeze(int $anchorUs): int
    { return $anchorUs + self::INPUT_FREEZE_OFFSET_SEC * self::US; }

    public static function publishDeadline(int $salesCloseUs): int
    { return $salesCloseUs - self::SAFETY_MARGIN_SEC * self::US; }

    public static function replyDeadline(int $salesCloseUs): int
    { return self::publishDeadline($salesCloseUs) - self::REPLY_BEFORE_PUBLISH_SEC * self::US; }

    /**
     * 締切の前倒しを反映した実効期限。延長では猶予を増やしません。
     * $liveCloseUs が null なら前倒しなし。
     */
    public static function effectiveDeadlines(int $salesCloseUs, ?int $liveCloseUs): array
    {
        $pub = self::publishDeadline($salesCloseUs);
        $rep = self::replyDeadline($salesCloseUs);
        if ($liveCloseUs !== null) {
            $pub = min($pub, $liveCloseUs - self::SAFETY_MARGIN_SEC * self::US);
        }
        $rep = min($rep, $pub - self::REPLY_BEFORE_PUBLISH_SEC * self::US);
        return ['publish' => $pub, 'reply' => $rep];
    }

    /**
     * 1バッチを採用してよいか。期限ちょうどは可、1マイクロ秒でも後なら不可。
     * @return array ['ok'=>bool, 'reason'=>string|null, 'code'=>string|null]
     */
    public static function acceptBatch(int $slot, array $b, ?int $anchorUs = null): array
    {
        if (!isset(self::GRACE_MS[$slot])) {
            return ['ok' => false, 'code' => 'SLOT_NOT_INPUT',
                    'reason' => '予想に使わないスロット（21/18/15/12/9/6分前だけ）'];
        }
        $need = ['request_started_at', 'response_received_at', 'available_at', 'input_freeze_at'];
        $v = [];
        foreach ($need as $k) {
            $v[$k] = self::us($b[$k] ?? null);
            if ($v[$k] === null) {
                return ['ok' => false, 'code' => 'TIME_UNREADABLE',
                        'reason' => $k . ' が無いか日時として読めない'];
            }
        }
        // 予定時刻は、与えられていれば使い、無ければ発走時刻から作ります
        $sch = self::us($b['slot_scheduled_at'] ?? null);
        if ($sch === null) {
            if ($anchorUs === null) {
                return ['ok' => false, 'code' => 'TIME_UNREADABLE',
                        'reason' => 'slot_scheduled_at も発走時刻も無い'];
            }
            $sch = self::slotScheduled($anchorUs, $slot);
        }
        $deadline = $sch + self::GRACE_MS[$slot] * 1000;

        if ($v['request_started_at']   < $sch)
            return ['ok' => false, 'code' => 'REQUEST_BEFORE_SCHEDULE', 'reason' => '要求開始が予定時刻より前'];
        if ($v['response_received_at'] < $v['request_started_at'])
            return ['ok' => false, 'code' => 'CLOCK_REVERSED', 'reason' => '受信完了が要求開始より前（時計逆行）'];
        if ($v['available_at']         < $v['response_received_at'])
            return ['ok' => false, 'code' => 'CLOCK_REVERSED', 'reason' => '利用可能が受信完了より前（時計逆行）'];
        if ($v['available_at'] > $deadline)
            return ['ok' => false, 'code' => 'ACQUISITION_DEADLINE_EXCEEDED', 'reason' => '取得猶予を超えた'];
        if ($v['available_at'] > $v['input_freeze_at'])
            return ['ok' => false, 'code' => 'ACQUISITION_DEADLINE_EXCEEDED', 'reason' => '情報上限 input_freeze_at を超えた'];

        if (($b['source_updated_at'] ?? null) !== null) {
            $su = self::us($b['source_updated_at']);
            if ($su === null)
                return ['ok' => false, 'code' => 'TIME_UNREADABLE', 'reason' => 'source_updated_at が日時として読めない'];
            if ($su > $v['response_received_at'])
                return ['ok' => false, 'code' => 'SOURCE_TIME_FUTURE', 'reason' => '取得元の更新時刻が受信完了より未来'];
        }
        return ['ok' => true, 'code' => null, 'reason' => null];
    }
}

/**
 * ═══════════════════════════════════════════════════════════════════════════
 * @ANCHOR-20261020-R122-ACQ  取得バッチの採用（SLOT_FIRST_VALID_COMMITTED_V1）
 * ═══════════════════════════════════════════════════════════════════════════
 * 根拠：server_contract_r12.2.txt 8章／詳細設計書 4.2・4.3
 *
 *   ・採用できるバッチを available_at → response_received_at → batch_id の
 *     昇順に並べ、最初の1件を採用します。batch_id は固定のバイト順で比べます。
 *   ・6分前だけは「同じバッチの中に全活動馬の有効な単勝がある」ことが追加条件です。
 *     別のバッチの馬を混ぜて揃えません。揃わなければ計算不能にします。
 *   ・それ以外の時点の部分欠損は欠損のまま信号へ伝えます。
 *     「全スロット完備」という新しい足切りを足しません。
 *   ・未確定の監査行は採用しません。available_at を予定時刻で埋めません。
 */
final class BaganrikiAcquisition
{
    /**
     * スロット1つぶんの採用バッチを選びます。
     *
     * @param int        $slot      スロット分数（21/18/15/12/9/6）
     * @param array      $batches   監査行の配列。各要素に batch_id・各実時刻・
     *                              values[馬番]=['win'=>文字列|null,'place_min'=>…] を持つ
     * @param array      $activeNums 活動馬の馬番（6分前の全頭確認に使う）
     * @param int|null   $anchorUs  発走時刻（予定時刻が無い行のため）
     * @return array ['status'=>'ADOPTED'|'UNAVAILABLE', 'batch'=>array|null,
     *                'reason'=>string|null, 'code'=>string|null, 'rejected'=>array]
     */
    public static function pick(int $slot, array $batches, array $activeNums,
                                ?int $anchorUs = null): array
    {
        $ok = []; $rejected = [];
        foreach ($batches as $b) {
            if (($b['committed'] ?? true) !== true) {
                $rejected[] = ['batch_id' => $b['batch_id'] ?? null,
                               'code' => 'NOT_COMMITTED',
                               'reason' => '監査行が未確定（保存commit前）'];
                continue;
            }
            $r = BaganrikiTime::acceptBatch($slot, $b, $anchorUs);
            if (!$r['ok']) {
                $rejected[] = ['batch_id' => $b['batch_id'] ?? null,
                               'code' => $r['code'], 'reason' => $r['reason']];
                continue;
            }
            if ($slot === 6) {
                $missing = self::missingWin($b, $activeNums);
                if (!empty($missing)) {
                    $rejected[] = ['batch_id' => $b['batch_id'] ?? null,
                                   'code' => 'FREEZE_ODDS_MISSING',
                                   'reason' => '6分前の単勝が同じバッチに揃っていない（馬番 '
                                             . implode('・', $missing) . '）'];
                    continue;
                }
            }
            $ok[] = $b;
        }
        if (empty($ok)) {
            return ['status' => 'UNAVAILABLE', 'batch' => null, 'rejected' => $rejected,
                    'code' => ($slot === 6) ? 'FREEZE_ODDS_MISSING' : 'ACQUISITION_DEADLINE_EXCEEDED',
                    'reason' => '採用できるバッチがありません'];
        }
        usort($ok, static function (array $x, array $y): int {
            $a = BaganrikiTime::us($x['available_at']);
            $b = BaganrikiTime::us($y['available_at']);
            if ($a !== $b) { return $a <=> $b; }
            $a = BaganrikiTime::us($x['response_received_at']);
            $b = BaganrikiTime::us($y['response_received_at']);
            if ($a !== $b) { return $a <=> $b; }
            // batch_id は固定のバイト順
            return strcmp((string) ($x['batch_id'] ?? ''), (string) ($y['batch_id'] ?? ''));
        });
        return ['status' => 'ADOPTED', 'batch' => $ok[0], 'rejected' => $rejected,
                'code' => null, 'reason' => null];
    }

    /** 6分前に単勝が無い活動馬の馬番 */
    private static function missingWin(array $b, array $activeNums): array
    {
        $vals = $b['values'] ?? [];
        $miss = [];
        foreach ($activeNums as $n) {
            $w = $vals[$n]['win'] ?? null;
            if (!self::usableDecimal($w)) { $miss[] = (int) $n; }
        }
        sort($miss);
        return $miss;
    }

    /** 使える十進数の文字列か（0・負・空・「取消」は不可） */
    public static function usableDecimal($v): bool
    {
        if ($v === null || is_bool($v)) { return false; }
        $s = trim((string) $v);
        if ($s === '' || $s === '取消' || $s === '除外') { return false; }
        // ══════════════════════════════════════════════════════════════
        // @ANCHOR-20261020-R122-DIGITS  10月20日005のご指摘7-1
        // ══════════════════════════════════════════════════════════════
        //   小数4桁までしか受け取らず、5桁以上を黙って欠損にしていました。
        //   契約9章は「整数・小数は最大128桁」です。
        //   【旧】'/^\d+(?:\.\d{1,4})?$/'
        if (!preg_match('/^\d{1,128}(?:\.\d{1,128})?$/', $s)) { return false; }
        return (ltrim($s, '0.') !== '');   // 0 や 0.0000 は不可
    }

    /**
     * collection_audit を組み立てます（入力JSONの最上位に入る項目）。
     * 採用時は ADOPTED と各時刻、欠損時は UNAVAILABLE と空でない理由。
     * 時刻を作り話で埋めません。
     */
    public static function buildAudit(array $picked): array
    {
        $out = [];
        foreach (BaganrikiTime::INPUT_SLOTS as $slot) {
            $p = $picked[$slot] ?? null;
            if ($p === null || ($p['status'] ?? '') !== 'ADOPTED') {
                $out[(string) $slot] = [
                    'status' => 'UNAVAILABLE',
                    'reason' => ($p['reason'] ?? null) ?: 'このスロットの採用バッチがありません',
                ];
                continue;
            }
            $b = $p['batch'];
            $out[(string) $slot] = [
                'status'               => 'ADOPTED',
                'batch_id'             => $b['batch_id'] ?? null,
                'payload_hash'         => $b['payload_hash'] ?? null,
                'slot_scheduled_at'    => $b['slot_scheduled_at'] ?? null,
                'source_updated_at'    => $b['source_updated_at'] ?? null,
                'request_started_at'   => $b['request_started_at'] ?? null,
                'response_received_at' => $b['response_received_at'] ?? null,
                'available_at'         => $b['available_at'] ?? null,
            ];
        }
        return $out;
    }
}

/**
 * ═══════════════════════════════════════════════════════════════════════════
 * @ANCHOR-20261020-R122-SNAPSHOT  凍結集合・頭数・共通JSON・hash
 * ═══════════════════════════════════════════════════════════════════════════
 * 根拠：server_contract_r12.2.txt 2章・3章・5章／詳細設計書 4.4・7.2
 *
 * 頭数の4つを別物として扱います（混ぜると意味が壊れます）。
 *   entry_count    正本出馬表の頭数。欠損なら null
 *   acquired_count 読み込めた対象馬の一意件数。正常出走頭数の代用にしない
 *   frozen_count   情報上限までの正式取消を除いた凍結出走集合の頭数（＝N）
 *   active_count   凍結集合から最新の累積取消を除いた頭数。集合矛盾時は null
 */
final class BaganrikiSnapshot
{
    /**
     * 入力の照合。止めるべきときは理由コードを返します。
     *
     * @param array|null $entryNums   出馬表の馬番。null は「出馬表が読めなかった」
     * @param int|null   $declared    レース情報の出走頭数
     * @param array      $oddsNums    オッズが取れた馬番
     * @param array      $cancelPre   情報上限までに利用可能だった正式取消の馬番
     * @param array      $cancelPost  情報上限より後の取消（凍結集合には残す）
     * @param array      $conflict    取消の時点より後に実オッズがある馬番（入力不整合）
     */
    public static function checkSets(?array $entryNums, ?int $declared, array $oddsNums,
                                     array $cancelPre = [], array $cancelPost = [],
                                     array $conflict = []): array
    {
        $entryCount    = ($entryNums === null) ? null : count(array_unique($entryNums));
        $acquiredCount = count(array_unique($oddsNums));

        $base = [
            'entry_count'    => $entryCount,
            'acquired_count' => $acquiredCount,
            'frozen_count'   => null,
            'active_count'   => null,
            'frozen_nums'    => [],
            'cancel_pre'     => array_values(array_unique($cancelPre)),
            'cancel_post'    => array_values(array_unique($cancelPost)),
        ];

        // 出馬表は必須。オッズの頭数で代用しません。
        if ($entryNums === null || $entryCount === 0) {
            return $base + ['ok' => false, 'code' => 'ENTRY_MISSING',
                'reason' => sprintf('出馬表が欠損している（出馬表 %d頭・レース情報の出走頭数 %s頭・オッズが取れた馬 %d頭）',
                    (int) $entryCount, $declared === null ? '不明' : (string) $declared, $acquiredCount)];
        }
        // 宣言頭数との照合
        if ($declared !== null && $declared !== $entryCount) {
            return $base + ['ok' => false, 'code' => 'ENTRY_SET_MISMATCH',
                'reason' => sprintf('レース情報の出走頭数（%d頭）と出馬表の頭数（%d頭）が合わない',
                    $declared, $entryCount)];
        }
        // 出馬表に無い馬のオッズ
        $extra = array_values(array_diff(array_unique($oddsNums), $entryNums));
        if (!empty($extra)) {
            sort($extra);
            return $base + ['ok' => false, 'code' => 'ENTRY_SET_MISMATCH',
                'reason' => '出馬表に無い馬番のオッズがある（馬番 ' . implode('・', $extra) . '）'];
        }
        // 取消の時点より後に実オッズ（入力不整合）
        if (!empty($conflict)) {
            sort($conflict);
            $r = $base + ['ok' => false, 'code' => 'CANCEL_CONFLICT',
                'reason' => sprintf('取消の時点より後に実オッズがある（入力不整合・馬番 %s）／出馬表 %d頭・オッズが取れた馬 %d頭',
                    implode('・', $conflict), $entryCount, $acquiredCount)];
            $r['active_count'] = null;   // 実出走頭数を確定できない
            return $r;
        }

        // 凍結集合＝出馬表 − 情報上限までの正式取消
        $frozen = array_values(array_diff($entryNums, $cancelPre));
        sort($frozen);
        $base['frozen_nums']  = $frozen;
        $base['frozen_count'] = count($frozen);
        // 凍結後の取消は凍結集合に残し、active_count からだけ引きます
        $base['active_count'] = count(array_diff($frozen, $cancelPost));

        return $base + ['ok' => true, 'code' => null, 'reason' => null];
    }

    /**
     * 凍結順位（6分前単勝の昇順、同値は馬番の小さい順）。
     * 非減少であることを確認し、矛盾は入力不正として拒否します。
     * 値は十進数文字列のまま受け取り、1万倍の整数で比べます（丸めを入れません）。
     */
    public static function frozenRank(array $win6): array
    {
        $scaled = [];
        foreach ($win6 as $num => $s) {
            $v = self::scale($s);
            if ($v === null) {
                return ['ok' => false, 'code' => 'FREEZE_ODDS_MISSING',
                        'reason' => '6分前の単勝が読めない馬がいる（馬番 ' . $num . '）',
                        'rank' => []];
            }
            $scaled[(int) $num] = $v;
        }
        if (empty($scaled)) {
            return ['ok' => false, 'code' => 'FREEZE_ODDS_MISSING',
                    'reason' => '6分前の単勝が1頭も無い', 'rank' => []];
        }
        $nums = array_keys($scaled);
        usort($nums, static function ($a, $b) use ($scaled) {
            if ($scaled[$a] !== $scaled[$b]) { return $scaled[$a] <=> $scaled[$b]; }
            return $a <=> $b;
        });
        $rank = []; $k = 1; $prev = null;
        foreach ($nums as $n) {
            if ($prev !== null && $scaled[$n] < $prev) {
                return ['ok' => false, 'code' => 'FREEZE_ODDS_MISSING',
                        'reason' => '凍結順位が非減少になっていない（馬番 ' . $n . '）', 'rank' => []];
            }
            $prev = $scaled[$n];
            $rank[$n] = $k++;
        }
        return ['ok' => true, 'code' => null, 'reason' => null, 'rank' => $rank];
    }

    /** 十進数文字列を1万倍の整数へ。PHP float を通しません */
    public static function scale($v): ?int
    {
        if ($v === null || is_bool($v)) { return null; }
        $s = trim((string) $v);
        if (!preg_match('/^(\d+)(?:\.(\d{1,4}))?$/', $s, $m)) { return null; }
        $frac = str_pad($m[2] ?? '', 4, '0');
        $n = (int) $m[1] * 10000 + (int) $frac;
        return ($n > 0) ? $n : null;
    }

    /**
     * 共通JSONとそのSHA-256。
     * ai_role / role_cap / role_quota / snapshot_hash 自身を除いたものを
     * 一度だけ作り、その本文を両roleへ渡します。
     * request_at とライブ取消は混ぜません。
     */
    public static function commonJson(array $input): array
    {
        foreach (['ai_role', 'role_cap', 'role_quota', 'snapshot_hash',
                  'request_at', 'live_cancellations'] as $k) {
            unset($input[$k]);
        }
        // ══════════════════════════════════════════════════════════════
        // @ANCHOR-20261020-R122-PROMPT  キーを全階層で昇順にそろえます
        // ══════════════════════════════════════════════════════════════
        // 【直した中身】並べ替えをしていなかったので、同じ内容でも
        //   作った順で hash が変わっていました。先方の参照入力14本の
        //   snapshot_hash と一致しない原因でした。
        //   【旧コード】消さずに残します。使っていません。
        //     $json = json_encode($input,
        //         JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PRESERVE_ZERO_FRACTION);
        $json = BaganrikiPrompt::canonical($input);
        if ($json === null) {
            return ['ok' => false, 'reason' => '共通JSONを作れませんでした', 'json' => null, 'hash' => null];
        }
        return ['ok' => true, 'reason' => null, 'json' => $json,
                'hash' => hash('sha256', $json),
                'hash_method' => 'exact-common-payload-sha256-r8'];
    }
}

/**
 * ═══════════════════════════════════════════════════════════════════════════
 * @ANCHOR-20261020-R122-RANK  順位・統合・公開候補
 * ═══════════════════════════════════════════════════════════════════════════
 * 根拠：server_contract_r12.2.txt 7章／詳細設計書 11.1・6章
 *
 *   ・帯の中の全適格馬が complete なら SCORE、partial を含むなら EVIDENCE。
 *     AIの申告で complete 帯を EVIDENCE に変えさせません。
 *     EVIDENCE では点数を順位キーに使いません。
 *   ・順位点 rank_score = 100 × (K − r + 1) ÷ K。K は凍結帯の頭数。
 *     統合点は両roleの最大値。
 *   ・両AIの検証済み原公開候補だと証明できる場合だけ +5。
 *   ・同点は「両AIの原公開一致あり」→「独立根拠群数の多い順」→「馬番の昇順」。
 *   ・統合後にライブ取消を除き、残った馬の凍結帯と active_count から
 *     構造配分を調整します。人気は詰め直しません。
 *   ・評価後の適格馬不足は D は B のみ、B は D のみ、A は B→D。
 *     B・D の不足を A で埋めません。
 */
final class BaganrikiRanking
{
    /** 帯の採点方式。全頭 complete なら SCORE、partial を含むなら EVIDENCE */
    public static function bandBasis(array $horses): string
    {
        foreach ($horses as $h) {
            if (($h['score_state'] ?? 'partial') !== 'complete') { return 'EVIDENCE'; }
        }
        return empty($horses) ? 'EVIDENCE' : 'SCORE';
    }

    /**
     * 帯の中の順位。SCORE は点数→独立根拠群数→馬番、
     * EVIDENCE は独立根拠群数→馬番（点数を使いません）。
     * @return array 馬番 => 順位r（1始まり）
     */
    public static function rankWithin(array $horses, string $basis): array
    {
        $rows = array_values($horses);
        usort($rows, static function (array $a, array $b) use ($basis): int {
            if ($basis === 'SCORE') {
                $x = (int) ($a['score'] ?? 0); $y = (int) ($b['score'] ?? 0);
                if ($x !== $y) { return $y <=> $x; }
            }
            $x = (int) ($a['independent_groups'] ?? 0);
            $y = (int) ($b['independent_groups'] ?? 0);
            if ($x !== $y) { return $y <=> $x; }
            return ((int) $a['num']) <=> ((int) $b['num']);
        });
        $out = []; $r = 1;
        foreach ($rows as $h) { $out[(int) $h['num']] = $r++; }
        return $out;
    }

    /**
     * 順位点 100×(K−r+1)÷K。K は凍結帯の頭数。
     *
     * @ANCHOR-20261020-R122-EXACT  10月20日の確認結果②への対応。
     *   K が 3 や 7 のとき 100×(K−r+1)÷K は割り切れません。
     *   float で持つと 33.333… のような値になり、
     *   統合点の大小や同点の判定が丸めに左右されます。
     *   分数（分子・分母）のまま持ち、比較はたすき掛けの整数で行います。
     *   下の rankScore() は画面と監査のための数値で、判定には使いません。
     */
    public static function rankScoreParts(int $K, int $r): array
    {
        if ($K <= 0) { return ['n' => 0, 'd' => 1]; }
        return ['n' => 100 * ($K - $r + 1), 'd' => $K];
    }

    /** 分数どうしの大小（-1 / 0 / 1）。分母は正の整数です */
    public static function cmpScore(array $a, array $b): int
    {
        return ($a['n'] * $b['d']) <=> ($b['n'] * $a['d']);
    }

    /** 分数へ整数を足す（+5 の加点など） */
    public static function addScore(array $a, int $plus): array
    {
        return ['n' => $a['n'] + $plus * $a['d'], 'd' => $a['d']];
    }

    /** 表示用の数値。判定には使いません */
    public static function rankScore(int $K, int $r): float
    {
        if ($K <= 0) { return 0.0; }
        return 100.0 * ($K - $r + 1) / $K;
    }

    /**
     * 両roleの順位から統合点を出します。
     * @param array $per  role => [馬番 => ['r'=>順位, 'K'=>帯頭数,
     *                              'public'=>bool（検証済み原公開候補か）,
     *                              'groups'=>独立根拠群数]]
     * @param array $proofHash role => 加点を証明する応答hash（無ければ null）
     */
    public static function merge(array $per, array $proofHash = []): array
    {
        // @ANCHOR-20261020-R122-EXACT  点は分数のまま持ちます（max も比較も整数で）
        $acc = [];
        foreach ($per as $role => $rows) {
            foreach ($rows as $num => $v) {
                $num = (int) $num;
                $p = self::rankScoreParts((int) $v['K'], (int) $v['r']);
                if (!isset($acc[$num])) {
                    $acc[$num] = ['num' => $num, 'parts' => $p, 'public_roles' => [],
                                  'groups' => (int) ($v['groups'] ?? 0), 'bonus' => 0.0,
                                  'public_proof_hash' => null];
                } else {
                    if (self::cmpScore($p, $acc[$num]['parts']) > 0) { $acc[$num]['parts'] = $p; }
                    $acc[$num]['groups'] = max($acc[$num]['groups'], (int) ($v['groups'] ?? 0));
                }
                if (!empty($v['public'])) { $acc[$num]['public_roles'][] = $role; }
            }
        }
        $roles = array_keys($per);
        foreach ($acc as $num => &$a) {
            // 両AIの検証済み原公開候補だと証明できたときだけ +5
            $both = true;
            foreach ($roles as $r) {
                if (!in_array($r, $a['public_roles'], true)) { $both = false; break; }
            }
            // ══════════════════════════════════════════════════════════
            // @ANCHOR-20261020-R122-PROOF  証明が無ければ +5 しません
            // ══════════════════════════════════════════════════════════
            // 【10月20日005のご指摘5-2。そのとおりでした】
            //   これまでは「両roleで public=true」だけで +5 していて、
            //   <b>proofHash の有無も正当性も条件にしていませんでした。</b>
            //   検証済みの原応答から取った証明が、その馬について
            //   両roleぶんそろっているときだけ加点します。
            $proven = $both && count($roles) >= 2
                    && self::proofForHorse($proofHash, $roles, (int) $num) !== null;
            if ($proven) {
                $a['bonus'] = 5.0;
                $a['parts'] = self::addScore($a['parts'], 5);
                $a['public_proof_hash'] = self::proofForHorse($proofHash, $roles, (int) $num);
            } elseif ($both && count($roles) >= 2) {
                $a['no_bonus_reason'] = '両roleの原公開を証明できないため加点しません';
            }
            $a['both_public'] = $both && count($roles) >= 2;
            $a['bonus_proven'] = $proven;
            // 表示用の数値（判定には使いません）。
            // PHPは割り切れると整数を返すので、表示用は必ず小数にそろえます。
            $a['score'] = (float) $a['parts']['n'] / (float) $a['parts']['d'];
        }
        unset($a);
        $rows = array_values($acc);
        usort($rows, static function (array $x, array $y): int {
            $c = self::cmpScore($y['parts'], $x['parts']);   // 点の高い順
            if ($c !== 0) { return $c; }
            if ($x['both_public'] !== $y['both_public']) { return $y['both_public'] <=> $x['both_public']; }
            if ($x['groups'] !== $y['groups']) { return $y['groups'] <=> $x['groups']; }
            return $x['num'] <=> $y['num'];
        });
        return $rows;
    }

    /**
     * 評価後の適格馬不足を埋めます。
     *   D の不足は B からだけ、B の不足は D からだけ、A の不足は B→D。
     *   B・D の不足を A で埋めません。
     * @param array $quota   ['A'=>n,'B'=>n,'D'=>n]
     * @param array $avail   ['A'=>適格馬数,'B'=>…,'D'=>…]
     * @return array ['quota'=>調整後, 'shortfalls'=>不足の記録]
     */
    /**
     * @ANCHOR-20261020-R122-PROOF  その馬の「両roleの原公開」の証明を取り出す
     *
     * 受け取る形は2つとも通します。
     *   $proofHash[role][馬番] = 64桁の16進
     *   $proofHash[馬番][role] = 64桁の16進
     * 全roleぶんそろっていて、どれも64桁の16進のときだけ配列を返します。
     * 1つでも欠けていれば null を返し、呼び出し側は加点しません。
     */
    public static function proofForHorse($proofHash, array $roles, int $num): ?array
    {
        if (!is_array($proofHash) || $proofHash === []) { return null; }
        $out = [];
        foreach ($roles as $r) {
            $v = $proofHash[$r][$num] ?? ($proofHash[$num][$r] ?? null);
            if (!is_string($v) || !preg_match('/^[0-9a-f]{64}$/', $v)) { return null; }
            $out[$r] = $v;
        }
        return ($out === []) ? null : $out;
    }

    public static function fillShortfall(array $quota, array $avail): array
    {
        $q = ['A' => (int) $quota['A'], 'B' => (int) $quota['B'], 'D' => (int) $quota['D']];
        $short = [];
        $from = ['D' => ['B'], 'B' => ['D'], 'A' => ['B', 'D']];
        foreach (['D', 'B', 'A'] as $band) {
            $need = $q[$band] - (int) ($avail[$band] ?? 0);
            if ($need <= 0) { continue; }
            $moved = 0;
            foreach ($from[$band] as $to) {
                while ($moved < $need) {
                    $used = $q[$to];
                    if ($used >= (int) ($avail[$to] ?? 0)) { break; }
                    $q[$to]++; $q[$band]--; $moved++;
                }
            }
            $short[] = ['band' => $band, 'requested' => (int) $quota[$band],
                        'eligible' => (int) ($avail[$band] ?? 0),
                        'shortfall' => $need - $moved,
                        'moved_to' => $from[$band], 'moved' => $moved];
        }
        return ['quota' => $q, 'shortfalls' => $short];
    }

    /**
     * 公開期限前の取消を反映して、公開quotaを作り直します。
     * 人気は詰め直しません（凍結帯のまま）。
     *
     * @param array $frozenBand 馬番 => 'A'|'B'|'D'（凍結時の帯）
     * @param array $cancelled  取消の馬番
     * @param array $quota1st   凍結時の1st配分
     */
    public static function afterCancellation(array $frozenBand, array $cancelled,
                                             array $quota1st,
                                             ?string $allocationMode = null): array
    {
        $alive = [];
        foreach ($frozenBand as $num => $band) {
            if (in_array((int) $num, array_map('intval', $cancelled), true)) { continue; }
            $alive[$band] = ($alive[$band] ?? 0) + 1;
        }
        $avail = ['A' => $alive['A'] ?? 0, 'B' => $alive['B'] ?? 0, 'D' => $alive['D'] ?? 0];
        $active = array_sum($avail);

        // ══════════════════════════════════════════════════════════════
        // @ANCHOR-20261020-R122-RECALC  最新の頭数から C と基本配分を引き直す
        // ══════════════════════════════════════════════════════════════
        // 【10月20日005のご指摘4。本物の不具合でした】
        //   これまでは旧 quota の不足移動しかしておらず、
        //   <b>頭数が減っても目標数 C と基本配分を引き直していませんでした。</b>
        //     16→15 … 3/3/1 のまま（正しくは 3/2/1）
        //     14→13 … 3/2/1 のまま（正しくは 3/2/0）
        //      9→8  … 3/2/0 のまま（正しくは 2/2/0）
        //   凍結帯は維持します（人気を詰め直しません）。
        //   引き直すのは「最新の頭数に応じた目標数と基本配分」だけです。
        $base = null; $moves = [];
        if ($allocationMode !== null) {
            $cap = BaganrikiAllocation::v04TargetCount($active);
            if ($cap <= 0) {
                // 全頭取消。候補を作りません。
                return ['active_count' => 0, 'band_alive' => $avail,
                        'target_count' => 0, 'base_quota' => null,
                        'live_quota' => null, 'quota_adjustments' => [],
                        'shortfalls' => [], 'all_cancelled' => true,
                        'note' => '全頭取消のため候補を作りません'];
            }
            $t = ($cap <= 3)
                ? [$cap, 0, 0]
                : (AiController::V04_QUOTA_BY_TARGET[$cap][$allocationMode] ?? null);
            if ($t !== null) {
                $base = ['A' => $t[0], 'B' => $t[1], 'D' => $t[2]];
                // 実在しない帯の枠を D→B→A の順に移します。
                // 実在数は「凍結帯で生き残っている頭数」で見ます。
                $q = [$t[0], $t[1], $t[2]];
                $cp = [$avail['A'], $avail['B'], $avail['D']];
                $idx = ['A' => 0, 'B' => 1, 'D' => 2];
                foreach ([['D', ['B', 'A']], ['B', ['D', 'A']], ['A', ['B', 'D']]] as $pair) {
                    [$from, $tos] = $pair;
                    $i = $idx[$from];
                    while ($q[$i] > $cp[$i]) {
                        $moved = false;
                        foreach ($tos as $to) {
                            $j = $idx[$to];
                            if ($q[$j] < $cp[$j]) {
                                $q[$i]--; $q[$j]++;
                                $moves[] = ['requested_band' => $from, 'actual_band' => $to,
                                            'count' => 1, 'reason' => 'BAND_CAPACITY'];
                                $moved = true; break;
                            }
                        }
                        if (!$moved) {
                            $q[$i]--;
                            $moves[] = ['requested_band' => $from, 'actual_band' => null,
                                        'count' => 1, 'reason' => 'BAND_CAPACITY'];
                        }
                    }
                }
                $quota1st = ['A' => $q[0], 'B' => $q[1], 'D' => $q[2]];
            }
        }

        $r = self::fillShortfall($quota1st, $avail);
        return ['active_count' => $active, 'band_alive' => $avail,
                'target_count' => ($allocationMode === null) ? null
                                  : BaganrikiAllocation::v04TargetCount($active),
                'base_quota' => $base,
                'live_quota' => $r['quota'], 'quota_adjustments' => $moves,
                'shortfalls' => $r['shortfalls'], 'all_cancelled' => false,
                'note' => '取消で人気を詰め直していません（凍結帯のまま）。'
                        . '目標数と基本配分は最新の頭数から引き直しています'];
    }
}

/**
 * ═══════════════════════════════════════════════════════════════════════════
 * @ANCHOR-20261020-R122-RESP  原応答の検証と局所回復
 * ═══════════════════════════════════════════════════════════════════════════
 * 根拠：server_contract_r12.2.txt 6章・11章／詳細設計書 10.2
 *
 *   ・識別・版・role・hash・quota・mode_status・allocation_mode・mode_policy_id の
 *     不一致は応答全体を不採用にします。
 *   ・馬番の欠落・重複・未知馬・局所フィールド不正は、その範囲だけ隔離して
 *     正常な他馬を残します。片側のroleが失敗しても、もう片側は残します。
 *   ・未完了や長さ打切りは complete=false のまま保持し、選出へ使いません。
 *   ・訂正は各role最大1回。正常な根拠を消す訂正、complete を partial へ
 *     悪化させる訂正は採用せず、初回を保持します。
 */
final class BaganrikiResponse
{
    public const BEGIN = '<<<BAGANRIKI_V041_R8_BEGIN>>>';
    public const END   = '<<<BAGANRIKI_V041_R8_END>>>';

    /** BEGIN/END に挟まれたJSONを1つだけ厳密に取り出します */
    public static function extract(string $raw): array
    {
        $i = strpos($raw, self::BEGIN);
        $j = strpos($raw, self::END);
        if ($i === false || $j === false || $j <= $i) {
            return ['ok' => false, 'code' => 'AI_FAILURE',
                    'reason' => 'BEGIN/END マーカーが揃っていない', 'json' => null];
        }
        if (strpos($raw, self::BEGIN, $i + 1) !== false) {
            return ['ok' => false, 'code' => 'AI_FAILURE',
                    'reason' => 'BEGIN が複数ある', 'json' => null];
        }
        $body = substr($raw, $i + strlen(self::BEGIN), $j - $i - strlen(self::BEGIN));
        $data = json_decode(trim($body), true, 64);
        if (!is_array($data)) {
            return ['ok' => false, 'code' => 'AI_FAILURE',
                    'reason' => 'JSONとして読めない（' . json_last_error_msg() . '）', 'json' => null];
        }
        return ['ok' => true, 'code' => null, 'reason' => null, 'json' => $data];
    }

    /**
     * 応答全体の照合。ここが合わなければ応答ごと不採用にします。
     * @param array $expect ['prompt_version','schema_version','race_id','ai_role',
     *                       'snapshot_hash','role_cap','role_quota',
     *                       'mode','mode_status','allocation_mode','mode_policy_id']
     */
    public static function checkEnvelope(array $res, array $expect): array
    {
        $bad = [];
        foreach (['prompt_version', 'schema_version', 'race_id', 'ai_role',
                  'snapshot_hash', 'mode', 'mode_status', 'allocation_mode',
                  'mode_policy_id'] as $k) {
            if (!array_key_exists($k, $expect)) { continue; }
            if (($res[$k] ?? null) !== $expect[$k]) {
                $bad[] = sprintf('%s（期待 %s / 実際 %s）', $k,
                    var_export($expect[$k], true), var_export($res[$k] ?? null, true));
            }
        }
        if (array_key_exists('role_cap', $expect)
            && (int) ($res['role_cap'] ?? -1) !== (int) $expect['role_cap']) {
            $bad[] = 'role_cap';
        }
        if (array_key_exists('role_quota', $expect)) {
            // ══════════════════════════════════════════════════════════
            // @ANCHOR-20261020-R122-NULLQUOTA  選出停止（UNRESOLVED）の扱い
            // ══════════════════════════════════════════════════════════
            // 【本物の不具合でした】
            //   role_quota が null（選出しない）のとき、
            //   ?? -1 と ?? -2 の既定値が必ず食い違うので、
            //   <b>正しい応答まで不採用になっていました。</b>
            //   UNRESOLVED のレースは全部これに当たります。
            //   10月20日005の異常例試験で、正常出力14本のうち
            //   UNRESOLVED の2本が落ちたことで分かりました。
            $rq = $res['role_quota'] ?? null;
            $eq = $expect['role_quota'];
            if ($eq === null || $rq === null) {
                if ($eq !== $rq) {
                    $bad[] = sprintf('role_quota（期待 %s / 実際 %s）',
                        ($eq === null) ? 'null' : '値あり',
                        ($rq === null) ? 'null' : '値あり');
                }
            } else {
                foreach (['A', 'B', 'D'] as $b) {
                    if ((int) ($rq[$b] ?? -1) !== (int) ($eq[$b] ?? -2)) {
                        $bad[] = 'role_quota.' . $b;
                    }
                }
            }
        }
        if (!empty($bad)) {
            return ['ok' => false, 'code' => 'AI_FAILURE',
                    'reason' => '応答の識別・版・mode・配分が合わない: ' . implode('／', $bad)];
        }
        return ['ok' => true, 'code' => null, 'reason' => null];
    }

    /**
     * 馬ごとの隔離。凍結集合に無い馬・重複・局所不正はその馬だけ外します。
     * @return array ['kept'=>正常な馬の配列, 'isolated'=>[馬番=>理由]]
     */
    public static function isolateHorses(array $horses, array $frozenNums): array
    {
        $kept = []; $iso = []; $seen = [];
        foreach ($horses as $h) {
            // @ANCHOR-20261020-R122-HORSENO  正規応答のキーは horse_no です
            //   【10月20日005のご指摘5-3】num しか読んでおらず、
            //   正規の応答をそのまま渡すと馬番を読めませんでした。
            //   どちらの綴りでも読めるようにします（horse_no を優先）。
            $num = $h['horse_no'] ?? ($h['num'] ?? null);
            if (!is_int($num) && !(is_string($num) && ctype_digit($num))) {
                $iso['?' . count($iso)] = '馬番が数値でない';
                continue;
            }
            $num = (int) $num;
            if (isset($seen[$num])) { $iso[$num] = '同じ馬番が重複している'; continue; }
            $seen[$num] = true;
            if (!in_array($num, $frozenNums, true)) { $iso[$num] = '凍結集合に無い馬番'; continue; }
            $kept[$num] = $h;
        }
        // 欠落している馬は「不足」として返します（他馬は残します）
        $missing = array_values(array_diff($frozenNums, array_keys($kept)));
        sort($missing);
        return ['kept' => $kept, 'isolated' => $iso, 'missing' => $missing];
    }

    /**
     * 訂正を採用してよいか。
     *   ・初回の正常な根拠を全部失う → 採用しない
     *   ・complete を partial へ悪化させる → 採用しない
     *   ・凍結集合に無い馬・対象外の変更 → 採用しない
     *   ・受領時刻が初回より前 → 採用しない（同一時刻は可）
     */
    public static function acceptCorrection(array $first, array $fix,
                                            ?string $firstAt = null, ?string $fixAt = null,
                                            array $frozenNums = [], ?array $repairScope = null,
                                            array $rowValid = []): array
    {
        // ══════════════════════════════════════════════════════════════
        // @ANCHOR-20261020-R122-REPAIR  10月20日005のご指摘5-1
        // ══════════════════════════════════════════════════════════════
        // 【直した中身】
        //   ・初回に無い馬番を<b>一律に拒否</b>していました。
        //     契約6章は「凍結runner集合にいて、horses訂正の対象なら救済する」です。
        //     未知馬（凍結集合にいない）と、初回から漏れた実在馬を分けます。
        //   ・repair_scope と row_valid を受け取っていませんでした。
        //     対象外の馬を変えようとする訂正は採用しません。
        //     row_valid=false の行は適用しません。
        $rescued = []; $skipped = [];
        if ($firstAt !== null && $fixAt !== null) {
            $a = BaganrikiTime::us($firstAt); $b = BaganrikiTime::us($fixAt);
            if ($a === null || $b === null) {
                return ['ok' => false, 'reason' => '受領時刻が日時として読めない'];
            }
            if ($b < $a) { return ['ok' => false, 'reason' => '訂正の受領時刻が初回より前'];
            }
        }
        foreach ($first as $num => $h0) {
            if (!array_key_exists($num, $fix)) { continue; }   // 変更なしは初回を保持
            $h1 = $fix[$num];
            $g0 = (int) ($h0['independent_groups'] ?? 0);
            $g1 = (int) ($h1['independent_groups'] ?? 0);
            if ($g0 > 0 && $g1 === 0) {
                return ['ok' => false, 'reason' => sprintf('馬番 %d の正常な根拠を全部失う訂正', $num)];
            }
            $s0 = $h0['score_state'] ?? 'partial';
            $s1 = $h1['score_state'] ?? 'partial';
            if ($s0 === 'complete' && $s1 !== 'complete') {
                return ['ok' => false, 'reason' => sprintf('馬番 %d の採点を complete から悪化させる訂正', $num)];
            }
        }
        // ── 初回に無い馬番 ────────────────────────────────────────
        //   凍結集合にいる実在馬 → 救済（初回から漏れていただけ）
        //   凍結集合にいない馬   → 未知馬。応答ごと採用しない
        $frozen  = array_map('intval', $frozenNums);
        $extra   = array_values(array_diff(array_keys($fix), array_keys($first)));
        $unknown = [];
        foreach ($extra as $num) {
            if ($frozen !== [] && in_array((int) $num, $frozen, true)) {
                $rescued[] = (int) $num;
            } else {
                $unknown[] = (int) $num;
            }
        }
        if (!empty($unknown)) {
            sort($unknown);
            return ['ok' => false, 'rescued' => [], 'applied' => [], 'skipped' => [],
                    'reason' => '凍結集合にない馬番を足している（馬番 '
                              . implode('・', $unknown) . '）'];
        }

        // ── 訂正してよい範囲（repair_scope）────────────────────────
        //   horses に挙がっていない馬を変えようとしたら採用しません。
        //   repair_scope が無いときは、この検査をしません（従来どおり）。
        if (is_array($repairScope) && isset($repairScope['horses'])
            && is_array($repairScope['horses'])) {
            $allow = array_map('intval', $repairScope['horses']);
            $out   = [];
            foreach (array_keys($fix) as $num) {
                if (!in_array((int) $num, $allow, true)) { $out[] = (int) $num; }
            }
            if (!empty($out)) {
                sort($out);
                return ['ok' => false, 'rescued' => [], 'applied' => [], 'skipped' => [],
                        'reason' => 'repair_scope の対象外を変えようとしている（馬番 '
                                  . implode('・', $out) . '）'];
            }
        }

        // ── 行の有効性（row_valid）────────────────────────────────
        //   false の行は適用しません。応答ごと落とすのではなく、その行だけ飛ばします。
        $applied = [];
        foreach (array_keys($fix) as $num) {
            if ($rowValid !== [] && array_key_exists((int) $num, $rowValid)
                && $rowValid[(int) $num] !== true) {
                $skipped[] = (int) $num;
                continue;
            }
            $applied[] = (int) $num;
        }
        sort($rescued); sort($applied); sort($skipped);
        return ['ok' => true, 'reason' => null,
                'rescued' => $rescued, 'applied' => $applied, 'skipped' => $skipped];
    }

    /** 訂正を反映した結果。対象外の正常行は初回のままにします */
    public static function applyCorrection(array $first, array $fix,
                                           ?array $accept = null): array
    {
        // @ANCHOR-20261020-R122-REPAIR  採否の結果にある行だけを反映します
        //   $accept を渡さないときは、これまでどおり $fix を全部当てます。
        $out = $first;
        if ($accept === null) {
            foreach ($fix as $num => $h) { $out[$num] = $h; }
            return $out;
        }
        if (($accept['ok'] ?? false) !== true) { return $out; }   // 不採用なら初回のまま
        $allow = array_map('intval',
            array_merge((array) ($accept['applied'] ?? []), (array) ($accept['rescued'] ?? [])));
        foreach ($fix as $num => $h) {
            if (!in_array((int) $num, $allow, true)) { continue; }   // 対象外・row_valid=false
            $out[(int) $num] = $h;
        }
        return $out;
    }
}

/**
 * ═══════════════════════════════════════════════════════════════════════════
 * @ANCHOR-20261020-R122-VIEW  読取API用のDTOと表示状態
 * ═══════════════════════════════════════════════════════════════════════════
 * 根拠：server_contract_r12.2.txt 8章・11章／詳細設計書 12.2
 *
 *   state は公開状態で、mode_status とは別物です。
 *     PENDING     処理中で期限内
 *     PUBLISHED   有効な正式公開がある
 *     UNAVAILABLE 未公開のまま実効公開期限を過ぎた／固定入力が計算不能
 *     CANCELLED   全頭取消
 *   正式公開の履歴と現在のライブ状態を分けて返します。
 *   原AI応答・予約token・内部認証情報は返しません。
 */
final class BaganrikiPublicView
{
    /** 表示状態を決めます */
    public static function state(bool $hasPublication, bool $allCancelled,
                                 bool $inputInvalid, bool $pastDeadline): string
    {
        if ($allCancelled)   { return 'CANCELLED'; }
        if ($hasPublication) { return 'PUBLISHED'; }
        if ($inputInvalid)   { return 'UNAVAILABLE'; }
        return $pastDeadline ? 'UNAVAILABLE' : 'PENDING';
    }

    /** 暫定のときの表示文。確定した波乱度や星としては出しません */
    public static function provisionalLabel(?string $allocationMode): ?string
    {
        if ($allocationMode === 'MIXED')    { return '混戦として暫定選出'; }
        if ($allocationMode === 'VOLATILE') { return '波乱として暫定選出'; }
        return null;
    }

    public const PROVISIONAL_NOTE = '過去類似判定が未確定のため';

    /**
     * 読取APIが返す形を組み立てます。
     * 数値は十進数文字列のまま渡し、一律 double にしません。
     */
    public static function build(array $a): array
    {
        $modeStatus = $a['mode_status'] ?? null;
        $alloc      = $a['allocation_mode'] ?? null;
        return [
            'schema_version'  => 'baganriki-v041-r12-2',
            'race_id'         => $a['race_id'] ?? null,
            'state'           => $a['state'] ?? null,
            'mode'            => $a['mode'] ?? null,
            'mode_status'     => $modeStatus,
            'allocation_mode' => $alloc,
            'mode_policy_id'  => $a['mode_policy_id'] ?? null,
            'display_rating'  => ($modeStatus === 'PROVISIONAL') ? null : ($a['display_rating'] ?? null),
            'provisional'     => ($modeStatus === 'PROVISIONAL') ? [
                'label' => self::provisionalLabel($alloc),
                'note'  => self::PROVISIONAL_NOTE,
            ] : null,
            'publication'     => $a['publication'] ?? null,   // 未公開は null
            'live_state'      => [
                'state_revision'    => $a['state_revision'] ?? null,
                'cancellations'     => array_values($a['cancellations'] ?? []),
                'active_count'      => $a['active_count'] ?? null,
                'live_target_count' => $a['live_target_count'] ?? null,
                'live_quota'        => $a['live_quota'] ?? null,
                'effective_publish_deadline' => $a['effective_publish_deadline'] ?? null,
            ],
            'input_audit'     => [
                'collection_audit'      => $a['collection_audit'] ?? null,
                'input_freeze_at'       => $a['input_freeze_at'] ?? null,
                'coverage'              => $a['coverage'] ?? null,
                'time_contract_version' => 'baganriki-post-slot-grace-v1',
                'anchor_kind'           => 'POST_TIME',
                'sampling_policy_id'    => 'SLOT_FIRST_VALID_COMMITTED_V1',
            ],
            'diagnostics'     => array_values($a['diagnostics'] ?? []),
            'shortfalls'      => array_values($a['shortfalls'] ?? []),
            'buy_recommended' => false,
            'purchase_policy_status' => 'PENDING_VALIDATION',
            'learning_stage'  => 'COLLECT_ONLY',
            'model_version'   => null,
        ];
    }

    /** 診断コード（詳細設計書12.2の表） */
    public const CODES = [
        'ENTRY_MISSING'                    => '出馬表が欠損。計算停止（対象レースは集計に残す）',
        'ENTRY_SET_MISMATCH'               => '出馬表・宣言頭数・オッズの集合が合わない',
        'FREEZE_ODDS_MISSING'              => '6分前単勝が揃わない。計算停止',
        'CANCEL_CONFLICT'                  => '取消の時点より後に実オッズ。active_count は null',
        'ACQUISITION_DEADLINE_EXCEEDED'    => '取得猶予または情報上限を超えたバッチは不採用',
        'MODE_UNRESOLVED'                  => '選出停止。X6以外への暫定例外は広げない',
        'AI_FAILURE'                       => '応答全体が不採用。別role・別馬は残す',
        'PARTIAL_AI_VALIDATION'            => '一部だけ検証できた',
        'RANK_RECOVERY_FALLBACK'           => '縮退順位を使った',
        'PUBLICATION_DEADLINE_EXCEEDED'    => '新規公開の保存を拒否',
        'STALE_INTENT'                     => '読んだ版が古い。保存しない',
        'PUBLIC_CANDIDATE_VALIDATION_FAILED' => '公開候補の整合が取れない',
    ];
}


/**
 * ═══════════════════════════════════════════════════════════════════════════
 * @ANCHOR-20261020-REFACTOR-ML  機械学習（断層学習）の計算
 * ═══════════════════════════════════════════════════════════════════════════
 * AiController から切り出しました。新しいファイルは作らず、このファイルの中です。
 *
 * ここに入っているもの
 *   ・馬ブロックのテキストから数値特徴を読む処理
 *   ・特徴量の作成、カテゴリ辞書、時系列分割
 *   ・GBDT と線形モデルの学習・推論
 *   ・ラベル付け、確率の較正、評価、版の比較、モデル登録
 *   ・帯別順位の算出と、学習用スナップショットの保存
 *
 * 動きは切り出す前と同じです。
 * 中で呼び合っていた $this->… を self::… に置き換えただけで、
 * 計算の中身は1行も変えていません。
 * 本体に残した定数と静的プロパティは AiController:: で参照しています。
 *
 * 【運用の前提】
 *   学習段階は COLLECT_ONLY、model_version は null のままです（r12.2 契約9章）。
 *   ここは記録と研究のための経路で、本番の選出には使っていません。
 */
final class BaganrikiMl
{
    /**
     * 【20260924 追加】断層パターン学習（Block 11）用：馬ブロックのテキストから数値特徴を取り出す。
     *   プロンプトへ実際に渡した値そのものを保存するため、テーブルを引き直さずブロックから読む。
     *   読み取れない項目は null（欠損）。0 で埋めない。
     */
    public static function _parseHorseBlockFeatures(string $block): array
    {
        $f = [
            'tan_change_rate'     => self::_parseTanChangeRate($block),
            'tan_inflow_rank'     => null, 'tan_inflow_group_size'  => null,
            'fuku_inflow_rank'    => null, 'fuku_inflow_group_size' => null,
            'inflow_group'        => null,
            'last3min_fuku_rate'  => null, 'last3min_tan_rate' => null, 'accel_label' => null,
            'opi'                 => null, 'est_opi' => null, 'fuku_opi' => null,
            'est_tan_odds'        => null, 'est_tan_std' => null,
            'est_fuku_min'        => null, 'est_fuku_max' => null, 'est_fuku_err' => null,
        ];
        if (preg_match('/単勝流入ランク: (\d+)位\/(\d+)頭中（([^）]+)）/u', $block, $m)) {
            $f['tan_inflow_rank'] = (int)$m[1]; $f['tan_inflow_group_size'] = (int)$m[2]; $f['inflow_group'] = $m[3];
        }
        if (preg_match('/複勝流入ランク: (\d+)位\/(\d+)頭中（([^）]+)）/u', $block, $m)) {
            $f['fuku_inflow_rank'] = (int)$m[1]; $f['fuku_inflow_group_size'] = (int)$m[2]; $f['inflow_group'] = $m[3];
        }
        if (preg_match('/直前流入（9→6分前）: 複勝 ([+\-][\d.]+)%|直前流入（9→6分前）: 複勝 データなし/u', $block, $m) && isset($m[1])) {
            $f['last3min_fuku_rate'] = (float)$m[1];
        }
        if (preg_match('/直前流入（9→6分前）: .*単勝 ([+\-][\d.]+)%/u', $block, $m)) {
            $f['last3min_tan_rate'] = (float)$m[1];
        }
        if (preg_match('/直前流入（9→6分前）: .*判定: (\S+)/u', $block, $m)) {
            $f['accel_label'] = $m[1];
        }
        if (preg_match('/^\s*OPI: ([\d.]+)/mu', $block, $m))        $f['opi']      = (float)$m[1];
        if (preg_match('/予測補正OPI: ([\d.]+)/u', $block, $m))       $f['est_opi']  = (float)$m[1];
        if (preg_match('/複勝OPI: ([\d.]+)/u', $block, $m))           $f['fuku_opi'] = (float)$m[1];
        if (preg_match('/推定確定オッズ: ([\d.]+)倍（±([\d.]+)）/u', $block, $m)) {
            $f['est_tan_odds'] = (float)$m[1]; $f['est_tan_std'] = (float)$m[2];
        }
        if (preg_match('/推定確定複勝最小: ([\d.]+)倍\s+推定確定複勝最大: ([\d.]+)?/u', $block, $m)) {
            $f['est_fuku_min'] = (float)$m[1];
            $f['est_fuku_max'] = (isset($m[2]) && $m[2] !== '') ? (float)$m[2] : null;
        }
        if (preg_match('/補正誤差: ±([\d.]+)/u', $block, $m))          $f['est_fuku_err'] = (float)$m[1];
        return $f;
    }

    /**
     * 【20260924 追加】馬ブロックの「単勝: …倍（下落 X%）」行から、計測開始→6分前の単勝変化率を読む。
     *   下落 X% → -X ／ 上昇 +X% → +X ／ 変化なし → 0 ／ 行が無い → null（不明）
     */
    public static function _parseTanChangeRate(string $block): ?float
    {
        if (!preg_match('/^\s*単勝: .*倍（(下落 ([\d.]+)%|上昇 \+([\d.]+)%|変化なし)）/mu', $block, $m)) {
            return null;
        }
        if (($m[2] ?? '') !== '') return -1.0 * (float) $m[2];
        if (($m[3] ?? '') !== '') return (float) $m[3];
        return 0.0;
    }

    /**
     * 学習・評価結果の保存（評価指標の保存先）
     *
     * 仕様で求められている評価指標（M1〜M3 の 適合率・再現率・F1・ROC-AUC・
     * PR-AUC・Brier・校正誤差／M4 の 5着以内率・3着以内率・単複回収率・
     * 平均配当・中央値配当・最大連敗・最大値除外後回収率・平均選出頭数を揃えた比較）は、
     * runMlPipeline() が算出したあと、本メソッドで JSON ファイルとして保存する。
     *
     * 【保存先をファイルにしている理由】
     *   評価結果を格納する専用テーブルが存在しないため。勝手にテーブルを新設したり、
     *   存在しない列へ書いたりすると保存が落ちる（ai_merge_result で実際に起きた）。
     *   保存先テーブルが決まれば、本メソッドの中だけを DB 保存へ差し替えれば移行できる。
     *   呼び出し側も返り値の形も変えずに済むよう、保存処理はここに閉じてある。
     *
     * 保存パス: storage/app/ml_evaluation/YYYYMMDD_HHMMSS_<hash8>.json
     *   latest.json は常に最新の評価結果を指す（人が確認しやすいように）。
     *
     * @return array{saved:bool, path:?string, latest:?string, reason:?string}
     */
    public static function _saveMlEvaluation(array $result): array
    {
        try {
            $seBase = function_exists('storage_path')
                ? storage_path('app/ml_evaluation')
                : rtrim(sys_get_temp_dir(), '/') . '/ml_evaluation';
            if (!is_dir($seBase) && !@mkdir($seBase, 0775, true) && !is_dir($seBase)) {
                return ['saved' => false, 'path' => null, 'latest' => null,
                        'reason' => '保存ディレクトリを作成できない: ' . $seBase];
            }
            // JSON_PRESERVE_ZERO_FRACTION: 70.0 が 70 に化けると「整数の回収率」に見えるため
            $seJson = json_encode($result, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES
                                         | JSON_PRETTY_PRINT | JSON_PRESERVE_ZERO_FRACTION
                                         | JSON_PARTIAL_OUTPUT_ON_ERROR);
            if ($seJson === false) {
                return ['saved' => false, 'path' => null, 'latest' => null,
                        'reason' => 'JSONへ変換できない'];
            }
            $seName   = date('Ymd_His') . '_' . substr(hash('sha256', $seJson), 0, 8) . '.json';
            $sePath   = $seBase . '/' . $seName;
            $seLatest = $seBase . '/latest.json';
            if (@file_put_contents($sePath, $seJson) === false) {
                return ['saved' => false, 'path' => null, 'latest' => null,
                        'reason' => '書き込みに失敗: ' . $sePath];
            }
            @file_put_contents($seLatest, $seJson);

//             \Log::info('[Block11] 評価結果を保存', [
//                 'path'  => $sePath,
//                 'bytes' => strlen($seJson),
//                 'models'=> array_keys($result['evaluation'] ?? []),
//             ]);
            return ['saved' => true, 'path' => $sePath, 'latest' => $seLatest, 'reason' => null];
        } catch (\Throwable $seE) {
            \Log::error('[Block11] 評価結果の保存に失敗', ['err' => $seE->getMessage()]);
            return ['saved' => false, 'path' => null, 'latest' => null,
                    'reason' => $seE->getMessage()];
        }
    }

    /**
     * 断層学習パイプライン（Phase2以降で実行する学習・評価の一連処理）
     *
     * 呼び出し元: バッチ処理（artisan コマンド等）から public メソッドとして実行する。
     *   予測リクエストの経路からは呼ばない（学習は予測と切り離す）。
     *
     * これまで個別に実装していた各機能を、仕様の順序どおりに接続する。
     *   ① 時系列分割 70/15/15（日付順・ランダム分割禁止）
     *   ② カテゴリ辞書を【学習期間だけ】で作成
     *   ③ train 区分で M1〜M4 を GBDT 学習
     *   ④ validation 区分で確率校正（Platt scaling）
     *   ⑤ test 区分（未使用評価）で評価指標を算出
     *   ⑥ 現行版と学習版を並行比較
     *   ⑦ モデルをレジストリへ登録（旧モデルは残し、切戻し可能にする）
     *
     * 【重要】本メソッドは学習と評価を行うだけで、本番へは一切反映しない。
     *   本番候補・本番順位・Flutter表示への反映は、明示的な許可が出てから
     *   別途コードを変更して行う。戻り値の production_reflected は常に false。
     *
     * Phase1（1,000レース未満）では学習を行わず、理由つきで skipped を返す。
     *
     * @param  array $labeledRaces 学習用データ
     *        [['key'=>string, 'features'=>array, 'labels'=>['m1'=>int,...],
     *          'horse_labels'=>[num=>int], 'meta'=>[...]], ...]
     * @return array パイプラインの実行結果
     */
    public static function runMlPipeline(array $labeledRaces = []): array
    {
        $plPhase = self::_getMlPhase();

        if (!$plPhase['allow_training']) {
            return [
                'status' => 'skipped',
                'reason' => 'Phase1（1,000レース未満）のため学習を行わない',
                'phase'  => $plPhase,
                'production_reflected' => false,
            ];
        }
        if (empty($labeledRaces)) {
            return [
                'status' => 'skipped',
                'reason' => '正解ラベル付きデータが渡されていない',
                'phase'  => $plPhase,
                'production_reflected' => false,
            ];
        }

        // ── ① 時系列分割（日付順 70/15/15）──────────────────────────────
        $plSplit = self::_assignTimeSeriesSplit(null);
        $plIdx   = ['train' => [], 'validation' => [], 'test' => []];
        foreach ($labeledRaces as $plI => $plR) {
            $plKey = (string)($plR['key'] ?? '');
            foreach (['train', 'validation', 'test'] as $plSeg) {
                if (in_array($plKey, $plSplit[$plSeg] ?? [], true)) { $plIdx[$plSeg][] = $plI; break; }
            }
        }

        // ── ② カテゴリ辞書は学習期間だけで作成 ──────────────────────────
        $plDict = null;
        if (!empty($plIdx['train'])) {
            $plTrainKeys = array_map(fn($i) => (string)$labeledRaces[$i]['key'], $plIdx['train']);
            sort($plTrainKeys);
            $plFrom = explode('_', $plTrainKeys[0])[0];
            $plTo   = explode('_', end($plTrainKeys))[0];
            $plDict = self::_buildCategoryDict($plFrom, $plTo);
        }

        // ── ③ M1〜M3（レース単位）と M4（馬単位）を GBDT で学習 ──────────
        $plModels = []; $plCalib = []; $plEval = [];
        foreach (['m1', 'm2', 'm3'] as $plM) {
            $plX = []; $plY = [];
            foreach ($plIdx['train'] as $plI) {
                $plLab = $labeledRaces[$plI]['labels'][$plM] ?? null;
                if ($plLab === null) continue;   // 結果未確定は学習に使わない
                $plVec = self::_vectorizeFeatures($labeledRaces[$plI]['features']);
                $plX[] = $plVec['race']; $plY[] = (int)$plLab;
            }
            $plModels[strtoupper($plM)] = self::_trainGbdtModel($plX, $plY);
        }
        // M4: 馬単位
        $plX4 = []; $plY4 = []; $plMeta4 = [];
        foreach ($plIdx['train'] as $plI) {
            $plVec = self::_vectorizeFeatures($labeledRaces[$plI]['features']);
            foreach (($labeledRaces[$plI]['horse_labels'] ?? []) as $plNum => $plLab) {
                if (!isset($plVec['horses'][$plNum])) continue;
                $plX4[] = $plVec['horses'][$plNum]; $plY4[] = (int)$plLab;
            }
        }
        $plModels['M4'] = self::_trainGbdtModel($plX4, $plY4);

        // ── ④ validation 区分で確率校正（train/test は使わない）──────────
        foreach (['M1', 'M2', 'M3'] as $plM) {
            if (($plModels[$plM]['metrics']['status'] ?? '') !== 'trained') continue;
            $plS = []; $plL = [];
            foreach ($plIdx['validation'] as $plI) {
                $plLab = $labeledRaces[$plI]['labels'][strtolower($plM)] ?? null;
                if ($plLab === null) continue;
                $plVec = self::_vectorizeFeatures($labeledRaces[$plI]['features']);
                $plP   = self::_predictGbdt($plModels[$plM], $plVec['race']);
                $plS[] = $plP['probability'] * 100.0; $plL[] = (int)$plLab;
            }
            $plCalib[$plM] = self::_calibrateProbabilities($plS, $plL);
        }

        // ── ⑤ test（未使用評価）で評価指標を算出 ────────────────────────
        // 仕様: ROC-AUC / PR-AUC / 人気帯別回収率 / 最大連敗 / 断層タイプ別
        foreach (['M1', 'M2', 'M3'] as $plM) {
            if (($plModels[$plM]['metrics']['status'] ?? '') !== 'trained') continue;
            $plP2 = []; $plL2 = []; $plMt = [];
            foreach ($plIdx['test'] as $plI) {
                $plLab = $labeledRaces[$plI]['labels'][strtolower($plM)] ?? null;
                if ($plLab === null) continue;
                $plVec = self::_vectorizeFeatures($labeledRaces[$plI]['features']);
                $plPr  = self::_predictGbdt($plModels[$plM], $plVec['race']);
                $plP2[] = $plPr['probability']; $plL2[] = (int)$plLab;
                $plMt[] = $labeledRaces[$plI]['meta'] ?? [];
            }
            $plEval[$plM] = self::_evaluateMlModel($plP2, $plL2, $plMt);
        }
        // M4 の評価（仕様: 5着以内率 / 3着以内率 / 単複回収率 / 平均配当 /
        //   中央値配当 / 最大連敗 / 最大値除外後回収率 / 平均選出頭数を揃えた比較）
        if (($plModels['M4']['metrics']['status'] ?? '') === 'trained') {
            $plP4 = []; $plL4 = []; $plM4t = []; $plCurSel = [];
            foreach ($plIdx['test'] as $plI) {
                $plKey = (string)($labeledRaces[$plI]['key'] ?? '');
                $plVec = self::_vectorizeFeatures($labeledRaces[$plI]['features']);
                // 現行版がこのレースで選んでいる馬番（平均選出頭数を揃えるために使う）
                $plCurSel[$plKey] = array_map('intval',
                    (array)($labeledRaces[$plI]['current_ranking'] ?? []));
                foreach (($labeledRaces[$plI]['horse_labels'] ?? []) as $plNum => $plLab) {
                    if (!isset($plVec['horses'][$plNum])) continue;
                    $plPr = self::_predictGbdt($plModels['M4'], $plVec['horses'][$plNum]);
                    $plP4[] = $plPr['probability']; $plL4[] = (int)$plLab;
                    $plHm = $labeledRaces[$plI]['horse_meta'][$plNum] ?? [];
                    $plHm['race_key'] = $plKey;
                    $plHm['num']      = (int)$plNum;
                    $plM4t[] = $plHm;
                }
            }
            $plEval['M4'] = self::_evaluateM4Model($plP4, $plL4, $plM4t, $plCurSel);
        }

        // ── ⑥ 現行版と学習版の並行比較 ──────────────────────────────────
        $plCompare = null;
        if (!empty($plIdx['test']) && ($plModels['M4']['metrics']['status'] ?? '') === 'trained') {
            $plI0   = $plIdx['test'][0];
            $plVec0 = self::_vectorizeFeatures($labeledRaces[$plI0]['features']);
            // 現行版の順位（統合おすすめ度の降順＝保存済みの並び）
            $plCur = [];
            foreach (($labeledRaces[$plI0]['current_ranking'] ?? []) as $plRk => $plNum) {
                $plCur[] = ['num' => (int)$plNum, 'rank' => $plRk + 1];
            }
            // 学習版の順位（M4確率の降順）
            $plProbs = [];
            foreach ($plVec0['horses'] as $plNum => $plHv) {
                $plProbs[$plNum] = self::_predictGbdt($plModels['M4'], $plHv)['probability'];
            }
            arsort($plProbs);
            $plLrn = []; $plRk2 = 1;
            foreach ($plProbs as $plNum => $_p) $plLrn[] = ['num' => (int)$plNum, 'rank' => $plRk2++];
            if (!empty($plCur)) $plCompare = self::_compareModelVersions($plCur, $plLrn);
        }

        // ── ⑦ レジストリへ登録（旧モデルは残す＝切戻し可能）──────────────
        $plRegistry = self::_buildModelRegistry('');
        $plRegistry['active']['models']             = $plModels;
        $plRegistry['active']['model_hash']         = hash('sha256', json_encode(
            array_map(fn($m) => $m['model_hash'] ?? '', $plModels)
        ));
        $plRegistry['active']['train_sample_count'] = count($plIdx['train']);
        $plRegistry['active']['phase']              = $plPhase['phase'];
        $plRegistry['active']['category_dict']      = $plDict['meta'] ?? null;

//         \Log::info('[Block11] 学習パイプライン実行（本番未反映）', [
//             'phase'      => $plPhase['phase'],
//             'split'      => array_map('count', $plIdx),
//             'trained'    => array_map(fn($m) => $m['metrics']['status'] ?? '', $plModels),
//         ]);

        $plResult = [
            'status'     => 'completed',
            'phase'      => $plPhase,
            'split'      => ['train' => count($plIdx['train']),
                             'validation' => count($plIdx['validation']),
                             'test' => count($plIdx['test'])],
            'category_dict' => $plDict['meta'] ?? null,
            'models'     => array_map(fn($m) => $m['metrics'], $plModels),
            'calibration'=> $plCalib,
            'evaluation' => $plEval,
            'comparison' => $plCompare,
            'registry'   => $plRegistry,
            // 学習・評価するだけ。本番へは反映しない
            'production_reflected' => false,
            'note' => '学習・校正・評価・比較まで実施。本番候補・順位・表示への反映は別途許可が必要',
        ];

        // 評価指標をファイルへ保存する（保存先は _saveMlEvaluation() のコメント参照）
        $plResult['evaluation_saved'] = self::_saveMlEvaluation($plResult);

        return $plResult;
    }

    /**
     * レース結果確定後のラベル書き込み
     *
     * 呼び出し元: レース結果が確定した後のバッチ処理から public メソッドとして実行する。
     *
     * _calcMlLabels() で M1〜M4 の正解ラベルを算出し、
     * 保存済みスナップショットの features_json へ result_label として追記する。
     * 予測時点ではラベルが存在しないため、本処理で後から埋める。
     */
    public static function writeMlLabels(string $date, int $kaisuu, string $basho, int $day, int $race): array
    {
        $wlLabels = self::_calcMlLabels($date, $kaisuu, $basho, $day, $race);
        if (($wlLabels['detail']['status'] ?? '') !== 'confirmed') {
            return ['status' => 'pending', 'reason' => $wlLabels['detail']['reason'] ?? '結果未確定'];
        }
        try {
            $wlRow = DB::table('t_horse_odds_finder_ml_snapshot')
                ->where('date', $date)->where('kaisuu', $kaisuu)->where('basho_code', $basho)
                ->where('day', $day)->where('race', $race)->first();
            if (!$wlRow || empty($wlRow->features)) {
                return ['status' => 'skipped', 'reason' => 'スナップショットが未保存'];
            }
            // 【実DDL照合済み】t_horse_odds_finder_ml_snapshot の専用列:
            //   result_m1 / result_m2 / result_m3 (tinyint(1)) /
            //   result_m4_json (json) / result_label_status (varchar(10))
            //   result_label_status の取りうる値は実DDLのコメントどおり
            //   filled / excluded / skipped とする。
            //   万一の列差異に備え、UPDATE は features のみのフォールバックを残す。
            $wlFeat = json_decode($wlRow->features, true);
            $wlFeat['result_label'] = [
                'm1' => $wlLabels['m1'], 'm2' => $wlLabels['m2'], 'm3' => $wlLabels['m3'],
                'm4' => $wlLabels['m4'], 'detail' => $wlLabels['detail'],
                'written_at' => date('Y-m-d H:i:s'),
            ];
            $wlFeatJson = json_encode($wlFeat, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
            try {
                DB::statement(
                    'UPDATE t_horse_odds_finder_ml_snapshot'
                    . ' SET features = ?, result_m1 = ?, result_m2 = ?, result_m3 = ?,'
                    . '     result_m4_json = ?, result_label_status = ?'
                    . ' WHERE date = ? AND kaisuu = ? AND basho_code = ? AND day = ? AND race = ?',
                    [
                        $wlFeatJson,
                        $wlLabels['m1'], $wlLabels['m2'], $wlLabels['m3'],
                        json_encode($wlLabels['m4'], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
                        'filled', // 実DDLのコメントに合わせる（filled / excluded / skipped）
                        $date, $kaisuu, $basho, $day, $race,
                    ]
                );
            } catch (\Throwable $wlColE) {
                // 専用列が存在しない環境では features だけでも確実に残す
//                 \Log::warning('[Block11] 専用列へのUPDATEに失敗。featuresのみ更新する', [
//                     'err' => $wlColE->getMessage(),
//                 ]);
                DB::statement(
                    'UPDATE t_horse_odds_finder_ml_snapshot SET features = ?'
                    . ' WHERE date = ? AND kaisuu = ? AND basho_code = ? AND day = ? AND race = ?',
                    [$wlFeatJson, $date, $kaisuu, $basho, $day, $race]
                );
            }
//             \Log::info('[Block11] result_label 書き込み', [
//                 'race' => "{$date}_{$kaisuu}_{$basho}_{$day}_{$race}",
//                 'm1' => $wlLabels['m1'], 'm2' => $wlLabels['m2'], 'm3' => $wlLabels['m3'],
//             ]);
            return ['status' => 'written', 'labels' => $wlLabels];
        } catch (\Throwable $wlE) {
            \Log::error('[Block11] result_label 書き込み失敗', ['err' => $wlE->getMessage()]);
            return ['status' => 'error', 'reason' => $wlE->getMessage()];
        }
    }

    /**
     * 決定木系 勾配ブースティング（GBDT）：学習
     *
     * 仕様（最新確定版）:
     *   「欠損と非線形な組合せを扱える決定木系勾配ブースティングを基本とする」
     *
     * 実装方式: XGBoost 系の二次近似を用いた勾配ブースティング決定木。
     *   損失は logloss。各反復で勾配 g = p - y、ヘシアン h = p(1-p) を求め、
     *   利得 Gain = GL^2/(HL+λ) + GR^2/(HR+λ) - (GL+GR)^2/(HL+HR+λ) - γ
     *   を最大化する分割を選ぶ。葉の重みは w = -G/(H+λ)。
     *
     * 【欠損値の扱い（仕様: 0へ置換しない）】
     *   特徴量の欠損は null のまま受け取る。0で埋めない。
     *   各分割で「欠損を左へ送るか右へ送るか」を利得が大きい方に学習し、
     *   ノードに missing_left として保存する。
     *   これが決定木系を使う理由そのもので、線形モデルでは実現できない。
     *
     * @param  array $X 特徴量行列（各要素は float または null）
     * @param  array $y 正解ラベル（0 or 1）
     * @return array{trees:array, base_score:float, model_hash:string, metrics:array}
     */
    public static function _trainGbdtModel(
        array $X,
        array $y,
        int   $nEstimators = 60,
        int   $maxDepth = 3,
        float $learningRate = 0.1,
        float $lambda = 1.0,
        float $gamma = 0.0,
        int   $minChildSamples = 5
    ): array {
        $gbN = count($X);
        if ($gbN === 0 || $gbN !== count($y)) {
            return ['trees' => [], 'base_score' => 0.0, 'model_hash' => '',
                    'metrics' => ['status' => 'skipped', 'reason' => 'データ件数が0、または件数不一致']];
        }
        $gbD   = count($X[0]);
        $gbPos = count(array_filter($y, fn($v) => (int)$v === 1));
        if ($gbPos === 0 || $gbPos === $gbN) {
            return ['trees' => [], 'base_score' => 0.0, 'model_hash' => '',
                    'metrics' => ['status' => 'skipped',
                                  'reason' => '正例または負例が0件のため学習不能',
                                  'positive' => $gbPos, 'total' => $gbN]];
        }

        // 初期スコア = 全体の対数オッズ
        $gbP0   = $gbPos / $gbN;
        $gbBase = log(max(1e-9, $gbP0) / max(1e-9, 1.0 - $gbP0));
        $gbF    = array_fill(0, $gbN, $gbBase);
        $gbSig  = fn(float $z): float => 1.0 / (1.0 + exp(max(-60, min(60, -$z))));

        // クラス不均衡の補正（M3 大穴は正例が極端に少ないため）
        $gbWpos = $gbN / (2.0 * $gbPos);
        $gbWneg = $gbN / (2.0 * ($gbN - $gbPos));

        $gbTrees = [];
        for ($gbIt = 0; $gbIt < $nEstimators; $gbIt++) {
            // 勾配・ヘシアン
            $gbG = []; $gbH = [];
            for ($gbI = 0; $gbI < $gbN; $gbI++) {
                $gbPi = $gbSig($gbF[$gbI]);
                $gbYi = ((int)$y[$gbI] === 1) ? 1.0 : 0.0;
                $gbW  = ($gbYi > 0.5) ? $gbWpos : $gbWneg;
                $gbG[$gbI] = ($gbPi - $gbYi) * $gbW;
                $gbH[$gbI] = max(1e-6, $gbPi * (1.0 - $gbPi) * $gbW);
            }
            $gbTree = self::_gbdtBuildTree(
                $X, $gbG, $gbH, range(0, $gbN - 1), $gbD, 0,
                $maxDepth, $lambda, $gamma, $minChildSamples
            );
            $gbTrees[] = $gbTree;
            // 予測値を更新
            for ($gbI = 0; $gbI < $gbN; $gbI++) {
                $gbF[$gbI] += $learningRate * self::_gbdtTreePredict($gbTree, $X[$gbI]);
            }
        }

        // 学習データ上の当てはまり（過学習確認用。汎化はtestで別途評価）
        $gbCorrect = 0; $gbLoss = 0.0;
        for ($gbI = 0; $gbI < $gbN; $gbI++) {
            $gbPi = $gbSig($gbF[$gbI]);
            $gbYi = ((int)$y[$gbI] === 1) ? 1.0 : 0.0;
            if ((($gbPi >= 0.5) ? 1.0 : 0.0) === $gbYi) $gbCorrect++;
            $gbLoss += -($gbYi * log(max(1e-12, $gbPi)) + (1 - $gbYi) * log(max(1e-12, 1 - $gbPi)));
        }

        $gbHyper = ['n_estimators' => $nEstimators, 'max_depth' => $maxDepth,
                    'learning_rate' => $learningRate, 'lambda' => $lambda,
                    'gamma' => $gamma, 'min_child_samples' => $minChildSamples];
        $gbHash = hash('sha256', json_encode(['trees' => $gbTrees, 'base' => $gbBase, 'hyper' => $gbHyper]));

        return [
            'trees'      => $gbTrees,
            'base_score' => round($gbBase, 8),
            'model_hash' => $gbHash,
            'metrics'    => [
                'status'         => 'trained',
                'algorithm'      => 'gbdt_logloss',          // 決定木系 勾配ブースティング
                'sample_count'   => $gbN,
                'feature_count'  => $gbD,
                'positive'       => $gbPos,
                'tree_count'     => count($gbTrees),
                'class_weight'   => ['pos' => round($gbWpos, 4), 'neg' => round($gbWneg, 4)],
                'train_accuracy' => round($gbCorrect / $gbN, 4),
                'train_logloss'  => round($gbLoss / $gbN, 6),
                'hyper'          => $gbHyper,
                'missing_policy' => 'keep_null_learn_direction', // 0埋めせず分岐方向を学習
                'note'           => '学習データ上の指標。汎化性能は test 区分で別途評価する',
            ],
        ];
    }

    /**
     * GBDT: 1本の決定木を再帰的に構築する
     *
     * 欠損（null）は「左へ送る」「右へ送る」の両方を試し、
     * 利得が大きい方を missing_left としてノードへ記録する。
     */
    public static function _gbdtBuildTree(
        array $X, array $g, array $h, array $idx, int $dim, int $depth,
        int $maxDepth, float $lambda, float $gamma, int $minChild
    ): array {
        $btG = 0.0; $btH = 0.0;
        foreach ($idx as $i) { $btG += $g[$i]; $btH += $h[$i]; }

        // 葉にする条件
        if ($depth >= $maxDepth || count($idx) < 2 * $minChild) {
            return ['leaf' => round(-$btG / ($btH + $lambda), 8)];
        }

        // 利得ゼロの分割も許可する（-1e-9 を初期値にする）。
        // XOR のような組合せは、根では単独の分割利得がちょうど0になり、
        // 「利得>0のみ許可」にすると木が根で止まって組合せを学習できない。
        // 深さ2以降で初めて効く相互作用を拾うために、ゼロ利得の分割を通す。
        // 明確に有害な負利得の分割は従来どおり却下する。
        $btBestGain = -1e-9;
        $btBest     = null;
        $btParent   = ($btG * $btG) / ($btH + $lambda);

        for ($btJ = 0; $btJ < $dim; $btJ++) {
            // 欠損とそれ以外に分ける
            $btVals = []; $btMissIdx = [];
            foreach ($idx as $i) {
                $v = $X[$i][$btJ] ?? null;
                if ($v === null) $btMissIdx[] = $i;
                else             $btVals[] = [(float)$v, $i];
            }
            if (count($btVals) < 2 * $minChild) continue;
            usort($btVals, fn($a, $b) => $a[0] <=> $b[0]);

            // 欠損分の勾配合計
            $btMg = 0.0; $btMh = 0.0;
            foreach ($btMissIdx as $i) { $btMg += $g[$i]; $btMh += $h[$i]; }

            // 非欠損の合計
            $btTg = 0.0; $btTh = 0.0;
            foreach ($btVals as [$v, $i]) { $btTg += $g[$i]; $btTh += $h[$i]; }

            // ── 分割候補①「欠損 vs 非欠損」────────────────────────────
            // 非欠損の値がすべて同じ場合、しきい値による分割候補は作れない。
            // それでも「データが無い馬」と「値を持つ馬」を分けることには意味があるため、
            // 欠損そのものを分割軸にする候補を明示的に評価する。
            // （これが無いと、欠損と値0の区別を木が学習できない）
            if (count($btMissIdx) >= $minChild && count($btVals) >= $minChild) {
                $btGainM = ($btMg ** 2) / ($btMh + $lambda)
                         + ($btTg ** 2) / ($btTh + $lambda) - $btParent - $gamma;
                if ($btGainM > $btBestGain) {
                    $btBestGain = $btGainM;
                    // threshold = -INF 相当。非欠損はすべて右、欠損は左へ送る
                    $btBest = ['feature' => $btJ, 'threshold' => -INF, 'missing_left' => true];
                }
            }

            // ── 分割候補②しきい値による分割 ────────────────────────────
            $btLg = 0.0; $btLh = 0.0; $btCnt = 0;
            for ($btK = 0; $btK < count($btVals) - 1; $btK++) {
                [$btV, $btI] = $btVals[$btK];
                $btLg += $g[$btI]; $btLh += $h[$btI]; $btCnt++;
                // 同値は分割点にしない
                if ($btVals[$btK + 1][0] === $btV) continue;
                if ($btCnt < $minChild || (count($btVals) - $btCnt) < $minChild) continue;

                $btRg = $btTg - $btLg; $btRh = $btTh - $btLh;
                $btThr = ($btV + $btVals[$btK + 1][0]) / 2.0;

                // 欠損を左へ送る場合
                $btGainL = ($btLg + $btMg) ** 2 / ($btLh + $btMh + $lambda)
                         + ($btRg ** 2) / ($btRh + $lambda) - $btParent - $gamma;
                // 欠損を右へ送る場合
                $btGainR = ($btLg ** 2) / ($btLh + $lambda)
                         + ($btRg + $btMg) ** 2 / ($btRh + $btMh + $lambda) - $btParent - $gamma;

                if ($btGainL > $btBestGain) {
                    $btBestGain = $btGainL;
                    $btBest = ['feature' => $btJ, 'threshold' => $btThr, 'missing_left' => true];
                }
                if ($btGainR > $btBestGain) {
                    $btBestGain = $btGainR;
                    $btBest = ['feature' => $btJ, 'threshold' => $btThr, 'missing_left' => false];
                }
            }
        }

        if ($btBest === null) {
            return ['leaf' => round(-$btG / ($btH + $lambda), 8)];
        }

        // 実際に振り分ける
        $btLeft = []; $btRight = [];
        foreach ($idx as $i) {
            $v = $X[$i][$btBest['feature']] ?? null;
            if ($v === null) {
                if ($btBest['missing_left']) $btLeft[] = $i; else $btRight[] = $i;
            } elseif ((float)$v <= $btBest['threshold']) {
                $btLeft[] = $i;
            } else {
                $btRight[] = $i;
            }
        }
        if (empty($btLeft) || empty($btRight)) {
            return ['leaf' => round(-$btG / ($btH + $lambda), 8)];
        }

        return [
            'feature'      => $btBest['feature'],
            // -INF は「欠損 vs 非欠損」の分割を表す（round すると INF が壊れるため分岐）
            'threshold'    => is_finite($btBest['threshold']) ? round($btBest['threshold'], 8) : $btBest['threshold'],
            'missing_left' => $btBest['missing_left'],
            'left'         => self::_gbdtBuildTree($X, $g, $h, $btLeft,  $dim, $depth + 1, $maxDepth, $lambda, $gamma, $minChild),
            'right'        => self::_gbdtBuildTree($X, $g, $h, $btRight, $dim, $depth + 1, $maxDepth, $lambda, $gamma, $minChild),
        ];
    }

    /** GBDT: 1本の木の予測値を返す（欠損は学習した方向へ送る） */
    public static function _gbdtTreePredict(array $node, array $x): float
    {
        while (!isset($node['leaf'])) {
            $v = $x[$node['feature']] ?? null;
            if ($v === null) {
                $node = $node['missing_left'] ? $node['left'] : $node['right'];
            } else {
                $node = ((float)$v <= $node['threshold']) ? $node['left'] : $node['right'];
            }
        }
        return (float) $node['leaf'];
    }

    /**
     * GBDT: 推論（全木の合計を確率へ変換）
     *
     * 欠損は 0 で埋めず null のまま渡すこと。
     * 木が学習済みの分岐方向（missing_left）に従って振り分ける。
     */
    public static function _predictGbdt(array $model, array $vector, float $learningRate = 0.1): array
    {
        if (empty($model['trees'])) {
            return ['probability' => 0.0, 'z' => 0.0, 'status' => 'skipped',
                    'reason' => 'モデルが未学習'];
        }
        $pgZ = (float)($model['base_score'] ?? 0.0);
        foreach ($model['trees'] as $pgT) {
            $pgZ += $learningRate * self::_gbdtTreePredict($pgT, $vector);
        }
        return [
            'probability' => round(1.0 / (1.0 + exp(max(-60, min(60, -$pgZ)))), 6),
            'z'           => round($pgZ, 6),
            'status'      => 'predicted',
        ];
    }

    /**
     * 特徴量ベクトル化（推論エンジン入力の生成）
     *
     * features_json（可変構造のJSON）を、学習・推論で使える
     * 「固定長の数値ベクトル」へ変換する。
     *
     * 設計方針:
     *   ・欠損は 0.0 で埋めたうえで、別途「存在フラグ」を持たせる。
     *     0埋めだけだと「値が0」と「データが無い」を区別できないため。
     *   ・列の順序は $mvRaceKeys / $mvHorseKeys で固定する。
     *     順序が変わると学習済みモデルの重みと対応が崩れるので、
     *     この配列を書き換えるときは必ずモデルを再学習すること。
     *
     * @param  array $f features_json をデコードした配列
     * @return array{race:array, race_keys:array, horses:array, horse_keys:array}
     */
    public static function _vectorizeFeatures(array $f): array
    {
        // 【仕様】欠損値は欠損フラグを別に持たせ、0へ置換しない。
        //   0で埋めると「値が0」と「データが無い」が区別できず、学習が歪む。
        //   GBDT は欠損を null のまま受け取り、分岐方向を学習するため 0埋めは不要。
        $mvNum = function ($v): ?float {
            if ($v === null || $v === '' || !is_numeric($v)) return null; // ← 0にしない
            return (float) $v;
        };
        // 欠損フラグ（0/1）。欠損そのものは null のまま残す。
        $mvHas = fn($v): float => ($v === null || $v === '') ? 0.0 : 1.0;
        // 単位換算つき（欠損は null を維持）
        $mvScale = function ($v, float $d) use ($mvNum): ?float {
            $n = $mvNum($v);
            return ($n === null) ? null : $n / $d;
        };

        // ── レース単位（M1・M2・M3 用）────────────────────────────────
        $mvGapType = strtoupper((string)($f['gap_type'] ?? ''));
        $mvRace = [];
        // 断層タイプ one-hot（A〜E）
        foreach (['A', 'B', 'C', 'D', 'E'] as $mvT) {
            $mvRace["gap_type_{$mvT}"] = ($mvGapType === $mvT) ? 1.0 : 0.0;
        }
        $mvRace['primary_gap_upper_pop']     = $mvNum($f['primary_gap_upper_pop'] ?? null);
        $mvRace['primary_gap_upper_pop_has'] = $mvHas($f['primary_gap_upper_pop'] ?? null);
        $mvRace['horse_count']        = $mvNum($f['horse_count']        ?? null);
        $mvRace['upset_race']         = $mvNum($f['upset_race']         ?? null);
        $mvRace['wave_level']         = $mvNum($f['wave_level']         ?? null);
        $mvRace['lower_entry']        = $mvNum($f['lower_entry']        ?? null);
        $mvRace['big_gap_entry']      = $mvNum($f['big_gap_entry']      ?? null);
        $mvRace['cond_a_met']         = $mvNum($f['cond_a_met']         ?? null);
        $mvRace['cond_b_met']         = $mvNum($f['cond_b_met']         ?? null);
        $mvRace['cond_c_met']         = $mvNum($f['cond_c_met']         ?? null);
        $mvRace['cond_d_met']         = $mvNum($f['cond_d_met']         ?? null);
        $mvRace['gap_max_ratio_6m']   = $mvNum($f['gap_max_ratio_6m']   ?? null);
        $mvRace['gap_min_ratio_6m']   = $mvNum($f['gap_min_ratio_6m']   ?? null);
        $mvRace['gap_primary_ratio_6m']= $mvNum($f['gap_primary_ratio_6m'] ?? null);
        $mvRace['gap_count_6m']       = $mvNum($f['gap_count_6m']       ?? null);
        $mvRace['tanpuku_consistent'] = $mvNum($f['tanpuku_gap_match']['is_consistent'] ?? null);
        $mvRace['merged_horse_count'] = $mvNum($f['merged_horse_count'] ?? null);
        $mvRace['matched_count']      = $mvNum($f['matched_count']      ?? null);
        $mvRace['score_e']            = $mvNum($f['score_e']            ?? null);
        $mvRace['distance']           = $mvScale($f['distance'] ?? null, 1000.0); // 欠損はnull維持
        // コース one-hot（芝・ダート・障害）
        $mvCourse = (string)($f['course'] ?? '');
        foreach (['芝' => 'turf', 'ダート' => 'dirt', '障害' => 'jump'] as $mvJp => $mvEn) {
            $mvRace["course_{$mvEn}"] = (mb_strpos($mvCourse, $mvJp) !== false) ? 1.0 : 0.0;
        }
        // 断層遷移の総量（出現・消滅の多さ＝相場の動きの激しさ）
        $mvApp = 0; $mvVan = 0;
        foreach (($f['gap_transitions'] ?? []) as $mvTr) {
            $mvApp += count($mvTr['appeared'] ?? []);
            $mvVan += count($mvTr['vanished'] ?? []);
        }
        $mvRace['gap_appeared_total'] = (float) $mvApp;
        $mvRace['gap_vanished_total'] = (float) $mvVan;

        // ── 馬単位（M4 用）────────────────────────────────────────────
        $mvHorses = [];
        foreach (($f['all_horses_features'] ?? []) as $mvH) {
            $mvAgg = $mvH['ability_vector']['agg'] ?? [];
            $mvSim = $mvH['similar_stats'] ?? [];
            $mvRt  = $mvH['rates'] ?? [];
            $mvRow = [];
            $mvRow['pop_6m']        = $mvNum($mvH['pop_6m']       ?? null);
            $mvRow['fuku_pop_6m']   = $mvNum($mvH['fuku_pop_6m']  ?? null);
            $mvRow['waku']          = $mvNum($mvH['waku']         ?? null);
            $mvRow['tan_odds_6m']   = $mvNum($mvH['tan_odds_6m']  ?? null);
            $mvRow['fuku_min_est']  = $mvNum($mvH['fuku_min_est'] ?? null);
            $mvRow['gap_upper']     = (($mvH['gap_position'] ?? '') === 'upper') ? 1.0 : 0.0;
            $mvRow['pop_swap_count']= $mvNum($mvH['pop_swap_count'] ?? null);
            $mvRow['in_ai_candidate']= $mvNum($mvH['in_ai_candidate'] ?? null);
            // 能力・適性（集約統計）
            $mvRow['ability_history_count'] = $mvNum($mvAgg['history_count'] ?? null);
            $mvRow['ability_avg_finish']    = $mvNum($mvAgg['avg_finish']    ?? null);
            $mvRow['ability_avg_finish_has']= $mvHas($mvAgg['avg_finish']    ?? null);
            $mvRow['ability_top3_rate']     = $mvNum($mvAgg['top3_rate']     ?? null);
            $mvRow['ability_top3_rate_has'] = $mvHas($mvAgg['top3_rate']     ?? null);
            $mvRow['ability_same_cond']     = $mvNum($mvAgg['same_cond_count']   ?? null);
            $mvRow['ability_same_dist']     = $mvNum($mvAgg['same_dist_count']   ?? null);
            $mvRow['ability_same_jockey']   = $mvNum($mvAgg['same_jockey_count'] ?? null);
            // 回収率3種（値とサンプル数）
            foreach (['過去回収率' => 'rate_past', 'OPI帯別回収率' => 'rate_opi',
                      'フェーズパターン別回収率' => 'rate_phase'] as $mvJp => $mvEn) {
                $mvRow[$mvEn]            = $mvScale($mvRt[$mvJp]['rate']    ?? null, 100.0);
                $mvRow["{$mvEn}_samples"]= $mvScale($mvRt[$mvJp]['samples'] ?? null, 100.0);
                $mvRow["{$mvEn}_has"]    = $mvHas($mvRt[$mvJp]['rate']    ?? null);
            }
            // 類似レース統計
            $mvRow['similar_top3_rate'] = $mvScale($mvSim['top3_rate'] ?? null, 100.0);
            $mvRow['similar_top5_rate'] = $mvScale($mvSim['top5_rate'] ?? null, 100.0);
            $mvRow['similar_samples']   = $mvScale($mvSim['sample_count'] ?? null, 100.0);
            $mvRow['similar_has']       = $mvHas($mvSim['top3_rate'] ?? null);
            // ── 不利フラグ（出遅れ／進路妨害／不利／外々）────────────────
            // 【仕様・07.txt指示】取得元が確定するまでは欠損（null）のまま学習へ渡す。
            //   0（不利なし）にはしない。自由記述からの推測生成も行わない。
            //   GBDT は欠損の分岐方向を学習するため、null のままで安全に扱える。
            $mvTrb = $mvH['ability_vector']['trouble'] ?? [];
            foreach (['late_start', 'interference', 'trouble', 'wide_course'] as $mvTk) {
                // 直近10走のうち該当回数。取得元が無い現状では必ず null。
                $mvTv = null;
                if (!empty($mvTrb['available']) && isset($mvTrb[$mvTk]) && is_array($mvTrb[$mvTk])) {
                    $mvTvals = array_filter($mvTrb[$mvTk], fn($x) => $x !== null);
                    $mvTv = empty($mvTvals) ? null : (float) array_sum($mvTvals);
                }
                $mvRow["trouble_{$mvTk}"]       = $mvTv;
                $mvRow["trouble_{$mvTk}_has"]   = ($mvTv === null) ? 0.0 : 1.0;
            }

            // 全時点オッズ推移（S→6分前の変化率）
            $mvTs = $mvH['tan_series'] ?? [];
            $mvS  = $mvNum($mvTs['999'] ?? null);
            $mvE6 = $mvNum($mvTs['6']   ?? null);
            // 算出できない場合は 0 ではなく null（「変化なし」と「データ無し」は別物）
            $mvRow['tan_change_rate'] = ($mvS !== null && $mvE6 !== null && $mvS > 0)
                ? round(($mvE6 - $mvS) / $mvS, 4) : null;

            $mvHorses[(int)($mvH['num'] ?? 0)] = $mvRow;
        }

        return [
            'race'        => array_values($mvRace),
            'race_keys'   => array_keys($mvRace),
            'horses'      => array_map('array_values', $mvHorses),
            'horse_keys'  => !empty($mvHorses) ? array_keys(reset($mvHorses)) : [],
        ];
    }

    /**
     * 【仕様外・未使用】ロジスティック回帰 + L2正則化
     * ※どこからも呼ばれない。仕様は決定木系勾配ブースティング（_trainGbdtModel）。
     *
     * 最新確定仕様は「決定木系 勾配ブースティングを基本とする」であり、
     * 本番の学習には _trainGbdtModel() を使用する。
     * 本メソッドは線形モデルとの比較用に残しているだけで、
     * _runMlInference() からは呼ばれない。
     * 仕様をロジスティック回帰へ変更する場合は、仕様書自体の改訂が必要。
     *
     * 仕様: Phase2以降で train 区分のスナップショットから学習する。
     *   モデルは重みベクトルとして model_registry へ保存し、
     *   input_hash と model_hash の組で当時の予測を再現できるようにする。
     *
     * 実装:
     *   ロジスティック回帰を勾配降下法で学習する。
     *   決定木やGBDTではなく線形モデルを選んだ理由は、
     *   ①重みがそのまま「どの特徴量が効いたか」の説明になる
     *   ②モデルがJSONで完全に保存でき、切戻し・再現が容易
     *   ③レース数が数千規模では過学習しにくい
     *   の3点。
     *
     * 特徴量の列順は _vectorizeFeatures() が返す *_keys で固定される。
     * 列順を変えたら必ず再学習すること（重みとの対応が崩れる）。
     *
     * @param  array $X 特徴量行列（各行が固定長の数値ベクトル）
     * @param  array $y 正解ラベル（0 or 1）
     * @return array{weights:array, bias:float, model_hash:string, metrics:array}
     */
    public static function _trainMlModel(
        array $X,
        array $y,
        float $learningRate = 0.1,
        int   $epochs = 400,
        float $l2 = 0.01
    ): array {
        $tmN = count($X);
        if ($tmN === 0 || $tmN !== count($y)) {
            return ['weights' => [], 'bias' => 0.0, 'model_hash' => '',
                    'metrics' => ['status' => 'skipped', 'reason' => 'データ件数が0、または件数不一致']];
        }
        $tmD = count($X[0]);
        $tmPos = count(array_filter($y, fn($v) => (int)$v === 1));
        if ($tmPos === 0 || $tmPos === $tmN) {
            return ['weights' => [], 'bias' => 0.0, 'model_hash' => '',
                    'metrics' => ['status' => 'skipped',
                                  'reason' => '正例または負例が0件のため学習不能',
                                  'positive' => $tmPos, 'total' => $tmN]];
        }

        // クラス不均衡の補正（大穴モデルM3は正例が少ないため）
        $tmWpos = $tmN / (2.0 * $tmPos);
        $tmWneg = $tmN / (2.0 * ($tmN - $tmPos));

        $tmW = array_fill(0, $tmD, 0.0);
        $tmB = 0.0;
        $tmSig = fn(float $z): float => 1.0 / (1.0 + exp(max(-60, min(60, -$z))));

        for ($tmEp = 0; $tmEp < $epochs; $tmEp++) {
            $tmGw = array_fill(0, $tmD, 0.0);
            $tmGb = 0.0;
            for ($tmI = 0; $tmI < $tmN; $tmI++) {
                $tmZ = $tmB;
                for ($tmJ = 0; $tmJ < $tmD; $tmJ++) $tmZ += $tmW[$tmJ] * $X[$tmI][$tmJ];
                $tmP   = $tmSig($tmZ);
                $tmYi  = ((int)$y[$tmI] === 1) ? 1.0 : 0.0;
                $tmCw  = ($tmYi > 0.5) ? $tmWpos : $tmWneg;
                $tmErr = ($tmP - $tmYi) * $tmCw;
                for ($tmJ = 0; $tmJ < $tmD; $tmJ++) $tmGw[$tmJ] += $tmErr * $X[$tmI][$tmJ];
                $tmGb += $tmErr;
            }
            for ($tmJ = 0; $tmJ < $tmD; $tmJ++) {
                // L2正則化（バイアスには掛けない）
                $tmW[$tmJ] -= $learningRate * (($tmGw[$tmJ] / $tmN) + $l2 * $tmW[$tmJ]);
            }
            $tmB -= $learningRate * ($tmGb / $tmN);
        }

        // 学習データ上の当てはまり（過学習の確認用。評価はtestで別途行う）
        $tmCorrect = 0;
        $tmLoss = 0.0;
        for ($tmI = 0; $tmI < $tmN; $tmI++) {
            $tmZ = $tmB;
            for ($tmJ = 0; $tmJ < $tmD; $tmJ++) $tmZ += $tmW[$tmJ] * $X[$tmI][$tmJ];
            $tmP = $tmSig($tmZ);
            $tmYi = ((int)$y[$tmI] === 1) ? 1.0 : 0.0;
            if ((($tmP >= 0.5) ? 1.0 : 0.0) === $tmYi) $tmCorrect++;
            $tmLoss += -($tmYi * log(max(1e-12, $tmP)) + (1 - $tmYi) * log(max(1e-12, 1 - $tmP)));
        }

        $tmWr = array_map(fn($w) => round($w, 8), $tmW);
        $tmBr = round($tmB, 8);
        // モデルハッシュ: 重み・バイアス・ハイパーパラメータから生成
        $tmHash = hash('sha256', json_encode([
            'w' => $tmWr, 'b' => $tmBr, 'lr' => $learningRate, 'ep' => $epochs, 'l2' => $l2,
        ]));

        return [
            'weights'    => $tmWr,
            'bias'       => $tmBr,
            'model_hash' => $tmHash,
            'metrics'    => [
                'status'        => 'trained',
                'algorithm'     => 'logistic_regression_l2',
                'sample_count'  => $tmN,
                'feature_count' => $tmD,
                'positive'      => $tmPos,
                'class_weight'  => ['pos' => round($tmWpos, 4), 'neg' => round($tmWneg, 4)],
                'train_accuracy'=> round($tmCorrect / $tmN, 4),
                'train_logloss' => round($tmLoss / $tmN, 6),
                'hyper'         => ['learning_rate' => $learningRate, 'epochs' => $epochs, 'l2' => $l2],
                'note'          => '学習データ上の指標。汎化性能は test 区分で別途評価する',
            ],
        ];
    }

    /**
     * 断層学習 M1〜M4 推論エンジン：推論
     *
     * 学習済みの重みベクトルを特徴量へ適用し、確率を返す。
     * 返す確率は未校正なので、_calibrateProbabilities() を通してから
     * 「確率」として扱うこと。
     *
     * @return array{probability:float, z:float, status:string}
     */
    /** 【仕様外・未使用】線形モデル用の推論。本番は _predictGbdt() を使う。 */
    public static function _predictMl(array $weights, float $bias, array $vector): array
    {
        if (empty($weights) || count($weights) !== count($vector)) {
            return ['probability' => 0.0, 'z' => 0.0, 'status' => 'skipped',
                    'reason' => '重みが未学習、または特徴量の次元が一致しない（列順の変更は再学習が必要）'];
        }
        $pmZ = $bias;
        foreach ($weights as $pmJ => $pmW) $pmZ += $pmW * $vector[$pmJ];
        return [
            'probability' => round(1.0 / (1.0 + exp(max(-60, min(60, -$pmZ)))), 6),
            'z'           => round($pmZ, 6),
            'status'      => 'predicted',
        ];
    }

    /**
     * 断層学習 M1〜M4 推論エンジン：実行（シャドー専用）
     *
     * Phase2以降で、保存済みスナップショットに対して M1〜M4 の推論を行う。
     * Phase1（1,000レース未満）では学習モデルが無いため実行せず、
     * 理由つきで skipped を返す。
     *
     * 【重要】結果は features_json へ保存するだけで、
     *   本番候補・本番順位・Flutter表示には一切反映しない。
     *   本番反映はよっしーの明示的な許可が出るまで行わない。
     *
     * @param  array $features features_json をデコードした配列
     * @param  array $models   ['M1'=>['weights'=>..,'bias'=>..], ...] 学習済みモデル
     * @return array 推論結果（シャドー値）
     */
    public static function _runMlInference(array $features, array $models = []): array
    {
        $riPhase = self::_getMlPhase();

        // Phase1 は学習モデルが存在しないため推論しない
        if (!$riPhase['allow_inference'] || empty($models)) {
            return [
                'status' => 'skipped',
                'reason' => empty($models)
                    ? '学習済みモデルが未生成（Phase1は保存のみで学習を行わない）'
                    : 'Phase1のため推論を行わない',
                'phase'  => $riPhase['phase'],
                'race_count' => $riPhase['race_count'],
                'production_reflected' => false,
            ];
        }

        $riVec = self::_vectorizeFeatures($features);
        $riOut = ['status' => 'inferred', 'phase' => $riPhase['phase'],
                  'production_reflected' => false, 'race_models' => [], 'm4' => []];

        // ── M1〜M3: レース単位 ────────────────────────────────────────
        foreach (['M1', 'M2', 'M3'] as $riM) {
            if (!isset($models[$riM]['trees'])) {
                $riOut['race_models'][$riM] = ['status' => 'skipped', 'reason' => 'モデル未登録'];
                continue;
            }
            // 仕様: 決定木系 勾配ブースティング（GBDT）で推論する
            $riOut['race_models'][$riM] = self::_predictGbdt(
                $models[$riM], $riVec['race'],
                (float)($models[$riM]['learning_rate'] ?? 0.1)
            );
        }

        // ── M4: 馬単位 ────────────────────────────────────────────────
        if (isset($models['M4']['trees'])) {
            foreach ($riVec['horses'] as $riNum => $riHv) {
                $riP = self::_predictGbdt(
                    $models['M4'], $riHv, (float)($models['M4']['learning_rate'] ?? 0.1)
                );
                $riOut['m4'][$riNum] = $riP;
            }
        } else {
            $riOut['m4'] = ['status' => 'skipped', 'reason' => 'モデル未登録'];
        }

//         \Log::info('[Block11] M1〜M4 推論（シャドー専用・本番未反映）', [
//             'phase' => $riPhase['phase'],
//             'race_models' => array_map(fn($r) => $r['probability'] ?? null, $riOut['race_models']),
//         ]);
        return $riOut;
    }

    /**
     * 断層学習 M1〜M4 の正解ラベル算出（受入チェック #50〜#52）
     *
     * 仕様（よっしー最新確定版 / 20260913-10.txt・11.txt）:
     *   M1 上位完結モデル : 実着順5着以内が【すべて】6分前1〜6番人気なら1、それ以外0
     *   M2 中穴進入モデル : 実着順5着以内に6分前【7〜10番人気】が1頭以上いれば1、それ以外0
     *   M3 大穴進入モデル : 実着順5着以内に6分前【11番人気以下】が1頭以上いれば1、それ以外0
     *   M4 馬別正解ラベル : 馬ごとに5着以内なら1。母集団を
     *                       「2AI候補内」と「全頭発見」の2種類に分けて別々に保存する
     *
     * 重要な注意:
     *   ・人気順は【6分前時点】のもの。確定人気ではない。
     *   ・M2とM3の人気帯は重複させない（7〜10 と 11以下）。
     *   ・「5着以内」であって「馬券内（3着以内）」ではない。
     *
     * 実行タイミング:
     *   レース結果が確定した後のバッチ処理から呼ぶ。
     *   予測時には実着順が存在しないため、スナップショットには特徴量のみを保存し、
     *   本メソッドで算出したラベルを後から書き込む。
     *
     * @return array{m1:?int, m2:?int, m3:?int, m4:array, detail:array}
     *         結果が未確定・取得できない場合は m1〜m3 が null（0ではない）
     */
    public static function _calcMlLabels(
        string $date,
        int    $kaisuu,
        string $basho,
        int    $day,
        int    $race
    ): array {
        // ── 6分前の単勝人気順を算出（馬番 => 人気順）────────────────────
        $mlOdds6 = DB::table('t_horse_odds_finder_odds')
            ->where('date',   $date)
            ->where('kaisuu', $kaisuu)
            ->where('basho',  $basho)
            ->where('day',    $day)
            ->where('race',   $race)
            ->where('minutes_before_start', 6)
            ->get(['num', 'odds']);

        $mlPopPairs = [];
        foreach ($mlOdds6 as $mlO) {
            if ((float)$mlO->odds > 0) $mlPopPairs[(int)$mlO->num] = (float)$mlO->odds;
        }
        asort($mlPopPairs);
        $mlPopMap = [];   // 馬番 => 6分前人気順
        $mlRank   = 1;
        foreach ($mlPopPairs as $mlNum => $_o) { $mlPopMap[$mlNum] = $mlRank++; }

        // ── 実着順を取得 ──────────────────────────────────────────────
        // @ANCHOR-20261005-RESULT-COLUMNS  着順の列名は result（finishing_position ではない）
        //   t_horse_odds_finder_race_results        … basho（2桁コード）/ result
        //   t_horse_odds_finder_race_result_history … basho_code / finishing_position
        //   【従来からの不具合】ここは finishing_position を読もうとしてSQLエラーになり、
        //     学習用スナップショットの正解ラベル（m1〜m4）が常に作られていなかった。
        $mlResults = DB::table('t_horse_odds_finder_race_results')
            ->where('date',   $date)
            ->where('kaisuu', $kaisuu)
            ->where('basho',  $basho)
            ->where('day',    $day)
            ->where('race',   $race)
            ->get(['num', 'result']);

        // 結果未確定・人気順不明ならラベルを作らない（0で埋めない）
        if ($mlResults->count() === 0 || empty($mlPopMap)) {
            return [
                'm1' => null, 'm2' => null, 'm3' => null, 'm4' => [],
                'detail' => [
                    'status' => 'pending',
                    'reason' => ($mlResults->count() === 0)
                        ? 'レース結果が未確定（race_results に行が無い）'
                        : '6分前オッズが無く人気順を算出できない',
                ],
            ];
        }

        // ── 5着以内の馬を抽出し、その6分前人気順を集める ──────────────
        $mlTop5Pops = [];   // 5着以内の馬の6分前人気順
        $mlTop5Nums = [];   // 5着以内の馬番
        $mlFinishMap = [];  // 馬番 => 実着順
        foreach ($mlResults as $mlR) {
            $mlN  = (int)$mlR->num;
            $mlFp = isset($mlR->result) ? (int)$mlR->result : null;
            if ($mlFp === null || $mlFp <= 0) continue;   // 除外・取消などはスキップ
            $mlFinishMap[$mlN] = $mlFp;
            if ($mlFp <= 5) {
                $mlTop5Nums[] = $mlN;
                if (isset($mlPopMap[$mlN])) $mlTop5Pops[] = $mlPopMap[$mlN];
            }
        }

        if (empty($mlTop5Pops)) {
            return [
                'm1' => null, 'm2' => null, 'm3' => null, 'm4' => [],
                'detail' => ['status' => 'pending',
                             'reason' => '5着以内の馬の6分前人気順が取得できない'],
            ];
        }

        // ── M1: 5着以内が【すべて】1〜6番人気なら1 ────────────────────
        $mlM1 = 1;
        foreach ($mlTop5Pops as $mlP) {
            if ($mlP < 1 || $mlP > 6) { $mlM1 = 0; break; }
        }

        // ── M2: 5着以内に【7〜10番人気】が1頭以上いれば1 ──────────────
        $mlM2 = 0;
        foreach ($mlTop5Pops as $mlP) {
            if ($mlP >= 7 && $mlP <= 10) { $mlM2 = 1; break; }
        }

        // ── M3: 5着以内に【11番人気以下】が1頭以上いれば1 ──────────────
        // ※M2（7〜10）とM3（11以下）の人気帯は重複させない
        $mlM3 = 0;
        foreach ($mlTop5Pops as $mlP) {
            if ($mlP >= 11) { $mlM3 = 1; break; }
        }

        // ── M4: 馬別ラベル（5着以内なら1）を2つの母集団で分けて保存 ──────
        // 母集団①「2AI候補内」は features_json.m4_separated.in_ai_candidates から取る
        $mlCandNums = [];
        $mlSnap = DB::table('t_horse_odds_finder_ml_snapshot')
            ->where('date', $date)->where('kaisuu', $kaisuu)->where('basho_code', $basho)
            ->where('day', $day)->where('race', $race)
            ->first();
        if ($mlSnap && !empty($mlSnap->features)) {
            $mlFeat = json_decode($mlSnap->features, true);
            $mlCandNums = $mlFeat['m4_separated']['in_ai_candidates']['nums'] ?? [];
        }

        $mlM4All  = [];
        $mlM4Cand = [];
        foreach ($mlPopMap as $mlN => $mlPop) {
            $mlLabel = (isset($mlFinishMap[$mlN]) && $mlFinishMap[$mlN] <= 5) ? 1 : 0;
            $mlRow = [
                'num'                => $mlN,
                'pop_6m'             => $mlPop,
                'finishing_position' => $mlFinishMap[$mlN] ?? null,
                'label'              => $mlLabel,
            ];
            $mlM4All[] = $mlRow;                                   // ②全頭発見
            if (in_array($mlN, $mlCandNums, true)) $mlM4Cand[] = $mlRow; // ①2AI候補内
        }

        $mlOut = [
            'm1' => $mlM1,
            'm2' => $mlM2,
            'm3' => $mlM3,
            'm4' => [
                'in_ai_candidates' => [
                    'rows'         => $mlM4Cand,
                    'count'        => count($mlM4Cand),
                    'hit_count'    => count(array_filter($mlM4Cand, fn($r) => $r['label'] === 1)),
                ],
                'all_horses'       => [
                    'rows'         => $mlM4All,
                    'count'        => count($mlM4All),
                    'hit_count'    => count(array_filter($mlM4All, fn($r) => $r['label'] === 1)),
                ],
            ],
            'detail' => [
                'status'        => 'confirmed',
                'top5_nums'     => $mlTop5Nums,
                'top5_pops_6m'  => $mlTop5Pops,
                'definition'    => [
                    'm1' => '実着順5着以内がすべて6分前1〜6番人気なら1',
                    'm2' => '実着順5着以内に6分前7〜10番人気が1頭以上いれば1',
                    'm3' => '実着順5着以内に6分前11番人気以下が1頭以上いれば1',
                    'm4' => '馬別: 5着以内なら1。母集団は2AI候補内／全頭発見の2種類',
                ],
            ],
        ];

//         \Log::info('[Block11] M1〜M4 正解ラベル算出', [
//             'race' => "{$date}_{$kaisuu}_{$basho}_{$day}_{$race}",
//             'm1' => $mlM1, 'm2' => $mlM2, 'm3' => $mlM3,
//             'top5_pops' => $mlTop5Pops,
//         ]);
        return $mlOut;
    }

    /**
     * 学習フェーズの判定（受入チェック #55・#56 / 最新確定仕様準拠）
     *
     * 仕様:
     *   Phase1 : 1,000レース未満 — 保存のみ。学習・推論は行わない
     *   Phase2 : 1,000〜 — 予備学習・シャドー推論。本番へは反映しない
     *   Phase3 : 正式評価可能。ただし件数だけでは不可で、次をすべて満たすこと
     *            ・2,000レース以上
     *            ・最新の【未使用評価期間】が500レース以上
     *            ・70/15/15 固定なら test が500レース以上 ⇒ 実質 3,334レース以上
     *
     * 「2,000件到達＝正式評価可能」は誤り。未使用評価500レースの確保を必ず判定する。
     *
     * 本番反映は、条件をすべて満たしても自動では解禁しない（明示許可が必要）。
     */
    public static function _getMlPhase(): array
    {
        $phCount = (int) DB::table('t_horse_odds_finder_ml_snapshot')->count();

        // 70/15/15 固定のため test 区分は全体の15%
        $phTestCount   = intdiv($phCount * 15, 100);
        $phNeedHoldout = 500;                                   // 未使用評価に必要なレース数
        $phMinTotal    = 2000;                                  // 最低件数
        // test が500件に達するために必要な総件数（70/15/15 固定）
        $phRequiredForHoldout = (int) ceil($phNeedHoldout / 0.15);  // = 3,334

        $phHoldoutOk = ($phTestCount >= $phNeedHoldout);
        $phCountOk   = ($phCount >= $phMinTotal);

        if     ($phCount < 1000)              { $phPhase = 1; }
        elseif (!($phCountOk && $phHoldoutOk)) { $phPhase = 2; }
        else                                   { $phPhase = 3; }

        $phUnmet = [];
        if (!$phCountOk)   $phUnmet[] = "総レース数が{$phMinTotal}件未満（現在{$phCount}件）";
        if (!$phHoldoutOk) $phUnmet[] = "未使用評価が{$phNeedHoldout}レース未満"
                                      . "（現在の test 区分{$phTestCount}件／"
                                      . "70-15-15固定では総{$phRequiredForHoldout}件以上が必要）";

        $phOut = [
            'phase'            => $phPhase,
            'race_count'       => $phCount,
            'allow_training'   => ($phPhase >= 2),
            'allow_inference'  => ($phPhase >= 2),
            'allow_formal_eval'=> ($phPhase >= 3),
            // 本番反映は条件を満たしても自動解禁しない（明示許可が必要）
            'allow_production' => false,
            'phase3_conditions' => [
                'min_total_races'        => $phMinTotal,
                'min_holdout_races'      => $phNeedHoldout,
                'required_total_for_holdout' => $phRequiredForHoldout, // 3,334
                'current_test_count'     => $phTestCount,
                'total_ok'               => $phCountOk,
                'holdout_ok'             => $phHoldoutOk,
                'unmet'                  => $phUnmet,
            ],
            'note' => match ($phPhase) {
                1 => 'Phase1: スナップショット保存のみ。学習・推論は未実施',
                2 => 'Phase2: 予備学習・シャドー推論。正式評価の条件は未達（下記 unmet を参照）',
                3 => 'Phase3: 正式評価が可能。ただし本番有効化には別途明示許可が必要',
            },
            'thresholds' => ['phase2_from' => 1000, 'phase3_from' => $phMinTotal,
                             'phase3_holdout' => $phNeedHoldout],
        ];

//         \Log::debug('[Block11] ml phase', $phOut);
        return $phOut;
    }

    /**
     * モデル評価指標の算出（最新確定仕様の指定指標）
     *
     * 仕様で保存を求められている指標（M1〜M3）:
     *   ・適合率(precision) ・再現率(recall) ・F1
     *   ・ROC-AUC
     *   ・PR-AUC（Average Precision）
     *   ・Brier score
     *   ・校正誤差（ECE / MCE・10分割の信頼度曲線つき）
     *   ・人気帯別の回収率
     *   ・最大連敗
     *   ・断層タイプ別の集計
     * これらに加え、logloss / 的中率 も併せて返す。
     *
     * 適合率・再現率・F1 は 2 種類の閾値で算出する。
     *   ・threshold 0.5（既定の分類閾値）
     *   ・$betThreshold（購入とみなす閾値。回収率の集計と同じ条件）
     *
     * 回収率は「単勝100円均等買い」を前提に、
     *   回収率 = 払戻合計 ÷ 購入額合計 = Σ(label×odds×100) ÷ (件数×100)
     * で算出する（odds は推定確定単勝オッズ）。
     *
     * @param  array $probs    予測確率
     * @param  array $labels   正解ラベル（0/1）
     * @param  array $meta     各サンプルの付随情報 ['popularity'=>int,'odds'=>float,'gap_type'=>string]
     * @param  float $betThreshold 購入とみなす確率のしきい値
     */
    public static function _evaluateMlModel(
        array $probs,
        array $labels,
        array $meta = [],
        float $betThreshold = 0.5
    ): array {
        $evN = count($probs);
        if ($evN === 0 || $evN !== count($labels)) {
            return ['status' => 'skipped', 'reason' => 'データ件数が0、または件数不一致'];
        }
        $evY = array_map(fn($v) => ((int)$v === 1) ? 1 : 0, $labels);
        $evPos = array_sum($evY);
        $evNeg = $evN - $evPos;

        // ── ROC-AUC（順位法。同値は平均順位で扱う）──────────────────────
        $evAuc = null;
        if ($evPos > 0 && $evNeg > 0) {
            $evIdx = range(0, $evN - 1);
            usort($evIdx, fn($a, $b) => $probs[$a] <=> $probs[$b]);
            $evRank = array_fill(0, $evN, 0.0);
            $evI = 0;
            while ($evI < $evN) {
                $evJ = $evI;
                while ($evJ + 1 < $evN && $probs[$evIdx[$evJ + 1]] === $probs[$evIdx[$evI]]) $evJ++;
                $evAvg = (($evI + 1) + ($evJ + 1)) / 2.0;   // 1始まりの平均順位
                for ($evK = $evI; $evK <= $evJ; $evK++) $evRank[$evIdx[$evK]] = $evAvg;
                $evI = $evJ + 1;
            }
            $evSumPos = 0.0;
            for ($evK = 0; $evK < $evN; $evK++) if ($evY[$evK] === 1) $evSumPos += $evRank[$evK];
            $evAuc = round(($evSumPos - $evPos * ($evPos + 1) / 2.0) / ($evPos * $evNeg), 6);
        }

        // ── PR-AUC（Average Precision）────────────────────────────────
        $evPrAuc = null;
        if ($evPos > 0) {
            $evOrd = range(0, $evN - 1);
            usort($evOrd, fn($a, $b) => $probs[$b] <=> $probs[$a]);   // 確率降順
            $evTp = 0; $evFp = 0; $evPrevRecall = 0.0; $evAp = 0.0;
            foreach ($evOrd as $evK) {
                if ($evY[$evK] === 1) $evTp++; else $evFp++;
                $evPrec   = $evTp / max(1, $evTp + $evFp);
                $evRecall = $evTp / $evPos;
                $evAp    += $evPrec * ($evRecall - $evPrevRecall);
                $evPrevRecall = $evRecall;
            }
            $evPrAuc = round($evAp, 6);
        }

        // ── logloss / Brier / 的中率 ───────────────────────────────────
        $evLoss = 0.0; $evBrier = 0.0; $evHit = 0;
        for ($evK = 0; $evK < $evN; $evK++) {
            $evP = min(1 - 1e-12, max(1e-12, (float)$probs[$evK]));
            $evLoss  += -($evY[$evK] * log($evP) + (1 - $evY[$evK]) * log(1 - $evP));
            $evBrier += ($evP - $evY[$evK]) ** 2;
            if ((($evP >= 0.5) ? 1 : 0) === $evY[$evK]) $evHit++;
        }

        // ── 適合率 / 再現率 / F1（閾値ごとの混同行列から算出）─────────────
        $evPrf = function (float $th) use ($evN, $probs, $evY): array {
            $tp = 0; $fp = 0; $fn = 0; $tn = 0;
            for ($k = 0; $k < $evN; $k++) {
                $pred = ((float)$probs[$k] >= $th) ? 1 : 0;
                if ($pred === 1 && $evY[$k] === 1) $tp++;
                elseif ($pred === 1 && $evY[$k] === 0) $fp++;
                elseif ($pred === 0 && $evY[$k] === 1) $fn++;
                else $tn++;
            }
            // 分母0のときは「算出不能」を null で表す（0にしない）
            $prec = ($tp + $fp) > 0 ? $tp / ($tp + $fp) : null;
            $rec  = ($tp + $fn) > 0 ? $tp / ($tp + $fn) : null;
            $f1   = ($prec !== null && $rec !== null && ($prec + $rec) > 0)
                    ? 2 * $prec * $rec / ($prec + $rec) : null;
            return [
                'threshold' => $th,
                'tp' => $tp, 'fp' => $fp, 'fn' => $fn, 'tn' => $tn,
                'precision' => $prec !== null ? round($prec, 6) : null,
                'recall'    => $rec  !== null ? round($rec,  6) : null,
                'f1'        => $f1   !== null ? round($f1,   6) : null,
            ];
        };
        $evPrf05  = $evPrf(0.5);
        $evPrfBet = $evPrf($betThreshold);

        // ── 校正誤差（ECE / MCE）──────────────────────────────────────
        // 予測確率を10等分の区間に分け、各区間で |平均予測確率 - 実際の発生率| を測る。
        //   ECE = サンプル数で重み付けした平均、MCE = 最大値。
        //   reliability には信頼度曲線（横軸=平均予測確率, 縦軸=実測率）の点を残す。
        $evBins = 10;
        $evBinAcc = array_fill(0, $evBins, ['n' => 0, 'p' => 0.0, 'y' => 0]);
        for ($evK = 0; $evK < $evN; $evK++) {
            $evP = min(1.0, max(0.0, (float)$probs[$evK]));
            $evB = (int) floor($evP * $evBins);
            if ($evB >= $evBins) $evB = $evBins - 1;
            $evBinAcc[$evB]['n']++;
            $evBinAcc[$evB]['p'] += $evP;
            $evBinAcc[$evB]['y'] += $evY[$evK];
        }
        $evEce = 0.0; $evMce = 0.0; $evRel = [];
        foreach ($evBinAcc as $evBi => $evBv) {
            if ($evBv['n'] === 0) continue;
            $evMeanP = $evBv['p'] / $evBv['n'];
            $evFrac  = $evBv['y'] / $evBv['n'];
            $evGapAbs = abs($evMeanP - $evFrac);
            $evEce += ($evBv['n'] / $evN) * $evGapAbs;
            if ($evGapAbs > $evMce) $evMce = $evGapAbs;
            $evRel[] = [
                'bin'            => sprintf('%.1f-%.1f', $evBi / $evBins, ($evBi + 1) / $evBins),
                'count'          => $evBv['n'],
                'mean_predicted' => round($evMeanP, 6),
                'observed_rate'  => round($evFrac, 6),
                'gap'            => round($evMeanP - $evFrac, 6),
            ];
        }

        // ── 購入シミュレーション（単勝100円均等買い）────────────────────
        $evBet = 0; $evRet = 0.0;
        $evStreak = 0; $evMaxStreak = 0;
        $evByPop = [];   // 人気帯別
        $evByGap = [];   // 断層タイプ別
        for ($evK = 0; $evK < $evN; $evK++) {
            if ((float)$probs[$evK] < $betThreshold) continue;
            $evOdds = (float)($meta[$evK]['odds'] ?? 0.0);
            $evBet++;
            $evPay = ($evY[$evK] === 1 && $evOdds > 0) ? $evOdds * 100.0 : 0.0;
            $evRet += $evPay;
            // 最大連敗
            if ($evY[$evK] === 1) { $evStreak = 0; }
            else { $evStreak++; if ($evStreak > $evMaxStreak) $evMaxStreak = $evStreak; }
            // 人気帯別（1-3 / 4-6 / 7-10 / 11+）
            $evPop = (int)($meta[$evK]['popularity'] ?? 0);
            $evBand = ($evPop >= 1 && $evPop <= 3) ? '1-3'
                    : (($evPop <= 6) ? '4-6' : (($evPop <= 10) ? '7-10' : '11+'));
            if ($evPop <= 0) $evBand = 'unknown';
            $evByPop[$evBand]['bet'] = ($evByPop[$evBand]['bet'] ?? 0) + 1;
            $evByPop[$evBand]['ret'] = ($evByPop[$evBand]['ret'] ?? 0.0) + $evPay;
            $evByPop[$evBand]['hit'] = ($evByPop[$evBand]['hit'] ?? 0) + $evY[$evK];
            // 断層タイプ別
            $evGt = (string)($meta[$evK]['gap_type'] ?? 'unknown');
            $evByGap[$evGt]['bet'] = ($evByGap[$evGt]['bet'] ?? 0) + 1;
            $evByGap[$evGt]['ret'] = ($evByGap[$evGt]['ret'] ?? 0.0) + $evPay;
            $evByGap[$evGt]['hit'] = ($evByGap[$evGt]['hit'] ?? 0) + $evY[$evK];
        }
        $evRate = fn(array $a): array => [
            'bet_count'     => $a['bet'],
            'hit_count'     => $a['hit'],
            'hit_rate'      => round($a['hit'] / max(1, $a['bet']), 4),
            'recovery_rate' => round($a['ret'] / max(1, $a['bet'] * 100.0) * 100.0, 2), // %
        ];
        ksort($evByPop); ksort($evByGap);

        return [
            'status'        => 'evaluated',
            'sample_count'  => $evN,
            'positive'      => $evPos,
            'roc_auc'       => $evAuc,
            'pr_auc'        => $evPrAuc,
            'logloss'       => round($evLoss / $evN, 6),
            'brier'         => round($evBrier / $evN, 6),
            'accuracy'      => round($evHit / $evN, 4),
            // 適合率・再現率・F1（仕様の必須指標）
            'precision'     => $evPrf05['precision'],
            'recall'        => $evPrf05['recall'],
            'f1'            => $evPrf05['f1'],
            'prf_at_0_5'    => $evPrf05,
            'prf_at_bet_threshold' => $evPrfBet,
            // 校正誤差（仕様の必須指標）
            'calibration_error' => [
                'ece'         => round($evEce, 6),
                'mce'         => round($evMce, 6),
                'bins'        => $evBins,
                'reliability' => $evRel,
            ],
            'bet_threshold' => $betThreshold,
            'overall'       => [
                'bet_count'     => $evBet,
                'recovery_rate' => round($evRet / max(1, $evBet * 100.0) * 100.0, 2),
                'max_losing_streak' => $evMaxStreak,
            ],
            'by_popularity' => array_map($evRate, $evByPop),
            'by_gap_type'   => array_map($evRate, $evByGap),
            'note'          => '回収率は単勝100円均等買いを前提に算出。odds は推定確定単勝オッズ',
        ];
    }


    /**
     * M4（馬単位・5着以内）専用の評価指標
     *
     * 最新確定仕様で M4 に求められている指標:
     *   ・5着以内率        ・3着以内率
     *   ・単勝回収率        ・複勝回収率
     *   ・平均配当          ・中央値配当
     *   ・最大連敗          ・最大値除外後回収率
     *   ・平均選出頭数を揃えた、現行版との比較
     *   ・上記を【全体および人気帯別】で保存する
     *   ・学習モデルによって追加で拾えた馬・押し出された馬・偽陽性・偽陰性を
     *     【断層タイプ別】に集計する
     *
     * ROC-AUC / PR-AUC / F1 / 校正誤差など共通の指標は _evaluateMlModel() が返すので、
     * 本メソッドは「買った場合にどうなるか」の指標に絞って算出し、両方を返す。
     *
     * 回収率は 100円均等買いを前提とする。
     *   単勝回収率 = Σ(1着 × 単勝オッズ × 100) ÷ (購入点数 × 100)
     *   複勝回収率 = Σ(3着以内 × 複勝オッズ × 100) ÷ (購入点数 × 100)
     *
     * 「最大値除外後回収率」は、最も高い払戻を出した1点を分子・分母の両方から除いて
     * 再計算する（1回の大穴だけで回収率が見かけ上良くなる現象を除くため）。
     *
     * 「平均選出頭数を揃えた比較」は、現行版が1レースあたり平均何頭選んでいるかを数え、
     * 学習版も同じ頭数だけ（M4確率の高い順に）選んだうえで比較する。
     * 頭数が違うまま比較すると、単に多く買っただけで数字が動くため。
     *
     * @param array      $probs   M4 予測確率（馬ごと）
     * @param array      $labels  5着以内ラベル（0/1）
     * @param array      $meta    馬ごとの付随情報
     *        ['race_key'=>string,'num'=>int,'win'=>0|1,'top3'=>0|1,
     *         'tan_odds'=>float,'fuku_odds'=>float,'popularity'=>int,'gap_type'=>string]
     * @param array|null $currentSelection 現行版の選出 ['race_key' => [馬番, ...], ...]
     * @param float      $betThreshold     購入とみなす確率のしきい値
     */
    public static function _evaluateM4Model(
        array  $probs,
        array  $labels,
        array  $meta = [],
        ?array $currentSelection = null,
        float  $betThreshold = 0.5
    ): array {
        $m4N = count($probs);
        if ($m4N === 0 || $m4N !== count($labels)) {
            return ['status' => 'skipped', 'reason' => 'データ件数が0、または件数不一致'];
        }
        $m4Y = array_map(fn($v) => ((int)$v === 1) ? 1 : 0, $labels);

        // ── 選出した添字集合に対して、仕様の指標一式を算出する ────────────
        $m4Calc = function (array $idxList) use ($probs, $m4Y, $meta): array {
            $cnt = count($idxList);
            if ($cnt === 0) {
                return ['status' => 'skipped', 'reason' => '選出0件', 'bet_count' => 0];
            }
            $top5 = 0; $top3 = 0; $win = 0;
            $tanRet = 0.0; $fukuRet = 0.0;
            $tanPays = []; $fukuPays = [];
            $streak = 0; $maxStreak = 0;
            foreach ($idxList as $i) {
                $mW  = (int)   ($meta[$i]['win']       ?? 0);
                $mT3 = (int)   ($meta[$i]['top3']      ?? 0);
                $mTo = (float) ($meta[$i]['tan_odds']  ?? 0.0);
                $mFo = (float) ($meta[$i]['fuku_odds'] ?? 0.0);

                $top5 += $m4Y[$i];
                $top3 += $mT3;
                $win  += $mW;

                $pT = ($mW  === 1 && $mTo > 0) ? $mTo * 100.0 : 0.0;
                $pF = ($mT3 === 1 && $mFo > 0) ? $mFo * 100.0 : 0.0;
                $tanRet  += $pT;
                $fukuRet += $pF;
                $tanPays[]  = $pT;
                $fukuPays[] = $pF;

                // 最大連敗（複勝＝3着以内を外した連続回数）
                if ($mT3 === 1) { $streak = 0; }
                else { $streak++; if ($streak > $maxStreak) $maxStreak = $streak; }
            }

            // 的中したぶんだけの配当（平均配当・中央値配当）
            $hitTan  = array_values(array_filter($tanPays,  fn($v) => $v > 0));
            $hitFuku = array_values(array_filter($fukuPays, fn($v) => $v > 0));
            $avgOf   = fn(array $a) => empty($a) ? null : round(array_sum($a) / count($a), 2);
            $medOf   = function (array $a) {
                if (empty($a)) return null;
                sort($a); $n = count($a); $h = intdiv($n, 2);
                return round(($n % 2) ? $a[$h] : ($a[$h - 1] + $a[$h]) / 2.0, 2);
            };

            // 最大値除外後回収率（最高払戻の1点を分子・分母の両方から除く）
            $exRate = function (array $pays) use ($cnt): ?float {
                if ($cnt <= 1) return null;                 // 1点しかなければ算出できない
                $mx  = max($pays);
                $sum = array_sum($pays) - $mx;   // 最高払戻の1点を分子から除く
                return round($sum / (($cnt - 1) * 100.0) * 100.0, 2);
            };

            return [
                'status'        => 'evaluated',
                'bet_count'     => $cnt,
                'top5_rate'     => round($top5 / $cnt, 6),   // 5着以内率
                'top3_rate'     => round($top3 / $cnt, 6),   // 3着以内率
                'win_rate'      => round($win  / $cnt, 6),   // 勝率（参考）
                'tan_recovery_rate'  => round($tanRet  / ($cnt * 100.0) * 100.0, 2), // 単勝回収率(%)
                'fuku_recovery_rate' => round($fukuRet / ($cnt * 100.0) * 100.0, 2), // 複勝回収率(%)
                'avg_payout_tan'     => $avgOf($hitTan),     // 平均配当（単勝・的中分のみ）
                'median_payout_tan'  => $medOf($hitTan),     // 中央値配当（単勝・的中分のみ）
                'avg_payout_fuku'    => $avgOf($hitFuku),    // 平均配当（複勝・的中分のみ）
                'median_payout_fuku' => $medOf($hitFuku),    // 中央値配当（複勝・的中分のみ）
                'max_losing_streak'  => $maxStreak,          // 最大連敗（複勝基準）
                'tan_recovery_excluding_max'  => $exRate($tanPays),  // 最大値除外後回収率(単勝)
                'fuku_recovery_excluding_max' => $exRate($fukuPays), // 最大値除外後回収率(複勝)
            ];
        };

        // 人気帯別（1-3 / 4-6 / 7-10 / 11+ / unknown）に分けて同じ指標を出す
        $m4Band = function (int $i) use ($meta): string {
            $pv = (int) ($meta[$i]['popularity'] ?? 0);
            if ($pv <= 0)  return 'unknown';
            if ($pv <= 3)  return '1-3';
            if ($pv <= 6)  return '4-6';
            if ($pv <= 10) return '7-10';
            return '11+';
        };
        $m4ByBand = function (array $idxList) use ($m4Band, $m4Calc): array {
            $groups = [];
            foreach ($idxList as $i) $groups[$m4Band($i)][] = $i;
            ksort($groups);
            return array_map($m4Calc, $groups);
        };

        // ── ① しきい値方式での選出 ──────────────────────────────────────
        $m4ByTh = [];
        for ($i = 0; $i < $m4N; $i++) if ((float)$probs[$i] >= $betThreshold) $m4ByTh[] = $i;

        // ── ② 平均選出頭数を揃えた比較 ──────────────────────────────────
        // レース単位に添字をまとめる
        $m4Races = [];
        for ($i = 0; $i < $m4N; $i++) {
            $m4Races[(string)($meta[$i]['race_key'] ?? '')][] = $i;
        }
        $m4Aligned = null;
        $m4Diff    = null;
        if (!empty($currentSelection)) {
            // 現行版が1レースあたり平均何頭選んでいるか
            $m4CurCounts = array_map(fn($a) => count((array)$a), $currentSelection);
            $m4AvgN = !empty($m4CurCounts)
                ? array_sum($m4CurCounts) / count($m4CurCounts) : 0.0;
            $m4TakeN = max(1, (int) round($m4AvgN));

            // 現行版の選出添字（馬番で突き合わせる）
            $m4CurIdx = [];
            foreach ($m4Races as $m4Rk => $m4Idxs) {
                $m4Sel = array_map('intval', (array)($currentSelection[$m4Rk] ?? []));
                foreach ($m4Idxs as $i) {
                    if (in_array((int)($meta[$i]['num'] ?? -1), $m4Sel, true)) $m4CurIdx[] = $i;
                }
            }
            // 学習版：各レースで確率上位 $m4TakeN 頭を選ぶ（頭数を揃える）
            $m4LrnIdx = [];
            foreach ($m4Races as $m4Idxs) {
                usort($m4Idxs, fn($a, $b) => $probs[$b] <=> $probs[$a]);
                foreach (array_slice($m4Idxs, 0, $m4TakeN) as $i) $m4LrnIdx[] = $i;
            }
            $m4Aligned = [
                'race_count'            => count($m4Races),
                'current_avg_selected'  => round($m4AvgN, 4),
                'selected_per_race'     => $m4TakeN,
                'current_version'       => $m4Calc($m4CurIdx),
                'learned_version'       => $m4Calc($m4LrnIdx),
                'note' => '1レースあたりの選出頭数を揃えたうえで比較している（頭数差による見かけの差を排除）',
            ];
            // 人気薄を増やしただけの改善になっていないかの確認材料
            $m4PopAvg = function (array $idxList) use ($meta): ?float {
                $vals = [];
                foreach ($idxList as $i) {
                    $pv = $meta[$i]['popularity'] ?? null;
                    if ($pv !== null && (int)$pv > 0) $vals[] = (int)$pv;
                }
                return empty($vals) ? null : round(array_sum($vals) / count($vals), 3);
            };
            $m4Aligned['current_version']['avg_popularity'] = $m4PopAvg($m4CurIdx);
            $m4Aligned['learned_version']['avg_popularity'] = $m4PopAvg($m4LrnIdx);
            $m4Aligned['popularity_note'] =
                '平均人気が学習版だけ大きく下がっている場合、回収率の改善は「人気薄を多く買った」結果の可能性がある';
            // 人気帯別（仕様: 全体および人気帯別を保存する）
            $m4Aligned['current_version']['by_popularity'] = $m4ByBand($m4CurIdx);
            $m4Aligned['learned_version']['by_popularity'] = $m4ByBand($m4LrnIdx);

            // ── 追加で拾えた馬 / 押し出された馬 / 偽陽性 / 偽陰性（断層タイプ別）──
            // 学習版だけが選んだ馬 = 追加で拾えた馬、現行版だけが選んだ馬 = 押し出された馬。
            // 偽陽性 = 選んだのに5着以内でなかった、偽陰性 = 選ばなかったのに5着以内だった。
            $m4CurSet = array_fill_keys($m4CurIdx, true);
            $m4LrnSet = array_fill_keys($m4LrnIdx, true);
            $m4Diff = [];
            $m4Bump = function (string $gt, string $key) use (&$m4Diff) {
                if (!isset($m4Diff[$gt])) {
                    $m4Diff[$gt] = ['picked_up' => 0, 'picked_up_hit' => 0,
                                    'pushed_out' => 0, 'pushed_out_hit' => 0,
                                    'false_positive' => 0, 'false_negative' => 0];
                }
                $m4Diff[$gt][$key]++;
            };
            for ($i = 0; $i < $m4N; $i++) {
                $gt  = (string) ($meta[$i]['gap_type'] ?? 'unknown');
                $inC = isset($m4CurSet[$i]);
                $inL = isset($m4LrnSet[$i]);
                if ($inL && !$inC) {
                    $m4Bump($gt, 'picked_up');
                    if ($m4Y[$i] === 1) $m4Bump($gt, 'picked_up_hit');
                } elseif ($inC && !$inL) {
                    $m4Bump($gt, 'pushed_out');
                    if ($m4Y[$i] === 1) $m4Bump($gt, 'pushed_out_hit');
                }
                if ($inL && $m4Y[$i] === 0) $m4Bump($gt, 'false_positive');
                if (!$inL && $m4Y[$i] === 1) $m4Bump($gt, 'false_negative');
            }
            ksort($m4Diff);
        }

        return [
            'status'         => 'evaluated',
            'sample_count'   => $m4N,
            'bet_threshold'  => $betThreshold,
            // 共通指標（ROC-AUC / PR-AUC / F1 / Brier / 校正誤差 など）
            'common_metrics' => self::_evaluateMlModel($probs, $labels, $meta, $betThreshold),
            // M4 固有指標（しきい値方式）: 全体
            'by_threshold'   => $m4Calc($m4ByTh),
            // 同じ指標の人気帯別内訳
            'by_popularity'  => $m4ByBand($m4ByTh),
            // 平均選出頭数を揃えた現行版との比較（全体＋人気帯別）
            'aligned_comparison' => $m4Aligned,
            // 追加で拾えた馬・押し出された馬・偽陽性・偽陰性（断層タイプ別）
            'diff_by_gap_type'   => $m4Diff,
            'note' => '回収率は100円均等買いを前提に算出。配当は的中した点のみで平均・中央値を取る',
        ];
    }


    /**
     * 確率校正（受入チェック #53）
     *
     * 仕様: モデルが出す生スコアは、そのままでは「確率」として読めない。
     *   実際の的中率と一致するよう補正してから確率として扱う。
     *
     * 方式: Platt scaling（ロジスティック回帰による1次元校正）
     *   p = 1 / (1 + exp(A * s + B))
     *   A・B を勾配降下法で学習し、生スコア s を校正済み確率 p へ写像する。
     *
     * 学習データの制約:
     *   校正は【validation区分】のデータだけで行う。
     *   train を使うとモデルが過学習した分まで学習してしまい、
     *   test を使うと評価が汚れるため。
     *
     * 品質指標:
     *   Brier Score（低いほど良い）と ECE（Expected Calibration Error）を
     *   校正前後で返し、校正が実際に効いているかを確認できるようにする。
     *
     * @param  array $scores 生スコア（0〜100想定）
     * @param  array $labels 正解ラベル（0 or 1）
     * @return array{a:float, b:float, calibrated:array, metrics:array}
     */
    public static function _calibrateProbabilities(array $scores, array $labels, int $iterations = 300): array
    {
        $cbN = count($scores);
        if ($cbN === 0 || $cbN !== count($labels)) {
            return ['a' => 0.0, 'b' => 0.0, 'calibrated' => [],
                    'metrics' => ['status' => 'skipped', 'reason' => 'データ件数が0、または件数不一致']];
        }
        // 正例・負例が片方しか無いと校正できない
        $cbPos = count(array_filter($labels, fn($v) => (int)$v === 1));
        if ($cbPos === 0 || $cbPos === $cbN) {
            return ['a' => 0.0, 'b' => 0.0, 'calibrated' => [],
                    'metrics' => ['status' => 'skipped',
                                  'reason' => '正例または負例が0件のため校正不能',
                                  'positive' => $cbPos, 'total' => $cbN]];
        }

        // スコアを 0〜1 へ正規化（数値安定化のため）
        $cbMin = min($scores); $cbMax = max($scores);
        $cbRange = ($cbMax - $cbMin) > 0 ? ($cbMax - $cbMin) : 1.0;
        $cbX = array_map(fn($s) => ($s - $cbMin) / $cbRange, $scores);
        $cbY = array_map(fn($v) => (int)$v === 1 ? 1.0 : 0.0, $labels);

        // Platt の目標値（過学習を避けるための平滑化）
        $cbNp = $cbPos; $cbNn = $cbN - $cbPos;
        $cbHi = ($cbNp + 1.0) / ($cbNp + 2.0);
        $cbLo = 1.0 / ($cbNn + 2.0);
        $cbT  = array_map(fn($y) => $y > 0.5 ? $cbHi : $cbLo, $cbY);

        // 勾配降下法で A・B を学習
        $cbA = 0.0; $cbB = 0.0; $cbLr = 0.5;
        for ($cbIt = 0; $cbIt < $iterations; $cbIt++) {
            $cbGa = 0.0; $cbGb = 0.0;
            for ($cbI = 0; $cbI < $cbN; $cbI++) {
                $cbZ = $cbA * $cbX[$cbI] + $cbB;
                $cbP = 1.0 / (1.0 + exp(max(-60, min(60, $cbZ))));  // オーバーフロー防止
                // p = sigmoid(-z) のため dL/dz = (t - p)。
                // ここを (p - t) にすると勾配の符号が逆になり、
                // 学習するほど精度が悪化する（Brierが増え単調性も崩れる）。
                $cbD = $cbT[$cbI] - $cbP;
                $cbGa += $cbD * $cbX[$cbI];
                $cbGb += $cbD;
            }
            $cbA -= $cbLr * $cbGa / $cbN;
            $cbB -= $cbLr * $cbGb / $cbN;
        }

        // 校正済み確率
        $cbCal = [];
        for ($cbI = 0; $cbI < $cbN; $cbI++) {
            $cbZ = $cbA * $cbX[$cbI] + $cbB;
            $cbCal[] = round(1.0 / (1.0 + exp(max(-60, min(60, $cbZ)))), 6);
        }

        // ── 品質指標: Brier Score と ECE ──────────────────────────────
        $cbBrier = function (array $p, array $y): float {
            $s = 0.0;
            foreach ($p as $i => $v) $s += ($v - $y[$i]) ** 2;
            return round($s / max(1, count($p)), 6);
        };
        $cbEce = function (array $p, array $y, int $bins = 10): float {
            $n = count($p); if ($n === 0) return 0.0;
            $sum = 0.0;
            for ($b = 0; $b < $bins; $b++) {
                $lo = $b / $bins; $hi = ($b + 1) / $bins;
                $idx = [];
                foreach ($p as $i => $v) {
                    if ($v > $lo && $v <= $hi) $idx[] = $i;
                    elseif ($b === 0 && $v <= 0.0 + 1e-12) $idx[] = $i;
                }
                if (empty($idx)) continue;
                $avgP = array_sum(array_map(fn($i) => $p[$i], $idx)) / count($idx);
                $avgY = array_sum(array_map(fn($i) => $y[$i], $idx)) / count($idx);
                $sum += (count($idx) / $n) * abs($avgP - $avgY);
            }
            return round($sum, 6);
        };
        // 校正前は「正規化スコアをそのまま確率とみなした場合」と比較する
        $cbRaw = $cbX;

        return [
            'a' => round($cbA, 6),
            'b' => round($cbB, 6),
            'calibrated' => $cbCal,
            'metrics' => [
                'status'        => 'calibrated',
                'method'        => 'platt_scaling',
                'sample_count'  => $cbN,
                'positive'      => $cbPos,
                'brier_before'  => $cbBrier($cbRaw, $cbY),
                'brier_after'   => $cbBrier($cbCal, $cbY),
                'ece_before'    => $cbEce($cbRaw, $cbY),
                'ece_after'     => $cbEce($cbCal, $cbY),
                'note'          => '校正は validation 区分のみで行う（train は過学習、test は評価汚染のため）',
            ],
        ];
    }

    /**
     * 現行版と学習版の並行比較（受入チェック #54）
     *
     * 仕様: 学習版を本番へ入れる前に、現行版とどれだけ違うかを定量的に比較する。
     *   一致率・順位相関・上位N重なりを出し、差が大きすぎないかを確認する。
     *
     * 本メソッドは比較結果を返すだけで、順位の採否は行わない。
     * 学習版の本番反映はよっしーの許可が出るまで禁止。
     *
     * @param  array $currentRanking 現行版の順位（[['num'=>int,'rank'=>int], ...]）
     * @param  array $learnedRanking 学習版の順位（同形式）
     * @return array 比較メトリクス
     */
    public static function _compareModelVersions(array $currentRanking, array $learnedRanking): array
    {
        $cmCur = []; foreach ($currentRanking as $r) $cmCur[(int)$r['num']] = (int)$r['rank'];
        $cmLrn = []; foreach ($learnedRanking as $r) $cmLrn[(int)$r['num']] = (int)$r['rank'];
        $cmCommon = array_values(array_intersect(array_keys($cmCur), array_keys($cmLrn)));
        $cmN = count($cmCommon);

        if ($cmN === 0) {
            return ['status' => 'skipped', 'reason' => '共通の馬が無く比較できない',
                    'current_count' => count($cmCur), 'learned_count' => count($cmLrn)];
        }

        // 順位完全一致数
        $cmSameRank = 0;
        $cmDiffSum  = 0;
        $cmDiffMax  = 0;
        foreach ($cmCommon as $cmNum) {
            $cmD = abs($cmCur[$cmNum] - $cmLrn[$cmNum]);
            if ($cmD === 0) $cmSameRank++;
            $cmDiffSum += $cmD;
            if ($cmD > $cmDiffMax) $cmDiffMax = $cmD;
        }

        // Spearman 順位相関（共通馬のみ・同順位なしを前提とした簡易式）
        $cmD2 = 0;
        foreach ($cmCommon as $cmNum) $cmD2 += ($cmCur[$cmNum] - $cmLrn[$cmNum]) ** 2;
        $cmSpearman = ($cmN > 1)
            ? round(1.0 - (6.0 * $cmD2) / ($cmN * (($cmN ** 2) - 1)), 4)
            : null;

        // 上位N重なり
        $cmTopN = function (array $map, int $n): array {
            asort($map);
            return array_slice(array_keys($map), 0, $n);
        };
        $cmOverlap = [];
        foreach ([1, 3, 5] as $cmK) {
            $cmA = $cmTopN($cmCur, $cmK);
            $cmB = $cmTopN($cmLrn, $cmK);
            $cmOverlap["top{$cmK}"] = [
                'current' => $cmA,
                'learned' => $cmB,
                'shared'  => array_values(array_intersect($cmA, $cmB)),
                'rate'    => round(count(array_intersect($cmA, $cmB)) / max(1, $cmK), 4),
            ];
        }

        return [
            'status'            => 'compared',
            'common_count'      => $cmN,
            'same_rank_count'   => $cmSameRank,
            'same_rank_rate'    => round($cmSameRank / $cmN, 4),
            'avg_rank_diff'     => round($cmDiffSum / $cmN, 4),
            'max_rank_diff'     => $cmDiffMax,
            'spearman'          => $cmSpearman,
            'top_n_overlap'     => $cmOverlap,
            'production_switch' => false,   // 比較するだけ。本番切替は行わない
            'note'              => '比較結果のみ。学習版の本番反映は許可が出るまで行わない',
        ];
    }

    /**
     * 日付順 70% / 15% / 15% の時系列分割（受入チェック #49）
     *
     * 仕様: 学習・検証・評価を「日付順」で分割する。
     *   ランダム分割は未来のレースが学習側へ混ざる（未来情報混入）ため禁止。
     *   古い順に 70% を train、次の 15% を validation、最後の 15% を test とする。
     *
     * 決定論性:
     *   並び順は date, kaisuu, basho, day, race の昇順で一意に定まるため、
     *   同じスナップショット集合からは常に同じ分割結果が得られる。
     *
     * 境界の扱い:
     *   intdiv で切り下げるため、端数は test 側に寄る。
     *   同一レース（同一キー）が2つの区分にまたがることはない。
     *
     * @param  int|null $limitDate この日付以前のスナップショットのみ対象（null=全件）
     * @return array{train:array, validation:array, test:array, summary:array}
     */
    public static function _assignTimeSeriesSplit(?string $limitDate = null): array
    {
        $tsQuery = DB::table('t_horse_odds_finder_ml_snapshot')
            ->select(['date', 'kaisuu', 'basho_code', 'day', 'race'])
            ->orderBy('date')->orderBy('kaisuu')->orderBy('basho_code')
            ->orderBy('day')->orderBy('race');
        if ($limitDate !== null) {
            $tsQuery->where('date', '<=', $limitDate);
        }
        $tsRows = $tsQuery->get();

        $tsTotal = $tsRows->count();
        if ($tsTotal === 0) {
            return [
                'train' => [], 'validation' => [], 'test' => [],
                'summary' => ['total' => 0, 'train' => 0, 'validation' => 0, 'test' => 0,
                              'note' => 'スナップショットが0件のため分割なし'],
            ];
        }

        // 日付順に 70% / 15% / 15%
        $tsTrainEnd = intdiv($tsTotal * 70, 100);
        $tsValEnd   = intdiv($tsTotal * 85, 100);

        $tsOut = ['train' => [], 'validation' => [], 'test' => []];
        foreach ($tsRows->values()->all() as $tsI => $tsR) {
            $tsKey = sprintf('%s_%d_%s_%d_%d',
                $tsR->date, (int)$tsR->kaisuu, $tsR->basho_code, (int)$tsR->day, (int)$tsR->race);
            if     ($tsI <  $tsTrainEnd) $tsOut['train'][]      = $tsKey;
            elseif ($tsI <  $tsValEnd)   $tsOut['validation'][] = $tsKey;
            else                         $tsOut['test'][]       = $tsKey;
        }

        $tsOut['summary'] = [
            'total'      => $tsTotal,
            'train'      => count($tsOut['train']),
            'validation' => count($tsOut['validation']),
            'test'       => count($tsOut['test']),
            'ratio'      => '70/15/15（日付順・ランダム分割禁止）',
            'train_period' => [
                'from' => $tsOut['train'][0]      ?? null,
                'to'   => end($tsOut['train'])    ?: null,
            ],
            'test_period'  => [
                'from' => $tsOut['test'][0]       ?? null,
                'to'   => end($tsOut['test'])     ?: null,
            ],
        ];
        reset($tsOut['train']); reset($tsOut['test']);

//         \Log::info('[Block11] 時系列分割 70/15/15', $tsOut['summary']);
        return $tsOut;
    }

    /**
     * モデル更新・旧モデルへの切戻し管理（受入チェック #57）
     *
     * 仕様: モデルを更新したら旧モデルへ戻せること。戻したときに
     *   当時の予測を再現できること。
     *
     * 本メソッドはモデル登録簿（レジストリ）を返す。
     *   - 各モデルは version / hash / 有効フラグ / 学習期間 / 件数 を持つ
     *   - 有効なモデルは常に1つだけ（is_active=1）
     *   - 旧モデルの行は消さずに残すため、is_active を切り替えるだけで切戻しできる
     *   - 予測の再現には features_json の input_hash と model_hash の組が必要なため、
     *     両方をスナップショットへ保存している
     *
     * Phase1（1,000レース未満）は学習を行わないため、レジストリは
     * 「現行ルールベース版」1件のみを返す。学習開始後にモデル行が追加される。
     *
     * @return array{active:array, registry:array, rollback_ready:bool}
     */
    public static function _buildModelRegistry(string $inputHash): array
    {
        // Phase1: 学習モデル未生成。現行のルールベース版のみが有効。
        $mrCurrent = [
            'model_id'           => 'rule-based-v7',
            'model_type'         => 'llm-ensemble+rule',
            'model_hash'         => null,   // 学習モデル未生成のため null
            'is_active'          => 1,
            'trained_at'         => null,
            'train_period'       => null,
            'train_sample_count' => 0,
            'phase'              => 1,
            // M1〜M4 の学習済みモデル（重みベクトル）。Phase1は未生成のため空。
            // Phase2で _trainMlModel() の結果をここへ格納する。
            'models'             => [],
            'note'               => 'Phase1: 学習未実施。ルールベースのみで候補・順位を決定している',
        ];

        // 学習モデルが登録され次第ここへ追加される。行は削除せず is_active のみ切り替える。
        $mrRegistry = [$mrCurrent];

        return [
            'active'         => $mrCurrent,
            'registry'       => $mrRegistry,
            // 切戻し可能条件: レジストリに2件以上あり、かつ再現用ハッシュが揃っていること
            'rollback_ready' => (count($mrRegistry) >= 2),
            'reproducibility' => [
                'input_hash' => $inputHash,
                'model_hash' => $mrCurrent['model_hash'],
                'note'       => 'input_hash と model_hash の組で当時の予測を再現する。'
                              . 'Phase1は model_hash が null のため、入力の再現のみ可能。',
            ],
        ];
    }

    /**
     * 走破時計の文字列を秒へ変換する
     *
     * DB の time 列は "1:34.5"（分:秒.小数）または "94.5"（秒）の形式。
     * 仕様では走破時計を別カラムで保持することになっているため数値へ直す。
     * 解釈できない値・空値は 0 ではなく null（欠損）を返す。
     */
    public static function _parseRaceTimeToSeconds($value): ?float
    {
        if ($value === null) return null;
        $rtStr = trim((string) $value);
        if ($rtStr === '' || $rtStr === '-' || $rtStr === '－') return null;
        if (preg_match('/^(\d+):(\d{1,2}(?:\.\d+)?)$/', $rtStr, $rtM)) {
            return round((int)$rtM[1] * 60 + (float)$rtM[2], 3);
        }
        if (preg_match('/^\d+(\.\d+)?$/', $rtStr)) {
            return round((float)$rtStr, 3);
        }
        return null; // 解釈できない形式は欠損扱い
    }

    /**
     * 能力・適性データの固定長ベクトル化（受入チェック #63 / 最新確定仕様準拠）
     *
     * 仕様:
     *   ・直近【最大10走】を固定長で保持する（5走ではない）
     *   ・直近3走 / 5走 / 10走 の窓ごとに 件数・平均・中央値・最小・最大 を集約する
     *   ・条件別成績（同コース・同距離帯・同クラス・同騎手）を別途集計する
     *   ・カテゴリ項目は【学習期間だけで作った辞書】でIDへ変換し、
     *     辞書に無い値は UNKNOWN(0) とする
     *   ・欠損値は 0 へ置換せず null のまま保持する（欠損フラグを別に持つ）
     *   ・数値欠損の補完に使う中央値は model_version へ保存し、再現可能にする
     *
     * 未来情報混入の防止:
     *   取得を「今走日より前（date < $date）」に限定する。
     *
     * @param  array      $horseNums 対象馬番（全出走馬）
     * @param  array|null $catDict   学習期間で作成済みのカテゴリ辞書（null=辞書未作成）
     * @return array{vectors:array, imputation:array, dict_used:array}
     */
    public static function _buildAbilityVectors(
        array  $horseNums,
        string $date,
        int    $kaisuu,
        string $basho,
        int    $day,
        int    $race,
        object $raceRow,
        ?array $catDict = null
    ): array {
        $avLen = 10; // 仕様: 最大10走の固定長

        $avTodayDist  = isset($raceRow->dist) ? (int)$raceRow->dist : null;
        $avTodayCond  = $raceRow->course    ?? null;
        $avTodayGrade = $raceRow->grade     ?? null;
        $avTodayBaba  = $raceRow->condition ?? null; // 馬場状態

        // ── カテゴリ辞書（学習期間だけで作る。無ければ UNKNOWN のみ）──────
        // 仕様: 辞書に無い値は UNKNOWN(0)。今走のデータで辞書を増やしてはいけない
        //       （増やすと学習期間外の情報が混入する）
        $avDict = $catDict ?? ['course' => [], 'grade' => [], 'condition' => [],
                               'jockey' => [], 'basho'  => []];
        $avCatId = function (string $kind, $value) use ($avDict): int {
            if ($value === null || $value === '') return 0;               // 欠損も UNKNOWN
            return (int)($avDict[$kind][(string)$value] ?? 0);            // 辞書に無ければ UNKNOWN(0)
        };

        $avHorses = DB::table('t_horse_odds_finder_horses')
            ->where('date', $date)->where('kaisuu', $kaisuu)->where('basho', $basho)
            ->where('day', $day)->where('race', $race)
            ->get(['num', 'name', 'jockey', 'waku']);

        // 集約対象にする数値系列（この一覧で窓集約を作る）
        // 仕様【固定長変換】2 の列挙に対応する数値系列。
        //   着順 / 着差 / 人気 / 単勝オッズ / 距離 / 頭数 / 枠番 / 通過順位(4コーナー個別) /
        //   上がり3F / 上がり順位 / 走破時計 / 斤量 / 斤量差 / 馬体重 / 増減 / 前走からの日数
        $avNumericKeys = ['finishing_position', 'popularity', 'num_horses', 'dist', 'dist_diff',
                          'last_3f', 'last_3f_rank', 'fin_time_diff', 'burden_weight',
                          'burden_weight_diff',
                          'horse_weight', 'horse_weight_diff', 'corner_avg', 'odds',
                          'rest_days', 'finish_rate',
                          'gate', 'time_sec',
                          'corner_1', 'corner_2', 'corner_3', 'corner_4'];

        $avOut = [];
        $avAllForMedian = []; // 補完用中央値の算出に使う（全馬ぶんを集める）

        foreach ($avHorses as $avH) {
            $avNum = (int)$avH->num;
            if (!in_array($avNum, $horseNums, true)) continue;

            $avRows = DB::table('t_horse_odds_finder_shutsuba_history')
                ->where('name', $avH->name)
                ->where('date', '<', $date)   // ← 未来情報混入の防止
                ->orderBy('date', 'desc')
                ->limit($avLen)
                ->get(['date', 'dist', 'condition', 'grade', 'finishing_position',
                       'num_horses', 'popularity', 'jockey', 'burden_weight',
                       'horse_weight', 'last_3f', 'fin_time_diff',
                       // 【20260924】'odds' は t_horse_odds_finder_shutsuba_history に存在しない列のため取得しない
                       //   （Unknown column で例外になり ml_snapshot の保存ごと失敗していた）。下の isset() で欠損(null)扱いになる
                       'corner_1', 'corner_2', 'corner_3', 'corner_4',
                       // 仕様【M4能力・適性元データの固定長変換】2 で列挙されている項目
                       'time', 'gate', 'basho_code'])
                ->values()->all();

            // ── 固定長シリーズ（必ず10要素・欠損は null。0で埋めない）──────
            $avSeries = [];
            foreach ($avNumericKeys as $avK) $avSeries[$avK] = array_fill(0, $avLen, null);
            foreach (['same_condition', 'same_grade', 'same_jockey', 'same_baba',
                      'same_basho',
                      'course_id', 'grade_id', 'condition_id', 'jockey_id',
                      'basho_id'] as $avK) {
                $avSeries[$avK] = array_fill(0, $avLen, null);
            }

            $avPrevWeight = null;
            $avPrevBurden = null;
            $avPrevDate   = null;
            foreach ($avRows as $avI => $avR) {
                $avFp = isset($avR->finishing_position) ? (int)$avR->finishing_position : null;
                $avNh = isset($avR->num_horses)         ? (int)$avR->num_horses         : null;
                $avDs = isset($avR->dist)               ? (int)$avR->dist               : null;
                $avHw = isset($avR->horse_weight)       ? (int)$avR->horse_weight       : null;

                $avSeries['finishing_position'][$avI] = $avFp;
                $avSeries['popularity'][$avI]  = isset($avR->popularity) ? (int)$avR->popularity : null;
                $avSeries['num_horses'][$avI]  = $avNh;
                $avSeries['dist'][$avI]        = $avDs;
                $avSeries['dist_diff'][$avI]   = ($avDs !== null && $avTodayDist !== null)
                                                 ? $avDs - $avTodayDist : null;
                $avSeries['last_3f'][$avI]     = isset($avR->last_3f)       ? (float)$avR->last_3f       : null;
                $avSeries['fin_time_diff'][$avI]= isset($avR->fin_time_diff)? (float)$avR->fin_time_diff : null;
                $avSeries['burden_weight'][$avI]= isset($avR->burden_weight)? (float)$avR->burden_weight : null;
                // 斤量差（前走比）。前走が無ければ null（0にしない）
                $avBw = ($avSeries['burden_weight'][$avI] !== null)
                        ? $avSeries['burden_weight'][$avI] : null;
                $avSeries['burden_weight_diff'][$avI] = ($avBw !== null && $avPrevBurden !== null)
                                                        ? round($avBw - $avPrevBurden, 2) : null;
                $avPrevBurden = $avBw ?? $avPrevBurden;
                // 枠番
                $avSeries['gate'][$avI] = (isset($avR->gate) && $avR->gate !== '')
                                          ? (int)$avR->gate : null;
                // 走破時計（"1:34.5" / "94.5" を秒へ。解釈できなければ null。0にしない）
                $avSeries['time_sec'][$avI] = self::_parseRaceTimeToSeconds($avR->time ?? null);
                $avSeries['horse_weight'][$avI] = $avHw;
                // 馬体重の増減（前走比）。前走が無ければ null
                $avSeries['horse_weight_diff'][$avI] = ($avHw !== null && $avPrevWeight !== null)
                                                       ? $avHw - $avPrevWeight : null;
                $avPrevWeight = $avHw ?? $avPrevWeight;
                // 単勝オッズ（当時）
                $avSeries['odds'][$avI] = isset($avR->odds) ? (float)$avR->odds : null;
                // 休養日数（次走との間隔）
                if ($avPrevDate !== null && !empty($avR->date)) {
                    $avT1 = strtotime((string)$avPrevDate);
                    $avT2 = strtotime((string)$avR->date);
                    $avSeries['rest_days'][$avI - 1] = ($avT1 && $avT2)
                        ? (int)round(($avT1 - $avT2) / 86400) : null;
                }
                $avPrevDate = $avR->date ?? null;

                $avCorners = array_values(array_filter(
                    [$avR->corner_1 ?? null, $avR->corner_2 ?? null,
                     $avR->corner_3 ?? null, $avR->corner_4 ?? null],
                    fn($c) => $c !== null && $c !== ''
                ));
                $avSeries['corner_avg'][$avI] = !empty($avCorners)
                    ? round(array_sum(array_map('intval', $avCorners)) / count($avCorners), 2) : null;
                // 通過順位は平均だけでなく各コーナーも別カラムで保持する（仕様【固定長変換】2）
                foreach ([1, 2, 3, 4] as $avCn) {
                    $avCv = $avR->{'corner_' . $avCn} ?? null;
                    $avSeries['corner_' . $avCn][$avI] = ($avCv === null || $avCv === '')
                                                         ? null : (int)$avCv;
                }
                // 競馬場（カテゴリ）。今走と同競馬場かどうかも保持する
                $avSeries['basho_id'][$avI]   = $avCatId('basho', $avR->basho_code ?? null);
                $avSeries['same_basho'][$avI] = (isset($avR->basho_code) && $avR->basho_code !== '')
                    ? ((string)$avR->basho_code === (string)$basho ? 1 : 0) : null;

                $avSeries['finish_rate'][$avI] = ($avFp !== null && $avNh !== null && $avNh > 0)
                    ? round($avFp / $avNh, 4) : null;

                // 条件一致フラグ（比較対象が無ければ null。0にしない）
                $avSeries['same_condition'][$avI] = ($avTodayCond !== null && isset($avR->condition))
                    ? (($avR->condition === $avTodayCond) ? 1 : 0) : null;
                $avSeries['same_grade'][$avI] = ($avTodayGrade !== null && isset($avR->grade))
                    ? (($avR->grade === $avTodayGrade) ? 1 : 0) : null;
                $avSeries['same_jockey'][$avI] = (isset($avH->jockey) && isset($avR->jockey))
                    ? (($avR->jockey === $avH->jockey) ? 1 : 0) : null;
                $avSeries['same_baba'][$avI] = ($avTodayBaba !== null && isset($avR->condition))
                    ? (($avR->condition === $avTodayBaba) ? 1 : 0) : null;

                // カテゴリID（学習期間の辞書のみ。未知は UNKNOWN=0）
                $avSeries['course_id'][$avI]    = $avCatId('course',    $avR->condition ?? null);
                $avSeries['grade_id'][$avI]     = $avCatId('grade',     $avR->grade     ?? null);
                $avSeries['condition_id'][$avI] = $avCatId('condition', $avR->condition ?? null);
                $avSeries['jockey_id'][$avI]    = $avCatId('jockey',    $avR->jockey    ?? null);
            }

            // 上がり3F順位（同一馬の履歴内での相対順位。全走の比較で算出）
            $avL3 = [];
            foreach ($avSeries['last_3f'] as $avI2 => $avV) if ($avV !== null) $avL3[$avI2] = $avV;
            asort($avL3);
            $avRk = 1;
            foreach ($avL3 as $avI2 => $_v) { $avSeries['last_3f_rank'][$avI2] = $avRk++; }

            // ── 窓別集約（3走 / 5走 / 10走）──────────────────────────────
            // 仕様: 件数・平均・中央値・最小・最大
            $avAgg = [];
            foreach ([3, 5, 10] as $avW) {
                foreach ($avNumericKeys as $avK) {
                    $avSlice = array_slice($avSeries[$avK], 0, $avW);
                    $avVals  = array_values(array_filter($avSlice, fn($v) => $v !== null));
                    $avCnt   = count($avVals);
                    $avPfx   = "w{$avW}_{$avK}";
                    $avAgg["{$avPfx}_count"]  = $avCnt;
                    // 件数0のとき平均等は null（0にしない＝「成績0」と誤認させない）
                    $avAgg["{$avPfx}_mean"]   = $avCnt ? round(array_sum($avVals) / $avCnt, 4) : null;
                    $avAgg["{$avPfx}_median"] = $avCnt ? self::_medianOf($avVals) : null;
                    $avAgg["{$avPfx}_min"]    = $avCnt ? min($avVals) : null;
                    $avAgg["{$avPfx}_max"]    = $avCnt ? max($avVals) : null;
                    if ($avCnt) {
                        foreach ($avVals as $avV) $avAllForMedian[$avK][] = $avV;
                    }
                }
                // 着順ベースの率（窓ごと）
                $avFin = array_values(array_filter(array_slice($avSeries['finishing_position'], 0, $avW),
                                                   fn($v) => $v !== null));
                $avC = count($avFin);
                $avAgg["w{$avW}_win_count"]  = count(array_filter($avFin, fn($v) => $v === 1));
                $avAgg["w{$avW}_top3_count"] = count(array_filter($avFin, fn($v) => $v <= 3));
                $avAgg["w{$avW}_top3_rate"]  = $avC ? round(count(array_filter($avFin, fn($v) => $v <= 3)) / $avC, 4) : null;
                $avAgg["w{$avW}_top5_rate"]  = $avC ? round(count(array_filter($avFin, fn($v) => $v <= 5)) / $avC, 4) : null;
            }

            // ── 条件別成績（同コース・同距離帯±100m・同クラス・同騎手）──────
            $avCondAgg = [];
            // 仕様【固定長変換】4: 同競馬場・同距離・同芝ダート・同馬場状態・同クラスについて
            //   過去出走数／1着数／3着以内数／5着以内数／平均着順／中央値着順を作る。
            //   分母0は「率0」ではなく「不明」（null）とする。
            foreach ([
                'same_course' => fn($i) => $avSeries['same_condition'][$i] === 1,
                'same_dist'   => fn($i) => $avSeries['dist_diff'][$i] !== null && abs($avSeries['dist_diff'][$i]) <= 100,
                'same_grade'  => fn($i) => $avSeries['same_grade'][$i] === 1,
                'same_jockey' => fn($i) => $avSeries['same_jockey'][$i] === 1,
                'same_baba'   => fn($i) => $avSeries['same_baba'][$i] === 1,
                'same_basho'  => fn($i) => $avSeries['same_basho'][$i] === 1,
            ] as $avName => $avPred) {
                $avFinC = [];
                for ($avI3 = 0; $avI3 < $avLen; $avI3++) {
                    if ($avPred($avI3) && $avSeries['finishing_position'][$avI3] !== null) {
                        $avFinC[] = $avSeries['finishing_position'][$avI3];
                    }
                }
                $avN = count($avFinC);
                $avCondAgg["{$avName}_count"]     = $avN;
                $avCondAgg["{$avName}_mean"]      = $avN ? round(array_sum($avFinC) / $avN, 4) : null;
                $avCondAgg["{$avName}_median"]    = $avN ? self::_medianOf($avFinC) : null;
                $avCondAgg["{$avName}_best"]      = $avN ? min($avFinC) : null;
                $avCondAgg["{$avName}_win_count"]  = $avN ? count(array_filter($avFinC, fn($v) => $v === 1)) : 0;
                $avCondAgg["{$avName}_top3_count"] = $avN ? count(array_filter($avFinC, fn($v) => $v <= 3)) : 0;
                $avCondAgg["{$avName}_top5_count"] = $avN ? count(array_filter($avFinC, fn($v) => $v <= 5)) : 0;
                // 分母0は「率0」ではなく「不明」（null）
                $avCondAgg["{$avName}_win_rate"]  = $avN ? round(count(array_filter($avFinC, fn($v) => $v === 1)) / $avN, 4) : null;
                $avCondAgg["{$avName}_top3_rate"] = $avN ? round(count(array_filter($avFinC, fn($v) => $v <= 3)) / $avN, 4) : null;
                $avCondAgg["{$avName}_top5_rate"] = $avN ? round(count(array_filter($avFinC, fn($v) => $v <= 5)) / $avN, 4) : null;
            }

            // ── 不利フラグ（出遅れ／進路妨害／不利／外々）────────────────────
            // 【仕様・07.txt指示】取得元が確定するまでは NULL（欠損）で保持する。
            //   ・0（＝不利なし）として扱ってはならない
            //   ・自由記述から推測生成してはならない
            //   実DDL照合の結果、t_horse_odds_finder_shutsuba_history には
            //   不利に相当する列も自由記述列も存在しない（取得元が無い）。
            //   取得元が用意された時点で、ここへ実値を詰めるだけで学習に載る。
            $avTrouble = ['source' => null, 'available' => false];
            foreach (['late_start', 'interference', 'trouble', 'wide_course'] as $avTk) {
                $avTrouble[$avTk] = array_fill(0, $avLen, null); // 0で埋めない
            }

            $avOut[$avNum] = [
                'series'     => $avSeries,    // 固定長10のシリーズ
                'trouble'    => $avTrouble,   // 不利フラグ（取得元未確定のため全て null）
                'agg'        => $avAgg,       // 3/5/10走の窓集約
                'cond_agg'   => $avCondAgg,   // 条件別成績
                'waku'       => isset($avH->waku) ? (int)$avH->waku : null,
                'num'        => $avNum,
                'today_ids'  => [            // 今走のカテゴリID（辞書ベース）
                    'course_id'    => $avCatId('course',    $avTodayCond),
                    'grade_id'     => $avCatId('grade',     $avTodayGrade),
                    'condition_id' => $avCatId('condition', $avTodayBaba),
                    'jockey_id'    => $avCatId('jockey',    $avH->jockey ?? null),
                ],
            ];
        }

        // 履歴が取れなかった馬も固定長の枠で埋める（値は null。0にしない）
        foreach ($horseNums as $avN2) {
            if (isset($avOut[$avN2])) continue;
            $avEmpty = [];
            foreach ($avNumericKeys as $avK) $avEmpty[$avK] = array_fill(0, $avLen, null);
            foreach (['same_condition','same_grade','same_jockey','same_baba','same_basho',
                      'course_id','grade_id','condition_id','jockey_id','basho_id'] as $avK) {
                $avEmpty[$avK] = array_fill(0, $avLen, null);
            }
            $avAgg2 = [];
            foreach ([3,5,10] as $avW) {
                foreach ($avNumericKeys as $avK) {
                    $avAgg2["w{$avW}_{$avK}_count"]  = 0;
                    $avAgg2["w{$avW}_{$avK}_mean"]   = null;
                    $avAgg2["w{$avW}_{$avK}_median"] = null;
                    $avAgg2["w{$avW}_{$avK}_min"]    = null;
                    $avAgg2["w{$avW}_{$avK}_max"]    = null;
                }
                $avAgg2["w{$avW}_win_count"]=0; $avAgg2["w{$avW}_top3_count"]=0;
                $avAgg2["w{$avW}_top3_rate"]=null; $avAgg2["w{$avW}_top5_rate"]=null;
            }
            $avCond2 = [];
            foreach (['same_course','same_dist','same_grade','same_jockey',
                      'same_baba','same_basho'] as $avName) {
                $avCond2["{$avName}_count"]=0; $avCond2["{$avName}_mean"]=null;
                $avCond2["{$avName}_median"]=null; $avCond2["{$avName}_best"]=null;
                $avCond2["{$avName}_win_count"]=0; $avCond2["{$avName}_top3_count"]=0;
                $avCond2["{$avName}_top5_count"]=0;
                $avCond2["{$avName}_win_rate"]=null; $avCond2["{$avName}_top3_rate"]=null;
                $avCond2["{$avName}_top5_rate"]=null;
            }
            // 不利フラグ（取得元未確定。NULL固定。0にしない・推測しない）
            $avTrouble2 = ['source' => null, 'available' => false];
            foreach (['late_start', 'interference', 'trouble', 'wide_course'] as $avTk2) {
                $avTrouble2[$avTk2] = array_fill(0, $avLen, null);
            }
            $avOut[$avN2] = ['series'=>$avEmpty,'agg'=>$avAgg2,'cond_agg'=>$avCond2,
                             'trouble'=>$avTrouble2,
                             'waku'=>null,'num'=>$avN2,
                             'today_ids'=>['course_id'=>0,'grade_id'=>0,'condition_id'=>0,'jockey_id'=>0]];
        }
        ksort($avOut);

        // ── 補完用中央値（model_version へ保存して再現可能にする）──────────
        // 仕様: 数値欠損の補完に使う中央値は学習期間から求め、モデルと一緒に保存する。
        //   ここで返す値は「このレース時点で観測できた値」の中央値であり、
        //   学習時は train 区分のみから作り直して model_version へ格納する。
        $avImput = [];
        foreach ($avAllForMedian as $avK => $avVals) {
            $avImput[$avK] = self::_medianOf($avVals);
        }

        return [
            'vectors'    => $avOut,
            'imputation' => $avImput,
            'dict_used'  => [
                'is_loaded' => ($catDict !== null),
                'sizes'     => array_map('count', $avDict),
                'unknown_id'=> 0,
                'note'      => 'カテゴリ辞書は学習期間のみで作成し、未知の値は UNKNOWN(0) とする',
            ],
        ];
    }

    /** 中央値（空配列なら null）。偶数個は中央2値の平均。 */
    public static function _medianOf(array $values): ?float
    {
        $mdV = array_values(array_filter($values, fn($v) => $v !== null));
        $mdN = count($mdV);
        if ($mdN === 0) return null;
        sort($mdV);
        $mdH = intdiv($mdN, 2);
        return ($mdN % 2 === 1)
            ? round((float)$mdV[$mdH], 4)
            : round(((float)$mdV[$mdH - 1] + (float)$mdV[$mdH]) / 2.0, 4);
    }

    /**
     * カテゴリ辞書の作成（学習期間のみ）
     *
     * 仕様: 辞書は【学習期間だけ】で作る。検証・評価期間や今走のデータで
     *   辞書を増やしてはいけない（学習期間外の情報が混入するため）。
     *   辞書に無い値は UNKNOWN(0) として扱う。ID は 1 から振る。
     *
     * @param  string $trainFromDate 学習期間の開始日
     * @param  string $trainToDate   学習期間の終了日
     * @return array{course:array, grade:array, condition:array, jockey:array, meta:array}
     */
    public static function _buildCategoryDict(string $trainFromDate, string $trainToDate): array
    {
        $cdRows = DB::table('t_horse_odds_finder_shutsuba_history')
            ->where('date', '>=', $trainFromDate)
            ->where('date', '<=', $trainToDate)
            ->get(['condition', 'grade', 'jockey', 'basho_code']);

        $cdSets = ['course' => [], 'grade' => [], 'condition' => [], 'jockey' => [], 'basho' => []];
        foreach ($cdRows as $cdR) {
            if (!empty($cdR->condition)) {
                $cdSets['course'][(string)$cdR->condition]    = true;
                $cdSets['condition'][(string)$cdR->condition] = true;
            }
            if (!empty($cdR->grade))      $cdSets['grade'][(string)$cdR->grade]       = true;
            if (!empty($cdR->jockey))     $cdSets['jockey'][(string)$cdR->jockey]     = true;
            if (!empty($cdR->basho_code)) $cdSets['basho'][(string)$cdR->basho_code]  = true;
        }

        $cdDict = [];
        foreach ($cdSets as $cdKind => $cdVals) {
            $cdKeys = array_keys($cdVals);
            sort($cdKeys); // ID を決定論的にするため並べてから振る
            $cdMap = [];
            $cdId  = 1;    // 0 は UNKNOWN 予約
            foreach ($cdKeys as $cdV) $cdMap[$cdV] = $cdId++;
            $cdDict[$cdKind] = $cdMap;
        }
        $cdDict['meta'] = [
            'train_from' => $trainFromDate,
            'train_to'   => $trainToDate,
            'unknown_id' => 0,
            'sizes'      => array_map('count', array_diff_key($cdDict, ['meta' => 1])),
            'note'       => '学習期間のみで作成。未知の値は UNKNOWN(0)',
        ];
//         \Log::info('[Block11] カテゴリ辞書作成', $cdDict['meta']);
        return $cdDict;
    }

    /**
     * 帯基準馬方式（5点比較帯）による決定論的順位生成
     *
     * 仕様（よっしー最新確定版 / 20260913-11.txt）:
     *   統合おすすめ度が帯基準馬から5点以内の候補を同一比較帯にまとめ、
     *   帯内を次のタイブレーク順で並べ替える。
     *     ① 高配当総合点  ② 両AI一致馬  ③ 複勝継続流入A点  ④ 回収率裏付けD点
     *     ⑤ 予測補正OPI   ⑥ ability_score  ⑦ 馬番
     *
     * 帯の作り方:
     *   統合おすすめ度の降順に走査し、先頭馬を最初の「帯基準馬」とする。
     *   基準馬のスコアから5点以内の馬を同じ帯へ入れる。
     *   5点を超えて離れた馬が現れたら、その馬を次の帯の基準馬とする。
     *
     * 決定論性:
     *   最終タイブレークが馬番（全馬で一意）のため、同一入力からは常に同一順位が得られる。
     *   ソートは安定性に依存しない全順序比較で行う。
     *
     * 【重要】本メソッドはシャドー専用。戻り値は features_json への保存のみに使用し、
     *   本番候補・本番順位・Flutter表示には一切反映しない（よっしー指示により本番反映禁止）。
     *   呼び出し側でも $mergedHorses の並び順は変更しないこと。
     *
     * @param  array $horses          統合済み候補馬（_saveHighPayoutShadow 実行後）
     * @param  array $b13ScoreAMap    馬番 => 複勝継続流入A点
     * @param  array $b10ScoreDMap    馬番 => 回収率裏付けD点
     * @param  array $oddsHorseBlocks 馬番 => 馬別プロンプトブロック（予測補正OPI抽出用）
     * @return array{bands:array, ranking:array, band_width:float, tiebreak_order:array}
     */
    public static function _calcBandBasedRanking(
        array $horses,
        array $b13ScoreAMap,
        array $b10ScoreDMap,
        array $oddsHorseBlocks
    ): array {
        $bandWidth = 5.0; // 帯幅: 帯基準馬から5点以内

        if (empty($horses)) {
            return [
                'bands'          => [],
                'ranking'        => [],
                'band_width'     => $bandWidth,
                'tiebreak_order' => [],
            ];
        }

        // ── タイブレーク用の値を各馬へ集約 ────────────────────────────────
        $bmRows = [];
        foreach ($horses as $bmH) {
            $bmNum = (int)($bmH['num'] ?? 0);
            if ($bmNum <= 0) continue;

            // ⑤ 予測補正OPI: 馬別ブロックから抽出（「－」表記や欠損は null）
            $bmOpi   = null;
            $bmBlock = $oddsHorseBlocks[$bmNum] ?? '';
            if (preg_match('/予測補正OPI: ([\d.]+)/u', $bmBlock, $bmOm)) {
                $bmOpi = (float)$bmOm[1];
            }

            $bmRows[] = [
                'num'               => $bmNum,
                'name'              => $bmH['name'] ?? '',
                'score'             => (float)($bmH['score'] ?? 0),   // 統合おすすめ度（帯の判定軸）
                'category'          => $bmH['category'] ?? '',
                // ① 高配当総合点（_saveHighPayoutShadow が付与済み。null=不明）
                'high_payout_score' => isset($bmH['high_payout_score']) ? (float)$bmH['high_payout_score'] : null,
                // ② 両AI一致馬
                'is_matched'        => (($bmH['category'] ?? '') === 'matched') ? 1 : 0,
                // ③ 複勝継続流入A点
                'score_a'           => isset($b13ScoreAMap[$bmNum]) ? (int)$b13ScoreAMap[$bmNum] : null,
                // ④ 回収率裏付けD点
                'score_d'           => isset($b10ScoreDMap[$bmNum]) ? (int)$b10ScoreDMap[$bmNum] : null,
                // ⑤ 予測補正OPI（小さいほど market が過小評価＝妙味あり → 昇順が上位）
                'predicted_opi'     => $bmOpi,
                // ⑥ ability_score（_saveHighPayoutShadow が付与済み）
                'ability_score'     => isset($bmH['ability_corr_merged']) ? (float)$bmH['ability_corr_merged'] : null,
            ];
        }
        if (empty($bmRows)) {
            return [
                'bands'          => [],
                'ranking'        => [],
                'band_width'     => $bandWidth,
                'tiebreak_order' => [],
            ];
        }

        // ── 帯分け: 統合おすすめ度 降順（同点は馬番昇順）で走査 ──────────────
        usort($bmRows, function ($x, $y) {
            if ($x['score'] !== $y['score']) return $y['score'] <=> $x['score'];
            return $x['num'] <=> $y['num'];
        });

        $bmBands       = [];
        $bmCurBand     = [];
        $bmBaseScore   = null;  // 現在の帯基準馬の統合おすすめ度
        $bmBaseNum     = null;  // 現在の帯基準馬の馬番
        foreach ($bmRows as $bmRow) {
            if ($bmBaseScore === null || ($bmBaseScore - $bmRow['score']) > $bandWidth) {
                // 新しい帯を開始（この馬が次の帯基準馬）
                if (!empty($bmCurBand)) {
                    $bmBands[] = ['base_num' => $bmBaseNum, 'base_score' => $bmBaseScore, 'members' => $bmCurBand];
                }
                $bmCurBand   = [];
                $bmBaseScore = $bmRow['score'];
                $bmBaseNum   = $bmRow['num'];
            }
            $bmCurBand[] = $bmRow;
        }
        if (!empty($bmCurBand)) {
            $bmBands[] = ['base_num' => $bmBaseNum, 'base_score' => $bmBaseScore, 'members' => $bmCurBand];
        }

        // ── 帯内タイブレーク（7段階・全順序） ────────────────────────────
        // null は「不明」として常に後ろへ回す（決定論性を保つため null 同士は次段へ）
        $bmCmpDesc = function ($a, $b) {          // 大きいほど上位
            if ($a === null && $b === null) return 0;
            if ($a === null) return  1;
            if ($b === null) return -1;
            return $b <=> $a;
        };
        $bmCmpAsc = function ($a, $b) {           // 小さいほど上位
            if ($a === null && $b === null) return 0;
            if ($a === null) return  1;
            if ($b === null) return -1;
            return $a <=> $b;
        };
        $bmTiebreak = function ($x, $y) use ($bmCmpDesc, $bmCmpAsc) {
            // ① 高配当総合点（降順）
            if (($r = $bmCmpDesc($x['high_payout_score'], $y['high_payout_score'])) !== 0) return $r;
            // ② 両AI一致馬（一致馬を上位）
            if ($x['is_matched'] !== $y['is_matched']) return $y['is_matched'] <=> $x['is_matched'];
            // ③ 複勝継続流入A点（降順）
            if (($r = $bmCmpDesc($x['score_a'], $y['score_a'])) !== 0) return $r;
            // ④ 回収率裏付けD点（降順）
            if (($r = $bmCmpDesc($x['score_d'], $y['score_d'])) !== 0) return $r;
            // ⑤ 予測補正OPI（昇順: 小さいほど市場の過小評価＝妙味あり）
            if (($r = $bmCmpAsc($x['predicted_opi'], $y['predicted_opi'])) !== 0) return $r;
            // ⑥ ability_score（降順）
            if (($r = $bmCmpDesc($x['ability_score'], $y['ability_score'])) !== 0) return $r;
            // ⑦ 馬番（昇順・全馬一意のため必ずここで確定＝決定論的）
            return $x['num'] <=> $y['num'];
        };

        $bmRanking  = [];
        $bmRank     = 1;
        $bmBandsOut = [];
        foreach ($bmBands as $bmBandIdx => $bmBand) {
            $bmMembers = $bmBand['members'];
            usort($bmMembers, $bmTiebreak);
            $bmMemberNums = [];
            foreach ($bmMembers as $bmM) {
                $bmMemberNums[]  = $bmM['num'];
                $bmRanking[]     = [
                    'rank'              => $bmRank++,
                    'band_id'           => $bmBandIdx + 1,
                    'num'               => $bmM['num'],
                    'name'              => $bmM['name'],
                    'score'             => $bmM['score'],
                    'category'          => $bmM['category'],
                    'high_payout_score' => $bmM['high_payout_score'],
                    'score_a'           => $bmM['score_a'],
                    'score_d'           => $bmM['score_d'],
                    'predicted_opi'     => $bmM['predicted_opi'],
                    'ability_score'     => $bmM['ability_score'],
                ];
            }
            $bmBandsOut[] = [
                'band_id'      => $bmBandIdx + 1,
                'base_num'     => $bmBand['base_num'],
                'base_score'   => $bmBand['base_score'],
                'score_range'  => [$bmBand['base_score'] - $bandWidth, $bmBand['base_score']],
                'member_count' => count($bmMembers),
                'member_nums'  => $bmMemberNums,
            ];
        }

//         \Log::info('[BandMethod] 帯基準馬方式 順位生成（シャドー専用・本番未反映）', [
//             'band_count'  => count($bmBandsOut),
//             'horse_count' => count($bmRanking),
//             'bands'       => array_map(
//                 fn($b) => "帯{$b['band_id']}: 基準馬番{$b['base_num']}({$b['base_score']}点) "
//                         . count($b['member_nums']) . '頭',
//                 $bmBandsOut
//             ),
//         ]);

        return [
            'bands'          => $bmBandsOut,
            'ranking'        => $bmRanking,
            'band_width'     => $bandWidth,
            'tiebreak_order' => [
                '1_high_payout_score', '2_matched_ai', '3_score_a_fuku_inflow',
                '4_score_d_recovery',  '5_predicted_opi', '6_ability_score', '7_num',
            ],
        ];
    }

    /**
     * Block 11: 断層パターン学習 特徴量スナップショット保存
     * フェーズ1: 1,000レース分の特徴量を蓄積するだけ（予測は行わない）
     * result_label はレース結果確定後のバッチ処理で別途書き込む
     */
    public static function _saveMlSnapshot(
        array  $mergedHorses,
        string $gapTypeForMerge,
        ?int   $primaryGapUpperPopForMerge,
        int    $mergeUpperMax,
        int    $mergeMidMax,
        int    $mergeLowerMax,
        int    $horseCount2nd,
        ?int   $upsetRaceFinal,   // 【20260928】null = 厳選穴レース「不明」（受入チェック#84）
        ?int   $b14WaveLevel,
        ?int   $b14LowerEntry,
        ?int   $b14BigGap,
        bool   $condAMet,
        ?bool  $condBMet,   // 【20260928】null = 不明（受入チェック#84）
        ?bool  $condCMet,   // 同上
        ?bool  $condDMet,   // 同上
        int    $b10ScoreE,
        array  $firstAiHorses,
        array  $secondAiHorses,
        string $oddsData,            // input_hash 計算用・全頭テキスト抽出用
        array  $oddsHorseBlocks,     // 馬別プロンプトブロック（各種特徴量抽出用）
        array  $b6TanPopMap,         // 馬番→単勝人気マップ（6分前基準）
        array  $b6FukuPopMap,        // 馬番→複勝人気マップ（6分前基準）
        $b6OddsRows,                 // 6分前オッズ行（Illuminate\Support\Collection）
                                     // ※型宣言なし: DB::table()->get() は Collection を返すため
                                     //   array 型宣言を付けると実行時 TypeError になる
        array  $b13ScoreAMap,        // 馬番→複勝継続流入A点（帯基準馬方式タイブレーク③）
        array  $b10ScoreDMap,        // 馬番→回収率裏付けD点（帯基準馬方式タイブレーク④）
        string $date,
        int    $kaisuu,
        string $basho,
        int    $day,
        int    $race,
        object $raceRow,
        array  $b10ScoreEMap = []    // 【20260924】馬番→基礎点E（null=不明）
    ): void {
        // @ANCHOR-20261004-DRY-RUN  試算モードでは保存しない
        if (AiController::$dryRunNoPersist) return;
        // ── Block 11: 断層パターン学習 特徴量スナップショット保存 ───────────────────
        // フェーズ1: 1,000レース分の特徴量を蓄積するだけ（予測は行わない）
        // result_label はレース結果確定後のバッチ処理で別途書き込む
        try {
            // ── features_json の構築 ──────────────────────────────────────────
            // 断層構造・レース指標・統合馬リストのサマリーを特徴量として記録
            $b11MergedPops    = array_values(array_map(fn($h) => (int)($h['popularity'] ?? 0), $mergedHorses));
            $b11MergedScores  = array_values(array_map(fn($h) => (int)($h['score']      ?? 0), $mergedHorses));
            $b11MergedNums    = array_values(array_map(fn($h) => (int)($h['num']        ?? 0), $mergedHorses)); // B-14: M4馬別正解ラベル算出用

            // カテゴリ別集計（matched / first_unique / second_unique）
            $b11CntMatched  = 0;
            $b11CntFirst    = 0;
            $b11CntSecond   = 0;
            foreach ($mergedHorses as $b11h) {
                switch ($b11h['category'] ?? '') {
                    case 'matched':       $b11CntMatched++; break;
                    case 'first_only':    $b11CntFirst++;   break;
                    case 'second_only':   $b11CntSecond++;  break;
                }
            }

            // ── input_hash: 推論の完全再現用ハッシュ（複数データソースを含む）──────
            // $oddsData（プロンプト本文）+ $b6TanPopMap（6分前人気マップ）
            // + $b6OddsRows行数ハッシュ（全時点オッズ変化検知）の連結
            //
            // 【能力・適性元データの包含証明（よっしー03.txt指摘#6）】
            //   $oddsData には getHorseOddsFinderAiAnalysis() 内で
            //     $oddsData .= $b9HistoryText;   （Block 9・本ファイル内）
            //   により「【各馬の直近成績（過去最大10走）と今走データ】」ブロックが結合される。
            //   $b9HistoryText は t_horse_odds_finder_shutsuba_history から取得した
            //   全出走馬の直近最大10走（着順・距離・コース・グレード・騎手・斤量・馬体重・
            //   コーナー通過順）と今走条件（dist/course/grade）を含む能力・適性の元データ。
            //   したがって能力・適性元データが1バイトでも変われば $oddsData が変わり、
            //   input_hash も必ず変化する（＝ハッシュ対象に含まれている）。
            $b11TanPopSerial = '';
            ksort($b6TanPopMap);
            foreach ($b6TanPopMap as $_b11num => $_b11pop) {
                $b11TanPopSerial .= "{$_b11num}:{$_b11pop}|";
            }
            $b11OddsRowsSerial = count($b6OddsRows) . ':' . md5(json_encode($b6OddsRows, JSON_UNESCAPED_UNICODE));
            $b11InputHash = hash('sha256',
                $oddsData . '||' . $b11TanPopSerial . '||' . $b11OddsRowsSerial
            );

            // ══════════════════════════════════════════════════════════════════
            // 全時点特徴量（よっしー03.txt指摘#4 対応）
            // S(999)・21・18・15・12・9・6分の全時点オッズ推移から
            // 断層比率・断層遷移（出現/継続/消滅/拡大/縮小）・人気入替回数を算出
            // ══════════════════════════════════════════════════════════════════
            $b11Timings = [Constants::ODDS_DB_FIRST, 21, 18, 15, 12, 9, 6]; // = [999,21,18,15,12,9,6]

            $b11AllOddsRows = DB::table('t_horse_odds_finder_odds')
                ->where('date',   $date)
                ->where('kaisuu', $kaisuu)
                ->where('basho',  $basho)
                ->where('day',    $day)
                ->where('race',   $race)
                ->whereIn('minutes_before_start', $b11Timings)
                ->get(['num', 'minutes_before_start', 'odds', 'fuku_min', 'fuku_max']);

            // 馬番 → 時点 → {tan, fuku_min, fuku_max}
            $b11Series = [];
            foreach ($b11AllOddsRows as $_b11r) {
                $_b11n = (int)$_b11r->num;
                $_b11t = (int)$_b11r->minutes_before_start;
                $b11Series[$_b11n][$_b11t] = [
                    'tan'      => (float)$_b11r->odds,
                    'fuku_min' => (float)$_b11r->fuku_min,
                    'fuku_max' => (float)$_b11r->fuku_max,
                ];
            }

            // ── 各時点の単勝人気順・複勝人気順を算出 ──────────────────────────
            $b11TanPopByTiming  = []; // [timing][num] = 単勝人気順
            $b11FukuPopByTiming = []; // [timing][num] = 複勝人気順
            foreach ($b11Timings as $_b11t) {
                $_b11tanPairs  = [];
                $_b11fukuPairs = [];
                foreach ($b11Series as $_b11n => $_b11byT) {
                    if (isset($_b11byT[$_b11t])) {
                        if ($_b11byT[$_b11t]['tan'] > 0) {
                            $_b11tanPairs[$_b11n] = $_b11byT[$_b11t]['tan'];
                        }
                        if ($_b11byT[$_b11t]['fuku_min'] > 0) {
                            $_b11fukuPairs[$_b11n] = $_b11byT[$_b11t]['fuku_min'];
                        }
                    }
                }
                asort($_b11tanPairs);
                asort($_b11fukuPairs);
                $_b11rank = 1;
                foreach ($_b11tanPairs as $_b11n => $_b11o) {
                    $b11TanPopByTiming[$_b11t][$_b11n] = $_b11rank++;
                }
                $_b11rank = 1;
                foreach ($_b11fukuPairs as $_b11n => $_b11o) {
                    $b11FukuPopByTiming[$_b11t][$_b11n] = $_b11rank++;
                }
            }

            // ── 人気入替回数: 隣接時点間で単勝人気順が変化した回数（馬別）──────
            $b11PopSwapCount = [];
            foreach ($b11Series as $_b11n => $_b11byT) {
                $_b11cnt  = 0;
                $_b11prev = null;
                foreach ($b11Timings as $_b11t) {
                    $_b11p = $b11TanPopByTiming[$_b11t][$_b11n] ?? null;
                    if ($_b11p !== null) {
                        if ($_b11prev !== null && $_b11p !== $_b11prev) $_b11cnt++;
                        $_b11prev = $_b11p;
                    }
                }
                $b11PopSwapCount[$_b11n] = $_b11cnt;
            }

            // ── 各時点の隣接人気間 断層比率（単勝・複勝）────────────────────
            // 断層比率 = 直下人気馬のオッズ ÷ 直上人気馬のオッズ（既存ロジックと同一）
            // is_gap: 比率 >= 2.0 で断層成立
            $b11BuildGapRows = function (array $popMap, int $timing, string $oddsKey) use ($b11Series): array {
                if (empty($popMap)) return [];
                asort($popMap); // 人気順に整列
                $_nums = array_keys($popMap);
                $_rows = [];
                for ($_i = 0; $_i < count($_nums) - 1; $_i++) {
                    $_uN = $_nums[$_i];
                    $_lN = $_nums[$_i + 1];
                    $_uO = $b11Series[$_uN][$timing][$oddsKey] ?? 0;
                    $_lO = $b11Series[$_lN][$timing][$oddsKey] ?? 0;
                    if ($_uO <= 0 || $_lO <= 0) continue; // 【20260924】片方が欠損なら比率を作らない（0比率を作らない）
                    $_ratio = round($_lO / $_uO, 2);
                    $_rows[] = [
                        'upper_pop' => $_i + 1,
                        'lower_pop' => $_i + 2,
                        'upper_num' => $_uN,
                        'lower_num' => $_lN,
                        'ratio'     => $_ratio,
                        'is_gap'    => ($_ratio >= 2.0) ? 1 : 0,
                    ];
                }
                return $_rows;
            };

            $b11TanGapByTiming  = [];
            $b11FukuGapByTiming = [];
            foreach ($b11Timings as $_b11t) {
                $b11TanGapByTiming[$_b11t]  = $b11BuildGapRows(
                    $b11TanPopByTiming[$_b11t] ?? [], $_b11t, 'tan'
                );
                $b11FukuGapByTiming[$_b11t] = $b11BuildGapRows(
                    $b11FukuPopByTiming[$_b11t] ?? [], $_b11t, 'fuku_min'
                );
            }

            // ── 【20260924 追加】6分前人気順を基準軸に固定した断層比率の時系列 ──────────
            //   仕様【人気順位固定と追跡】「断層時系列は6分前人気順を基準軸とし、各馬を馬番で過去時点へ追跡する。
            //   過去時点ごとに人気順の馬を入れ替えて別馬同士の断層推移を作ってはいけない」
            //   上の gap_ratios_by_timing は各時点の人気順で並べ直した比較（参考として残す）。
            //   学習にはこちらの固定軸版を使う。
            $b11TanGapFixed6  = [];
            $b11FukuGapFixed6 = [];
            foreach ($b11Timings as $_b11t) {
                $b11TanGapFixed6[$_b11t]  = $b11BuildGapRows($b11TanPopByTiming[6]  ?? [], $_b11t, 'tan');
                $b11FukuGapFixed6[$_b11t] = $b11BuildGapRows($b11FukuPopByTiming[6] ?? [], $_b11t, 'fuku_min');
            }

            // ── 断層の 出現／継続／消滅／拡大／縮小（隣接時点比較・単勝基準）──
            $b11GapTransitions = [];
            $b11PrevGapSet     = null;
            foreach ($b11Timings as $_b11t) {
                $_b11cur = [];
                // 【20260924】仕様【人気順位固定と追跡】に合わせ、6分前人気順の固定軸で出現・消滅・拡大・縮小を判定する
                foreach (($b11TanGapFixed6[$_b11t] ?? []) as $_b11g) {
                    if ($_b11g['is_gap']) $_b11cur[$_b11g['upper_pop']] = $_b11g['ratio'];
                }
                if ($b11PrevGapSet !== null) {
                    $_b11curPos  = array_keys($_b11cur);
                    $_b11prevPos = array_keys($b11PrevGapSet);
                    $_b11cont    = array_values(array_intersect($_b11curPos, $_b11prevPos));
                    $_b11exp     = [];
                    $_b11shr     = [];
                    foreach ($_b11cont as $_b11pos) {
                        if ($_b11cur[$_b11pos] > $b11PrevGapSet[$_b11pos])      $_b11exp[] = $_b11pos;
                        elseif ($_b11cur[$_b11pos] < $b11PrevGapSet[$_b11pos])  $_b11shr[] = $_b11pos;
                    }
                    $b11GapTransitions[$_b11t] = [
                        'appeared'  => array_values(array_diff($_b11curPos,  $_b11prevPos)),
                        'continued' => $_b11cont,
                        'vanished'  => array_values(array_diff($_b11prevPos, $_b11curPos)),
                        'expanded'  => $_b11exp,
                        'shrunk'    => $_b11shr,
                    ];
                }
                $b11PrevGapSet = $_b11cur;
            }

            // ── 最大・最小・主断層比率（6分前基準）────────────────────────
            $b11Gap6       = $b11TanGapByTiming[6] ?? [];
            $b11RatioList  = array_map(fn($g) => $g['ratio'], $b11Gap6);
            $b11MaxRatio   = !empty($b11RatioList) ? max($b11RatioList) : null;
            $b11MinRatio   = !empty($b11RatioList) ? min($b11RatioList) : null;
            $b11GapCount6  = count(array_filter($b11Gap6, fn($g) => $g['is_gap'] === 1));
            $b11PrimaryRatio = null;
            if ($primaryGapUpperPopForMerge !== null) {
                foreach ($b11Gap6 as $_b11g) {
                    if ((int)$_b11g['upper_pop'] === (int)$primaryGapUpperPopForMerge) {
                        $b11PrimaryRatio = $_b11g['ratio'];
                        break;
                    }
                }
            }

            // ── 【20260924 追加】仕様【予測入力特徴量】のレース特徴のうち未保存だったもの ──
            //   6番人気以内／以降の断層本数、人気別オッズ分布、上位集中度
            $b11GapCountTop6  = count(array_filter($b11Gap6, fn($g) => $g['is_gap'] === 1 && (int)$g['upper_pop'] <= 6));
            $b11GapCountBelow = count(array_filter($b11Gap6, fn($g) => $g['is_gap'] === 1 && (int)$g['upper_pop'] >= 7));
            $b11TanDist6  = [];   // 6分前 単勝人気順 → 単勝オッズ
            $b11FukuDist6 = [];   // 6分前 複勝人気順 → 複勝最小オッズ
            foreach (($b11TanPopByTiming[6] ?? []) as $_b11n => $_b11p) {
                $b11TanDist6[$_b11p] = $b11Series[$_b11n][6]['tan'] ?? null;
            }
            foreach (($b11FukuPopByTiming[6] ?? []) as $_b11n => $_b11p) {
                $b11FukuDist6[$_b11p] = $b11Series[$_b11n][6]['fuku_min'] ?? null;
            }
            ksort($b11TanDist6);
            ksort($b11FukuDist6);
            // 上位集中度: 単勝の支持率（1/オッズ）の合計に占める1〜3番人気の割合
            $b11InvAll = 0.0; $b11InvTop3 = 0.0;
            foreach ($b11TanDist6 as $_b11p => $_b11o) {
                if ($_b11o === null || $_b11o <= 0) continue;
                $b11InvAll += 1 / $_b11o;
                if ($_b11p <= 3) $b11InvTop3 += 1 / $_b11o;
            }
            $b11TopConcentration = $b11InvAll > 0 ? round($b11InvTop3 / $b11InvAll, 4) : null;

            // ── 単複断層の一致・不一致（6分前・断層成立位置の比較）──────────
            $b11TanGapPos6  = array_values(array_map(
                fn($g) => $g['upper_pop'],
                array_filter($b11Gap6, fn($g) => $g['is_gap'] === 1)
            ));
            $b11FukuGap6    = $b11FukuGapByTiming[6] ?? [];
            $b11FukuGapPos6 = array_values(array_map(
                fn($g) => $g['upper_pop'],
                array_filter($b11FukuGap6, fn($g) => $g['is_gap'] === 1)
            ));
            $b11GapMatch = [
                'tan_gap_positions'  => $b11TanGapPos6,
                'fuku_gap_positions' => $b11FukuGapPos6,
                'matched_positions'  => array_values(array_intersect($b11TanGapPos6, $b11FukuGapPos6)),
                'tan_only_positions' => array_values(array_diff($b11TanGapPos6, $b11FukuGapPos6)),
                'fuku_only_positions'=> array_values(array_diff($b11FukuGapPos6, $b11TanGapPos6)),
                'is_consistent'      => (
                    count(array_diff($b11TanGapPos6, $b11FukuGapPos6)) === 0
                    && count(array_diff($b11FukuGapPos6, $b11TanGapPos6)) === 0
                ) ? 1 : 0,
            ];

            // ── 当時の類似レース統計を保存（受入チェック #48）────────────────
            // 類似統計はプロンプトには出していたが保存していなかった。
            // 後から当時の統計を復元できないため、Phase1の今から保存する。
            // 取得方法: プロンプトへ埋め込んだ「類似レース統計（N番人気 × 帯）」行を
            //   正規表現で回収する。テーブルを引き直すと帯の判定条件がずれる可能性があり、
            //   また将来テーブルが更新されると当時の値と変わってしまう。
            //   プロンプトから回収すれば、当時AIへ渡した値そのものが保存され再現性が最も高い。
            $b11SimilarStats = [];
            foreach ($b6TanPopMap as $_b11sn => $_b11sp) {
                $_b11sb = $oddsHorseBlocks[$_b11sn] ?? '';
                if (preg_match(
                    '/類似レース統計[（(](\d+)番人気 × ([^・)）]+)・N=(\d+)・信頼度:([^)）]+)[）)]: '
                    . '3着以内率([\d.]+)% \/ 5着以内率([\d.]+)% \/ 平均着順([\d.]+)位 \/ 着外率([\d.]+)%/u',
                    $_b11sb, $_b11sm
                )) {
                    $b11SimilarStats[$_b11sn] = [
                        'popularity'    => (int)$_b11sm[1],
                        'band'          => trim($_b11sm[2]),
                        'sample_count'  => (int)$_b11sm[3],
                        'reliability'   => trim($_b11sm[4]),
                        'top3_rate'     => (float)$_b11sm[5],
                        'top5_rate'     => (float)$_b11sm[6],
                        'avg_finish'    => (float)$_b11sm[7],
                        'outside_rate'  => (float)$_b11sm[8],
                    ];
                } else {
                    $b11SimilarStats[$_b11sn] = ['status' => 'insufficient'];
                }
            }

            // ── 枠番マップ取得（よっしー03.txt指摘#4: 枠番）──────────────────
            $b11WakuMap = [];
            foreach (DB::table('t_horse_odds_finder_horses')
                ->where('date',   $date)
                ->where('kaisuu', $kaisuu)
                ->where('basho',  $basho)
                ->where('day',    $day)
                ->where('race',   $race)
                ->get(['num', 'waku']) as $_b11w) {
                $b11WakuMap[(int)$_b11w->num] = isset($_b11w->waku) ? (int)$_b11w->waku : null;
            }

            // ── 能力・適性データの固定長ベクトル化（受入チェック #63）──────────
            // 当時のデータを後から再現できないため Phase1 の今から保存する。
            // 取得は「今走日より前」に限定し未来情報混入を防止している。
            // カテゴリ辞書は学習期間のみで作成する（Phase1は学習未実施のため null）
            $b11CatDict = null;
            $b11AbilityRes = self::_buildAbilityVectors(
                array_map('intval', array_keys($b6TanPopMap)),
                $date, $kaisuu, $basho, $day, $race, $raceRow, $b11CatDict
            );
            $b11AbilityVectors = $b11AbilityRes['vectors'];
            $b11Imputation     = $b11AbilityRes['imputation'];  // 中央値補完値
            $b11DictUsed       = $b11AbilityRes['dict_used'];

            // ── M4: 「2AI候補内」と「全頭発見」の分離保存 ──────────────────
            // 仕様: M4は2つの母集団で別々に正解ラベルを作るため、保存時点で分離しておく。
            $b11AllNums      = array_map('intval', array_keys($b6TanPopMap));
            sort($b11AllNums);
            $b11CandidateNums = array_values(array_unique(array_map(
                fn($h) => (int)($h['num'] ?? 0), $mergedHorses
            )));
            sort($b11CandidateNums);
            $b11M4Separated = [
                // ①2AI候補内: 統合候補に入った馬のみを母集団とする
                'in_ai_candidates' => [
                    'nums'  => $b11CandidateNums,
                    'count' => count($b11CandidateNums),
                ],
                // ②全頭発見: 出走全頭を母集団とする
                'all_horses'       => [
                    'nums'  => $b11AllNums,
                    'count' => count($b11AllNums),
                ],
                // 候補に入らなかった馬（全頭発見でのみ評価対象になる馬）
                'not_in_candidates' => array_values(array_diff($b11AllNums, $b11CandidateNums)),
                'note' => 'result_label はレース結果確定後のバッチ処理で母集団ごとに別々に書き込む',
            ];

            // ── all_horses_features: 全馬の固定長特徴量ベクトル ────────────────────
            // 各馬について: 馬番・6分前人気・6分前単勝オッズ・推定確定複勝最小・
            //              推定確定単勝・過去回収率（3種）・断層上下位置
            $b11AllHorsesFeatures = [];
            foreach ($b6TanPopMap as $_b11num => $_b11pop) {
                $_b11block     = $oddsHorseBlocks[$_b11num] ?? '';
                $_b11tanOdds   = null;
                $_b11fukuMin   = null;
                $_b11rateArr   = [];
                $_b11gapPos    = null;
                if (preg_match('/推定確定オッズ: ([\d.]+)/u', $_b11block, $_b11tm)) {
                    $_b11tanOdds = (float)$_b11tm[1];
                }
                if (preg_match('/推定確定複勝最小: ([\d.]+)/u', $_b11block, $_b11fm)) {
                    $_b11fukuMin = (float)$_b11fm[1];
                }
                foreach ([
                    '過去回収率',
                    'OPI帯別回収率',
                    'フェーズパターン別回収率',
                ] as $_b11rLabel) {
                    if (preg_match(
                        '/' . preg_quote($_b11rLabel, '/') . '[（(][^）)]+[）)]: 回収率([\d.]+)%\s+勝率[\d.]+%\s+サンプル(\d+)件/u',
                        $_b11block, $_b11rm
                    )) {
                        $_b11rateArr[$_b11rLabel] = [
                            'rate'    => (float)$_b11rm[1],
                            'samples' => (int)$_b11rm[2],
                        ];
                    }
                }
                // 断層上下位置: primaryGapUpperPopForMerge が有効な場合のみ判定
                if ($primaryGapUpperPopForMerge !== null) {
                    $_b11gapPos = ((int)$_b11pop <= $primaryGapUpperPopForMerge) ? 'upper' : 'lower';
                }
                // 全時点オッズ推移・人気順推移（S(999)・21・18・15・12・9・6分）
                $_b11tanSeries  = [];
                $_b11fukuSeries = [];
                $_b11popSeries  = [];
                foreach ($b11Timings as $_b11t) {
                    $_b11tanSeries[(string)$_b11t]  = $b11Series[$_b11num][$_b11t]['tan']      ?? null;
                    $_b11fukuSeries[(string)$_b11t] = $b11Series[$_b11num][$_b11t]['fuku_min'] ?? null;
                    $_b11popSeries[(string)$_b11t]  = $b11TanPopByTiming[$_b11t][$_b11num]     ?? null;
                }
                // 【20260924 追加】仕様【予測入力特徴量】の馬別特徴のうち未保存だったもの
                //   （流入ランク・直前流入・OPI3種・推定確定オッズと誤差・主断層からの距離・基礎点E）
                //   欠損は null のまま保持し、別に missing_flags へ列挙する（0へ置換しない）
                $_b11bf = self::_parseHorseBlockFeatures($_b11block);
                $_b11bf['score_e_horse'] = $b10ScoreEMap[$_b11num] ?? null;
                $_b11bf['gap_distance']  = ($primaryGapUpperPopForMerge !== null)
                    ? (int)$_b11pop - (int)$primaryGapUpperPopForMerge  // 正=断層下側で何順位下か、0以下=上側
                    : null;
                $_b11bf['tanpuku_pop_diff'] = isset($b6FukuPopMap[$_b11num])
                    ? (int)$_b11pop - (int)$b6FukuPopMap[$_b11num]      // 正=複勝人気の方が高い
                    : null;
                $_b11bf['missing_flags'] = array_values(array_keys(array_filter(
                    $_b11bf, fn($v) => $v === null
                )));
                $b11AllHorsesFeatures[] = [
                    'block_features' => $_b11bf,
                    'num'            => $_b11num,
                    'waku'           => $b11WakuMap[$_b11num] ?? null,    // 枠番
                    'pop_6m'         => (int)$_b11pop,
                    'fuku_pop_6m'    => $b6FukuPopMap[$_b11num] ?? null,  // 複勝人気
                    'tan_odds_6m'    => $_b11tanOdds,
                    'fuku_min_est'   => $_b11fukuMin,
                    'rates'          => $_b11rateArr,
                    'gap_position'   => $_b11gapPos,
                    'tan_series'     => $_b11tanSeries,   // 全時点単勝オッズ
                    'fuku_series'    => $_b11fukuSeries,  // 全時点複勝最小オッズ
                    'pop_series'     => $_b11popSeries,   // 全時点単勝人気順
                    'pop_swap_count' => $b11PopSwapCount[$_b11num] ?? 0, // 人気入替回数
                    // #48: 当時の類似レース統計（AIへ渡した値そのもの）
                    'similar_stats'  => $b11SimilarStats[$_b11num] ?? null,
                    // #63: 能力・適性の固定長ベクトル（最大10走・不足はnull埋め）
                    'ability_vector' => $b11AbilityVectors[$_b11num] ?? null,
                    // M4: この馬が2AI統合候補に入っているか（母集団の分離用）
                    'in_ai_candidate'=> in_array($_b11num, $b11CandidateNums, true) ? 1 : 0,
                ];
            }

            // ── 時系列分割 70/15/15（#49）とモデルレジストリ（#57）────────────
            // 分割は日付順で決定論的に行う（ランダム分割は未来情報混入のため禁止）
            try {
                $b11Split = self::_assignTimeSeriesSplit($date)['summary'];
            } catch (\Throwable $b11se) {
                $b11Split = ['error' => $b11se->getMessage()];
            }
            $b11ModelRegistry = self::_buildModelRegistry($b11InputHash);

            // ── 学習フェーズ判定（#55・#56）────────────────────────────
            try { $b11Phase = self::_getMlPhase(); }
            catch (\Throwable $b11pe) { $b11Phase = ['error' => $b11pe->getMessage()]; }

            // ── M1〜M4 推論エンジン実行（シャドー専用・Phase1ではskipped）──
            // 学習済みモデルは model_registry から渡す。Phase1は未生成のため空。
            // 結果は保存するだけで、本番候補・順位・Flutter表示には反映しない。
            $b11MlModels = $b11ModelRegistry['active']['models'] ?? [];
            try {
                $b11Inference = self::_runMlInference(
                    ['gap_type' => $gapTypeForMerge,
                     'primary_gap_upper_pop' => $primaryGapUpperPopForMerge,
                     'horse_count' => (int)$horseCount2nd,
                     'all_horses_features' => $b11AllHorsesFeatures],
                    $b11MlModels
                );
            } catch (\Throwable $b11ie) { $b11Inference = ['error' => $b11ie->getMessage()]; }

            // ── 帯基準馬方式（5点比較帯）による決定論的順位を算出（シャドー専用）──
            // 本番順位（$mergedHorses の並び）は変更しない。結果は features_json へ保存するのみ。
            $b11BandRanking = self::_calcBandBasedRanking(
                $mergedHorses, $b13ScoreAMap, $b10ScoreDMap, $oddsHorseBlocks
            );

            $b11Features = json_encode([
                // メタ情報
                'model_version'         => [
                    'schema_version'     => 'v3.0',                    // 特徴量スキーマ版
                    'model_type'         => 'llm-ensemble',            // モデル種別
                    'models'             => [
                        '1st_ai' => 'claude (AnthropicService)',
                        '2nd_ai' => 'deepseek-chat',
                    ],
                    'library_versions'   => [
                        'php'     => PHP_VERSION,
                        // バージョン取得の失敗でスナップショット保存全体を落とさない
                        'laravel' => function_exists('app') ? app()->version() : null,
                    ],
                    'feature_set'        => 'phase1-full-timeseries-v5',  // v5: GBDT・10走集約・辞書・補完値
                    'algorithm'          => 'gbdt',  // 仕様: 決定木系 勾配ブースティング
                    'missing_policy'     => 'keep_null_with_flag', // 仕様: 欠損を0へ置換しない
                    'ability_history_max'=> 10,      // 仕様: 最大10走
                    'agg_windows'        => [3, 5, 10],
                    // 仕様: 数値欠損の補完に使う中央値をモデルと一緒に保存し再現可能にする
                    'imputation_medians' => $b11Imputation,
                    'category_dict'      => $b11DictUsed,
                    'feature_count'      => count($b11AllHorsesFeatures),
                    'params'             => [
                        'gap_threshold'        => 2.0,   // 断層成立比率
                        'low_odds_fuku_thresh' => 1.5,   // Block13a 複勝除外閾値
                        'low_odds_tan_thresh'  => 3.0,   // Block13a 単勝除外閾値
                        'low_odds_exception'   => 'AND', // 例外3条件の結合方式
                        'recovery_min_sample'  => 30,    // 回収率有効サンプル数
                        // @ANCHOR-20260926-B12-RECOVERY-THRESHOLD（実処理と同じ値を記録する）
                        'recovery_low_thresh'  => AiController::B12_RECOVERY_LOW_THRESH, // Block12 ハード除外閾値
                        'recovery_high_thresh' => 110.0, // Block13a 例外③閾値
                        'score_a_thresh'       => 12,    // 複勝継続流入判定
                        'merge_bonus'          => 5,     // 一致馬ボーナス
                        'band_width'           => 5.0,   // 帯基準馬方式の帯幅（シャドー）
                        'ability_history_len'  => 10,    // 能力適性ベクトルの固定長（最大10走）
                    ],
                    'train_period'       => null, // Phase1: 学習未実施
                    'train_sample_count' => 0,    // Phase1: 学習未実施
                    'model_hash'         => null, // Phase1: 学習モデル未生成
                    'phase'              => 1,
                ],
                'input_hash'            => $b11InputHash,
                // 断層構造
                'gap_type'              => $gapTypeForMerge,
                'primary_gap_upper_pop' => $primaryGapUpperPopForMerge,
                'merge_upper_max'       => $mergeUpperMax,
                'merge_mid_max'         => $mergeMidMax,
                'merge_lower_max'       => $mergeLowerMax,
                // ── レース条件（よっしー03.txt指摘#4: 競馬場・距離・クラス等）────
                'race_date'             => $date,
                'basho_code'            => $basho,
                'basho_name'            => $raceRow->basho_name ?? $basho,
                'race_num'              => $race,
                'race_name'             => $raceRow->race_name ?? null,
                'distance'              => isset($raceRow->dist)   ? (int)$raceRow->dist : null,
                'course'                => $raceRow->course ?? null,   // 芝/ダート等
                'grade'                 => $raceRow->grade  ?? null,   // クラス・格付け
                'kaisuu'                => (int)$kaisuu,
                'day'                   => (int)$day,
                // レース指標
                'horse_count'           => (int)$horseCount2nd,
                'upset_race'            => $upsetRaceFinal,
                'wave_level'            => $b14WaveLevel,
                'lower_entry'           => $b14LowerEntry,
                'big_gap_entry'         => $b14BigGap,
                'cond_a_met'            => $condAMet ? 1 : 0,
                // 【20260928】条件B・C・Dは三値。不明は 0 ではなく null で残す
                //   （欠損を不成立=0として学習データに混ぜないため）
                'cond_b_met'            => $condBMet === null ? null : ($condBMet ? 1 : 0),
                'cond_c_met'            => $condCMet === null ? null : ($condCMet ? 1 : 0),
                'cond_d_met'            => $condDMet === null ? null : ($condDMet ? 1 : 0),
                // 統合馬サマリー
                'merged_horse_count'    => count($mergedHorses),
                'matched_count'         => $b11CntMatched,
                'first_unique_count'    => $b11CntFirst,
                'second_unique_count'   => $b11CntSecond,
                'merged_pops'           => $b11MergedPops,
                'merged_scores'         => $b11MergedScores,
                'merged_nums'           => $b11MergedNums,
                // スコア指標
                'score_e'               => (int)($b10ScoreE ?? 0),
                'first_ai_count'        => count($firstAiHorses),
                'second_ai_count'       => count($secondAiHorses),
                // ── 全時点断層特徴量（よっしー03.txt指摘#4）──────────────
                'timings'               => $b11Timings,            // [999,21,18,15,12,9,6]
                'gap_ratios_by_timing'  => $b11TanGapByTiming,     // 各時点の単勝隣接断層比率
                'fuku_gap_by_timing'    => $b11FukuGapByTiming,    // 各時点の複勝隣接断層比率
                'tan_gap_fixed6_by_timing'  => $b11TanGapFixed6,   // 【20260924】6分前人気順固定軸の単勝断層比率
                'fuku_gap_fixed6_by_timing' => $b11FukuGapFixed6,  // 【20260924】6分前複勝人気順固定軸の複勝断層比率
                'gap_transitions'       => $b11GapTransitions,     // 出現/継続/消滅/拡大/縮小
                'gap_max_ratio_6m'      => $b11MaxRatio,           // 最大断層比率
                'gap_min_ratio_6m'      => $b11MinRatio,           // 最小断層比率
                'gap_primary_ratio_6m'  => $b11PrimaryRatio,       // 主断層比率
                'gap_count_6m'          => $b11GapCount6,          // 断層成立数
                'gap_count_top6_6m'     => $b11GapCountTop6,       // 【20260924】6番人気以内の断層本数
                'gap_count_below6_6m'   => $b11GapCountBelow,      // 【20260924】6番人気以降の断層本数
                'tan_odds_dist_6m'      => $b11TanDist6,           // 【20260924】人気順別 単勝オッズ分布
                'fuku_odds_dist_6m'     => $b11FukuDist6,          // 【20260924】複勝人気順別 複勝最小オッズ分布
                'top3_concentration_6m' => $b11TopConcentration,   // 【20260924】上位集中度（1〜3番人気の支持率シェア）
                'inner_outer'           => $raceRow->inner_outer ?? null, // 【20260924】内外
                'num_horses_race'       => isset($raceRow->num_horses) ? (int)$raceRow->num_horses : null,
                'tanpuku_gap_match'     => $b11GapMatch,           // 単複断層の一致/不一致
                // ── M4: 「2AI候補内」と「全頭発見」の分離保存 ──────────────
                'm4_separated'          => $b11M4Separated,
                // ── 時系列分割 70/15/15（#49）────────────────────────────
                'timeseries_split'      => $b11Split,
                // ── モデル更新・切戻し管理（#57）──────────────────────────
                'model_registry'        => $b11ModelRegistry,
                // ── 学習フェーズ（#55・#56）──────────────────────────────
                'ml_phase'              => $b11Phase,
                // ── M1〜M4 推論結果（シャドー専用・本番未反映）──────────────
                'ml_inference'          => $b11Inference,
                // ── 帯基準馬方式（5点比較帯）シャドー順位 ────────────────
                // ※シャドー専用。本番候補・本番順位・Flutter表示には未反映
                'band_method_ranking'   => $b11BandRanking,
                // 全頭固定長特徴量
                'all_horses_features'   => $b11AllHorsesFeatures,
            ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);

            DB::statement(
                'INSERT INTO t_horse_odds_finder_ml_snapshot'
                . ' (date, kaisuu, basho, basho_code, day, race, gap_type, features)'
                . ' VALUES (?, ?, ?, ?, ?, ?, ?, ?)'
                . ' ON DUPLICATE KEY UPDATE'
                . '   gap_type = VALUES(gap_type),'
                . '   features = VALUES(features)',
                [
                    $date,
                    (int)$kaisuu,
                    $raceRow->basho_name ?? '',
                    $basho,
                    (int)$day,
                    (int)$race,
                    $gapTypeForMerge,
                    $b11Features,
                ]
            );
//             \Log::debug('[Block11] ml_snapshot saved', [
//                 'date'       => $date,
//                 'kaisuu'     => $kaisuu,
//                 'basho_code' => $basho,
//                 'day'        => $day,
//                 'race'       => $race,
//                 'gap_type'   => $gapTypeForMerge,
//                 'merged_cnt' => count($mergedHorses),
//             ]);
        } catch (\Throwable $b11e) {
            \Log::error('[Block11] ml_snapshot INSERT failed', ['err' => $b11e->getMessage()]);
        }
        // ── Block 11 End ──────────────────────────────────────────────────────────
    }
}

/**
 * ═══════════════════════════════════════════════════════════════════════════
 * @ANCHOR-20261020-R122-PROMPT  r12.2 の両AI本文（1st・2nd）と INPUT_JSON
 * ═══════════════════════════════════════════════════════════════════════════
 * 根拠：server_contract_r12.2.txt 6章・9章／詳細設計書 5章・13章
 *       同梱 prompts/prompt_1st.txt・prompt_2nd.txt・common_prompt.txt
 *       同梱 schemas/input_schema.json・source_registry_schema.json
 *
 * ■ ここが何をするところか
 *   r12.2 では、AIへ送るものが2つとも入れ替わります。
 *     ・system 本文   … 先方が配った prompt_1st.txt / prompt_2nd.txt の全文。
 *                        <b>旧本文への追記ではなく、全文の置換です。</b>
 *                        1st・2nd それぞれが単独で完全な本文なので、
 *                        common_prompt.txt を後ろに足してはいけません
 *                        （足すと同じ規則が二重に入ります）。
 *     ・user 本文     … Laravel が作る INPUT_JSON 1個だけ。
 *                        日本語の散文でオッズを並べる旧方式はやめます。
 *
 * ■ 本文を PHP の文字列に書き写さない理由
 *   本文は先方が版管理している配布物です。コードへ書き写すと、
 *   写し間違いが起きても誰も気づけません。配布ファイルをそのまま置き、
 *   読み込むたびに
 *       ・BEGIN/END マーカーがあるか
 *       ・schema_version・prompt_version が r12.2 のものか
 *       ・未置換の差し込み記号（{{ }}）が残っていないか
 *       ・UTF-8 として壊れていないか
 *   を確かめ、SHA-256 を記録します。
 *
 * ■ 置き場所
 *   既定  storage/app/baganriki/prompts/r12_2/
 *   .env の BAGANRIKI_R122_PROMPT_DIR で変えられます。
 *   <b>新しい PHP ファイルは作りません。</b>本文は PHP ではなくデータです。
 *
 * ■ 機能フラグ
 *   .env の BAGANRIKI_R122_PROMPT=1 のときだけ新しい送信文に切り替わります。
 *   既定は 0（切）で、1バイトも今までと変わりません。
 *   フラグを入れていても、INPUT_JSON を正しく作れないときは
 *   <b>旧本文へ落ちずに送信を止めます</b>（契約11.2「正本が特定できない
 *   レースは公開しない」。中途半端な入力でAIを呼ぶほうが危険です）。
 *
 * ■ snapshot_hash の作り方（ここは先方の実装と1バイト単位で合わせました）
 *   対象   INPUT_JSON から ai_role・role_cap・role_quota・snapshot_hash を
 *          外した残り（＝両roleで同一の共通本文）
 *   並び   すべての階層でキーを文字列として昇順に並べ替える
 *   書式   区切りは "," と ":"（余白なし）、非ASCIIはエスケープしない
 *   SHA-256 を取り、snapshot_hash_version='exact-common-payload-sha256-r8'
 *   先方の参照入力14本すべてで同じ値になることを --r122-prompt-check で
 *   確かめています。
 */
final class BaganrikiPrompt
{
    public const BEGIN = '<<<BAGANRIKI_V041_R8_BEGIN>>>';
    public const END   = '<<<BAGANRIKI_V041_R8_END>>>';

    public const SCHEMA_VERSION = 'baganriki-v041-r12-2';
    public const PROMPT_VERSION = 'baganriki-v041-r12-2-20261020';
    public const HASH_VERSION   = 'exact-common-payload-sha256-r8';

    /** 共通hashの対象から外すキー（契約5章） */
    public const HASH_EXCLUDE = ['ai_role', 'role_cap', 'role_quota', 'snapshot_hash'];

    /** 配布された本文ファイル名 */
    public const FILES = ['1st' => 'prompt_1st.txt', '2nd' => 'prompt_2nd.txt',
                          'common' => 'common_prompt.txt'];

    /**
     * INPUT_JSON のトップレベル必須キー。
     * input_schema.json の required と同じ<b>35件</b>です。
     * @ANCHOR-20261020-R122-PROMPT  10月20日004のご指摘3
     *   報告書に「34キー」と書いたのはこちらの数え間違いでした。
     *   定数も照合処理も最初から35キーで動いています（件数は数えて出します）。
     */
    public const TOP_KEYS = [
        'schema_version', 'prompt_version', 'race_id', 'snapshot_hash',
        'snapshot_hash_version', 'time_contract', 'cutoff_at', 'N', 'runners',
        'source_registry', 'field_catalog', 'input_indices', 'legacy_gap_type',
        'signals', 'S', 'S_min', 'S_max', 'mode', 'target_count', 'base_quota',
        'quota', 'quota_adjustments', 'selection_enabled', 'display_rating',
        'learning_stage', 'model_version', 'ai_role', 'role_cap', 'role_quota',
        'coverage', 'mode_status', 'allocation_mode', 'mode_policy_id',
        'input_freeze_at', 'collection_audit',
    ];

    /** coverage の7区分（契約3章・順序は問いません） */
    public const COVERAGE_KEYS = ['past_runs', 'OPI', 'estimated_odds',
        'recovery_statistics', 'similar_statistics', 'legacy_qualifications',
        'gap_history'];

    /**
     * 項目辞書の定義。
     * 値そのものからは単位や下限を決められないので、知っている項目は表で持ちます。
     * 知らない項目が来たら登録内容から組み立てます（取りこぼしを作らないため）。
     */
    public const FIELD_DEFS = [
        'win_odds'         => ['unit' => 'odds',  'value_type' => 'number',
                               'missing_allowed' => true, 'minimum' => 0, 'maximum' => null],
        'place_min'        => ['unit' => 'odds',  'value_type' => 'number',
                               'missing_allowed' => true, 'minimum' => 0, 'maximum' => null],
        'place_max'        => ['unit' => 'odds',  'value_type' => 'number',
                               'missing_allowed' => true, 'minimum' => 0, 'maximum' => null],
        'past_performance' => ['unit' => 'index', 'value_type' => 'number',
                               'missing_allowed' => true, 'minimum' => 0, 'maximum' => null],
    ];

    /** JSONの制限（契約9章・出力側と同じ値を入力側にも当てます） */
    public const MAX_DEPTH  = 64;
    public const MAX_DIGITS = 128;

    // ───────────────────────────────────────────────────────────────────────
    // 本文（system）
    // ───────────────────────────────────────────────────────────────────────

    /** 機能フラグ。既定は切。 */
    public static function enabled(): bool
    {
        $v = env('BAGANRIKI_R122_PROMPT', '0');
        return in_array((string) $v, ['1', 'true', 'on', 'yes'], true);
    }

    /** 本文の置き場所 */
    public static function dir(): string
    {
        $d = (string) env('BAGANRIKI_R122_PROMPT_DIR', '');
        if ($d !== '') return rtrim($d, '/');
        return rtrim(storage_path('app/baganriki/prompts/r12_2'), '/');
    }

    /**
     * 本文を読み、そのまま使えるかどうかを確かめます。
     * 使えないときは ok=false を返し、呼び出し側は送信しません。
     *
     * @param string $role '1st'|'2nd'|'common'
     * @return array ['ok','body','path','sha256','bytes','lines','reason','checks']
     */
    public static function systemBody(string $role): array
    {
        $out = ['ok' => false, 'body' => null, 'path' => null, 'sha256' => null,
                'bytes' => 0, 'lines' => 0, 'reason' => null, 'checks' => []];
        if (!isset(self::FILES[$role])) {
            $out['reason'] = "role が違います（{$role}）";
            return $out;
        }
        $path = self::dir() . '/' . self::FILES[$role];
        $out['path'] = $path;
        if (!is_file($path) || !is_readable($path)) {
            $out['reason'] = '本文ファイルがありません: ' . $path;
            return $out;
        }
        $body = file_get_contents($path);
        if ($body === false || $body === '') {
            $out['reason'] = '本文ファイルが空です: ' . $path;
            return $out;
        }
        // BOM は送信文に混ぜません（hashが変わるため）
        if (strncmp($body, "\xEF\xBB\xBF", 3) === 0) $body = substr($body, 3);
        $out['body']   = $body;
        $out['sha256'] = hash('sha256', $body);
        $out['bytes']  = strlen($body);
        $out['lines']  = substr_count($body, "\n") + 1;

        $checks = [];
        $checks['utf8']           = (mb_check_encoding($body, 'UTF-8') === true);
        $checks['has_begin']      = (strpos($body, self::BEGIN) !== false);
        $checks['has_end']        = (strpos($body, self::END) !== false);
        $checks['schema_version'] = (strpos($body, self::SCHEMA_VERSION) !== false);
        $checks['prompt_version'] = (strpos($body, self::PROMPT_VERSION) !== false);
        $checks['no_placeholder'] = (strpos($body, '{{') === false);
        if ($role !== 'common') {
            // それぞれが単独で完全な本文であることの目印（共通部の見出し）
            $checks['has_common_part'] = (strpos($body, '【最優先規則】') !== false);
            $checks['has_output_part'] = (strpos($body, '【出力形式】') !== false);
            $checks['has_input_part']  = (strpos($body, '【実入力】') !== false);
        }
        $out['checks'] = $checks;
        $bad = array_keys(array_filter($checks, static fn($v) => $v !== true));
        if ($bad !== []) {
            $out['reason'] = '本文の確認に失敗しました: ' . implode('・', $bad);
            return $out;
        }
        $out['ok'] = true;
        return $out;
    }

    // ───────────────────────────────────────────────────────────────────────
    // 正規化とhash
    // ───────────────────────────────────────────────────────────────────────

    /**
     * すべての階層でキーを文字列として昇順に並べ替えます。
     * 配列（0始まりの連番）は順序を変えません（runners や source_refs の順は意味を持つ）。
     * 空の連想配列は {} として残すため stdClass に替えます（[] になると別物）。
     */
    public static function sortDeep($v)
    {
        if ($v instanceof \stdClass) {
            $v = (array) $v;
            if ($v === []) return new \stdClass();
        }
        if (!is_array($v)) return $v;
        $isList = array_keys($v) === range(0, count($v) - 1);
        if ($isList) {
            $out = [];
            foreach ($v as $x) $out[] = self::sortDeep($x);
            return $out;
        }
        $keys = array_map('strval', array_keys($v));
        $vals = array_values($v);
        array_multisort($keys, SORT_ASC, SORT_STRING, $vals);
        $out = [];
        foreach ($keys as $i => $k) $out[$k] = self::sortDeep($vals[$i]);
        return $out;
    }

    /**
     * 共通hashの対象文（キー昇順・余白なし・非ASCIIはそのまま）。
     * 先方の python 実装 json.dumps(sort_keys=True, separators=(',',':'),
     * ensure_ascii=False) と1バイト単位で同じになることを確かめています。
     */
    public static function canonical($v): ?string
    {
        // JSON_PARTIAL_OUTPUT_ON_ERROR は付けません。付けると NaN / Infinity が
        // 黙って 0 に置き換わり、気づかないまま送ってしまいます。
        $json = json_encode(self::sortDeep($v),
            JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES
            | JSON_PRESERVE_ZERO_FRACTION);
        if ($json === false) return null;
        if (json_last_error() !== JSON_ERROR_NONE) return null;
        return $json;
    }

    /**
     * snapshot_hash。role に依存する4キーを外してから取ります。
     * @return array ['ok','json','hash','hash_version','reason']
     */
    public static function commonHash(array $input): array
    {
        foreach (self::HASH_EXCLUDE as $k) unset($input[$k]);
        $json = self::canonical($input);
        if ($json === null) {
            return ['ok' => false, 'json' => null, 'hash' => null,
                    'hash_version' => self::HASH_VERSION,
                    'reason' => '共通本文をJSONにできませんでした'];
        }
        return ['ok' => true, 'json' => $json, 'hash' => hash('sha256', $json),
                'hash_version' => self::HASH_VERSION, 'reason' => null];
    }

    /**
     * 送信する user 本文。契約9章の制限（入れ子64階層・数値128桁）を確かめます。
     * 送信文のキー順は hash と同じ昇順に揃えます（差分を読むときに楽なので）。
     * @return array ['ok','json','bytes','depth','reason']
     */
    public static function encode(array $input): array
    {
        $depth = self::depthOf($input);
        if ($depth > self::MAX_DEPTH) {
            return ['ok' => false, 'json' => null, 'bytes' => 0, 'depth' => $depth,
                    'reason' => '入れ子が ' . $depth . ' 階層で上限64を超えています'];
        }
        $long = self::tooLongNumber($input);
        if ($long !== null) {
            return ['ok' => false, 'json' => null, 'bytes' => 0, 'depth' => $depth,
                    'reason' => '数値の桁数が上限128を超えています: ' . $long];
        }
        $json = self::canonical($input);
        if ($json === null) {
            return ['ok' => false, 'json' => null, 'bytes' => 0, 'depth' => $depth,
                    'reason' => 'INPUT_JSON を作れませんでした'];
        }
        if (strpos($json, 'NaN') !== false || strpos($json, 'Infinity') !== false) {
            return ['ok' => false, 'json' => null, 'bytes' => 0, 'depth' => $depth,
                    'reason' => 'NaN / Infinity が混ざっています'];
        }
        return ['ok' => true, 'json' => $json, 'bytes' => strlen($json),
                'depth' => $depth, 'reason' => null];
    }

    /**
     * RFC3339（秒まで必須・タイムゾーン必須）。
     * マイクロ秒が 0 のときは小数部を付けません。
     * 同梱スキーマは小数部を任意にしていますが、先方の参照入力は
     * 小数部なしで書かれているため、同じ書き方にそろえます
     * （snapshot_hash は本文のバイト列から取るので、書き方がそろっていないと
     *   同じ内容でも値が変わります）。
     */
    public static function rfc3339(int $us): string
    {
        return str_replace('.000000', '', BaganrikiTime::toJst($us));
    }

    /** 入れ子の深さ */
    public static function depthOf($v, int $cur = 1): int
    {
        if ($v instanceof \stdClass) $v = (array) $v;
        if (!is_array($v) || $v === []) return $cur;
        $max = $cur;
        foreach ($v as $x) {
            $d = self::depthOf($x, $cur + 1);
            if ($d > $max) $max = $d;
        }
        return $max;
    }

    /** 128桁を超える数値があればその場所を返します */
    public static function tooLongNumber($v, string $path = '')
    {
        if ($v instanceof \stdClass) $v = (array) $v;
        if (is_array($v)) {
            foreach ($v as $k => $x) {
                $r = self::tooLongNumber($x, $path . '/' . $k);
                if ($r !== null) return $r;
            }
            return null;
        }
        if (is_int($v) || is_float($v)) {
            // ══════════════════════════════════════════════════════════
            // @ANCHOR-20261020-R122-PROMPT  指数表記を展開して桁を数えます
            // ══════════════════════════════════════════════════════════
            // 【直した中身】(string) だけで数えていたので、1.0E+129 のような
            //   指数表記が「6桁」に見えて、桁あふれを見逃していました。
            //   受入試験 R122-P01「129桁の整数は送らない」が不合格でした。
            //   十進数で書いたときの桁数（整数部＋小数部）で数えます。
            if (is_int($v)) {
                $digits = strlen((string) abs($v));
            } else {
                if (!is_finite($v)) return ($path === '' ? '(root)' : $path);
                $abs    = abs($v);
                $digits = strlen(sprintf('%.0F', $abs));     // 整数部（指数を展開）
                $short  = (string) $abs;                      // 最短表記
                if (stripos($short, 'e') === false) {
                    $dot = strpos($short, '.');
                    if ($dot !== false) $digits += strlen(substr($short, $dot + 1));
                }
            }
            if ($digits > self::MAX_DIGITS) return ($path === '' ? '(root)' : $path);
        }
        return null;
    }

    // ───────────────────────────────────────────────────────────────────────
    // INPUT_JSON の組み立て
    // ───────────────────────────────────────────────────────────────────────

    /** 登録索引のキー（先方の examples と同じ形。slot が無いときは文字 None） */
    public static function indexKey(array $e): string
    {
        $slot = ($e['slot_offset'] === null) ? 'None' : (string) $e['slot_offset'];
        $scope = (string) ($e['scope'] ?? 'HORSE');
        $field = (string) ($e['field'] ?? '');
        if ($scope === 'HORSE') {
            $no = (int) (($e['horse_nos'][0]) ?? 0);
            return 'horse/' . $no . '/' . $field . '/' . $slot;
        }
        if ($scope === 'PAIR') {
            $ns = array_map('intval', (array) ($e['horse_nos'] ?? []));
            sort($ns);
            return 'pair/' . implode('-', $ns) . '/' . $field . '/' . $slot;
        }
        if ($scope === 'COHORT') {
            $ns = array_map('intval', (array) ($e['applicable_horse_nos'] ?? []));
            sort($ns);
            return 'cohort/' . implode('-', $ns) . '/' . $field . '/' . $slot;
        }
        return 'race/' . $field . '/' . $slot;
    }

    /** 登録から項目辞書を作ります */
    public static function fieldCatalogFor(array $registry): array
    {
        $cat = [];
        foreach ($registry as $e) {
            $f = (string) ($e['field'] ?? '');
            if ($f === '' || isset($cat[$f])) continue;
            $def = self::FIELD_DEFS[$f] ?? null;
            $vt = 'number';
            if ($def === null) {
                $v = $e['value'] ?? null;
                if (is_bool($v))        $vt = 'boolean';
                elseif (is_string($v))  $vt = 'string';
                $def = ['unit' => (string) ($e['unit'] ?? 'unit'), 'value_type' => $vt,
                        'missing_allowed' => true, 'minimum' => null, 'maximum' => null];
            }
            $cat[$f] = [
                'unit'            => $def['unit'],
                'scope'           => (string) ($e['scope'] ?? 'HORSE'),
                'display_label'   => $f,
                'value_type'      => $def['value_type'],
                'missing_allowed' => $def['missing_allowed'],
                'minimum'         => $def['minimum'],
                'maximum'         => $def['maximum'],
            ];
        }
        return $cat;
    }

    /** 登録から索引を作ります（同じ場所に2件あれば並べます） */
    public static function indicesFor(array $registry): array
    {
        $idx = [];
        foreach ($registry as $ref => $e) {
            $k = self::indexKey($e);
            $idx[$k][] = (string) ($e['source_ref'] ?? $ref);
        }
        foreach ($idx as $k => $v) {
            $v = array_values(array_unique($v));
            sort($v, SORT_STRING);
            $idx[$k] = $v;
        }
        return $idx;
    }

    /**
     * 文脈から INPUT_JSON を組み立てます。
     *
     * $ctx に入れるもの（呼び出し側が正本から用意します）
     *   race_id            文字列
     *   anchor_at          発走時刻（RFC3339・秒必須・TZ必須）
     *   sales_close_at     投票締切（同）。<b>null なら作りません。</b>
     *   registry           source_ref => 登録1件（source_registry_schema と同じ形）
     *   audit              スロット => 取得監査1件（collection_audit と同じ形）
     *   coverage           7区分の状態
     *   entry_nums         出馬表の馬番（任意・集合照合に使う）
     *   cancelled          正式取消の馬番（任意）
     *   legacy_gap_type    旧断層タイプ（無ければ null）
     *   similar            X6 の類似統計（無ければ null＝N>=7で不明）
     *
     * @return array ['ok','input','code','reason','derived']
     */
    public static function buildInput(array $ctx, string $role): array
    {
        $ng = static fn(string $code, string $why) =>
            ['ok' => false, 'input' => null, 'code' => $code, 'reason' => $why,
             'derived' => []];

        if (!in_array($role, ['1st', '2nd'], true)) {
            return $ng('ROLE_INVALID', 'role は 1st か 2nd だけです');
        }
        $raceId = (string) ($ctx['race_id'] ?? '');
        if ($raceId === '') return $ng('ENTRY_MISSING', 'race_id がありません');

        // ── 時刻契約 ───────────────────────────────────────────────────
        $anchorUs = BaganrikiTime::us($ctx['anchor_at'] ?? null);
        if ($anchorUs === null) {
            return $ng('TIME_CONTRACT_INVALID',
                       '発走時刻を RFC3339（秒・タイムゾーン必須）として読めません');
        }
        $salesUs = BaganrikiTime::us($ctx['sales_close_at'] ?? null);
        if ($salesUs === null) {
            // 契約11.2。推測した締切でAIを呼ぶことはしません。
            return $ng('SALES_CLOSE_UNRESOLVED',
                       '投票締切の正本が特定できないため送信しません（契約11.2）');
        }
        $time = [
            'version'            => 'baganriki-post-slot-grace-v1',
            'anchor_kind'        => 'POST_TIME',
            'anchor_at'          => self::rfc3339($anchorUs),
            'snapshot_offsets'   => BaganrikiTime::INPUT_SLOTS,
            'sampling_policy_id' => 'SLOT_FIRST_VALID_COMMITTED_V1',
            'reply_deadline'     => self::rfc3339(BaganrikiTime::replyDeadline($salesUs)),
            'publish_deadline'   => self::rfc3339(BaganrikiTime::publishDeadline($salesUs)),
            'sales_close_at'     => self::rfc3339($salesUs),
            'safety_margin_ms'   => BaganrikiTime::SAFETY_MARGIN_SEC * 1000,
            'acquisition_grace_ms' => BaganrikiTime::GRACE_MS,
        ];
        $cutoffUs = BaganrikiTime::cutoff($anchorUs);
        $freezeUs = BaganrikiTime::inputFreeze($anchorUs);

        // ── 取得監査 ───────────────────────────────────────────────────
        $audit = (array) ($ctx['audit'] ?? []);
        if (!isset($audit[6]) && !isset($audit['6'])) {
            return $ng('COLLECTION_AUDIT_MISSING',
                       '6分前の取得監査がありません（6分前は必須です）');
        }
        $auditOut = [];
        foreach (BaganrikiTime::INPUT_SLOTS as $slot) {
            $a = $audit[$slot] ?? $audit[(string) $slot] ?? null;
            if ($a === null) {
                $auditOut[(string) $slot] = ['status' => 'UNAVAILABLE',
                    'reason' => 'このスロットの採用できる監査行がありません'];
                continue;
            }
            $auditOut[(string) $slot] = $a;
        }
        if (($auditOut['6']['status'] ?? '') !== 'ADOPTED') {
            return $ng('COLLECTION_AUDIT_MISSING',
                       '6分前の取得監査が ADOPTED ではありません');
        }

        // ── 登録・辞書・索引 ──────────────────────────────────────────
        $registry = (array) ($ctx['registry'] ?? []);
        if ($registry === []) {
            return $ng('SOURCE_REGISTRY_EMPTY', 'source_registry が空です');
        }
        foreach ($registry as $ref => $e) {
            $miss = [];
            foreach (['source_ref', 'race_id', 'value', 'scope', 'horse_nos',
                      'applicable_horse_nos', 'field', 'unit', 'slot_offset',
                      'observed_at', 'available_at', 'computed_at', 'source_kind',
                      'parents', 'formula_id', 'formula_version', 'dependency_key',
                      'dependency_role'] as $k) {
                if (!array_key_exists($k, (array) $e)) $miss[] = $k;
            }
            if ($miss !== []) {
                return $ng('SOURCE_REGISTRY_INVALID',
                           $ref . ' に ' . implode('・', $miss) . ' がありません');
            }
        }

        // ── 凍結集合と N ───────────────────────────────────────────────
        //   6分前の単勝だけが凍結順位の土台です。欠けていれば作りません。
        $win6 = [];
        foreach ($registry as $e) {
            if (($e['field'] ?? '') !== 'win_odds') continue;
            if ((int) ($e['slot_offset'] ?? -1) !== 6) continue;
            $no = (int) (($e['horse_nos'][0]) ?? 0);
            if ($no <= 0) continue;
            $v = $e['value'];
            if ($v === null) continue;
            $win6[$no] = is_string($v) ? trim($v) : $v;
        }
        $cancelled = array_map('intval', (array) ($ctx['cancelled'] ?? []));
        foreach ($cancelled as $no) unset($win6[$no]);
        if (count($win6) < 2) {
            return $ng('ODDS_SERIES_INCOMPLETE',
                       '6分前の単勝オッズが2頭ぶんに届きません');
        }
        $entryNums = ($ctx['entry_nums'] ?? null);
        if (is_array($entryNums) && $entryNums !== []) {
            $lack = array_values(array_diff(
                array_map('intval', $entryNums), $cancelled, array_keys($win6)));
            if ($lack !== []) {
                return $ng('ODDS_SERIES_INCOMPLETE',
                           '6分前の単勝が無い馬がいます: ' . implode('・', $lack));
            }
        }
        $fr = BaganrikiSnapshot::frozenRank($win6);
        if (($fr['ok'] ?? false) !== true) {
            return $ng((string) ($fr['code'] ?? 'FREEZE_ODDS_MISSING'),
                       (string) ($fr['reason'] ?? '凍結順位を作れません'));
        }
        $frozen = $fr['rank'];                            // 馬番 => 凍結人気
        $N = count($frozen);
        $runners = [];
        foreach ($frozen as $no => $rank) {
            $runners[] = ['horse_no' => (int) $no, 'win_rank' => (int) $rank,
                          'band' => BaganrikiAllocation::v04Band((int) $rank)];
        }
        usort($runners, static fn($a, $b) => $a['win_rank'] <=> $b['win_rank']);

        // ── 信号・mode ────────────────────────────────────────────────
        //   判定は本番側の実装（BaganrikiSignals）をそのまま使います。
        //   検証側（--mode-check）との72レース突き合わせで食い違い0です。
        $pHorses = self::horsesForSignals($registry, $frozen);
        $pairs   = BaganrikiSignals::v04Pairs($pHorses);
        $flags   = BaganrikiSignals::v04DeriveFlags($N, $pairs, $pHorses,
                                                    $ctx['similar'] ?? null);
        $cls     = BaganrikiSignals::v04Classify($flags['flags']);
        $tri = static function ($v) {
            if ($v === 'TRUE')  return true;
            if ($v === 'FALSE') return false;
            return null;
        };
        $signals = [];
        foreach (['X1', 'X2', 'X3', 'X4', 'X5', 'X6', 'Z'] as $k) {
            $signals[$k] = $tri($flags['flags'][$k] ?? 'UNKNOWN');
        }

        // ── 配分 ──────────────────────────────────────────────────────
        $alloc = BaganrikiAllocation::v04Allocation($N, $cls);
        $baseQ = $alloc['base_quota'] ?? null;
        $selEnabled = (bool) $cls['selection_enabled'];
        $quota = $alloc['quota'];
        if ($role === '1st') {
            $roleQuota = $selEnabled ? $quota : null;
            $roleCap   = $selEnabled ? (int) $alloc['target_count'] : 0;
        } else {
            $roleQuota = $selEnabled ? $alloc['quota_2nd'] : null;
            $roleCap   = $selEnabled ? min(5, (int) $alloc['target_count']) : 0;
        }

        // ── 組み立て ──────────────────────────────────────────────────
        $input = [
            'schema_version'        => self::SCHEMA_VERSION,
            'prompt_version'        => self::PROMPT_VERSION,
            'race_id'               => $raceId,
            'snapshot_hash'         => '',           // あとで入れます
            'snapshot_hash_version' => self::HASH_VERSION,
            'time_contract'         => $time,
            'cutoff_at'             => self::rfc3339($cutoffUs),
            'input_freeze_at'       => self::rfc3339($freezeUs),
            'N'                     => $N,
            'runners'               => $runners,
            'source_registry'       => $registry,
            'field_catalog'         => self::fieldCatalogFor($registry),
            'input_indices'         => self::indicesFor($registry),
            'legacy_gap_type'       => $ctx['legacy_gap_type'] ?? null,
            'signals'               => $signals,
            'S'                     => $cls['S'],
            'S_min'                 => (int) $cls['S_min'],
            'S_max'                 => (int) $cls['S_max'],
            'mode'                  => (string) $cls['mode'],
            'target_count'          => (int) $alloc['target_count'],
            'base_quota'            => $baseQ,
            'quota'                 => $quota,
            'quota_adjustments'     => array_values((array) $alloc['quota_adjustments']),
            'selection_enabled'     => $selEnabled,
            'display_rating'        => $cls['display_rating'],
            'learning_stage'        => 'COLLECT_ONLY',
            'model_version'         => null,
            'ai_role'               => $role,
            'role_cap'              => $roleCap,
            'role_quota'            => $roleQuota,
            'coverage'              => self::coverageOf($ctx['coverage'] ?? null),
            'mode_status'           => (string) $cls['mode_status'],
            'allocation_mode'       => $cls['allocation_mode'],
            'mode_policy_id'        => (string) $cls['mode_policy_id'],
            'collection_audit'      => $auditOut,
        ];
        $h = self::commonHash($input);
        if (!$h['ok']) return $ng('SNAPSHOT_HASH_FAILED', (string) $h['reason']);
        $input['snapshot_hash'] = $h['hash'];

        $miss = array_values(array_diff(self::TOP_KEYS, array_keys($input)));
        if ($miss !== []) {
            return $ng('INPUT_KEYS_MISSING', '必須キーが足りません: ' . implode('・', $miss));
        }
        $extra = array_values(array_diff(array_keys($input), self::TOP_KEYS));
        if ($extra !== []) {
            return $ng('INPUT_KEYS_EXTRA', '余分なキーがあります: ' . implode('・', $extra));
        }

        return ['ok' => true, 'input' => $input, 'code' => null, 'reason' => null,
                'derived' => ['N' => $N, 'flags' => $flags['flags'],
                              'mode' => $cls['mode'], 'mode_status' => $cls['mode_status'],
                              'snapshot_hash' => $h['hash'],
                              'common_json_bytes' => strlen((string) $h['json'])]];
    }

    /** coverage を7区分そろえます。指定が無い区分は UNAVAILABLE にします。 */
    public static function coverageOf($given): array
    {
        $g = is_array($given) ? $given : [];
        $out = [];
        foreach (self::COVERAGE_KEYS as $k) {
            $v = $g[$k] ?? null;
            if (is_array($v) && ($v['status'] ?? '') === 'INCLUDED'
                && !empty($v['source_refs'])) {
                $refs = array_values(array_unique(array_map('strval', $v['source_refs'])));
                $out[$k] = ['status' => 'INCLUDED', 'source_refs' => $refs];
                continue;
            }
            $reason = (is_array($v) && isset($v['reason']) && (string) $v['reason'] !== '')
                    ? (string) $v['reason']
                    : 'この区分の実データを入力へ入れていません';
            $out[$k] = ['status' => 'UNAVAILABLE', 'reason' => $reason];
        }
        return $out;
    }

    /**
     * 信号判定が受け取る形（6分前人気の昇順）へ直します。
     * tan_series / fuku_min_series は「スロット => 元の十進数文字列」です。
     * 丸めません（@ANCHOR-20261020-R122-EXACT と同じ扱い）。
     */
    public static function horsesForSignals(array $registry, array $frozen): array
    {
        $byNo = [];
        foreach ($registry as $e) {
            $scope = (string) ($e['scope'] ?? '');
            if ($scope !== 'HORSE') continue;
            $no = (int) (($e['horse_nos'][0]) ?? 0);
            if ($no <= 0 || !isset($frozen[$no])) continue;
            $slot = $e['slot_offset'];
            if ($slot === null) continue;
            $v = $e['value'];
            if ($v === null) continue;
            $s = is_string($v) ? trim($v) : self::numToDecimalString($v);
            if ($s === '') continue;
            $f = (string) ($e['field'] ?? '');
            // tan_series は v04Pairs() が読むキー名です（単勝の時系列）。
            if ($f === 'win_odds')  $byNo[$no]['tan_series'][(int) $slot]      = $s;
            if ($f === 'place_min') $byNo[$no]['fuku_min_series'][(int) $slot] = $s;
        }
        $order = $frozen;
        asort($order);
        $out = [];
        foreach (array_keys($order) as $no) {
            $out[] = [
                'num'             => (int) $no,
                'popularity'      => (int) $frozen[$no],
                'tan_series'      => $byNo[$no]['tan_series']      ?? [],
                'fuku_min_series' => $byNo[$no]['fuku_min_series'] ?? [],
            ];
        }
        return $out;
    }

    /** 数値を十進数の文字列へ（指数表記にしない・余分な0を付けない） */
    public static function numToDecimalString($v): string
    {
        if (is_int($v)) return (string) $v;
        if (!is_float($v)) return trim((string) $v);
        if (!is_finite($v)) return '';
        $s = rtrim(rtrim(number_format($v, 12, '.', ''), '0'), '.');
        return ($s === '' || $s === '-') ? '0' : $s;
    }

    // ───────────────────────────────────────────────────────────────────────
    // 送信の一式
    // ───────────────────────────────────────────────────────────────────────

    /**
     * system 本文と user 本文を1組にします。送れる状態でなければ ok=false。
     * @return array ['ok','role','system','system_sha256','user','user_bytes',
     *                'input','snapshot_hash','code','reason','issues','derived']
     */
    public static function assemble(array $ctx, string $role): array
    {
        $sys = self::systemBody($role);
        if (!$sys['ok']) {
            return ['ok' => false, 'role' => $role, 'code' => 'PROMPT_BODY_INVALID',
                    'reason' => (string) $sys['reason'], 'system' => null,
                    'system_sha256' => null, 'user' => null, 'user_bytes' => 0,
                    'input' => null, 'snapshot_hash' => null, 'issues' => [],
                    'derived' => []];
        }
        $b = self::buildInput($ctx, $role);
        if (!$b['ok']) {
            return ['ok' => false, 'role' => $role, 'code' => (string) $b['code'],
                    'reason' => (string) $b['reason'], 'system' => null,
                    'system_sha256' => $sys['sha256'], 'user' => null, 'user_bytes' => 0,
                    'input' => null, 'snapshot_hash' => null, 'issues' => [],
                    'derived' => []];
        }
        $enc = self::encode($b['input']);
        if (!$enc['ok']) {
            return ['ok' => false, 'role' => $role, 'code' => 'INPUT_ENCODE_FAILED',
                    'reason' => (string) $enc['reason'], 'system' => null,
                    'system_sha256' => $sys['sha256'], 'user' => null, 'user_bytes' => 0,
                    'input' => $b['input'], 'snapshot_hash' => null, 'issues' => [],
                    'derived' => $b['derived']];
        }
        $asm = ['ok' => true, 'role' => $role, 'system' => $sys['body'],
                'system_sha256' => $sys['sha256'], 'user' => $enc['json'],
                'user_bytes' => $enc['bytes'], 'input' => $b['input'],
                'snapshot_hash' => $b['input']['snapshot_hash'], 'code' => null,
                'reason' => null, 'issues' => [], 'derived' => $b['derived']];
        $asm['issues'] = self::selfCheck($asm);
        if ($asm['issues'] !== []) {
            $asm['ok'] = false;
            $asm['code'] = 'SEND_SELF_CHECK_FAILED';
            $asm['reason'] = implode('／', array_column($asm['issues'], 'reason'));
        }
        return $asm;
    }

    /**
     * 送る直前の自己点検。1つでも引っかかったら送りません。
     * @return array 各件 ['code','reason']
     */
    public static function selfCheck(array $asm): array
    {
        $bad = [];
        $sys = (string) ($asm['system'] ?? '');
        $usr = (string) ($asm['user'] ?? '');
        $in  = (array) ($asm['input'] ?? []);
        $add = static function (array &$bad, string $code, string $why) {
            $bad[] = ['code' => $code, 'reason' => $why];
        };
        if (strpos($sys, self::BEGIN) === false || strpos($sys, self::END) === false) {
            $add($bad, 'MARKER_MISSING', 'system本文にBEGIN/ENDの指定がありません');
        }
        if (strpos($sys, self::PROMPT_VERSION) === false) {
            $add($bad, 'PROMPT_VERSION_MISMATCH', 'system本文のprompt_versionが違います');
        }
        if (($in['schema_version'] ?? null) !== self::SCHEMA_VERSION) {
            $add($bad, 'SCHEMA_VERSION_MISMATCH', 'INPUT_JSONのschema_versionが違います');
        }
        if (($in['prompt_version'] ?? null) !== self::PROMPT_VERSION) {
            $add($bad, 'PROMPT_VERSION_MISMATCH', 'INPUT_JSONのprompt_versionが違います');
        }
        if (($in['snapshot_hash_version'] ?? null) !== self::HASH_VERSION) {
            $add($bad, 'HASH_VERSION_MISMATCH', 'snapshot_hash_versionが違います');
        }
        if (($in['ai_role'] ?? null) !== ($asm['role'] ?? null)) {
            $add($bad, 'ROLE_MISMATCH', 'ai_roleと送り先のroleが違います');
        }
        $h = self::commonHash($in);
        if (!$h['ok'] || $h['hash'] !== ($in['snapshot_hash'] ?? null)) {
            $add($bad, 'SNAPSHOT_HASH_MISMATCH', 'snapshot_hashが共通本文と合いません');
        }
        if ($usr === '' || $usr[0] !== '{') {
            $add($bad, 'INPUT_NOT_OBJECT', 'user本文がJSONオブジェクト1個ではありません');
        }
        if (json_decode($usr, true) === null) {
            $add($bad, 'INPUT_NOT_PARSEABLE', 'user本文を読み直せません');
        }
        if (strpos($usr, '{{') !== false) {
            $add($bad, 'PLACEHOLDER_LEFT', 'user本文に未置換の差し込み記号があります');
        }
        // 選出停止のときは枠を渡しません（契約7章）
        if (($in['selection_enabled'] ?? null) === false) {
            // role_quota は null が正しい値なので ?? で既定値を当てません
            // （?? は null を「無い」と見なすため、null のときに誤検知します）
            $rq0 = array_key_exists('role_quota', $in) ? $in['role_quota'] : '(キー無し)';
            if (($in['role_cap'] ?? null) !== 0 || $rq0 !== null) {
                $add($bad, 'SELECTION_DISABLED_MISMATCH',
                     'selection_enabled=false なのに role_cap/role_quota が空ではありません');
            }
        } else {
            $rq = $in['role_quota'] ?? null;
            if (!is_array($rq)) {
                $add($bad, 'ROLE_QUOTA_MISSING', 'role_quota がありません');
            } else {
                $sum = (int) ($rq['A'] ?? 0) + (int) ($rq['B'] ?? 0) + (int) ($rq['D'] ?? 0);
                if ($sum !== (int) ($in['role_cap'] ?? -1)) {
                    $add($bad, 'ROLE_CAP_MISMATCH',
                         'role_quota の合計（' . $sum . '）が role_cap と合いません');
                }
            }
        }
        // 2nd の上限は5頭（契約7章）
        if (($asm['role'] ?? '') === '2nd' && (int) ($in['role_cap'] ?? 0) > 5) {
            $add($bad, 'ROLE_CAP_OVER', '2ndのrole_capが5を超えています');
        }
        return $bad;
    }
}
