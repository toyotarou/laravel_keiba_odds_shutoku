<?php
// @ANCHOR-20261020-R122-PROMPT  送信文の検査（コマンドと同じ手順を単体で）
require __DIR__ . '/harness.php';
use App\Http\Controllers\Api\BaganrikiPrompt as BP;
use App\Http\Controllers\Api\BaganrikiTime as BT;

$vDir = __DIR__ . '/mat/validation';
$sDir = __DIR__ . '/mat/schemas';
$ng = 0;
function say($s) { echo $s, "\n"; }

say('== §1 本文3本 ==');
foreach (BP::FILES as $role => $name) {
    $b = BP::systemBody($role);
    if (!$b['ok']) { say("  NG {$name}: {$b['reason']}"); $GLOBALS['ng']++; continue; }
    printf("  OK %-18s 行%4d バイト%7d sha256=%s\n", $name, $b['lines'], $b['bytes'], $b['sha256']);
}
$b1 = BP::systemBody('1st'); $b2 = BP::systemBody('2nd'); $bc = BP::systemBody('common');
$head = mb_substr($bc['body'], 0, 120);
say('  共通本文の冒頭が1stに含まれる: ' . (mb_strpos($b1['body'], $head) !== false ? 'はい' : 'いいえ'));
say('  共通本文の冒頭が2ndに含まれる: ' . (mb_strpos($b2['body'], $head) !== false ? 'はい' : 'いいえ'));

say('');
say('== §2 snapshot_hash の作り方 ==');
$refs = glob($vDir . '/normal/*_input.json'); sort($refs);
$ok = 0;
foreach ($refs as $f) {
    $in = json_decode(file_get_contents($f), true);
    $h = BP::commonHash($in);
    if ($h['hash'] === $in['snapshot_hash']) { $ok++; }
    else { say('  NG ' . basename($f) . ' 得た値 ' . substr((string)$h['hash'],0,16) . ' / 期待値 ' . substr($in['snapshot_hash'],0,16)); $ng++; }
}
say(sprintf('  一致 %d / %d 件', $ok, count($refs)));

say('');
say('== §3 生payloadから組み立てて参照入力と照合 ==');
function caseCtx($vDir, $case, $ref) {
    $registry = []; $audit = [];
    $anchorUs = BT::us($ref['time_contract']['anchor_at']);
    foreach (BT::INPUT_SLOTS as $slot) {
        $f = $vDir . '/raw_payloads/' . $case . '_s' . $slot . '.json';
        if (!is_file($f)) { $audit[(string)$slot] = ['status'=>'UNAVAILABLE','reason'=>'payloadなし']; continue; }
        $bytes = file_get_contents($f);
        $pl = json_decode($bytes, true);
        $obs = null; $av = null;
        foreach ((array)$pl['records'] as $r) {
            $registry[(string)$r['source_ref']] = $r;
            $o = BT::us($r['observed_at'] ?? null); $a = BT::us($r['available_at'] ?? null);
            if ($o !== null && ($obs === null || $o > $obs)) $obs = $o;
            if ($a !== null && ($av === null || $a > $av)) $av = $a;
        }
        $sch = BT::slotScheduled($anchorUs, $slot);
        $audit[(string)$slot] = [
            'status' => 'ADOPTED',
            'batch_id' => (string)($ref['collection_audit'][(string)$slot]['batch_id'] ?? ''),
            'payload_hash' => hash('sha256', $bytes),
            'slot_scheduled_at' => BP::rfc3339($sch),
            'source_updated_at' => null,
            'request_started_at' => BP::rfc3339($sch),
            'response_received_at' => $obs === null ? null : BP::rfc3339($obs),
            'available_at' => $av === null ? null : BP::rfc3339($av),
        ];
    }
    foreach ((array)$ref['source_registry'] as $k => $e) {
        if (($e['slot_offset'] ?? null) === null) $registry[(string)$k] = $e;
    }
    return [
        'race_id' => $ref['race_id'],
        'anchor_at' => $ref['time_contract']['anchor_at'],
        'sales_close_at' => $ref['time_contract']['sales_close_at'],
        'registry' => $registry, 'audit' => $audit,
        'coverage' => $ref['coverage'],
        'entry_nums' => array_map(fn($r) => (int)$r['horse_no'], $ref['runners']),
        'cancelled' => [], 'legacy_gap_type' => $ref['legacy_gap_type'] ?? null,
        'similar' => null,
    ];
}
$cases = [];
foreach ($refs as $f) {
    if (preg_match('/^(.+)_(1st|2nd)_input\.json$/', basename($f), $m)) $cases[$m[1]][$m[2]] = $f;
}
$built = [];
foreach ($cases as $case => $byRole) {
    foreach (['1st','2nd'] as $role) {
        $ref = json_decode(file_get_contents($byRole[$role]), true);
        $ctx = caseCtx($vDir, $case, $ref);
        $b = BP::buildInput($ctx, $role);
        if (!$b['ok']) { say("  NG {$case} {$role} {$b['code']} {$b['reason']}"); $ng++; continue; }
        $built[$case.'|'.$role] = $b['input'];
        $diff = [];
        $keys = array_unique(array_merge(array_keys($ref), array_keys($b['input'])));
        sort($keys, SORT_STRING);
        foreach ($keys as $k) {
            $ja = BP::canonical($b['input'][$k] ?? '(なし)');
            $jb = BP::canonical($ref[$k] ?? '(なし)');
            if ($ja === $jb) continue;
            if (in_array($k, ['source_registry','input_indices','field_catalog','collection_audit'], true)) {
                $kk = array_unique(array_merge(array_keys((array)$ref[$k]), array_keys((array)$b['input'][$k])));
                sort($kk, SORT_STRING);
                foreach ($kk as $k2) {
                    $x = BP::canonical($b['input'][$k][$k2] ?? '(なし)');
                    $y = BP::canonical($ref[$k][$k2] ?? '(なし)');
                    if ($x !== $y) $diff[] = "$k.$k2 得=" . mb_strimwidth($x,0,120,'…') . ' 期=' . mb_strimwidth($y,0,120,'…');
                }
                continue;
            }
            $diff[] = "$k 得=" . mb_strimwidth($ja,0,150,'…') . ' 期=' . mb_strimwidth($jb,0,150,'…');
        }
        if ($diff === []) {
            printf("  OK %-26s %s  全%dキー一致 hash=%s\n", $case, $role, count($keys), substr($b['input']['snapshot_hash'],0,16));
        } else {
            printf("  NG %-26s %s  違い%d件\n", $case, $role, count($diff));
            foreach (array_slice($diff,0,10) as $d) say('      ' . $d);
            $ng += count($diff);
        }
    }
}

say('');
say('== §5 送信の一式 ==');
foreach ($cases as $case => $byRole) {
    foreach (['1st','2nd'] as $role) {
        $ref = json_decode(file_get_contents($byRole[$role]), true);
        $asm = BP::assemble(caseCtx($vDir, $case, $ref), $role);
        if (!$asm['ok']) { say("  NG {$case} {$role} {$asm['code']} {$asm['reason']}"); $ng++; continue; }
        printf("  OK %-26s %s system%7dB user%7dB 深さ%2d 点検%d件\n", $case, $role,
            strlen($asm['system']), $asm['user_bytes'], BP::depthOf($asm['input']), count($asm['issues']));
    }
}
say('');
say($ng === 0 ? '>>> 不一致 0 件' : ">>> 不一致 {$ng} 件");
file_put_contents(__DIR__ . '/built.json', json_encode($built));
