<?php
/**
 * 試験用の小さな代用品。Laravel の \DB と \Schema のうち、
 * BaganrikiWorker が使う分だけを PDO(sqlite) で動かします。
 * 本番では Laravel 本体が使われます。ここはコンテナで論理を回すためだけのものです。
 */
final class QtDb
{
    public static \PDO $pdo;
    public static int $depth = 0;
}

final class QtBuilder
{
    private array $w = [];
    private array $in = [];
    private array $order = [];
    public function __construct(private string $table) {}
    public function where($col, $op = null, $val = null): self
    {
        if (is_array($col)) { foreach ($col as $k => $v) { $this->w[] = [$k, '=', $v]; } return $this; }
        if ($val === null && !is_string($op)) { $this->w[] = [$col, '=', $op]; return $this; }
        if ($val === null && is_string($op) && !in_array($op, ['=', '<', '>', '<=', '>=', '!='], true)) {
            $this->w[] = [$col, '=', $op]; return $this;
        }
        if ($val === null) { $this->w[] = [$col, '=', $op]; return $this; }
        $this->w[] = [$col, $op, $val];
        return $this;
    }
    public function orderBy(string $c, string $d = 'asc'): self
    { $this->order[] = $c . ' ' . (strtolower($d) === 'desc' ? 'DESC' : 'ASC'); return $this; }
    public function orderByDesc(string $c): self { return $this->orderBy($c, 'desc'); }
    public function whereIn(string $c, array $v): self
    {
        $this->in[] = [$c, $v]; return $this;
    }
    public function increment(string $c, int $n = 1): int
    {
        $bind = [];
        $sql = "UPDATE \"{$this->table}\" SET \"$c\" = \"$c\" + " . (int) $n;
        $wb = []; $sql .= $this->sqlWhere($wb);
        $st = QtDb::$pdo->prepare($sql); $st->execute($wb); return $st->rowCount();
    }
    public function delete(): int
    {
        $bind = [];
        $sql = "DELETE FROM \"{$this->table}\"" . $this->sqlWhere($bind);
        $st = QtDb::$pdo->prepare($sql); $st->execute($bind); return $st->rowCount();
    }
    public function distinct(): self { return $this; }
    public function lockForUpdate(): self { return $this; }   // sqlite には不要
    private function sqlWhere(array &$bind): string
    {
        if ($this->w === [] && $this->in === []) { return ''; }
        $p = [];
        foreach ($this->w as [$c, $op, $v]) {
            if ($v === null && $op === '=') { $p[] = "\"$c\" IS NULL"; }
            else { $p[] = "\"$c\" $op ?"; $bind[] = $v; }
        }
        foreach ($this->in as [$c, $vs]) {
            if ($vs === []) { $p[] = '0=1'; continue; }
            $p[] = "\"$c\" IN (" . implode(',', array_fill(0, count($vs), '?')) . ')';
            foreach ($vs as $v) { $bind[] = $v; }
        }
        return ' WHERE ' . implode(' AND ', $p);
    }
    private function sqlOrder(): string
    { return ($this->order === []) ? '' : (' ORDER BY ' . implode(', ', $this->order)); }
    public function get(array $cols = ['*']): array
    {
        $bind = [];
        $sel = ($cols === ['*']) ? '*' : implode(',', array_map(fn($c) => "\"$c\"", $cols));
        $st = QtDb::$pdo->prepare("SELECT $sel FROM \"{$this->table}\""
                                  . $this->sqlWhere($bind) . $this->sqlOrder());
        $st->execute($bind);
        return array_map(fn($r) => (object) $r, $st->fetchAll(\PDO::FETCH_ASSOC));
    }
    public function first(array $cols = ['*'])
    { $r = $this->get($cols); return $r === [] ? null : $r[0]; }
    public function exists(): bool { return $this->count() > 0; }
    public function count(): int
    {
        $bind = [];
        $st = QtDb::$pdo->prepare("SELECT COUNT(*) c FROM \"{$this->table}\"" . $this->sqlWhere($bind));
        $st->execute($bind);
        return (int) $st->fetch(\PDO::FETCH_ASSOC)['c'];
    }
    public function value(string $col)
    { $r = $this->first([$col]); return ($r === null) ? null : $r->{$col}; }
    public function pluck(string $col): QtColl
    {
        $o = [];
        foreach ($this->get([$col]) as $r) { $o[] = $r->{$col}; }
        return new QtColl($o);
    }
    public function insert(array $rows): bool
    {
        if ($rows === []) { return true; }
        if (!is_array(reset($rows))) { $rows = [$rows]; }
        foreach ($rows as $row) { $this->one($row, false); }
        return true;
    }
    public function insertOrIgnore(array $row): bool { $this->one($row, true); return true; }
    public function insertGetId(array $row): int
    { $this->one($row, false); return (int) QtDb::$pdo->lastInsertId(); }
    private function one(array $row, bool $ignore): void
    {
        $cols = array_keys($row);
        $sql = 'INSERT ' . ($ignore ? 'OR IGNORE ' : '') . "INTO \"{$this->table}\" ("
             . implode(',', array_map(fn($c) => "\"$c\"", $cols)) . ') VALUES ('
             . implode(',', array_fill(0, count($cols), '?')) . ')';
        QtDb::$pdo->prepare($sql)->execute(array_map(
            fn($v) => is_bool($v) ? (int) $v : $v, array_values($row)));
    }
    public function update(array $set): int
    {
        $bind = [];
        $p = [];
        foreach ($set as $c => $v) { $p[] = "\"$c\" = ?"; $bind[] = is_bool($v) ? (int) $v : $v; }
        $sql = "UPDATE \"{$this->table}\" SET " . implode(', ', $p);
        $wb = [];
        $sql .= $this->sqlWhere($wb);
        $st = QtDb::$pdo->prepare($sql);
        $st->execute(array_merge($bind, $wb));
        return $st->rowCount();
    }
}

final class QtColl
{
    public function __construct(private array $a) {}
    public function all(): array { return $this->a; }
}

final class QtRows implements ArrayAccess, IteratorAggregate, Countable
{
    public function __construct(private array $a) {}
    public function keyBy(string $k): self
    {
        $o = [];
        foreach ($this->a as $r) { $o[$r->{$k}] = $r; }
        return new self($o);
    }
    public function pluck(string $k): QtColl
    {
        $o = [];
        foreach ($this->a as $r) { $o[] = $r->{$k}; }
        return new QtColl($o);
    }
    public function getIterator(): Iterator { return new ArrayIterator($this->a); }
    public function offsetExists($i): bool { return isset($this->a[$i]); }
    public function offsetGet($i): mixed { return $this->a[$i] ?? null; }
    public function offsetSet($i, $v): void { $this->a[$i] = $v; }
    public function offsetUnset($i): void { unset($this->a[$i]); }
    public function count(): int { return count($this->a); }
}

final class DB
{
    public static function table(string $t): QtBuilder { return new QtBuilder($t); }
    public static function beginTransaction(): void
    {
        if (QtDb::$depth === 0) { QtDb::$pdo->beginTransaction(); }
        else { QtDb::$pdo->exec('SAVEPOINT sp' . QtDb::$depth); }
        QtDb::$depth++;
    }
    public static function rollBack(): void
    {
        QtDb::$depth--;
        if (QtDb::$depth === 0) { QtDb::$pdo->rollBack(); }
        else { QtDb::$pdo->exec('ROLLBACK TO SAVEPOINT sp' . QtDb::$depth); }
    }
    public static function commit(): void
    {
        QtDb::$depth--;
        if (QtDb::$depth === 0) { QtDb::$pdo->commit(); }
        else { QtDb::$pdo->exec('RELEASE SAVEPOINT sp' . QtDb::$depth); }
    }
    public static function transaction(callable $f)
    {
        self::beginTransaction();
        try { $r = $f(); self::commit(); return $r; }
        catch (\Throwable $e) { self::rollBack(); throw $e; }
    }
}

final class Schema
{
    public static function hasTable(string $t): bool
    {
        $st = QtDb::$pdo->prepare(
            "SELECT COUNT(*) c FROM sqlite_master WHERE type='table' AND name=?");
        $st->execute([$t]);
        return ((int) $st->fetch(\PDO::FETCH_ASSOC)['c']) > 0;
    }
}

eval('namespace Illuminate\\Database; class QueryException extends \\RuntimeException {}');

function env($k, $d = null) { return $d; }

function qt_schema(): void
{
    QtDb::$pdo->exec('CREATE TABLE baganriki_snapshots (
        id INTEGER PRIMARY KEY AUTOINCREMENT, race_id TEXT NOT NULL,
        generation INTEGER NOT NULL DEFAULT 0, run_id TEXT, release_version TEXT,
        common_json TEXT, input_json_1st TEXT, input_json_2nd TEXT, snapshot_hash TEXT,
        frozen_nums TEXT, frozen_rank TEXT, mode TEXT, mode_status TEXT,
        allocation_mode TEXT, mode_policy_id TEXT, display_rating INTEGER,
        signals TEXT, s_min INTEGER, s_max INTEGER, s0 INTEGER, target_count INTEGER,
        quota_1st TEXT, quota_2nd TEXT, quota_adjustments TEXT, collection_audit TEXT,
        coverage TEXT, anchor_at TEXT, cutoff_at TEXT, input_freeze_at TEXT,
        frozen_at TEXT, sales_close_at TEXT, input_invalid_code TEXT,
        input_invalid_reason TEXT, created_at TEXT NOT NULL,
        UNIQUE (race_id, generation))');
    QtDb::$pdo->exec('CREATE TABLE baganriki_ai_attempts (
        id INTEGER PRIMARY KEY AUTOINCREMENT, snapshot_id INTEGER NOT NULL,
        role TEXT NOT NULL, attempt_no INTEGER NOT NULL, token TEXT NOT NULL UNIQUE,
        status TEXT NOT NULL DEFAULT "RESERVED", reserved_at TEXT, received_at TEXT,
        complete INTEGER NOT NULL DEFAULT 0, raw_response TEXT, response_hash TEXT,
        failure_reason TEXT, UNIQUE (snapshot_id, role, attempt_no))');
    QtDb::$pdo->exec('CREATE TABLE baganriki_live_states (
        id INTEGER PRIMARY KEY AUTOINCREMENT, snapshot_id INTEGER NOT NULL UNIQUE,
        cancellations TEXT, active_count INTEGER, live_target_count INTEGER,
        live_quota TEXT, live_close TEXT, state_revision INTEGER NOT NULL DEFAULT 0,
        response_revision INTEGER NOT NULL DEFAULT 0,
        publication_revision INTEGER NOT NULL DEFAULT 0,
        latest_publication_id TEXT, updated_at TEXT NOT NULL)');
    QtDb::$pdo->exec('CREATE TABLE baganriki_audit_events (
        id INTEGER PRIMARY KEY AUTOINCREMENT, race_id TEXT NOT NULL,
        snapshot_id INTEGER, kind TEXT NOT NULL, happened_at TEXT NOT NULL,
        old_revision INTEGER, new_revision INTEGER, diagnostics TEXT, related_id TEXT)');
}
