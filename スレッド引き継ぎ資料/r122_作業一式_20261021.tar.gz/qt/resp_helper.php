<?php
final class QtJson {
    public function __construct(private $data, private int $status = 200) {}
    public function getData(bool $assoc = false) {
        return $assoc ? json_decode(json_encode($this->data), true) : $this->data;
    }
    public function status(): int { return $this->status; }
}
final class QtResponder {
    public function json($d, int $s = 200): QtJson { return new QtJson($d, $s); }
}
function response(): QtResponder { return new QtResponder(); }
final class Log { public static function __callStatic($m, $a) {} }
