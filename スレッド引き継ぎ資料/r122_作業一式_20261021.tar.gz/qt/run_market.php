<?php
require __DIR__ . '/shim.php';
require __DIR__ . '/tail_classes.php';
require __DIR__ . '/ctrl_past.php';
QtDb::$pdo = new PDO('sqlite:' . __DIR__ . '/past.sqlite');
QtDb::$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
use App\Http\Controllers\Api\PastCtl;

// 凍結人気（1〜13）と6分前のオッズ（十進数の文字列）
$rank = []; $cells = [];
$win = ['2.1','3.8','5.4','7.9','11.2','16.5','24.0','35.1','48.6','70.2','95.4','120.0','150.0'];
$fuk = ['1.2','1.4','1.6','1.9','2.4','3.0','4.1','5.2','6.8','8.9','11.5','14.0','18.0'];
for ($i = 1; $i <= 13; $i++) {
    $rank[$i] = $i;
    $cells[$i][6]['win_odds']  = $win[$i - 1];
    $cells[$i][6]['place_min'] = $fuk[$i - 1];
}

function show(string $label, string $date, string $freeze) {
    global $rank, $cells;
    $r = PastCtl::r122MarketPriorRegistry('TEST-' . $date, $date, $rank, $cells, $freeze);
    printf("\n== %s （対象日 %s）==\n", $label, $date);
    printf("  registry %d 件\n", count($r['registry']));
    foreach (['OPI', 'estimated_odds'] as $k) {
        $c = $r['coverage'][$k];
        printf("  %-16s %s  %s\n", $k, $c['status'],
            $c['status'] === 'INCLUDED'
              ? ('出典 ' . count($c['source_refs']) . ' 件')
              : mb_strimwidth((string) $c['reason'], 0, 70, '…'));
    }
    return $r;
}

// ① 10/18 のレース（集計の end_date が当日・補正は算出が10/19）→ 使えない
show('当日を含む集計', '2026-10-18', '2026-10-18T09:59:30.000000+09:00');

// ② 10/25 のレース（end_date 10/18 < 10/25、補正の算出 10/19 < 情報上限）→ 使える
$r = show('期間が終わっている集計', '2026-10-25', '2026-10-25T09:59:30.000000+09:00');
file_put_contents(__DIR__ . '/market_registry.json',
  json_encode($r['registry'], JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT));
echo "\n  -- 1番人気の馬（6分前 2.1倍）--\n";
foreach ($r['registry'] as $k => $e) {
    if (strpos($k, 'h1_') !== 0) continue;
    printf("    %-30s %-10s %s\n", $k, var_export($e['value'], true), $e['source_kind']);
}
echo "\n  -- 期待値の検算（1番人気）--\n";
printf("    OPI            2.6 / 2.1  = %.2f\n", round(2.6 / 2.1, 2));
printf("    複勝OPI        1.3 / 1.2  = %.2f\n", round(1.3 / 1.2, 2));
printf("    推定確定オッズ 2.1 × 0.9820 = %.2f\n", round(2.1 * 0.9820, 2));
printf("    予測補正OPI    2.6 / %.2f = %.2f\n", round(2.1 * 0.9820, 2),
    round(2.6 / round(2.1 * 0.9820, 2), 2));
