<?php
require __DIR__ . '/shim.php';
require __DIR__ . '/tail_classes.php';
require __DIR__ . '/ctrl_past.php';

QtDb::$pdo = new PDO('sqlite:' . __DIR__ . '/past.sqlite');
QtDb::$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

use App\Http\Controllers\Api\PastCtl;

$nums = [
  1 => 'シーラーステート', 2 => 'ブルーリボン', 3 => 'サノノベリー',
  4 => 'シークレットタワー', 5 => 'ニシノアトール', 6 => 'ナナレイ',
  7 => 'ステラヴェント', 8 => 'ジャスパーレーブ', 9 => 'シクラメン',
  10 => 'ゴールドショーマン', 11 => 'ルナディアナ', 12 => 'コスモルトチェコ',
  13 => 'ワイドアイリー',
];
// 発走 10:05 の 2026-10-18 → 入力の凍結は 09:59:30
$freeze = '2026-10-18T09:59:30.000000+09:00';
$r = PastCtl::r122PastRunsRegistry('20261018-4-04-2-1', '2026-10-18', $nums, $freeze);
printf("registry %d 件 / %d 頭ぶん\n", count($r['registry']), $r['horses_with_past'] ?? 0);
printf("coverage past_runs = %s\n", $r['coverage']['past_runs']['status']);
file_put_contents(__DIR__ . '/past_registry.json',
  json_encode($r['registry'], JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT));
// 1頭ぶんのぞき見
$i = 0;
foreach ($r['registry'] as $k => $e) {
  if (strpos($k, 'h3_') !== 0) continue;
  printf("  %-26s %-18s %s\n", $k, var_export($e['value'], true), $e['source_kind']);
  if (++$i > 12) break;
}
