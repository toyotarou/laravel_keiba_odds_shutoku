<?php
require __DIR__ . '/shim.php';
require __DIR__ . '/time.php';
require __DIR__ . '/worker.php';
function qt_out($s = '') { echo $s . "\n"; }
QtDb::$pdo = new PDO('sqlite::memory:');
QtDb::$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
qt_schema();
(function () {

        

        qt_out('════════════════════════════════════════════════════════');
        qt_out(' r12.2 キューと永続予約の通し試験');
        qt_out('════════════════════════════════════════════════════════');
        qt_out('  実行時刻 : ' . date('c'));
        qt_out('  ※ 全部ロールバックします。DBへ残る書き込みは0件です');
        qt_out('');

        if (!BaganrikiWorker::ready()) {
            qt_out('  × 必要な表がありません'
                . '（baganriki_snapshots / _ai_attempts / _live_states / _audit_events）');
            return;
        }

        $pass = 0; $fail = 0;
        $check = function (string $id, string $what, $got, $want) use (&$pass, &$fail) {
            $okk = ($got === $want);
            if ($okk) { $pass++; } else { $fail++; }
            qt_out(sprintf('  %s %-10s %-52s %s',
                $okk ? '○' : '×', $id, $what,
                $okk ? '' : ('得=' . var_export($got, true) . ' 期待=' . var_export($want, true))));
        };

        // 試験用の凍結入力を作る小さな道具
        $j = static fn($v) => (string) json_encode($v,
            JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        $mkSnap = function (string $raceId, int $salesUs, int $active, int $gen = 900)
                  use ($j): int {
            $id = \DB::table('baganriki_snapshots')->insertGetId([
                'race_id' => $raceId, 'generation' => $gen, 'run_id' => 'QT-' . $raceId,
                'release_version' => BaganrikiPrompt::PROMPT_VERSION,
                'snapshot_hash'  => hash('sha256', $raceId),
                'frozen_nums'    => $j(range(1, max(1, $active))),
                'target_count'   => 5,
                'quota_1st'      => $j([3, 2, 0]),
                'sales_close_at' => BaganrikiWorker::toDb($salesUs),
                'created_at'     => BaganrikiWorker::toDb(BaganrikiWorker::nowUs()),
            ]);
            \DB::table('baganriki_live_states')->insert([
                'snapshot_id' => $id, 'cancellations' => $j([]),
                'active_count' => $active, 'live_target_count' => 5,
                'live_quota' => $j([3, 2, 0]), 'live_close' => null,
                'state_revision' => 0, 'response_revision' => 0,
                'publication_revision' => 0, 'latest_publication_id' => null,
                'updated_at' => BaganrikiWorker::toDb(BaganrikiWorker::nowUs()),
            ]);
            return (int) $id;
        };
        $rev = static fn(int $sid) => (int) \DB::table('baganriki_live_states')
                 ->where('snapshot_id', $sid)->value('response_revision');

        $ok = true;
        \DB::beginTransaction();
        try {
            // 現在時刻は「期限のだいぶ前」に置きます
            $now   = BaganrikiWorker::nowUs();
            $sales = $now + 3600 * 1000000;          // 投票締切は1時間後
            $dl    = BaganrikiTime::effectiveDeadlines($sales, null);

            qt_out('── ① 初回の予約と送信許可 ──');
            $sid = $mkSnap('QT-20261020-A', $sales, 16);
            $r = BaganrikiWorker::reserve($sid, '1st', 0, $now);
            $check('Q-01', '初回の枠を予約できる', $r['ok'], true);
            $tok1 = (string) ($r['token'] ?? '');
            $check('Q-02', '予約で response_revision が1増える', $rev($sid), 1);

            $r2 = BaganrikiWorker::reserve($sid, '1st', 0, $now);
            $check('Q-03', '同じ枠は作り直さない', $r2['code'], 'SLOT_TAKEN');
            $check('Q-04', '作り直さないので版も増えない', $rev($sid), 1);

            $g = BaganrikiWorker::reserve($sid, '1st', 1, $now);
            $check('Q-05', '初回が未受領なら訂正を予約しない', $g['code'], 'FIRST_NOT_RECEIVED');

            $rc = BaganrikiWorker::receive($tok1, '{"a":1}', true, $now);
            $check('Q-06', '送信許可の前に受領はできない', $rc['code'], 'NOT_SENT');

            $s = BaganrikiWorker::allowSend($tok1, $now);
            $check('Q-07', '送信許可が出る', $s['ok'], true);
            $s2 = BaganrikiWorker::allowSend($tok1, $now);
            $check('Q-08', '送信許可は1回だけ', $s2['code'], 'ALREADY_SENT');

            qt_out('── ② 受領の冪等と付け替えの拒否 ──');
            $rc = BaganrikiWorker::receive($tok1, '{"a":1}', true, $now + 1000);
            $check('Q-09', '原応答を保存できる', $rc['ok'], true);
            $check('Q-10', '受領で version が1増える', $rev($sid), 2);
            $rc2 = BaganrikiWorker::receive($tok1, '{"a":1}', true, $now + 2000);
            $check('Q-11', '同じ応答の再保存は冪等', $rc2['code'], 'IDEMPOTENT');
            $check('Q-12', '冪等なら版は増えない', $rev($sid), 2);
            $rc3 = BaganrikiWorker::receive($tok1, '{"a":2}', true, $now + 3000);
            $check('Q-13', '別の応答は保存しない', $rc3['code'], 'RESPONSE_MISMATCH');
            $f = BaganrikiWorker::fail($tok1, 'あとから失敗にしてみる', $now + 4000);
            $check('Q-14', '終端の付け替えは拒否', $f['code'], 'TERMINAL');

            qt_out('── ③ 訂正の枠 ──');
            $g = BaganrikiWorker::fixAllowed($sid, '1st');
            $check('Q-15', '初回がcomplete=trueなら訂正できる', $g['ok'], true);
            $rf = BaganrikiWorker::reserve($sid, '1st', 1, $now + 5000);
            $check('Q-16', '訂正の枠を予約できる', $rf['ok'], true);
            $tokF = (string) ($rf['token'] ?? '');
            $check('Q-17', '訂正の予約で版が1増える', $rev($sid), 3);
            $r3 = BaganrikiWorker::reserve($sid, '1st', 2, $now + 6000);
            $check('Q-18', '3つめの枠は作らない', $r3['code'], 'INVALID_ATTEMPT');
            $g2 = BaganrikiWorker::fixAllowed($sid, '1st');
            $check('Q-19', '訂正の枠はもう作り直さない', $g2['code'], 'SLOT_TAKEN');

            BaganrikiWorker::allowSend($tokF, $now + 7000);
            $rbad = BaganrikiWorker::receive($tokF, '{"fix":1}', true, $now - 10000);
            $check('Q-20', '訂正の受領が初回より前なら拒否', $rbad['code'], 'RECEIVE_ORDER');
            $rgood = BaganrikiWorker::receive($tokF, '{"fix":1}', true, $now + 8000);
            $check('Q-21', '訂正の受領（初回以降の時刻）は通る', $rgood['ok'], true);
            $u = BaganrikiWorker::usable($sid, '1st');
            $check('Q-22', '選出には訂正を使う', $u['attempt_no'] ?? null, 1);
            $check('Q-23', '版は 予約2＋終端2 = 4', $rev($sid), 4);

            qt_out('── ④ complete=false は選出に使わない ──');
            $sidB = $mkSnap('QT-20261020-B', $sales, 14);
            $rb = BaganrikiWorker::reserve($sidB, '2nd', 0, $now);
            $tokB = (string) ($rb['token'] ?? '');
            BaganrikiWorker::allowSend($tokB, $now);
            $rcb = BaganrikiWorker::receive($tokB, '{"partial":true}', false, $now + 1000);
            $check('Q-24', 'complete=false でも本文は保存する', $rcb['ok'], true);
            $ub = BaganrikiWorker::usable($sidB, '2nd');
            $check('Q-25', 'complete=false は選出に使わない', $ub['code'], 'NONE');
            $gb = BaganrikiWorker::fixAllowed($sidB, '2nd');
            $check('Q-26', 'complete=false では訂正を予約しない', $gb['code'], 'FIRST_NOT_COMPLETE');

            qt_out('── ⑤ 期限・全頭取消・版の変化 ──');
            $sidC = $mkSnap('QT-20261020-C', $sales, 12);
            $late = BaganrikiWorker::reserve($sidC, '1st', 0, (int) $dl['reply'] + 1);
            $check('Q-27', '応答期限を1マイクロ秒でも超えたら予約しない',
                   $late['code'], 'DEADLINE_PASSED');
            $just = BaganrikiWorker::reserve($sidC, '1st', 0, (int) $dl['reply']);
            $check('Q-28', '期限ちょうどは予約できる', $just['ok'], true);

            $sidD = $mkSnap('QT-20261020-D', $sales, 0);
            $allc = BaganrikiWorker::reserve($sidD, '1st', 0, $now);
            $check('Q-29', '全頭取消では予約しない', $allc['code'], 'ALL_CANCELLED');

            $sidE = $mkSnap('QT-20261020-E', $sales, 10);
            BaganrikiWorker::reserve($sidE, '1st', 0, $now);              // ここで版が1になる
            $stale = BaganrikiWorker::reserve($sidE, '2nd', 0, $now, ['response_revision' => 0]);
            $check('Q-30', '版が変わっていたら予約しない', $stale['code'], 'STATE_CHANGED');
            $fresh = BaganrikiWorker::reserve($sidE, '2nd', 0, $now, ['response_revision' => 1]);
            $check('Q-31', '版が合っていれば予約できる', $fresh['ok'], true);

            qt_out('── ⑥ 再起動（結果不明にして再送しない）──');
            $sidF = $mkSnap('QT-20261020-F', $sales, 16);
            $t1 = (string) BaganrikiWorker::reserve($sidF, '1st', 0, $now)['token'];
            BaganrikiWorker::allowSend($t1, $now);                         // SENT のまま落ちた
            $t2 = (string) BaganrikiWorker::reserve($sidF, '2nd', 0, $now)['token'];  // RESERVED のまま
            $before = $rev($sidF);
            $rs = BaganrikiWorker::resume($sidF, $now + 1000);
            $check('Q-32', '送信済みは結果不明にする', $rs['unknown'], ['1st#0']);
            $check('Q-33', '未送信の枠はそのまま残す', $rs['reserved_kept'], ['2nd#0']);
            $check('Q-34', '結果不明は終端なので版が1増える', $rev($sidF), $before + 1);
            $again = BaganrikiWorker::reserve($sidF, '1st', 0, $now + 2000);
            $check('Q-35', '再起動でも枠は作り直さない', $again['code'], 'SLOT_TAKEN');
            $gf = BaganrikiWorker::fixAllowed($sidF, '1st');
            $check('Q-36', '結果不明の初回では訂正を予約しない', $gf['code'], 'FIRST_FAILED');
            $sr = BaganrikiWorker::allowSend($t2, $now + 3000);
            $check('Q-37', '未送信だった枠は送信許可が1回残る', $sr['ok'], true);
            $rs2 = BaganrikiWorker::resume($sidF, $now + 4000);
            $check('Q-38', '2回目の再起動で終端は動かさない', $rs2['unknown'], ['2nd#0']);

            qt_out('── ⑦ 読み取りに token と原文を出さない ──');
            $sl = BaganrikiWorker::slots($sid, '1st');
            $keys = ($sl === []) ? [] : array_keys($sl[0]);
            $check('Q-39', 'slots に token は無い', in_array('token', $keys, true), false);
            $check('Q-40', 'slots に原文は無い', in_array('raw_response', $keys, true), false);
            $check('Q-41', 'slots は2枠を返す', count($sl), 2);

            qt_out('── ⑧ 監査が残っているか ──');
            $ev = \DB::table('baganriki_audit_events')
                    ->where('race_id', 'QT-20261020-A')->pluck('kind')->all();
            $check('Q-42', 'Aレースの監査は 予約・送信・受領 で6件', count($ev), 6);
            $check('Q-43', '予約の監査が2件', count(array_filter($ev,
                   static fn($k) => $k === 'QUEUE_RESERVED')), 2);
            $evF = \DB::table('baganriki_audit_events')
                     ->where('race_id', 'QT-20261020-F')
                     ->where('kind', 'QUEUE_UNKNOWN_RESULT')->count();
            $check('Q-44', '結果不明の監査が2件', $evF, 2);

            // ───────────────────────────────────────────────────────────
            // ⑨ 送信口（r122QueueReserve / Receive / Fail）のつなぎ
            //    実AIは呼びません。凍結入力は試験用に1件だけ入れます。
            // ───────────────────────────────────────────────────────────
            if (function_exists('app')) {
                qt_out('── ⑨ 送信口のつなぎ（実AIは呼びません）──');
                $ctrl  = app(AiController::class);
                $keep  = [getenv('BAGANRIKI_R122_QUEUE'),
                          $_ENV['BAGANRIKI_R122_QUEUE'] ?? null,
                          $_SERVER['BAGANRIKI_R122_QUEUE'] ?? null];
                try {
                    // 旗が下りているときは素通り（1バイトも変わらない）
                    putenv('BAGANRIKI_R122_QUEUE=0');
                    $_ENV['BAGANRIKI_R122_QUEUE'] = '0';
                    $_SERVER['BAGANRIKI_R122_QUEUE'] = '0';
                    $w = $ctrl->r122QueueReserve('2026-10-18', '4', '04', '2', 1,
                                                 '1st', ['snapshot_hash' => 'x']);
                    $check('W-01', '旗が0なら素通りする（skip）', $w['skip'], true);

                    // 旗を上げて、試験用の凍結入力（generation=0）を1件だけ置きます。
                    //   すでに固定済みなので r122Freeze は呼ばれません。
                    putenv('BAGANRIKI_R122_QUEUE=1');
                    $_ENV['BAGANRIKI_R122_QUEUE'] = '1';
                    $_SERVER['BAGANRIKI_R122_QUEUE'] = '1';
                    $rid  = AiController::r122RaceId(
                                '2026-10-18', '4', '04', '2', 1);
                    $hash = hash('sha256', $rid);
                    $sidW = \DB::table('baganriki_snapshots')->insertGetId([
                        'race_id' => $rid, 'generation' => 0, 'run_id' => 'QT-W',
                        'snapshot_hash' => $hash, 'frozen_nums' => $j(range(1, 12)),
                        'target_count' => 5, 'quota_1st' => $j([3, 2, 0]),
                        'sales_close_at' => BaganrikiWorker::toDb($sales),
                        'created_at' => BaganrikiWorker::toDb($now),
                    ]);
                    \DB::table('baganriki_live_states')->insert([
                        'snapshot_id' => $sidW, 'cancellations' => $j([]),
                        'active_count' => 12, 'live_target_count' => 5,
                        'live_quota' => $j([3, 2, 0]), 'live_close' => null,
                        'state_revision' => 0, 'response_revision' => 0,
                        'publication_revision' => 0, 'latest_publication_id' => null,
                        'updated_at' => BaganrikiWorker::toDb($now),
                    ]);

                    // 固定した入力と送信文のhashが違えば送りません
                    $wNg = $ctrl->r122QueueReserve('2026-10-18', '4', '04', '2', 1,
                               '1st', ['snapshot_hash' => 'ちがうhash']);
                    $check('W-02', 'hashが違えば送らない', $wNg['code'], 'SNAPSHOT_MISMATCH');

                    // hashが合えば予約して送信許可まで進みます
                    $wOk = $ctrl->r122QueueReserve('2026-10-18', '4', '04', '2', 1,
                               '1st', ['snapshot_hash' => $hash]);
                    $check('W-03', 'hashが合えば枠を取って送信許可まで進む', $wOk['ok'], true);
                    $check('W-04', '予約した枠は初回（0）', (int) \DB::table('baganriki_ai_attempts')
                        ->where('snapshot_id', $sidW)->value('attempt_no'), 0);

                    // 2回目は送りません（重複送信の防止）
                    $wAgain = $ctrl->r122QueueReserve('2026-10-18', '4', '04', '2', 1,
                                  '1st', ['snapshot_hash' => $hash]);
                    $check('W-05', '2回目は送らない', $wAgain['code'], 'SLOT_TAKEN');

                    $cw = $ctrl->r122QueueReceive($wOk, '{"w":1}', true);
                    $check('W-06', '送信口から原応答を保存できる', $cw['ok'], true);
                    $cw2 = $ctrl->r122QueueReceive($wOk, '{"w":1}', true);
                    $check('W-07', '送信口から2回保存しても冪等', $cw2['code'], 'IDEMPOTENT');
                    $fw = $ctrl->r122QueueFail($wOk, '試験', true);
                    $check('W-08', '終端になった枠は付け替えない', $fw['code'], 'TERMINAL');
                    $cwS = $ctrl->r122QueueReceive(['skip' => true, 'ok' => false],
                               '{"w":2}', true);
                    $check('W-09', '素通りの枠には何もしない', $cwS['skip'], true);
                } finally {
                    // 旗を元へ戻します（この後の処理に残さないため）
                    if ($keep[0] === false) { putenv('BAGANRIKI_R122_QUEUE'); }
                    else { putenv('BAGANRIKI_R122_QUEUE=' . $keep[0]); }
                    if ($keep[1] === null) { unset($_ENV['BAGANRIKI_R122_QUEUE']); }
                    else { $_ENV['BAGANRIKI_R122_QUEUE'] = $keep[1]; }
                    if ($keep[2] === null) { unset($_SERVER['BAGANRIKI_R122_QUEUE']); }
                    else { $_SERVER['BAGANRIKI_R122_QUEUE'] = $keep[2]; }
                }
            }

        } catch (\Throwable $e) {
            $ok = false; $fail++;
            qt_out('  × 例外: ' . $e->getMessage());
            qt_out('     ' . $e->getFile() . ':' . $e->getLine());
        } finally {
            \DB::rollBack();
        }

        $n1 = \DB::table('baganriki_snapshots')->count();
        $n2 = \DB::table('baganriki_ai_attempts')->count();
        $n3 = \DB::table('baganriki_live_states')->count();
        $n4 = \DB::table('baganriki_audit_events')->count();
        qt_out('');
        qt_out(sprintf('  ロールバック後  snapshot %d／attempts %d／live %d／audit %d',
            $n1, $n2, $n3, $n4));
        qt_out('');
        qt_out('  判定件数 : ' . ($pass + $fail) . ' 件');
        qt_out('  合格     : ' . $pass . ' 件');
        qt_out('  不合格   : ' . $fail . ' 件');
        qt_out('');
        qt_out('════════════════════════════════════════════════════════');
        qt_out(($fail === 0 && $ok)
            ? ' キューと永続予約は契約どおりに動きました（DBへ残る書き込み0件）'
            : ' 通らなかった箇所があります。上の × をご確認ください');
        qt_out('════════════════════════════════════════════════════════');
    
})();
