<?php
final class BaganrikiPrompt { const PROMPT_VERSION = 'baganriki-v041-r12-2-20261020'; }
final class BaganrikiTime
{
    /** スロットごとの取得猶予（ミリ秒）。ここに無い時点は予想入力に使いません */
    public const GRACE_MS = [21 => 120000, 18 => 120000, 15 => 120000,
                             12 => 120000,  9 => 120000,  6 =>  30000];

    /** 予想入力に使うスロット（30分前・3分前・発走時は入りません） */
    public const INPUT_SLOTS = [21, 18, 15, 12, 9, 6];

    /** 取消の監視だけに読むスロット（数値は信号へ入れません） */
    public const WATCH_SLOTS = [3, 0];

    public const CUTOFF_OFFSET_SEC       = -360;   // T − 360秒
    public const INPUT_FREEZE_OFFSET_SEC = -330;   // T − 330秒
    public const SAFETY_MARGIN_SEC       = 60;     // safety_margin_ms = 60,000
    public const REPLY_BEFORE_PUBLISH_SEC = 30;    // reply_before_publish_ms = 30,000

    private const US = 1000000;

    /**
     * RFC3339 をマイクロ秒の整数へ。読めなければ null。
     * 小数秒は0〜6桁だけ。7桁以上は切り捨てずに拒否します（契約12章）。
     */
    public static function us(?string $t): ?int
    {
        if ($t === null) { return null; }
        $re = '/^(\d{4}-\d{2}-\d{2})[Tt](\d{2}:\d{2}:\d{2})(\.\d{1,6})?([Zz]|[+\-]\d{2}:\d{2})$/';
        if (!preg_match($re, $t, $m)) { return null; }
        $frac = isset($m[3]) ? str_pad(substr($m[3], 1), 6, '0') : '000000';
        $tz   = (strtoupper($m[4]) === 'Z') ? '+00:00' : $m[4];
        $d = \DateTimeImmutable::createFromFormat('Y-m-d H:i:sP', $m[1] . ' ' . $m[2] . $tz);
        if ($d === false) { return null; }
        return $d->getTimestamp() * self::US + (int) $frac;
    }

    /** マイクロ秒の整数を日本時間のRFC3339へ（表示・監査用） */
    public static function toJst(int $us): string
    {
        $d = (new \DateTimeImmutable('@' . intdiv($us, self::US)))
                ->setTimezone(new \DateTimeZone('Asia/Tokyo'));
        $f = $us % self::US;
        if ($f < 0) { $f += self::US; }
        return $d->format('Y-m-d\TH:i:s') . sprintf('.%06d', $f) . $d->format('P');
    }

    public static function slotScheduled(int $anchorUs, int $slotMin): int
    { return $anchorUs - $slotMin * 60 * self::US; }

    public static function slotDeadline(int $anchorUs, int $slotMin): ?int
    {
        if (!isset(self::GRACE_MS[$slotMin])) { return null; }
        return self::slotScheduled($anchorUs, $slotMin) + self::GRACE_MS[$slotMin] * 1000;
    }

    public static function cutoff(int $anchorUs): int
    { return $anchorUs + self::CUTOFF_OFFSET_SEC * self::US; }

    public static function inputFreeze(int $anchorUs): int
    { return $anchorUs + self::INPUT_FREEZE_OFFSET_SEC * self::US; }

    public static function publishDeadline(int $salesCloseUs): int
    { return $salesCloseUs - self::SAFETY_MARGIN_SEC * self::US; }

    public static function replyDeadline(int $salesCloseUs): int
    { return self::publishDeadline($salesCloseUs) - self::REPLY_BEFORE_PUBLISH_SEC * self::US; }

    /**
     * 締切の前倒しを反映した実効期限。延長では猶予を増やしません。
     * $liveCloseUs が null なら前倒しなし。
     */
    public static function effectiveDeadlines(int $salesCloseUs, ?int $liveCloseUs): array
    {
        $pub = self::publishDeadline($salesCloseUs);
        $rep = self::replyDeadline($salesCloseUs);
        if ($liveCloseUs !== null) {
            $pub = min($pub, $liveCloseUs - self::SAFETY_MARGIN_SEC * self::US);
        }
        $rep = min($rep, $pub - self::REPLY_BEFORE_PUBLISH_SEC * self::US);
        return ['publish' => $pub, 'reply' => $rep];
    }

    /**
     * 1バッチを採用してよいか。期限ちょうどは可、1マイクロ秒でも後なら不可。
     * @return array ['ok'=>bool, 'reason'=>string|null, 'code'=>string|null]
     */
    public static function acceptBatch(int $slot, array $b, ?int $anchorUs = null): array
    {
        if (!isset(self::GRACE_MS[$slot])) {
            return ['ok' => false, 'code' => 'SLOT_NOT_INPUT',
                    'reason' => '予想に使わないスロット（21/18/15/12/9/6分前だけ）'];
        }
        $need = ['request_started_at', 'response_received_at', 'available_at', 'input_freeze_at'];
        $v = [];
        foreach ($need as $k) {
            $v[$k] = self::us($b[$k] ?? null);
            if ($v[$k] === null) {
                return ['ok' => false, 'code' => 'TIME_UNREADABLE',
                        'reason' => $k . ' が無いか日時として読めない'];
            }
        }
        // 予定時刻は、与えられていれば使い、無ければ発走時刻から作ります
        $sch = self::us($b['slot_scheduled_at'] ?? null);
        if ($sch === null) {
            if ($anchorUs === null) {
                return ['ok' => false, 'code' => 'TIME_UNREADABLE',
                        'reason' => 'slot_scheduled_at も発走時刻も無い'];
            }
            $sch = self::slotScheduled($anchorUs, $slot);
        }
        $deadline = $sch + self::GRACE_MS[$slot] * 1000;

        if ($v['request_started_at']   < $sch)
            return ['ok' => false, 'code' => 'REQUEST_BEFORE_SCHEDULE', 'reason' => '要求開始が予定時刻より前'];
        if ($v['response_received_at'] < $v['request_started_at'])
            return ['ok' => false, 'code' => 'CLOCK_REVERSED', 'reason' => '受信完了が要求開始より前（時計逆行）'];
        if ($v['available_at']         < $v['response_received_at'])
            return ['ok' => false, 'code' => 'CLOCK_REVERSED', 'reason' => '利用可能が受信完了より前（時計逆行）'];
        if ($v['available_at'] > $deadline)
            return ['ok' => false, 'code' => 'ACQUISITION_DEADLINE_EXCEEDED', 'reason' => '取得猶予を超えた'];
        if ($v['available_at'] > $v['input_freeze_at'])
            return ['ok' => false, 'code' => 'ACQUISITION_DEADLINE_EXCEEDED', 'reason' => '情報上限 input_freeze_at を超えた'];

        if (($b['source_updated_at'] ?? null) !== null) {
            $su = self::us($b['source_updated_at']);
            if ($su === null)
                return ['ok' => false, 'code' => 'TIME_UNREADABLE', 'reason' => 'source_updated_at が日時として読めない'];
            if ($su > $v['response_received_at'])
                return ['ok' => false, 'code' => 'SOURCE_TIME_FUTURE', 'reason' => '取得元の更新時刻が受信完了より未来'];
        }
        return ['ok' => true, 'code' => null, 'reason' => null];
    }
}
