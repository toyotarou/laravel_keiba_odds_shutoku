<?php
namespace App\Http\Controllers\Api;

class Ctrl {

    /**
     * ═══════════════════════════════════════════════════════════════════════
     * @ANCHOR-20261020-R122-RESP  応答検証と局所回復（本番接続）
     * ═══════════════════════════════════════════════════════════════════════
     * 根拠：server_contract_r12.2.txt 6章・7章・10章
     *
     * ■ 通す順番（本番と同じ）
     *   extract → checkEnvelope → isolateHorses → BaganrikiDiagnose::run
     *
     * ■ 何を正とするか
     *   凍結入力（snapshot）と、予約済みの role を正とします。
     *   <b>応答が名乗る役は照合相手を選ぶのに使いません。</b>
     *   封筒照合は、予約した role の固定入力に対してだけ行います。
     *
     * ■ 局所回復
     *   馬番欠落・重複・未知馬・局所の項目不正は、その範囲だけ隔離します。
     *   正常な他馬はそのまま残します。
     *   直してよい範囲は repair_scope として baganriki_validation_results に残します。
     *
     * @return array ['ok','stage','code','reason','accepted','needs_fix',
     *                'repair_scope','normal','row_valid','diag']
     */
    public function r122InspectResponse(int $snapshotId, string $role,
                                        int $attemptNo = 0): array
    {
        $out = ['ok' => false, 'stage' => 'start', 'code' => null, 'reason' => null,
                'accepted' => false, 'needs_fix' => false,
                'repair_scope' => null, 'normal' => [], 'row_valid' => [],
                'diag' => null, 'attempt_id' => null];

        $snap = \DB::table('baganriki_snapshots')->where('id', $snapshotId)->first();
        if ($snap === null) {
            $out['stage'] = 'snapshot'; $out['code'] = 'NO_SNAPSHOT';
            $out['reason'] = '凍結入力がありません';
            return $out;
        }
        $a = \DB::table('baganriki_ai_attempts')
               ->where('snapshot_id', $snapshotId)->where('role', $role)
               ->where('attempt_no', $attemptNo)->first();
        if ($a === null) {
            $out['stage'] = 'attempt'; $out['code'] = 'NO_ATTEMPT';
            $out['reason'] = 'その枠がありません';
            return $out;
        }
        $out['attempt_id'] = (int) $a->id;
        if ((string) $a->status !== BaganrikiWorker::RECEIVED) {
            $out['stage'] = 'attempt'; $out['code'] = 'NOT_RECEIVED';
            $out['reason'] = '原応答を受け取っていません（' . $a->status . '）';
            return $out;
        }

        $col = ($role === '2nd') ? 'input_json_2nd' : 'input_json_1st';
        $src = json_decode((string) $snap->{$col}, true);
        if (!is_array($src)) {
            $out['stage'] = 'snapshot'; $out['code'] = 'NO_INPUT';
            $out['reason'] = '固定入力（' . $col . '）を読めません';
            return $out;
        }

        // ── ① 原文から封筒を取り出す ────────────────────────────────
        $ex = BaganrikiResponse::extract((string) $a->raw_response);
        if (!$ex['ok']) {
            $out['stage'] = 'extract';
            $out['code']  = (string) ($ex['code'] ?? 'AI_FAILURE');
            $out['reason'] = (string) ($ex['reason'] ?? '');
            $this->r122SaveValidation((int) $a->id, null, $out, null, null, null);
            return $out;
        }
        $res = (array) $ex['json'];

        // ── ② 封筒照合（予約した role の固定入力だけが相手）──────────
        $env = BaganrikiResponse::checkEnvelope($res, [
            'prompt_version'  => $src['prompt_version']  ?? null,
            'schema_version'  => $src['schema_version']  ?? null,
            'race_id'         => $src['race_id']         ?? null,
            'ai_role'         => $src['ai_role']         ?? null,
            'snapshot_hash'   => $src['snapshot_hash']   ?? null,
            'mode'            => $src['mode']            ?? null,
            'mode_status'     => $src['mode_status']     ?? null,
            'allocation_mode' => $src['allocation_mode'] ?? null,
            'mode_policy_id'  => $src['mode_policy_id']  ?? null,
            'role_cap'        => $src['role_cap']        ?? null,
            'role_quota'      => $src['role_quota']      ?? null,
        ]);
        if (!$env['ok']) {
            $out['stage'] = 'envelope';
            $out['code']  = (string) ($env['code'] ?? 'ENVELOPE');
            $out['reason'] = (string) ($env['reason'] ?? '');
            $this->r122SaveValidation((int) $a->id, null, $out, null, null, null);
            return $out;
        }

        // ── ③ 馬ごとの隔離（正常な他馬を残す）───────────────────────
        $frozen = [];
        foreach ((array) ($src['runners'] ?? []) as $r) {
            $frozen[] = (int) ($r['horse_no'] ?? 0);
        }
        $iso = BaganrikiResponse::isolateHorses((array) ($res['horses'] ?? []), $frozen);

        // ── ④ 診断（inspect と resolve で同じ関数）──────────────────
        $d = BaganrikiDiagnose::run($res, $src);

        // 正常部分＝隔離に残り、かつ row_valid が true の行
        $normal = [];
        foreach ((array) $iso['kept'] as $k => $h) {
            $no = is_int($k) ? $k : (int) ($h['horse_no'] ?? 0);
            if ($no <= 0) { continue; }
            if (($d['row_valid'][$no] ?? true) !== true) { continue; }
            $normal[$no] = $h;
        }
        ksort($normal);

        $out['ok']           = true;
        $out['stage']        = 'ok';
        $out['code']         = $d['ok'] ? 'OK' : 'REPAIRABLE';
        $out['reason']       = BaganrikiDiagnose::summary($d);
        $out['accepted']     = ($normal !== []);
        $out['needs_fix']    = !$d['ok'];
        $out['repair_scope'] = $d['repair_scope'];
        $out['normal']       = $normal;
        $out['row_valid']    = $d['row_valid'];
        $out['diag']         = [
            'findings'   => $d['findings'],
            'missing'    => $d['missing'],
            'duplicated' => $d['duplicated'],
            'unknown'    => $d['unknown'],
            'isolated'   => array_keys((array) $iso['isolated']),
            'iso_missing' => (array) $iso['missing'],
        ];
        $this->r122SaveValidation((int) $a->id, $normal, $out,
            $d['repair_scope'], self::r122FieldSources($normal),
            self::r122RankSources($res));
        return $out;
    }

    /**
     * @ANCHOR-20261020-R122-RESP  訂正を解決します（最大1回）
     *   初回の原応答と complete を保存してからでないと動きません。
     *   直してよい範囲は<b>初回の診断</b>から取ります（同じ診断関数です）。
     *   採用できない訂正では、初回の正常部分をそのまま残します。
     */
    public function r122ResolveCorrection(int $snapshotId, string $role): array
    {
        $out = ['ok' => false, 'code' => null, 'reason' => null,
                'merged' => [], 'applied' => [], 'rescued' => [], 'skipped' => []];

        $first = $this->r122InspectResponse($snapshotId, $role, BaganrikiWorker::FIRST);
        if (!$first['ok']) {
            $out['code'] = 'FIRST_NOT_USABLE';
            $out['reason'] = '初回が採用できません（' . $first['stage'] . '／'
                           . $first['code'] . '）';
            return $out;
        }
        $out['merged'] = $first['normal'];        // 何があっても初回の正常部分は残します
        if (!$first['needs_fix']) {
            $out['ok'] = true; $out['code'] = 'NO_FIX_NEEDED';
            $out['reason'] = '初回に直すところがないので訂正しません';
            return $out;
        }

        $fix = $this->r122InspectResponse($snapshotId, $role, BaganrikiWorker::FIX);
        if (!$fix['ok']) {
            $out['ok'] = true; $out['code'] = 'FIX_NOT_USABLE';
            $out['reason'] = '訂正が採用できないので初回の正常部分を残します（'
                           . $fix['stage'] . '／' . $fix['code'] . '）';
            return $out;
        }

        $rowsA = \DB::table('baganriki_ai_attempts')
                   ->where('snapshot_id', $snapshotId)->where('role', $role)
                   ->whereIn('attempt_no', [BaganrikiWorker::FIRST, BaganrikiWorker::FIX])
                   ->get()->keyBy('attempt_no');
        $firstAt = self::r122DbRfc3339($rowsA[BaganrikiWorker::FIRST]->received_at ?? null);
        $fixAt   = self::r122DbRfc3339($rowsA[BaganrikiWorker::FIX]->received_at ?? null);

        $snap = \DB::table('baganriki_snapshots')->where('id', $snapshotId)->first();
        $frozen = [];
        foreach ((array) json_decode((string) ($snap->frozen_nums ?? '[]'), true) as $n) {
            $frozen[] = (int) $n;
        }

        $acc = BaganrikiResponse::acceptCorrection(
            $first['normal'], $fix['normal'], $firstAt, $fixAt,
            $frozen, $first['repair_scope'], $fix['row_valid']);
        if (($acc['ok'] ?? false) !== true) {
            $out['ok'] = true; $out['code'] = 'FIX_REJECTED';
            $out['reason'] = '訂正を採用しません（' . (string) ($acc['reason'] ?? '')
                           . '）。初回の正常部分を残します';
            return $out;
        }
        $out['merged']  = BaganrikiResponse::applyCorrection(
                              $first['normal'], $fix['normal'], $acc);
        $out['applied'] = (array) ($acc['applied'] ?? []);
        $out['rescued'] = (array) ($acc['rescued'] ?? []);
        $out['skipped'] = (array) ($acc['skipped'] ?? []);
        $out['ok']   = true;
        $out['code'] = 'FIX_APPLIED';
        $out['reason'] = '訂正を反映しました（適用 ' . count($out['applied'])
                       . '頭・救済 ' . count($out['rescued'])
                       . '頭・飛ばし ' . count($out['skipped']) . '頭）';
        return $out;
    }

    /**
     * @ANCHOR-20261020-R122-RESP  選出に渡す馬（訂正があればそれを使う）
     */
    public function r122AcceptedHorses(int $snapshotId, string $role): array
    {
        $has = \DB::table('baganriki_ai_attempts')
                 ->where('snapshot_id', $snapshotId)->where('role', $role)
                 ->where('attempt_no', BaganrikiWorker::FIX)
                 ->where('status', BaganrikiWorker::RECEIVED)->exists();
        if ($has) { return $this->r122ResolveCorrection($snapshotId, $role); }
        $f = $this->r122InspectResponse($snapshotId, $role, BaganrikiWorker::FIRST);
        return ['ok' => $f['ok'], 'code' => $f['code'], 'reason' => $f['reason'],
                'merged' => $f['normal'], 'applied' => [], 'rescued' => [],
                'skipped' => [], 'needs_fix' => $f['needs_fix'],
                'repair_scope' => $f['repair_scope']];
    }

    /** @ANCHOR-20261020-R122-RESP  各馬の事実出典hash（加点の証明とは別に残します） */
    public static function r122FieldSources(array $horses): array
    {
        $o = [];
        foreach ($horses as $no => $h) {
            $refs = [];
            foreach ((array) ($h['evidence'] ?? []) as $e) {
                foreach ((array) ($e['source_refs'] ?? []) as $r) { $refs[] = (string) $r; }
            }
            foreach ((array) ($h['family_review'] ?? []) as $fam) {
                foreach ((array) ($fam['source_refs'] ?? []) as $r) { $refs[] = (string) $r; }
            }
            $refs = array_values(array_unique($refs));
            sort($refs, SORT_STRING);
            $o[(string) $no] = ['refs' => $refs,
                                'hash' => hash('sha256', implode("\n", $refs))];
        }
        return $o;
    }

    /** @ANCHOR-20261020-R122-RESP  順位の出どころ（帯ごとの方式と並び） */
    public static function r122RankSources(array $res): array
    {
        return [
            'band_ranks'          => (array) ($res['band_ranks'] ?? []),
            'evidence_band_ranks' => (array) ($res['evidence_band_ranks'] ?? []),
            'public_candidates'   => (array) ($res['public_candidates'] ?? []),
        ];
    }

    /** @ANCHOR-20261020-R122-RESP  検証の結果を残します（表が無ければ何もしません） */
    private function r122SaveValidation(int $attemptId, ?array $normal, array $out,
                                        ?array $scope, ?array $fieldSources,
                                        ?array $rankSources): void
    {
        if (!\Schema::hasTable('baganriki_validation_results')) { return; }
        $j = static fn($v) => ($v === null) ? null : (string) json_encode($v,
            JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PRESERVE_ZERO_FRACTION);
        try {
            \DB::table('baganriki_validation_results')->insert([
                'attempt_id'        => $attemptId,
                'validator_version' => BaganrikiDiagnose::VERSION,
                'normal_part'       => $j($normal),
                'diagnostics'       => $j(['stage' => $out['stage'], 'code' => $out['code'],
                                           'reason' => $out['reason'],
                                           'diag' => $out['diag'] ?? null]),
                'repair_scope'      => $j($scope),
                'field_sources'     => $j($fieldSources),
                'rank_sources'      => $j($rankSources),
                'created_at'        => BaganrikiWorker::toDb(BaganrikiWorker::nowUs()),
            ]);
        } catch (\Throwable $e) {
            \Log::error('[R122-RESP] 検証結果を残せません', ['message' => $e->getMessage()]);
        }
    }

    /**
     * ═══════════════════════════════════════════════════════════════════════
     * @ANCHOR-20261020-R122-PUB  統合・公開・intent・revision（本番接続）
     * ═══════════════════════════════════════════════════════════════════════
     * 根拠：server_contract_r12.2.txt 7章・8章・10章・11章
     *
     * ■ 通す順番
     *   ① 読取（書込ロックを持ちません）
     *      3つの版（state／response／publication）と、両roleの検証済み全頭評価。
     *      ここで「検証開始時刻」を取ります。
     *   ② 統合（BaganrikiRanking::merge）
     *      rank_score=100×(K−r+1)/K の max。同点は 両AIの原公開一致あり →
     *      独立根拠群数の多い順 → 馬番昇順。
     *      <b>両AIの検証済み原公開候補だと証明できたときだけ +5。</b>
     *   ③ 枠を先に全帯ぶん予約し、D不足はB、B不足はD、A不足はB→D で埋めます。
     *      馬番は重複させません。
     *   ④ 「検証完了時刻」を取り、intent_hash を作ります。
     *   ⑤ <b>短いトランザクション</b>で live_state と intent をロックし、
     *      3つの版・現在時刻・期限をもう一度見ます。
     *      古い処理は拒否。同じ intent の再実行は同じ publication_id。
     *   ⑥ 「commit直前時刻」を取り、
     *      検証開始 <= 検証完了 <= commit直前 を確かめます。
     *
     * ■ 加点の証明について
     *   訂正版または初回の<b>完全な原応答</b>が、公開に使う全頭の実効内容・
     *   帯順位・公開リスト・馬別フラグ・非選出理由と一致すると確かめられた
     *   ときだけ、その role の証明として使います。
     *   初回と訂正が混ざった行は証明できないので加点しません。
     *
     * @param array $opt ['now_us'=>int, 'job_id'=>string, 'handed'=>array]
     * @return array
     */
    public function r122Publish(int $snapshotId, array $opt = []): array
    {
        $out = ['ok' => false, 'code' => null, 'reason' => null,
                'publication_id' => null, 'reused' => false,
                'candidates' => [], 'quota' => null, 'shortfalls' => [],
                'intent_hash' => null, 'job_id' => null,
                'used' => [], 'proof' => []];

        $t0 = (int) ($opt['now_us'] ?? BaganrikiWorker::nowUs());   // 検証開始時刻

        $snap = \DB::table('baganriki_snapshots')->where('id', $snapshotId)->first();
        if ($snap === null) {
            $out['code'] = 'NO_SNAPSHOT'; $out['reason'] = '凍結入力がありません';
            return $out;
        }
        // 原応答手渡しは、ジャーナルがあるレースでは受け付けません（契約10章）
        if (!empty($opt['handed'])) {
            $hasJournal = \DB::table('baganriki_ai_attempts')
                            ->where('snapshot_id', $snapshotId)->exists();
            if ($hasJournal) {
                $out['code'] = 'HANDED_REFUSED';
                $out['reason'] = 'ジャーナルがあるレースでは原応答の手渡しを受け付けません';
                return $out;
            }
        }

        BaganrikiWorker::ensureLive($snapshotId, $t0);
        $live = \DB::table('baganriki_live_states')
                  ->where('snapshot_id', $snapshotId)->first();      // ロックしません
        $readRev = [
            'state'       => ($live === null) ? 0 : (int) $live->state_revision,
            'response'    => ($live === null) ? 0 : (int) $live->response_revision,
            'publication' => ($live === null) ? 0 : (int) $live->publication_revision,
        ];
        // 呼出側が整合した読取取引で3つの版を取っているときは、その値を使います。
        //   （読取→検証→保存を分けて行う呼び方のためです。保存の直前に
        //     もう一度見比べて、古ければ保存しません）
        if (isset($opt['read_revisions']) && is_array($opt['read_revisions'])) {
            foreach (['state', 'response', 'publication'] as $k) {
                if (array_key_exists($k, $opt['read_revisions'])) {
                    $readRev[$k] = (int) $opt['read_revisions'][$k];
                }
            }
        }
        $out['used'] = $readRev;

        // ── 期限（実効）──────────────────────────────────────────────
        $dl = BaganrikiWorker::deadlines($snap, $live);
        if (!$dl['ok']) {
            $out['code'] = (string) $dl['code']; $out['reason'] = (string) $dl['reason'];
            return $out;
        }
        if ($t0 > $dl['publish']) {
            $out['code'] = 'DEADLINE_PASSED';
            $out['reason'] = '実効の公開期限を過ぎています';
            return $out;
        }

        // ── 全頭取消 ────────────────────────────────────────────────
        $cancelled = (array) json_decode((string) ($live->cancellations ?? '[]'), true);
        $cancelled = array_map('intval', $cancelled);
        $frozenBand = [];
        $src1 = json_decode((string) $snap->input_json_1st, true);
        foreach ((array) ($src1['runners'] ?? []) as $r) {
            $frozenBand[(int) $r['horse_no']] = (string) ($r['band'] ?? '');
        }
        $activeNums = array_values(array_diff(array_keys($frozenBand), $cancelled));
        if ($activeNums === []) {
            $out['code'] = 'ALL_CANCELLED'; $out['reason'] = '全頭取消です';
            return $out;
        }

        // ── ① 両roleの検証済み全頭評価（読取だけ）────────────────────
        $per = []; $proofHash = []; $accepted = [];
        foreach (['1st', '2nd'] as $role) {
            $a = $this->r122AcceptedHorses($snapshotId, $role);
            if (!($a['ok'] ?? false) || ($a['merged'] ?? []) === []) { continue; }
            $accepted[$role] = $a;
            $srcCol = ($role === '2nd') ? 'input_json_2nd' : 'input_json_1st';
            $src = json_decode((string) $snap->{$srcCol}, true);
            $resUsed = $this->r122ResponseUsed($snapshotId, $role, $a);
            if ($resUsed['proof'] !== null) { $proofHash[$role] = $resUsed['proof']; }
            $rows = [];
            foreach ((array) $a['merged'] as $num => $h) {
                $num = (int) $num;
                if (in_array($num, $cancelled, true)) { continue; }   // 取消は入れません
                $band = $frozenBand[$num] ?? ($h['band'] ?? '');
                $K = 0;
                foreach ($frozenBand as $n2 => $b2) {
                    if ($b2 === $band && !in_array((int) $n2, $cancelled, true)) { $K++; }
                }
                $order = array_map('intval',
                    (array) ($resUsed['band_ranks'][$band] ?? []));
                $order = array_values(array_filter($order,
                    static fn($n3) => !in_array((int) $n3, $cancelled, true)));
                $r = array_search($num, $order, true);
                if ($r === false) { continue; }    // 順位の分からない馬は入れません
                $sup = 0;
                foreach ((array) ($h['family_review'] ?? []) as $fam) {
                    if (($fam['status'] ?? '') === 'SUPPORTED') { $sup++; }
                }
                $rows[$num] = [
                    'r' => (int) $r + 1, 'K' => max(1, $K),
                    'public' => in_array($num,
                        array_map('intval', (array) ($resUsed['public_candidates'] ?? [])), true),
                    'groups' => $sup,
                ];
            }
            if ($rows !== []) { $per[$role] = $rows; }
        }
        if ($per === []) {
            $out['code'] = 'NO_RESPONSE';
            $out['reason'] = '検証を通った応答がありません';
            return $out;
        }

        // ── ② 統合 ─────────────────────────────────────────────────
        $merged = BaganrikiRanking::merge($per, $proofHash);
        $out['proof'] = array_keys($proofHash);

        // ── ③ 枠（先に全帯ぶん予約し、不足を規則どおりに移す）─────────
        //   構造上の不足（取消で実在しなくなった帯）と、
        //   評価後の適格馬不足は別の規則なので、2段に分けます。
        $q0 = (array) json_decode((string) $snap->quota_1st, true);
        $quota1st = isset($q0[0])
            ? ['A' => (int) $q0[0], 'B' => (int) $q0[1], 'D' => (int) $q0[2]]
            : ['A' => (int) ($q0['A'] ?? 0), 'B' => (int) ($q0['B'] ?? 0),
               'D' => (int) ($q0['D'] ?? 0)];
        $afterC = BaganrikiRanking::afterCancellation($frozenBand, $cancelled,
                      $quota1st, $snap->allocation_mode);
        if (($afterC['all_cancelled'] ?? false) === true) {
            $out['code'] = 'ALL_CANCELLED'; $out['reason'] = '全頭取消です';
            return $out;
        }
        $quota = (array) ($afterC['live_quota'] ?? $quota1st);
        if ($quota === []) { $quota = ['A' => 0, 'B' => 0, 'D' => 0]; }
        if (isset($quota[0])) {
            $quota = ['A' => (int) $quota[0], 'B' => (int) $quota[1], 'D' => (int) $quota[2]];
        }
        // 評価後の適格馬（統合に乗った馬）の帯ごとの数
        $avail = ['A' => 0, 'B' => 0, 'D' => 0];
        foreach ($merged as $m) {
            $b = $frozenBand[$m['num']] ?? '';
            if (isset($avail[$b])) { $avail[$b]++; }
        }
        $fill = BaganrikiRanking::fillShortfall($quota, $avail);
        $quota = (array) $fill['quota'];
        $out['shortfalls'] = array_merge((array) ($afterC['shortfalls'] ?? []),
                                         (array) $fill['shortfalls']);

        $taken = []; $cands = [];
        foreach (['A', 'B', 'D'] as $b) {
            $want = (int) ($quota[$b] ?? 0);
            $got = 0;
            foreach ($merged as $m) {
                if ($got >= $want) { break; }
                $num = (int) $m['num'];
                if (isset($taken[$num])) { continue; }          // 馬番は重複させません
                if (($frozenBand[$num] ?? '') !== $b) { continue; }
                $taken[$num] = true; $got++;
                $cands[] = [
                    'horse_no' => $num, 'band' => $b,
                    'score' => $m['score'], 'bonus' => $m['bonus'],
                    'both_public' => $m['both_public'],
                    'bonus_proven' => $m['bonus_proven'],
                    'independent_groups' => $m['groups'],
                    'public_proof_hash' => $m['public_proof_hash'],
                ];
            }
        }
        $out['candidates'] = $cands;
        $out['quota'] = $quota;

        // ── ④ 検証完了時刻と intent ─────────────────────────────────
        $t1 = BaganrikiWorker::nowUs();                     // 検証完了時刻
        $canon = BaganrikiPrompt::canonical([
            'snapshot_hash' => (string) $snap->snapshot_hash,
            'quota'         => $quota,
            'candidates'    => array_map(static fn($c) => [
                                   'horse_no' => $c['horse_no'],
                                   'band'     => $c['band'],
                                   'bonus'    => $c['bonus'],
                               ], $cands),
            // @ANCHOR-20261020-R122-PUB  intentに入れるのは「読んだもの」だけです。
            //   publication_revision は公開した<b>結果</b>なので入れません。
            //   入れると、同じ計算の再実行が毎回別のintentになり、
            //   「同じintentの再実行は同じpublication_id」が守れません。
            'revisions'     => ['state'    => $readRev['state'],
                                'response' => $readRev['response']],
        ]);
        if ($canon === null) {
            $out['code'] = 'CANON_FAILED'; $out['reason'] = 'intentの正本を作れません';
            return $out;
        }
        $intentHash = hash('sha256', $canon);
        $jobId = (string) ($opt['job_id'] ?? ('job-' . $snapshotId . '-' . $t1 . '-'
                 . substr(bin2hex(random_bytes(3)), 0, 6)));
        $out['intent_hash'] = $intentHash;
        $out['job_id'] = $jobId;

        // ── ⑤ 短いトランザクション（ここだけロックします）─────────────
        try {
            $res = \DB::transaction(function () use ($snapshotId, $snap, $intentHash,
                    $jobId, $readRev, $cands, $quota, $out, $t0, $t1, $cancelled,
                    $activeNums) {
                $live = \DB::table('baganriki_live_states')
                          ->where('snapshot_id', $snapshotId)->lockForUpdate()->first();
                $now = $readRev;
                if ($live !== null) {
                    $now = ['state' => (int) $live->state_revision,
                            'response' => (int) $live->response_revision,
                            'publication' => (int) $live->publication_revision];
                }
                // 同じ intent の再実行は同じ publication_id を返します
                $same = \DB::table('baganriki_publication_intents')
                          ->where('snapshot_id', $snapshotId)
                          ->where('intent_hash', $intentHash)->lockForUpdate()->first();
                if ($same !== null && $same->publication_id !== null) {
                    return ['ok' => true, 'code' => 'ALREADY', 'reused' => true,
                            'publication_id' => (string) $same->publication_id];
                }
                // 読んだあとに版が変わっていたら、古い計算は保存しません
                if ($now !== $readRev) {
                    return ['ok' => false, 'code' => 'STALE',
                            'reason' => '読取のあとに版が変わりました（state '
                                      . $readRev['state'] . '→' . $now['state']
                                      . '／response ' . $readRev['response'] . '→'
                                      . $now['response'] . '／publication '
                                      . $readRev['publication'] . '→'
                                      . $now['publication'] . '）'];
                }
                // 期限と時刻をもう一度
                $dl = BaganrikiWorker::deadlines($snap, $live);
                if (!$dl['ok']) {
                    return ['ok' => false, 'code' => (string) $dl['code'],
                            'reason' => (string) $dl['reason']];
                }
                $t2 = BaganrikiWorker::nowUs();              // commit直前時刻
                if ($t2 > $dl['publish']) {
                    return ['ok' => false, 'code' => 'DEADLINE_PASSED',
                            'reason' => 'commit直前の検査で公開期限を過ぎています'];
                }
                // 検証開始 <= 検証完了 <= commit直前（1マイクロ秒でも逆行なら拒否）
                if (!($t0 <= $t1 && $t1 <= $t2)) {
                    return ['ok' => false, 'code' => 'CLOCK_BACKWARD',
                            'reason' => '時刻が逆行しています'];
                }

                $pubId = 'pub-' . $snap->race_id . '-' . $snap->generation . '-'
                       . substr($intentHash, 0, 12);
                $intentId = \DB::table('baganriki_publication_intents')->insertGetId([
                    'snapshot_id' => $snapshotId, 'job_id' => $jobId,
                    'intent_hash' => $intentHash,
                    'read_state_revision'       => $readRev['state'],
                    'read_response_revision'    => $readRev['response'],
                    'read_publication_revision' => $readRev['publication'],
                    'state' => 'COMMITTED', 'publication_id' => $pubId,
                    'created_at' => BaganrikiWorker::toDb($t2),
                ]);
                $j = static fn($v) => (string) json_encode($v,
                    JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES
                    | JSON_PRESERVE_ZERO_FRACTION);
                $proofs = [];
                foreach ($cands as $c) {
                    if ($c['public_proof_hash'] !== null) {
                        $proofs[(string) $c['horse_no']] = $c['public_proof_hash'];
                    }
                }
                \DB::table('baganriki_publications')->insert([
                    'publication_id' => $pubId, 'snapshot_id' => $snapshotId,
                    'intent_id' => $intentId,
                    'published_at' => BaganrikiWorker::toDb($t2),
                    'prediction_target_count'  => array_sum($quota),
                    'prediction_quota'         => $j($quota),
                    'publication_target_count' => array_sum($quota),
                    'publication_quota'        => $j($quota),
                    'active_count'             => count($activeNums),
                    'candidates' => $j($cands),
                    'evidence'   => $j(['shortfalls' => $out['shortfalls'],
                                        'proof_roles' => $out['proof'],
                                        'cancelled' => $cancelled]),
                    'shortfalls' => $j($out['shortfalls']),
                    'used_state_revision'    => $readRev['state'],
                    'used_response_revision' => $readRev['response'],
                    'public_proof_hash'      => $j($proofs),
                ]);
                \DB::table('baganriki_live_states')->where('snapshot_id', $snapshotId)
                  ->update(['publication_revision' => $readRev['publication'] + 1,
                            'latest_publication_id' => $pubId,
                            'updated_at' => BaganrikiWorker::toDb($t2)]);
                BaganrikiWorker::event((string) $snap->race_id, $snapshotId,
                    'PUBLISHED', $readRev['publication'], $readRev['publication'] + 1,
                    ['publication_id' => $pubId, 'intent_hash' => $intentHash,
                     'job_id' => $jobId, 'candidates' => array_column($cands, 'horse_no'),
                     'verify_started_at'  => BaganrikiTime::toJst($t0),
                     'verify_finished_at' => BaganrikiTime::toJst($t1),
                     'committed_at'       => BaganrikiTime::toJst($t2)],
                    $pubId, $t2);
                return ['ok' => true, 'code' => 'PUBLISHED', 'reused' => false,
                        'publication_id' => $pubId];
            });
        } catch (\Throwable $e) {
            if (BaganrikiWorker::isDup($e)) {
                // 別のintentが先に入った＝こちらは stale
                $out['code'] = 'STALE';
                $out['reason'] = 'ほかの処理が先に保存しました';
                return $out;
            }
            $out['code'] = 'PUBLISH_EXCEPTION'; $out['reason'] = $e->getMessage();
            \Log::error('[R122-PUB] 公開で例外', ['message' => $e->getMessage(),
                'at' => $e->getFile() . ':' . $e->getLine()]);
            return $out;
        }

        $out['ok']     = (bool) ($res['ok'] ?? false);
        $out['code']   = (string) ($res['code'] ?? '');
        $out['reason'] = $res['reason'] ?? null;
        $out['reused'] = (bool) ($res['reused'] ?? false);
        $out['publication_id'] = $res['publication_id'] ?? null;
        return $out;
    }

    /**
     * @ANCHOR-20261020-R122-PUB  公開に使った原応答を特定します
     *   加点の証明は、<b>1本の完全な原応答</b>が公開に使う全頭と
     *   そろっているときだけ出します。初回と訂正が混ざった行は証明しません。
     *
     * @return array ['band_ranks','public_candidates','proof'=>[馬番=>hash]|null,
     *                'attempt_no'=>?int]
     */
    public function r122ResponseUsed(int $snapshotId, string $role, array $accepted): array
    {
        $o = ['band_ranks' => [], 'public_candidates' => [], 'proof' => null,
              'attempt_no' => null];
        $mixed = ((array) ($accepted['applied'] ?? []) !== []
               || (array) ($accepted['rescued'] ?? []) !== [])
               && (string) ($accepted['code'] ?? '') === 'FIX_APPLIED';
        // 訂正を当てた＝初回と訂正が混ざるので、証明は出しません
        $try = ((string) ($accepted['code'] ?? '') === 'FIX_APPLIED')
             ? [BaganrikiWorker::FIX, BaganrikiWorker::FIRST]
             : [BaganrikiWorker::FIRST];
        foreach ($try as $no) {
            $a = \DB::table('baganriki_ai_attempts')
                   ->where('snapshot_id', $snapshotId)->where('role', $role)
                   ->where('attempt_no', $no)
                   ->where('status', BaganrikiWorker::RECEIVED)->first();
            if ($a === null) { continue; }
            $ex = BaganrikiResponse::extract((string) $a->raw_response);
            if (!$ex['ok']) { continue; }
            $res = (array) $ex['json'];
            if ($o['band_ranks'] === []) {
                $o['band_ranks'] = (array) ($res['band_ranks'] ?? []);
                $o['public_candidates'] = (array) ($res['public_candidates'] ?? []);
                $o['attempt_no'] = (int) $no;
            }
            // 証明にできるのは、complete で、診断に直すところが無く、
            // 公開に使う全頭がその応答の中で一致している応答だけです。
            if ((int) $a->complete !== 1) { continue; }
            $insp = $this->r122InspectResponse($snapshotId, $role, (int) $no);
            if (!$insp['ok'] || $insp['needs_fix']) { continue; }
            if ($mixed && (int) $no === BaganrikiWorker::FIRST) { continue; }
            $want = array_keys((array) $accepted['merged']);
            $got  = array_keys((array) $insp['normal']);
            sort($want); sort($got);
            if ($want !== $got) { continue; }
            $same = true;
            foreach ($want as $num) {
                if (($accepted['merged'][$num] ?? null) !== ($insp['normal'][$num] ?? null)) {
                    $same = false; break;
                }
            }
            if (!$same) { continue; }
            $proof = [];
            foreach ($want as $num) { $proof[(int) $num] = (string) $a->response_hash; }
            $o['proof'] = $proof;
            $o['attempt_no'] = (int) $no;
            $o['band_ranks'] = (array) ($res['band_ranks'] ?? []);
            $o['public_candidates'] = (array) ($res['public_candidates'] ?? []);
            break;
        }
        return $o;
    }

    public static function r122DbRfc3339($v): ?string
    {
        if ($v === null) return null;
        $s = trim((string) $v);
        if ($s === '' || strncmp($s, '0000', 4) === 0) return null;
        if (preg_match('/^(\d{4}-\d{2}-\d{2})[ T](\d{2}:\d{2}:\d{2})(\.\d{1,6})?/', $s, $m)) {
            $frac = $m[3] ?? '';
            if ($frac === '.000000' || $frac === '.0') $frac = '';
            return $m[1] . 'T' . $m[2] . $frac . '+09:00';
        }
        return null;
    }

}
