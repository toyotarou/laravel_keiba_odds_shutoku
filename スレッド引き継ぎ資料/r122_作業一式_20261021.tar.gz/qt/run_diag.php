<?php
require __DIR__ . '/diag.php';
$v = __DIR__ . '/../mat/validation';
$ng = 0; $n = 0;
foreach (glob($v . '/normal/*_output.json') as $f) {
    $in = str_replace('_output', '_input', $f);
    $o = json_decode(file_get_contents($f), true);
    $i = json_decode(file_get_contents($in), true);
    $d = BaganrikiDiagnose::run($o, $i);
    $n++;
    if (!$d['ok']) {
        $ng++;
        echo "× " . basename($f) . "\n";
        foreach (array_slice($d['findings'], 0, 6) as $x) {
            echo "    [{$x['scope']}] " . var_export($x['target'], true)
               . " {$x['code']} {$x['reason']}\n";
        }
    } else {
        echo "○ " . basename($f) . "  直すところなし\n";
    }
}
echo "\n正常出力 $n 件 / 誤検出 $ng 件\n\n";
foreach (glob($v . '/invalid/O*.json') as $f) {
    $o = json_decode(file_get_contents($f), true);
    // 対になる入力は示されていないので、応答が名乗る封筒から凍結集合を作れない。
    // 近い正常入力（同じN）を当てて、局所の診断だけを見る。
    $best = null; $bn = -1;
    foreach (glob($v . '/normal/*_input.json') as $g) {
        $i = json_decode(file_get_contents($g), true);
        if (count($i['runners']) === count($o['horses'] ?? [])) { $best = $i; break; }
        if (count($i['runners']) > $bn) { $bn = count($i['runners']); $best = $i; }
    }
    $d = BaganrikiDiagnose::run($o, $best);
    printf("%-34s %s  %s\n", basename($f), $d['ok'] ? '△ 直すところなし' : '○ 検出',
        BaganrikiDiagnose::summary($d));
}
