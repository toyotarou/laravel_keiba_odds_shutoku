<?php
namespace App\Http\Controllers\Api;
class AiController
{
    public const V04_CONFIG_VERSION      = 'v04-x-unified-20261013';
    public const V04_RESEARCH_VERSION    = 'v04-x-unified-20261013';
    public const V04_SCORING_VERSION     = 'hv10-v04';
    public const V04_ALLOCATION_VERSION  = 'abd-x-v04';
    public const V04_FEATURE_VERSION     = 'x1x6z-research-20261013';
    public const V04_SCHEMA_VERSION      = 'audit-v04-x-draft-1';
    public const V04_ENABLED_DEFAULT          = false;
    public const V04_SHADOW_DEFAULT           = true;
    public const V04_RESEARCH_EXTREME_DEFAULT = false;
    public const V04_ML_STAGE_DEFAULT         = 'COLLECT_ONLY';
    public const V04_HV_PROMPT_DEFAULT        = false;
    public const V04_THRESHOLDS = [
        'win_wall'                       => 2.00,
        'place_wall'                     => 1.50,
        'win_wall_shrink_fraction'       => 0.20,
        'middle_close_upper_bound'       => 1.50,
        'place_shorten_21_to_6_fraction' => 0.05,
        'place_shorten_9_to_6_fraction'  => 0.03,
        'similar_min_races'              => 50,
        'similar_3in_delta_pp'           => 10.0,
    ];
    public const V04_SIGNAL_WEIGHTS = [
        'X1' => 2, 'X2' => 1, 'X3' => 1, 'X4' => 1, 'X5' => 1, 'X6' => 1, 'Z' => -2,
    ];
    public const V04_MODE_FIRM_MAX   = 1;   // S<=1 → FIRM
    public const V04_MODE_MIXED_MAX  = 3;   // 2<=S<=3 → MIXED、S>=4 → VOLATILE
    /**
     * 不明が3信号以上なら mode=UNKNOWN、という旧規則の閾値。
     *
     * @ANCHOR-20261020-R122-MODE  r12.2 では使いません。
     *   r12.2 は「可能なmodeが一つならそのmode、複数ならUNKNOWN」だけで決めます
     *   （server_contract_r12.2 5章／詳細設計書5.2）。不明の件数は条件に入りません。
     *   定数は旧ログとの照合のために残します。
     */
    public const V04_UNKNOWN_COUNT_AT_LEAST = 3;
    public const V04_QUOTA_BY_TARGET = [
        7 => ['FIRM' => [5, 2, 0], 'MIXED' => [3, 3, 1], 'VOLATILE' => [3, 3, 1]],
        6 => ['FIRM' => [4, 2, 0], 'MIXED' => [3, 2, 1], 'VOLATILE' => [3, 2, 1]],
        5 => ['FIRM' => [4, 1, 0], 'MIXED' => [3, 2, 0], 'VOLATILE' => [2, 2, 1]],
        4 => ['FIRM' => [3, 1, 0], 'MIXED' => [2, 2, 0], 'VOLATILE' => [2, 1, 1]],
    ];
    public const V04_QUOTA_EXTREME = [7 => ['EXTREME' => [2, 3, 2]]];
    public const V04_SCORE_CAP = [
        'H1' => 18, 'H2' => 15, 'H3' => 12, 'H4' => 9, 'H5' => 6,
        'V1' => 12, 'V2' => 10, 'V3' => 8,  'V4' => 6, 'V5' => 4,
    ];
    public const V04_HV_JSON_BEGIN = '<<<BAGANRIKI_HV10_V04_BEGIN>>>';
    public const V04_HV_JSON_END   = '<<<BAGANRIKI_HV10_V04_END>>>';
    public const V04_PUBLIC_CAP_2ND = 5;
    public const V04_ML_PLAN = [
        'start_shadow_after_valid_races'    => 1000,
        'future_holdout_for_limited_live'   => 200,
        'future_holdout_for_allocation_live'=> 500,
        'requires_explicit_approval'        => true,
        'max_ai_candidate_swap_due_to_ml'   => 1,
        'max_band_slot_move_due_to_ml'      => 1,
        'current_live_ML_policy_do_not_change' => '2000+500',
    ];
    public const V04_X6_BASELINE = null;
    public const V04_ABNORMAL_FIX_LOG = [
        ['10/13', 'AIが配点の上限を超えた点数を返すと、合計が100点を超えたまま通っていた',
         '上限超過は invalid にし、合計を null にする。0点で補完しない',
         'v04ScoreTotals()／@ANCHOR-20261013-V04-HV', 'score（7項目）・AB-T11'],
        ['10/13', '採点できない項目を0点として合計していた',
         '欠損は null のままにし、score_status=partial・合計 null にする',
         'v04ScoreTotals()', 'score・AB-T08・AB-T09・AB-T10'],
        ['10/13', '仮選出が score_status=partial の馬まで通していた（02章7-4違反）',
         '検証済み（valid）だけで選出する。採点が無い間は0頭で PARTIAL_COUNT に残す',
         'v04BandSelection($strict=true)／@ANCHOR-20261013-V04-VALID-ONLY', 'valid-only（6項目）'],
        ['10/14', '出走頭数の不一致を anomalies に入れるだけで、候補生成を止めていなかった',
         'DATA_INVALID へ昇格させ、研究用の候補生成を止める',
         '@ANCHOR-20261014-COUNT-INVALID', 'count（4項目）・DATA_INVALID'],
        ['10/14', '同じ馬番が2回返ると後の行で上書きされ、黙って消えていた',
         '最初の行を残し、2回目以降は duplicated に記録して ok=false にする',
         '@ANCHOR-20261014-HV-DUP', 'hv-dup（5項目）'],
        ['10/14', 'race_id と snapshot_hash を実値で渡さず、照合していなかった',
         '実値を渡して回答と照合し、不一致なら UNDETERMINED にする',
         '@ANCHOR-20261014-ID-ECHO', 'id-echo（3項目）'],
        ['10/14', '契約検証を定義しただけで、採用処理に接続していなかった',
         '統合処理に接続し、UNDETERMINED の回答の採点を採用しない',
         '@ANCHOR-20261014-CONTRACT-GATE', 'hv-dup・id-echo・count'],
        ['10/14', '1stがタイムアウトしたとき、前レースの1st回答が使われ得た',
         'レースが変わったら控えをすべて捨てる（レースガード）',
         '@ANCHOR-20261014-RACE-GUARD／v04BeginRace()', 'race-guard（5項目）'],
        ['10/14', '2nd回答の控えをレースごとにクリアしておらず、2レースで同じ回答になった',
         '同じくレースガードで破棄。前レースと同一なら異常として表示する',
         '@ANCHOR-20261014-RACE-GUARD', 'race-guard'],
        ['10/14', 'AUDIT_MERGE にレース表記が無く、どのレースの統合か分からなかった',
         'race と race_id を記録する',
         '@ANCHOR-20261014-AUDIT-RACEID', '（実レースで確認）'],
        ['10/14', '知らない信号値（TRUE/FALSE/UNKNOWN以外）で例外を投げ、レースが止まり得た',
         '不明（UNKNOWN）へ倒して \\Log::error で表に出す。FALSE には倒さない',
         '@ANCHOR-20261014-ABNORMAL-INPUT／v04Classify()', 'AB-T01・AB-T02・AB-T03'],
        ['10/14', '出走頭数が負のとき例外を投げ、レースが止まり得た',
         '0頭として扱い、\\Log::error で表に出す',
         '@ANCHOR-20261014-ABNORMAL-INPUT／v04TargetCount()', 'AB-T04・AB-T05・AB-T06'],
        ['10/14', '公開候補に重複があると不足数を取り違え、補充すべきときに補充しなかった',
         '重複を除いてから不足数を数える',
         '@ANCHOR-20261014-ABNORMAL-INPUT／v04FillCandidates()', 'AB-T24'],
        ['10/14', '全頭採点が1頭も返っていなくても PARTIAL 止まりで、採点を採用し得た',
         '採点0頭は UNDETERMINED にして採用しない。公開は止めない',
         '@ANCHOR-20261014-ABNORMAL-INPUT／v04CheckAiContract()', 'AB-T27・AB-T28'],
        ['10/14', '2nd AIの全頭採点がDBに1件も残っていなかった（72レース全部）。'
                . '1stは生で保存しているのに、2ndだけ publicPart() を通して保存していたため',
         '2ndも生のまま保存する。画面へ出さないための publicPart() は応答側と'
         . '一覧APIの2か所で通す。あわせて1stの一覧APIが内部JSONを返していたのも閉じた。'
         . '全頭採点が入っていなければ [ALLSCORE_MISSING] を error で残す',
         '@ANCHOR-20261014-ALLSCORE-KEEP', '（10/17のレースで受領を確認）'],
    ];
    public const V04_EXCLUSION_POINTS = [
        // ── 実際に頭数が減る箇所 ─────────────────────────────────────────
        ['REDUCE', 'AI回答の行の形式不正',        '_parseAiHorses()',
         '馬番・馬名・人気順などが読めない行を候補にしない。読めた行はすべて残す'],
        ['REDUCE', 'DB照合（実在しない馬番）',    '_dbValidateHorses()',
         '6分前のDBに存在しない馬番、人気帯が矛盾する馬を落とす。馬番と理由をログに残す'],
        ['REDUCE', '上限超過の絞り込み',          '_trimAiCandidates()',
         '1stは目標数C、2ndは5頭まで。おすすめ度の降順→同点は馬番昇順で決定論的に絞る。'
         . '保護対象（人気薄の根拠付き）がいる場合は先に枠へ入れる。外した行は理由つきで記録'],
        ['REDUCE', '目標数Cでの最終絞り込み',     '_mergeAiResults() の順位確定',
         '人気側と資格ある穴側の枠を先に確保したうえで、目標数Cまで。'
         . '枠を確保してから絞るので、確保した穴馬が後段で消えることはない'],
        // ══════════════════════════════════════════════════════════════════
        // @ANCHOR-20261014-EXCLUSION-SLOT2  10/14に追記（この一覧の記載漏れ）
        // ══════════════════════════════════════════════════════════════════
        // 【記載漏れだった理由】
        //   上の「目標数Cでの最終絞り込み」を「C頭まで絞る」としか書いておらず、
        //   「C頭に届いていなくても補充しない馬がいる」ことを書いていなかった。
        //   --v04-trace の実データ（10/12）で、目標数Cに達していないのに
        //   AIの公開候補が公開されない馬が出たため、一覧に追記した。
        // 【この条件は意図した仕様】
        //   10/4の仕様書6.2「足りない枠は未選出全頭の順位で補い、
        //   根拠の弱い穴馬を数合わせで強制しない」に対応する処理。
        //   資格（旧 F AND (R OR O)）を満たさない7番人気以下は、
        //   枠が余っていても補充に使わない。結果として公開頭数がC未満になる。
        //   このとき [PREDICTION_PARTIAL] を警告ログに出し、公開は止めない。
        ['REDUCE', '資格未達の7番人気以下は数合わせに使わない',
         '_mergeAiResults() 第2パス（枠確保モードのときだけ）',
         '枠確保モード（配分フラグON かつ 人気側・穴側の目標頭数が決まっているレース）では、'
         . '資格を満たさない7番人気以下を目標数C合わせの補充に使わない。'
         . 'そのため公開頭数が目標数C未満になることがある（仕様書6.2）。'
         . '非選出の理由は「資格未達の7番人気以下（数合わせには使わない）」として'
         . '監査ログの全頭欄に残り、--v04-trace で馬番ごとに表示できる'],
        ['REDUCE', '1st AIの回答が使えない',      '@ANCHOR-20261004-NO-HTTP500-UNDETERMINED',
         'レースごと未確定（undetermined）として候補0件にする。'
         . '2nd AIだけの予想を通常の予想として出さないという現行ルール'],

        // ── 印をつけるだけで頭数を減らさない箇所（10/4〜10/6に変更済み）──
        ['FLAG', '低配当（Block 13a）',            'buy_avoid_low_payout',
         '推定確定複勝1.5倍未満かつ単勝3.0倍未満。購入回避フラグのみ。例外3条件で解除あり'],
        ['FLAG', '回収率40%未満（Block 12）',      'buy_avoid_recovery',
         'サンプル30件以上の有効値が2種類以上あり、うち2種類以上が40%未満。購入回避フラグのみ'],
        ['FLAG', '最低基準点（Block 13b）',        'buy_avoid_min_score',
         '本候補70点・補欠60点・人気薄55点。順位づけの優先材料と購入判断にのみ使う'],
        ['FLAG', '11番人気以下の大穴条件',         '4項目の確認',
         '満たさない項目があれば順位で後回しにするだけ。不明は「満たしていない」と扱わない'],
        ['FLAG', '旧資格 F AND (R OR O)',          'allocEvidence',
         '7番人気以下の穴側「優先枠」に入れるかの条件。満たさなくても候補一覧からは消えない'],

        // ── 記録だけで頭数を減らさない箇所 ───────────────────────────────
        ['LOG', '人気帯別上限（上位/中穴/大穴）',  '$mergeUpperMax／$mergeMidMax／$mergeLowerMax',
         '値は算出して監査ログ（merge_upper_max 等）に残すが、_mergeAiResults() の中では'
         . '候補を削る処理に一度も使っていない。人気帯別上限は廃止済み'],
        ['LOG', '2nd独自発見枠の採用条件',         '診断専用',
         'おすすめ度70点以上・8根拠のうち2つ以上・タイプ別頭数上限は、分類と記録にだけ使う。'
         . '満たさない2nd独自の馬も候補から落とさない'],
        ['LOG', '断層位置別の上限',                '廃止',
         '断層の上側・下側による頭数上限は設けていない。断層下側を自動で低評価・除外しない'],
        ['LOG', '大穴進入度による割り当て',        '廃止',
         '大穴進入度1〜2なら0頭といった頭数の割り当ては廃止。頭数はPHPが別途決める'],

        // ── v0.4研究経路だけで効く条件（公開候補には影響しない）──────────
        ['v0.4', 'Tier C／UNVERIFIED',             'v04BandSelection()',
         '独立根拠が無い、または全て未検証の馬は研究用の選出に採らない。頭数合わせの採用はしない'],
        ['v0.4', 'score_status が valid でない',   'v04BandSelection($strict=true)',
         '検証済みの得点が無い馬は採らない（順位を捏造しないため）。'
         . '採点が届くまで研究用の選出は0頭になり、PARTIAL_COUNT に残る'],
        ['v0.4', '契約検証 UNDETERMINED',          '@ANCHOR-20261014-CONTRACT-GATE',
         'snapshot_hash・race_idの不一致、馬番の重複があるAIの採点を採用しない'],
        ['v0.4', 'DATA_INVALID',                   '@ANCHOR-20261014-COUNT-INVALID',
         '入力破損（馬番重複・人気順重複・出走頭数の不一致）で研究用の候補生成を止める'],
    ];
    public const V04_REQ_STATUS = [
        'R01' => ['DB/PHP元値を正本とし、AIで書換えない',                 2, 5, ''],
        'R02' => ['6分前入力を固定し両AIに同じsnapshot_hashを渡す',       2, 5, ''],
        'R03' => ['21/18/15/12/9/6分前を固定馬番ペアで比較',              2, 0, '本番は21分と6分の単勝だけ。6時点のW/Pはv0.4研究経路のみ'],
        'R04' => ['X1〜X6＋Z、Q方式を混在させない',                       2, 0, '本番は旧断層A〜E'],
        'R05' => ['mode・target_count・A/B/D配分を選出前に固定',          2, 0, '本番は旧2区分の可変配分'],
        'R06' => ['H/V10項目で採点。欠損項目・partial合計はnull',          2, 0, '採点の集計とパーサーは試験済み。実AIで採点させるのは未（HV_PROMPT=false）'],
        'R07' => ['両AIは独立。1stは0〜target_count頭、2ndは0〜5頭',      2, 5, ''],
        'R08' => ['候補0頭でも内部全頭JSONを必須',                        2, 5, '本番は現行の11項目JSON。研究用H/V JSONは未受領'],
        'R09' => ['旧F AND(R OR O)は比較用。falseだけで削除しない',        2, 0, '本番は旧資格を使う方式のまま'],
        'R10' => ['Tier A/Bと検証済み得点で帯別選出',                     2, 0, '検証済み得点が無い間は適格0頭（02-7-4どおり）'],
        'R11' => ['不足帯は別帯で補充。不足はPARTIAL_COUNT',              2, 0, ''],
        'R12' => ['帯別採用後に全馬得点上位で再抽出して穴枠を消さない',    2, 5, '本番にも人気薄の保護枠あり（9月27日実装）。3帯版はv0.4研究経路のみ'],
        'R13' => ['+5一致加点は両AIの公開候補一致のみ',                   2, 5, ''],
        'R14' => ['回収率40%未満・低配当・基準点は購入判断と分離',        2, 5, ''],
        'R15' => ['UNKNOWNはSHADOWで暫定MIXED、LIVEは旧方式保持',         2, 5, '本番が旧方式のままという意味'],
        'R16' => ['DATA_INVALIDは候補生成停止。欠損でHTTP500にしない',    2, 5, '本番の500回避は10月5〜6日実装。DATA_INVALIDはv0.4研究経路のみ'],
        'R17' => ['旧DB・回答・成績を保護し、新研究結果は別保存',          2, 5, ''],
        'R18' => ['既知レースのデバッグと未使用レースの検証を分離',        1, 0, 'レポート機構は作成済み。実データは10月17日から'],
    ];
    public const V04_REQ_STAGE_LABEL = [
        0 => '該当なし（本番はv0.4を使っていない）',
        1 => 'コード作成済み',
        2 => '単体試験済み',
        3 => '実AI確認済み',
        4 => 'SHADOW稼働済み',
        5 => '本番有効化済み',
    ];
}
