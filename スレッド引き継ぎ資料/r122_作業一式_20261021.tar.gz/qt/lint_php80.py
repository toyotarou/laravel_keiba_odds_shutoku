#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
サーバの artisan は PHP 8.0.30 です。
このコンテナの php は 8.3 なので `php -l` では 8.1 以降の書き方が通ってしまいます。
そこで、8.1 以降で入った書き方を名指しで探します。

使い方:  python3 qt/lint_php80.py <phpファイル...>
戻り値:  見つかれば 1、無ければ 0
"""
import re
import sys

# 文字列とコメントを空白に潰してから探します（本文の中の単語に当たらないように）
def strip_noise(src: str) -> str:
    out = []
    i = 0
    n = len(src)
    while i < n:
        c = src[i]
        two = src[i:i+2]
        if two == '//':
            j = src.find('\n', i)
            j = n if j < 0 else j
            out.append(' ' * (j - i)); i = j; continue
        if two == '/*':
            j = src.find('*/', i + 2)
            j = n if j < 0 else j + 2
            out.append(re.sub(r'[^\n]', ' ', src[i:j])); i = j; continue
        if c == '#':
            j = src.find('\n', i)
            j = n if j < 0 else j
            out.append(' ' * (j - i)); i = j; continue
        if c in ('"', "'"):
            q = c; j = i + 1
            while j < n:
                if src[j] == '\\': j += 2; continue
                if src[j] == q: j += 1; break
                j += 1
            out.append(re.sub(r'[^\n]', ' ', src[i:j])); i = j; continue
        if src[i:i+3] == '<<<':
            m = re.match(r"<<<\s*(['\"]?)([A-Za-z_]\w*)\1\r?\n", src[i:])
            if m:
                tag = m.group(2)
                e = re.search(r'^\s*' + tag + r'\b', src[i + m.end():], re.M)
                j = i + m.end() + (e.end() if e else 0)
                out.append(re.sub(r'[^\n]', ' ', src[i:j])); i = j; continue
        out.append(c); i += 1
    return ''.join(out)

RULES = [
    # 8.1
    (r'(?<![\w$>])readonly(?![\w])',              'readonly プロパティ', '8.1'),
    (r'(?<![\w$>])enum\s+[A-Za-z_]\w*\s*[:{]',    'enum 宣言',           '8.1'),
    (r'\)\s*:\s*never\b',                          'never 戻り値型',      '8.1'),
    (r'(?<![\w$>])array_is_list\s*\(',             'array_is_list()',     '8.1'),
    (r'\(\s*\.\.\.\s*\)',                          '第一級callable記法',  '8.1'),
    (r'(?<![\w$>])final\s+const\b',                'final な定数',        '8.1'),
    (r'(?<![\w$>])fsync\s*\(',                     'fsync()',             '8.1'),
    (r'\b0o[0-7]',                                 '0o 八進リテラル',     '8.1'),
    (r':\s*[A-Za-z_\\][\w\\]*\s*&\s*[A-Za-z_\\][\w\\]*\s*(?:\{|;|\))', '交差型', '8.1'),
    # 8.2
    (r'(?<![\w$>])readonly\s+class\b',             'readonly なクラス',   '8.2'),
    # 型の位置に限って探します（`$a === null || ...` に当たらないように）
    (r'(?<![\w$>])(?:true|false|null)\s*\|\s*[\w\\]+\s*(?:\$\w|\{|;)', 'true/false/null の合併型', '8.2'),
    (r':\s*[\w\\]+\s*\|\s*(?:true|false)\s*(?:\{|;)',  'true/false の合併型', '8.2'),
    (r'(?<![\w$>])mb_str_split\s*\(',              'mb_str_split()',      '7.4'),
    # 8.3
    (r'(?<![\w$>])const\s+(?:string|int|float|bool|array|mixed)\s+[A-Z_]', '型つき定数', '8.3'),
    (r'(?<![\w$>])json_validate\s*\(',             'json_validate()',     '8.3'),
    (r'#\[\\?Override\]',                          '#[Override]',         '8.3'),
    # 8.4
    (r'(?<![\w$>])array_find\s*\(',                'array_find()',        '8.4'),
    (r'(?<![\w$>])array_any\s*\(',                 'array_any()',         '8.4'),
    (r'(?<![\w$>])array_all\s*\(',                 'array_all()',         '8.4'),
    (r'(?<![\w$>])mb_trim\s*\(',                   'mb_trim()',           '8.4'),
    (r'\{\s*get\s*(?:=>|\{)',                      'プロパティフック',    '8.4'),
]

def main(paths):
    bad = 0
    for p in paths:
        try:
            with open(p, encoding='utf-8') as f:
                src = f.read()
        except OSError as e:
            print('  読めません %s (%s)' % (p, e)); bad += 1; continue
        clean = strip_noise(src)
        for pat, name, ver in RULES:
            for m in re.finditer(pat, clean):
                line = clean.count('\n', 0, m.start()) + 1
                body = src.splitlines()[line - 1].strip()[:110] if line - 1 < len(src.count('\n') * [0] + src.splitlines()) else ''
                print('  × %s:%d  %s は PHP %s からです' % (p.split('/')[-1], line, name, ver))
                print('      %s' % body)
                bad += 1
    if bad:
        print('PHP 8.0 で動かない書き方が %d 件あります' % bad)
        return 1
    print('PHP 8.0 互換 : 問題なし（%d ファイル）' % len(paths))
    return 0

if __name__ == '__main__':
    sys.exit(main(sys.argv[1:]))
