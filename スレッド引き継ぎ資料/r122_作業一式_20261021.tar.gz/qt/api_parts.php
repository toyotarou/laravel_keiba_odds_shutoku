
    public function getBaganrikiR122Race(string $race_id)
    {
        $parts = explode('-', $race_id);
        if (count($parts) !== 5) {
            return response()->json([
                'schema_version' => 'baganriki-v041-r12-2',
                'race_id'        => $race_id,
                'state'          => 'UNAVAILABLE',
                'diagnostics'    => [['code' => 'ENTRY_SET_MISMATCH',
                                      'message' => 'race_id の形が違います（YYYYMMDD-回-場-日-R）']],
                'buy_recommended' => false,
            ], 400);
        }
        [$ymd, $kaisuu, $basho, $day, $race] = $parts;
        $date = substr($ymd, 0, 4) . '-' . substr($ymd, 4, 2) . '-' . substr($ymd, 6, 2);

        // ── 正本のレース情報 ────────────────────────────────────────────
        $r = \DB::table('t_horse_odds_finder_races')
            ->where('date', $date)->where('kaisuu', $kaisuu)->where('basho', $basho)
            ->where('day', $day)->where('race', (int) $race)->first();
        if ($r === null) {
            return response()->json(BaganrikiPublicView::build([
                'race_id'     => $race_id,
                'state'       => 'UNAVAILABLE',
                'diagnostics' => [['code' => 'ENTRY_MISSING',
                                   'message' => 'このレースは正本に存在しません']],
            ]), 404);
        }

        // ── 保存済みの r12.2 の記録を読む ───────────────────────────────
        //   まだ凍結・公開の保存を実装していない期間は、
        //   snapshot が無い状態として PENDING / UNAVAILABLE を返します。
        // ══════════════════════════════════════════════════════════════
        // @ANCHOR-20261020-R122-API  本番の世代（generation=0）だけを読みます
        // ══════════════════════════════════════════════════════════════
        // 【直した中身】
        //   これまで orderByDesc('generation') で読んでいたので、
        //   試験で保存した REPLAY（generation=900）があると
        //   <b>公開APIがその試験用の記録を返してしまいました。</b>
        //   読取APIは本番の世代だけを見ます。
        //
        //   3つの版と公開履歴は<b>ひとつの読取取引</b>でそろえて取ります。
        //   書込ロックは持ちません（契約8章）。
        $snap = null; $live = null; $pub = null; $slots = null;
        if (\Schema::hasTable('baganriki_snapshots')) {
            [$snap, $live, $pub, $slots] = \DB::transaction(function () use ($race_id) {
                $s = \DB::table('baganriki_snapshots')->where('race_id', $race_id)
                       ->where('generation', 0)->first();
                $l = null; $p = null; $w = null;
                if ($s !== null && \Schema::hasTable('baganriki_live_states')) {
                    $l = \DB::table('baganriki_live_states')
                           ->where('snapshot_id', $s->id)->first();
                }
                if ($s !== null && \Schema::hasTable('baganriki_publications')) {
                    $p = \DB::table('baganriki_publications')
                           ->where('snapshot_id', $s->id)
                           ->orderByDesc('published_at')->first();
                }
                if ($s !== null && \Schema::hasTable('baganriki_ai_attempts')) {
                    $w = BaganrikiWorker::slots((int) $s->id);
                }
                return [$s, $l, $p, $w];
            });
        }

        $cancellations = ($live !== null && $live->cancellations !== null)
            ? (json_decode((string) $live->cancellations, true) ?: []) : [];
        $activeCount   = ($live !== null) ? $live->active_count : null;
        $allCancelled  = ($activeCount !== null && (int) $activeCount === 0);

        // 実効公開期限。投票締切の正本が無ければ期限を作らず、推測もしません。
        $effPublish = null; $pastDeadline = false;
        $salesClose = $snap->sales_close_at ?? null;
        if ($salesClose !== null) {
            $sc = BaganrikiTime::us((string) $salesClose);
            if ($sc !== null) {
                $lc = ($live !== null && $live->live_close !== null)
                    ? BaganrikiTime::us((string) $live->live_close) : null;
                $eff = BaganrikiTime::effectiveDeadlines($sc, $lc);
                $effPublish   = BaganrikiTime::toJst($eff['publish']);
                $pastDeadline = (BaganrikiTime::us(date('c')) ?? 0) > $eff['publish'];
            }
        }

        $diag = [];
        if ($salesClose === null) {
            $diag[] = ['code' => 'PUBLICATION_DEADLINE_EXCEEDED',
                       'message' => '投票締切の正本が特定できていないため公開しません'];
        }
        $inputInvalid = ($snap === null)
            ? false
            : (($snap->input_invalid_code ?? null) !== null);
        if ($inputInvalid) {
            $diag[] = ['code' => (string) $snap->input_invalid_code,
                       'message' => (string) ($snap->input_invalid_reason ?? '')];
        }

        $state = BaganrikiPublicView::state(
            $pub !== null, $allCancelled, $inputInvalid, $pastDeadline);
        if ($snap === null) { $state = 'PENDING'; }

        $pubDto = null;
        if ($pub !== null) {
            $pubDto = [
                'publication_id'           => $pub->publication_id,
                'published_at'             => $pub->published_at,
                'prediction_target_count'  => $pub->prediction_target_count ?? null,
                'prediction_quota'         => json_decode((string) ($pub->prediction_quota ?? 'null'), true),
                'publication_target_count' => $pub->publication_target_count ?? null,
                'publication_quota'        => json_decode((string) ($pub->publication_quota ?? 'null'), true),
                'candidates'               => json_decode((string) ($pub->candidates ?? '[]'), true),
                'evidence'                 => json_decode((string) ($pub->evidence ?? '[]'), true),
            ];
        }

        // @ANCHOR-20261020-R122-API  いまの取消を映した枠と候補数
        //   正式公開のリストは動かしません（取消だけで再選出しません）。
        //   取消になった馬を除いた数だけを、別の欄として返します。
        $actualQuota = null; $availableCount = null;
        if ($pubDto !== null) {
            $cans = (array) ($pubDto['candidates'] ?? []);
            $actualQuota = ['A' => 0, 'B' => 0, 'D' => 0];
            $availableCount = 0;
            foreach ($cans as $c) {
                $no = (int) ($c['horse_no'] ?? 0);
                if (in_array($no, array_map('intval', $cancellations), true)) { continue; }
                $availableCount++;
                $b = (string) ($c['band'] ?? '');
                if (isset($actualQuota[$b])) { $actualQuota[$b]++; }
            }
        }
        $effReply = null;
        if ($salesClose !== null) {
            $sc2 = BaganrikiTime::us((string) $salesClose);
            if ($sc2 !== null) {
                $lc2 = ($live !== null && $live->live_close !== null)
                    ? BaganrikiTime::us((string) $live->live_close) : null;
                $eff2 = BaganrikiTime::effectiveDeadlines($sc2, $lc2);
                $effReply = BaganrikiTime::toJst($eff2['reply']);
            }
        }

        return response()->json(BaganrikiPublicView::build([
            'race_id'         => $race_id,
            'state'           => $state,
            'response_revision'     => $live->response_revision ?? null,
            'publication_revision'  => $live->publication_revision ?? null,
            'latest_publication_id' => $live->latest_publication_id ?? null,
            'actual_quota'              => $actualQuota,
            'available_candidate_count' => $availableCount,
            'live_close'              => $live->live_close ?? null,
            'effective_reply_deadline' => $effReply,
            'worker_state'    => $slots,
            'mode'            => $snap->mode            ?? null,
            'mode_status'     => $snap->mode_status     ?? null,
            'allocation_mode' => $snap->allocation_mode ?? null,
            'mode_policy_id'  => $snap->mode_policy_id  ?? null,
            'display_rating'  => $snap->display_rating  ?? null,
            'publication'     => $pubDto,
            'state_revision'  => $live->state_revision ?? null,
            'cancellations'   => $cancellations,
            'active_count'    => $activeCount,
            'live_target_count' => $live->live_target_count ?? null,
            'live_quota'      => ($live !== null && ($live->live_quota ?? null) !== null)
                                 ? json_decode((string) $live->live_quota, true) : null,
            'effective_publish_deadline' => $effPublish,
            'collection_audit' => ($snap !== null && ($snap->collection_audit ?? null) !== null)
                                  ? json_decode((string) $snap->collection_audit, true) : null,
            'input_freeze_at' => $snap->input_freeze_at ?? null,
            'coverage'        => ($snap !== null && ($snap->coverage ?? null) !== null)
                                 ? json_decode((string) $snap->coverage, true) : null,
            'diagnostics'     => $diag,
            'shortfalls'      => ($pub !== null && ($pub->shortfalls ?? null) !== null)
                                 ? json_decode((string) $pub->shortfalls, true) : [],
        ]));
    }

    public static function r122RaceId($date, $kaisuu, $basho, $day, $race): string
    {
        return str_replace('-', '', (string) $date) . '-' . (string) $kaisuu . '-'
             . (string) $basho . '-' . (string) $day . '-' . (int) $race;
    }
