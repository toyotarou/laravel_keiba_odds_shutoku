<?php

/**
 * ═══════════════════════════════════════════════════════════════════════════
 * @ANCHOR-20261020-R122-DIAG  応答の診断（inspect と resolve で同じ関数を使う）
 * ═══════════════════════════════════════════════════════════════════════════
 * 根拠：server_contract_r12.2.txt 6章・7章
 *   「訂正最大1回。inspectとresolveは同じ診断関数を使い、repair_scopeを返す」
 *   「馬番欠落、重複、未知馬、局所フィールド不正はその範囲だけ隔離し、
 *     正常な他馬を残す」
 *   「公開リストやフラグの不一致だけでは、無関係な評価行を訂正対象へ
 *     広げない。欠落馬は凍結runner集合に存在しhorses対象内なら新規救済する」
 *
 * ■ 直してよい範囲（repair_scope）の分け方
 *   horses              評価行そのもの（欠落・重複・未知馬・局所の項目不正）
 *   rank_bands          順位関連項目（band_ranks / evidence_band_ranks）
 *   presentation_horses 公開フラグ・非選出理由
 *   summary_horses      帯・資格・Tier・採点集計・5系統レビュー・
 *                       非適格馬の順位欄
 *   public_candidates   公開リスト
 *   top_fields          最上位項目
 *
 *   <b>公開リストと公開フラグの不一致では、horses を広げません。</b>
 *   その馬だけを presentation_horses / public_candidates に入れます。
 *
 * ■ 採点辞書（10月20日の指定）
 *   H1 能力適性18／H2 時系列15／H3 断層12／H4 類似統計9／H5 単複差6
 *   V1 補正OPI12／V2 能力価格乖離10／V3 回収率母数8／V4 推定確定オッズ6
 *   V5 情報価格信頼性4   合計100
 *
 * 読むだけです。DBへは書きません（保存は呼出側が行います）。
 */
final class BaganrikiDiagnose
{
    public const VERSION = 'r122-diagnose-v1';

    /** 採点辞書（満点） */
    public const SCORE_CAP = ['H1' => 18, 'H2' => 15, 'H3' => 12, 'H4' => 9, 'H5' => 6,
                              'V1' => 12, 'V2' => 10, 'V3' => 8,  'V4' => 6, 'V5' => 4];

    /** 1頭ぶんに必ずある項目 */
    public const HORSE_KEYS = ['horse_no', 'band', 'tier', 'eligibility', 'family_review',
                               'evidence', 'counterevidence', 'scores', 'score_evidence',
                               'score_status', 'total_score', 'observed_sum', 'observed_cap',
                               'rank_basis', 'rank_reason', 'public_candidate',
                               'nonselect_reason', 'explanation',
                               'evidence_rank_evidence_ids', 'evidence_rank_reason'];

    public const ENUMS = [
        'band'         => ['A', 'B', 'D'],
        'tier'         => ['A', 'B', 'C', 'UNVERIFIED'],
        'eligibility'  => ['ELIGIBLE', 'NO_EVIDENCE', 'UNVERIFIED'],
        'score_status' => ['complete', 'partial'],
        'rank_basis'   => ['SCORE', 'EVIDENCE', 'NOT_RANKED'],
    ];
    public const NONSELECT_CODES = ['BAND_QUOTA', 'NO_EVIDENCE', 'UNVERIFIED',
                                    'SELECTION_DISABLED'];
    public const FAMILIES = ['ability', 'gap', 'market', 'similar_value', 'win_place'];
    public const FAMILY_STATUS = ['SUPPORTED', 'NO_SUPPORT', 'DATA_MISSING'];
    public const BANDS = ['A', 'B', 'D'];

    /**
     * 応答を診断します。
     *
     * @param array $res 応答（extract で取り出した JSON）
     * @param array $src 凍結入力（INPUT_JSON）
     * @return array ['ok','validator_version','row_valid','repair_scope','findings',
     *                'missing','duplicated','unknown']
     */
    public static function run(array $res, array $src): array
    {
        $find = [];
        $scope = ['horses' => [], 'rank_bands' => [], 'presentation_horses' => [],
                  'summary_horses' => [], 'public_candidates' => false,
                  'top_fields' => []];
        $add = static function (string $sc, $target, string $code, string $why)
               use (&$find, &$scope) {
            $find[] = ['scope' => $sc, 'target' => $target, 'code' => $code,
                       'reason' => $why];
            if ($sc === 'public_candidates') { $scope['public_candidates'] = true; return; }
            if (!isset($scope[$sc])) { return; }
            if (!in_array($target, $scope[$sc], true)) { $scope[$sc][] = $target; }
        };

        // ── 凍結集合（帯も凍結入力の値を正とします）───────────────────
        $frozenBand = []; $frozenNums = [];
        foreach ((array) ($src['runners'] ?? []) as $r) {
            $no = (int) ($r['horse_no'] ?? 0);
            if ($no <= 0) { continue; }
            $frozenNums[] = $no;
            $frozenBand[$no] = (string) ($r['band'] ?? '');
        }
        sort($frozenNums);

        // ═══ ① 最上位項目 ═══════════════════════════════════════════
        foreach (['target_count', 'role_cap', 'quota', 'role_quota', 'learning_stage',
                  'selection_enabled'] as $k) {
            if (!array_key_exists($k, $res)) {
                $add('top_fields', $k, 'TOP_MISSING', $k . 'がありません');
                continue;
            }
            if (array_key_exists($k, $src) && $res[$k] !== $src[$k]) {
                $add('top_fields', $k, 'TOP_MISMATCH',
                     $k . 'が固定入力と違います');
            }
        }
        foreach (['shortfalls', 'validation_issues'] as $k) {
            if (!array_key_exists($k, $res) || !is_array($res[$k])) {
                $add('top_fields', $k, 'TOP_TYPE', $k . 'は配列です');
            }
        }
        $selEnabled = ($res['selection_enabled'] ?? null) === true;

        // ═══ ② 評価行（欠落・重複・未知馬・局所の項目不正）═══════════
        $rows = (array) ($res['horses'] ?? []);
        $byNo = []; $dup = []; $unknown = [];
        foreach ($rows as $h) {
            if (!is_array($h) || !array_key_exists('horse_no', $h)
                || !is_int($h['horse_no'])) {
                $add('horses', null, 'HORSE_NO_INVALID', 'horse_no が整数ではありません');
                continue;
            }
            $no = (int) $h['horse_no'];
            if (isset($byNo[$no])) {
                if (!in_array($no, $dup, true)) { $dup[] = $no; }
                $add('horses', $no, 'HORSE_DUPLICATED', '同じ馬番が2行あります');
                continue;
            }
            if ($frozenNums !== [] && !in_array($no, $frozenNums, true)) {
                $unknown[] = $no;
                $add('horses', $no, 'HORSE_UNKNOWN', '凍結集合にいない馬番です');
                continue;
            }
            $byNo[$no] = $h;
        }
        $missing = array_values(array_diff($frozenNums, array_keys($byNo)));
        sort($missing);
        foreach ($missing as $no) {
            // 凍結集合にいる馬の欠落は、horses の対象として救済します
            $add('horses', $no, 'HORSE_MISSING', '凍結集合にいるのに評価行がありません');
        }

        $rowValid = [];
        foreach ($byNo as $no => $h) {
            $okRow = true;
            foreach (self::HORSE_KEYS as $k) {
                if (!array_key_exists($k, $h)) {
                    $add('horses', $no, 'FIELD_MISSING', $k . 'がありません');
                    $okRow = false;
                }
            }
            foreach (self::ENUMS as $k => $allow) {
                if (array_key_exists($k, $h)
                    && !in_array($h[$k], $allow, true)) {
                    $add('horses', $no, 'FIELD_ENUM',
                         $k . 'の値が決められた中にありません');
                    $okRow = false;
                }
            }
            if (array_key_exists('public_candidate', $h)
                && !is_bool($h['public_candidate'])) {
                $add('horses', $no, 'FIELD_TYPE', 'public_candidate は真偽です');
                $okRow = false;
            }
            // 採点の内訳と集計
            $sc = $h['scores'] ?? null;
            if (!is_array($sc)) {
                $add('horses', $no, 'SCORES_TYPE', 'scores がありません');
                $okRow = false;
            } else {
                $extra = array_values(array_diff(array_keys($sc),
                                                 array_keys(self::SCORE_CAP)));
                if ($extra !== []) {
                    $add('horses', $no, 'SCORES_UNKNOWN_KEY',
                         '採点辞書に無い項目があります（' . implode('・', $extra) . '）');
                    $okRow = false;
                }
                $sum = 0; $cap = 0; $bad = [];
                foreach (self::SCORE_CAP as $k => $mx) {
                    if (!array_key_exists($k, $sc)) {
                        $add('horses', $no, 'SCORES_MISSING', $k . 'がありません');
                        $okRow = false;
                        continue;
                    }
                    $v = $sc[$k];
                    if ($v === null) { continue; }
                    if (!is_int($v) || $v < 0 || $v > $mx) { $bad[] = $k; continue; }
                    $sum += $v; $cap += $mx;
                }
                if ($bad !== []) {
                    $add('summary_horses', $no, 'SCORES_RANGE',
                         '満点を超える・整数でない採点があります（'
                         . implode('・', $bad) . '）');
                    $okRow = false;
                }
                if ($bad === [] && $extra === []) {
                    if (($h['observed_sum'] ?? null) !== $sum) {
                        $add('summary_horses', $no, 'OBSERVED_SUM',
                             'observed_sum が採点の合計と合いません');
                        $okRow = false;
                    }
                    if (($h['observed_cap'] ?? null) !== $cap) {
                        $add('summary_horses', $no, 'OBSERVED_CAP',
                             'observed_cap が採点した項目の満点合計と合いません');
                        $okRow = false;
                    }
                    if (($h['score_status'] ?? null) === 'complete'
                        && ($h['total_score'] ?? null) !== null
                        && (int) $h['total_score'] !== $sum) {
                        $add('summary_horses', $no, 'TOTAL_SCORE',
                             'total_score が採点の合計と合いません');
                        $okRow = false;
                    }
                }
            }
            // 帯は凍結入力が正
            if (isset($frozenBand[$no]) && $frozenBand[$no] !== ''
                && ($h['band'] ?? null) !== $frozenBand[$no]) {
                $add('summary_horses', $no, 'BAND_MISMATCH',
                     '帯が凍結入力と違います');
                $okRow = false;
            }
            // 5系統レビュー
            $fr = $h['family_review'] ?? null;
            $sup = false;
            if (!is_array($fr)) {
                $add('summary_horses', $no, 'FAMILY_TYPE', 'family_review がありません');
                $okRow = false;
            } else {
                foreach (self::FAMILIES as $fam) {
                    if (!isset($fr[$fam]) || !is_array($fr[$fam])) {
                        $add('summary_horses', $no, 'FAMILY_MISSING',
                             $fam . ' のレビューがありません');
                        $okRow = false;
                        continue;
                    }
                    $st = $fr[$fam]['status'] ?? null;
                    if (!in_array($st, self::FAMILY_STATUS, true)) {
                        $add('summary_horses', $no, 'FAMILY_STATUS',
                             $fam . ' の status が決められた中にありません');
                        $okRow = false;
                        continue;
                    }
                    if ($st === 'SUPPORTED') { $sup = true; }
                }
                $extraFam = array_values(array_diff(array_keys($fr), self::FAMILIES));
                if ($extraFam !== []) {
                    $add('summary_horses', $no, 'FAMILY_UNKNOWN',
                         '5系統に無いものがあります（' . implode('・', $extraFam) . '）');
                    $okRow = false;
                }
            }
            // 資格と5系統レビューの整合
            $elig = $h['eligibility'] ?? null;
            if (in_array($elig, self::ENUMS['eligibility'], true) && is_array($fr)) {
                if (($elig === 'ELIGIBLE') !== $sup) {
                    $add('summary_horses', $no, 'ELIGIBILITY_VS_FAMILY',
                         $sup ? '支持する系統があるのに ELIGIBLE ではありません'
                              : '支持する系統が1つも無いのに ELIGIBLE です');
                    $okRow = false;
                }
            }
            // 非適格馬の順位欄
            if ($elig !== null && $elig !== 'ELIGIBLE'
                && ($h['rank_basis'] ?? null) !== 'NOT_RANKED') {
                $add('summary_horses', $no, 'NOT_RANKED',
                     '非適格馬の rank_basis は NOT_RANKED です');
                $okRow = false;
            }
            $rowValid[$no] = $okRow;
        }

        // ═══ ③ 順位関連項目（band_ranks / evidence_band_ranks）═══════
        foreach (['band_ranks', 'evidence_band_ranks'] as $key) {
            $br = $res[$key] ?? null;
            if (!is_array($br)) {
                $add('rank_bands', $key, 'BANDS_TYPE', $key . 'がありません');
                continue;
            }
            $extraB = array_values(array_diff(array_keys($br), self::BANDS));
            if ($extraB !== []) {
                $add('rank_bands', $key, 'BANDS_UNKNOWN',
                     'A・B・D 以外の帯があります（' . implode('・', $extraB) . '）');
            }
            foreach (self::BANDS as $b) {
                $want = [];
                foreach ($frozenBand as $no => $bb) {
                    if ($bb === $b) { $want[] = (int) $no; }
                }
                sort($want);
                $got = array_map('intval', (array) ($br[$b] ?? []));
                $gotSorted = $got; sort($gotSorted);
                if (count(array_unique($got)) !== count($got)) {
                    $add('rank_bands', $b, 'BAND_DUPLICATED',
                         $b . '帯の順位に同じ馬番があります');
                    continue;
                }
                if ($gotSorted !== $want) {
                    $add('rank_bands', $b, 'BAND_SET',
                         $b . '帯の馬番の集合が凍結入力と違います');
                }
            }
        }
        // 方式（全頭complete の帯は SCORE、partial を含む帯は EVIDENCE）
        $br = (array) ($res['band_ranks'] ?? []);
        foreach (self::BANDS as $b) {
            $nums = array_map('intval', (array) ($br[$b] ?? []));
            if ($nums === []) { continue; }
            $allComplete = true; $have = false;
            foreach ($nums as $no) {
                if (!isset($byNo[$no])) { continue; }
                $have = true;
                if (($byNo[$no]['score_status'] ?? 'partial') !== 'complete') {
                    $allComplete = false;
                }
            }
            if (!$have) { continue; }
            $wantBasis = $allComplete ? 'SCORE' : 'EVIDENCE';
            foreach ($nums as $no) {
                if (!isset($byNo[$no])) { continue; }
                if (($byNo[$no]['eligibility'] ?? null) !== 'ELIGIBLE') { continue; }
                if (($byNo[$no]['rank_basis'] ?? null) !== $wantBasis) {
                    $add('rank_bands', $b, 'BASIS_MISMATCH',
                         $b . '帯は' . $wantBasis . 'のはずです（馬番 ' . $no . '）');
                    break;
                }
            }
        }
        // EVIDENCE の帯は両方の順位を一致させます
        if (isset($res['band_ranks'], $res['evidence_band_ranks'])
            && is_array($res['band_ranks']) && is_array($res['evidence_band_ranks'])) {
            foreach (self::BANDS as $b) {
                $a1 = array_map('intval', (array) ($res['band_ranks'][$b] ?? []));
                $a2 = array_map('intval', (array) ($res['evidence_band_ranks'][$b] ?? []));
                if ($a1 === [] && $a2 === []) { continue; }
                $allComplete = true; $have = false;
                foreach ($a1 as $no) {
                    if (!isset($byNo[$no])) { continue; }
                    $have = true;
                    if (($byNo[$no]['score_status'] ?? 'partial') !== 'complete') {
                        $allComplete = false;
                    }
                }
                if ($have && !$allComplete && $a1 !== $a2) {
                    $add('rank_bands', $b, 'EVIDENCE_ORDER',
                         $b . '帯は点数を順位キーに使えないので'
                         . '両方の順位をそろえます');
                }
            }
        }

        // ═══ ④ 公開リスト ═══════════════════════════════════════════
        $pc = $res['public_candidates'] ?? null;
        if (!is_array($pc)) {
            $add('public_candidates', 'public_candidates', 'PC_TYPE',
                 'public_candidates がありません');
            $pc = [];
        } else {
            $pc = array_map('intval', $pc);
            if (count(array_unique($pc)) !== count($pc)) {
                $add('public_candidates', 'public_candidates', 'PC_DUPLICATED',
                     '公開リストに同じ馬番があります');
            }
            $out = array_values(array_diff($pc, $frozenNums));
            if ($frozenNums !== [] && $out !== []) {
                $add('public_candidates', 'public_candidates', 'PC_UNKNOWN',
                     '公開リストに凍結集合にいない馬番があります（'
                     . implode('・', $out) . '）');
            }
            if (!$selEnabled && $pc !== []) {
                $add('public_candidates', 'public_candidates', 'PC_NOT_EMPTY',
                     '選出しない状態なので公開リストは空です');
            }
            if ($selEnabled) {
                // 帯の先頭から枠数ぶん、適格馬だけを取ります（飛ばし取りはしません）
                $q = (array) ($res['role_quota'] ?? []);
                $want = [];
                foreach (self::BANDS as $b) {
                    $k = (int) ($q[$b] ?? 0);
                    $taken = 0;
                    foreach (array_map('intval', (array) ($br[$b] ?? [])) as $no) {
                        if ($taken >= $k) { break; }
                        if (($byNo[$no]['eligibility'] ?? null) === 'ELIGIBLE') {
                            $want[] = $no; $taken++;
                        }
                    }
                }
                if ($want !== $pc) {
                    $add('public_candidates', 'public_candidates', 'PC_ORDER',
                         '帯の先頭から枠数ぶん取っていません（期待 '
                         . implode('-', $want) . '）');
                }
            }
        }

        // ═══ ⑤ 公開フラグと非選出理由 ═══════════════════════════════
        //   ここでの不一致では horses を広げません（契約6章）。
        foreach ($byNo as $no => $h) {
            $flag = $h['public_candidate'] ?? null;
            if (is_bool($flag) && $flag !== in_array((int) $no, $pc, true)) {
                $add('presentation_horses', $no, 'FLAG_VS_LIST',
                     'public_candidate が公開リストと合いません');
            }
            $nsr = $h['nonselect_reason'] ?? null;
            if ($flag === true) {
                if ($nsr !== null) {
                    $add('presentation_horses', $no, 'NSR_PRESENT',
                         '公開する馬に非選出理由があります');
                }
                continue;
            }
            if ($nsr === null) {
                $add('presentation_horses', $no, 'NSR_MISSING',
                     '公開しない馬に非選出理由がありません');
                continue;
            }
            if (!is_array($nsr)) {
                // 配列・objectでない値でも、この馬の表示項目だけの話にします
                $add('presentation_horses', $no, 'NSR_TYPE',
                     '非選出理由の形が違います');
                continue;
            }
            $code = $nsr['code'] ?? null;
            if (!is_string($code) || !in_array($code, self::NONSELECT_CODES, true)) {
                $add('presentation_horses', $no, 'NSR_CODE',
                     '非選出理由の code が決められた中にありません');
                continue;
            }
            if (!isset($nsr['reason']) || !is_string($nsr['reason'])
                || trim($nsr['reason']) === '') {
                $add('presentation_horses', $no, 'NSR_REASON',
                     '非選出理由の説明が空です');
            }
            if (!$selEnabled && $code !== 'SELECTION_DISABLED') {
                $add('presentation_horses', $no, 'NSR_DISABLED',
                     '選出しない状態の非選出理由は SELECTION_DISABLED です');
            }
        }

        sort($scope['horses']);
        sort($scope['presentation_horses']);
        sort($scope['summary_horses']);
        sort($scope['top_fields']);
        sort($unknown);
        return [
            'ok' => ($find === []),
            'validator_version' => self::VERSION,
            'row_valid'    => $rowValid,
            'repair_scope' => $scope,
            'findings'     => $find,
            'missing'      => $missing,
            'duplicated'   => $dup,
            'unknown'      => $unknown,
        ];
    }

    /**
     * 診断の見出し（監査やログに1行で残すため）
     */
    public static function summary(array $d): string
    {
        if ($d['ok']) { return '直すところはありません'; }
        $by = [];
        foreach ($d['findings'] as $f) {
            $by[$f['scope']] = ($by[$f['scope']] ?? 0) + 1;
        }
        $p = [];
        foreach ($by as $k => $n) { $p[] = $k . ' ' . $n . '件'; }
        return implode('／', $p);
    }
}
