<?php
require __DIR__ . '/shim.php';
require __DIR__ . '/logstub.php';
require __DIR__ . '/../harness.php';
require __DIR__ . '/worker_ns.php';
require __DIR__ . '/diag_ns.php';
require __DIR__ . '/ctrl.php';
function qt_out($s = '') { echo $s . "\n"; }
QtDb::$pdo = new PDO('sqlite::memory:');
QtDb::$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
qt_schema();
QtDb::$pdo->exec('CREATE TABLE baganriki_validation_results (
    id INTEGER PRIMARY KEY AUTOINCREMENT, attempt_id INTEGER NOT NULL,
    validator_version TEXT NOT NULL, normal_part TEXT, diagnostics TEXT,
    repair_scope TEXT, field_sources TEXT, rank_sources TEXT,
    created_at TEXT NOT NULL)');
QtDb::$pdo->exec('CREATE TABLE baganriki_publications (
    id INTEGER PRIMARY KEY AUTOINCREMENT, publication_id TEXT NOT NULL UNIQUE,
    snapshot_id INTEGER NOT NULL, intent_id INTEGER NOT NULL,
    published_at TEXT NOT NULL, prediction_target_count INTEGER,
    prediction_quota TEXT, publication_target_count INTEGER,
    publication_quota TEXT, active_count INTEGER, candidates TEXT,
    evidence TEXT, shortfalls TEXT, used_state_revision INTEGER,
    used_response_revision INTEGER, public_proof_hash TEXT)');
QtDb::$pdo->exec('CREATE TABLE baganriki_publication_intents (
    id INTEGER PRIMARY KEY AUTOINCREMENT, snapshot_id INTEGER NOT NULL,
    job_id TEXT NOT NULL UNIQUE, intent_hash TEXT NOT NULL,
    read_state_revision INTEGER, read_response_revision INTEGER,
    read_publication_revision INTEGER, state TEXT NOT NULL DEFAULT "OPEN",
    publication_id TEXT, created_at TEXT NOT NULL,
    UNIQUE (snapshot_id, intent_hash))');
$root = __DIR__ . '/../mat';
(function () use ($root) {

        
        $vDir = rtrim($root, '/') . '/validation/normal';
        qt_out('════════════════════════════════════════════════════════');
        qt_out(' r12.2 統合・公開・intent・revision の通し試験');
        qt_out('════════════════════════════════════════════════════════');
        qt_out('  実行時刻 : ' . date('c'));
        qt_out('  資料     : ' . $vDir);
        qt_out('  ※ 全部ロールバックします。DBへ残る書き込みは0件です');
        qt_out('');
        $need = ['MIXED_N16_1st_input.json', 'MIXED_N16_1st_output.json',
                 'MIXED_N16_2nd_input.json', 'MIXED_N16_2nd_output.json'];
        foreach ($need as $f) {
            if (!is_file($vDir . '/' . $f)) {
                qt_out('  × ' . $vDir . '/' . $f . ' がありません');
                return;
            }
        }

        $pass = 0; $fail = 0;
        $check = function (string $id, string $what, $got, $want) use (&$pass, &$fail) {
            $okk = ($got === $want);
            if ($okk) { $pass++; } else { $fail++; }
            qt_out(sprintf('  %s %-9s %-50s %s',
                $okk ? '○' : '×', $id, $what,
                $okk ? '' : ('得=' . var_export($got, true) . ' 期待=' . var_export($want, true))));
        };
        $rd = static fn(string $f) => json_decode(
            (string) file_get_contents($f), true);
        $j = static fn($v) => (string) json_encode($v,
            JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PRESERVE_ZERO_FRACTION);
        $BEGIN = \App\Http\Controllers\Api\BaganrikiResponse::BEGIN;
        $END   = \App\Http\Controllers\Api\BaganrikiResponse::END;

        $in1  = $rd($vDir . '/MIXED_N16_1st_input.json');
        $out1 = $rd($vDir . '/MIXED_N16_1st_output.json');
        $in2  = $rd($vDir . '/MIXED_N16_2nd_input.json');
        $out2 = $rd($vDir . '/MIXED_N16_2nd_output.json');

        $seq = 0;
        $mk = function (array $o1, array $o2, array $opt = [])
              use ($in1, $in2, $j, $BEGIN, $END, &$seq): int {
            $seq++;
            $now  = \App\Http\Controllers\Api\BaganrikiWorker::nowUs();
            $sales = $now + 3600 * 1000000;
            $nums = [];
            foreach ((array) $in1['runners'] as $r) { $nums[] = (int) $r['horse_no']; }
            $cancel = array_map('intval', (array) ($opt['cancelled'] ?? []));
            $sid = \DB::table('baganriki_snapshots')->insertGetId([
                'race_id' => 'PT-' . $seq, 'generation' => 900, 'run_id' => 'PT',
                'snapshot_hash'   => (string) $in1['snapshot_hash'],
                'input_json_1st'  => $j($in1), 'input_json_2nd' => $j($in2),
                'frozen_nums'     => $j($nums),
                'allocation_mode' => (string) $in1['allocation_mode'],
                'mode'            => (string) $in1['mode'],
                'mode_status'     => (string) $in1['mode_status'],
                'target_count'    => (int) $in1['target_count'],
                'quota_1st'       => $j($in1['quota']),
                'sales_close_at'  => \App\Http\Controllers\Api\BaganrikiWorker::toDb($sales),
                'created_at'      => \App\Http\Controllers\Api\BaganrikiWorker::toDb($now),
            ]);
            \DB::table('baganriki_live_states')->insert([
                'snapshot_id' => $sid, 'cancellations' => $j($cancel),
                'active_count' => count($nums) - count($cancel),
                'live_target_count' => (int) $in1['target_count'],
                'live_quota' => $j($in1['quota']), 'live_close' => null,
                'state_revision' => 0, 'response_revision' => 0,
                'publication_revision' => 0, 'latest_publication_id' => null,
                'updated_at' => \App\Http\Controllers\Api\BaganrikiWorker::toDb($now),
            ]);
            foreach ([['1st', $o1], ['2nd', $o2]] as $k => $pair) {
                [$role, $doc] = $pair;
                if ($doc === []) { continue; }
                $raw = $BEGIN . $j($doc) . $END;
                \DB::table('baganriki_ai_attempts')->insert([
                    'snapshot_id' => $sid, 'role' => $role, 'attempt_no' => 0,
                    'token' => hash('sha256', 'PT' . $sid . $role),
                    'status' => \App\Http\Controllers\Api\BaganrikiWorker::RECEIVED,
                    'reserved_at' => \App\Http\Controllers\Api\BaganrikiWorker::toDb($now),
                    'received_at' => \App\Http\Controllers\Api\BaganrikiWorker::toDb($now),
                    'complete' => (($opt['incomplete'] ?? null) === $role) ? 0 : 1,
                    'raw_response' => $raw,
                    'response_hash' => hash('sha256', $j($doc)),
                ]);
            }
            return (int) $sid;
        };

        $ok = true;
        \DB::beginTransaction();
        try {
            $ctrl = new \App\Http\Controllers\Api\Ctrl();

            // ── ① ふつうに公開する ──────────────────────────────────
            qt_out('── ① 統合して公開する ──');
            $sid = $mk($out1, $out2);
            $p = $ctrl->r122Publish($sid);
            $check('P-01', '公開できる', $p['code'], 'PUBLISHED');
            $q = (array) $p['quota'];
            $check('P-02', '枠ぶんの候補が出る', count($p['candidates']),
                   (int) array_sum($q));
            $nos = array_column($p['candidates'], 'horse_no');
            $check('P-03', '馬番が重複しない', count(array_unique($nos)), count($nos));
            qt_out('      枠 ' . $j($q) . '  候補 ' . implode('-', $nos));
            $check('P-04', 'publication_revision が1増える',
                   (int) \DB::table('baganriki_live_states')->where('snapshot_id', $sid)
                       ->value('publication_revision'), 1);
            $check('P-05', 'latest_publication_id が入る',
                   (string) \DB::table('baganriki_live_states')->where('snapshot_id', $sid)
                       ->value('latest_publication_id'), (string) $p['publication_id']);

            // ── ② 加点（両AIの原公開一致を証明できたときだけ）──────────
            qt_out('── ② 加点は証明できたときだけ ──');
            $both = array_values(array_intersect(
                array_map('intval', (array) $out1['public_candidates']),
                array_map('intval', (array) $out2['public_candidates'])));
            $bonused = [];
            foreach ($p['candidates'] as $c) {
                if ($c['bonus'] === 5.0) { $bonused[] = (int) $c['horse_no']; }
            }
            sort($both); sort($bonused);
            $check('P-06', '両AIの原公開一致した馬に +5',
                   $bonused, array_values(array_intersect($both, $nos)));
            $check('P-07', '証明がそろっている', $p['proof'], ['1st', '2nd']);
            $pub = \DB::table('baganriki_publications')
                     ->where('publication_id', $p['publication_id'])->first();
            $pf = json_decode((string) ($pub->public_proof_hash ?? '[]'), true);
            $check('P-08', '加点を証明する応答hashを別に残す',
                   is_array($pf) ? count($pf) : 0, count($bonused));

            // ── ③ 同じ intent の再実行 ──────────────────────────────
            qt_out('── ③ 同じ intent の再実行 ──');
            $p2 = $ctrl->r122Publish($sid);
            $check('P-09', '同じ結果を返す', $p2['code'], 'ALREADY');
            $check('P-10', '同じ publication_id', (string) $p2['publication_id'],
                   (string) $p['publication_id']);
            $check('P-11', '公開は1件のまま',
                   (int) \DB::table('baganriki_publications')
                       ->where('snapshot_id', $sid)->count(), 1);

            // ── ④ 読取のあとに版が変わったら保存しない ─────────────────
            qt_out('── ④ 版が変わったら保存しない（STALE）──');
            $sid3 = $mk($out1, $out2);
            // ほかの処理がライブ状態を進めた場面を作ります
            \DB::table('baganriki_live_states')->where('snapshot_id', $sid3)
              ->update(['state_revision' => 1]);
            // 進む前に読んだ版のまま保存を試みます
            $stale = $ctrl->r122Publish($sid3,
                ['read_revisions' => ['state' => 0, 'response' => 0,
                                      'publication' => 0]]);
            $check('P-12', '古い版の計算は保存しない', $stale['code'], 'STALE');
            $check('P-13', '公開は作られない',
                   (int) \DB::table('baganriki_publications')
                       ->where('snapshot_id', $sid3)->count(), 0);
            // 版を合わせれば保存できます
            $fresh = $ctrl->r122Publish($sid3,
                ['read_revisions' => ['state' => 1, 'response' => 0,
                                      'publication' => 0]]);
            $check('P-14', '版を合わせれば公開できる', $fresh['code'], 'PUBLISHED');

            // ── ⑤ 片方が complete=false ─────────────────────────────
            qt_out('── ⑤ 片方が complete=false ──');
            $sid4 = $mk($out1, $out2, ['incomplete' => '2nd']);
            $p4 = $ctrl->r122Publish($sid4);
            $check('P-15', '片方だけでも公開できる', $p4['code'], 'PUBLISHED');
            $check('P-16', '証明は1roleだけ', $p4['proof'], ['1st']);
            $b4 = 0;
            foreach ($p4['candidates'] as $c) { if ($c['bonus'] === 5.0) { $b4++; } }
            $check('P-17', '片方だけなら加点しない', $b4, 0);

            // ── ⑥ 期限・全頭取消・手渡し ───────────────────────────
            qt_out('── ⑥ 止まるところ ──');
            $sid5 = $mk($out1, $out2);
            $late = \App\Http\Controllers\Api\BaganrikiWorker::nowUs()
                  + 3600 * 1000000;
            $p5 = $ctrl->r122Publish($sid5, ['now_us' => $late]);
            $check('P-18', '公開期限を過ぎたら止まる', $p5['code'], 'DEADLINE_PASSED');

            $allNums = [];
            foreach ((array) $in1['runners'] as $r) { $allNums[] = (int) $r['horse_no']; }
            $sid6 = $mk($out1, $out2, ['cancelled' => $allNums]);
            $p6 = $ctrl->r122Publish($sid6);
            $check('P-19', '全頭取消で止まる', $p6['code'], 'ALL_CANCELLED');

            $sid7 = $mk($out1, $out2);
            $p7 = $ctrl->r122Publish($sid7, ['handed' => [['horse_no' => 1]]]);
            $check('P-20', 'ジャーナルがあるのに手渡しは受け付けない',
                   $p7['code'], 'HANDED_REFUSED');

            // ── ⑦ 監査に3つの時刻が残る ────────────────────────────
            qt_out('── ⑦ 公開の監査 ──');
            $ev = \DB::table('baganriki_audit_events')
                    ->where('snapshot_id', $sid)->where('kind', 'PUBLISHED')->first();
            $check('P-21', '公開の監査が残る', ($ev !== null), true);
            if ($ev !== null) {
                $d = json_decode((string) $ev->diagnostics, true);
                $has = is_array($d) && isset($d['verify_started_at'],
                        $d['verify_finished_at'], $d['committed_at']);
                $check('P-22', '3つの時刻が残る', $has, true);
                if ($has) {
                    $a = \App\Http\Controllers\Api\BaganrikiTime::us($d['verify_started_at']);
                    $b = \App\Http\Controllers\Api\BaganrikiTime::us($d['verify_finished_at']);
                    $c = \App\Http\Controllers\Api\BaganrikiTime::us($d['committed_at']);
                    $check('P-23', '検証開始<=完了<=commit直前',
                           ($a <= $b && $b <= $c), true);
                }
                $check('P-24', '版の増え方が残る',
                       [(int) $ev->old_revision, (int) $ev->new_revision], [0, 1]);
            }

        } catch (\Throwable $e) {
            $ok = false; $fail++;
            qt_out('  × 例外: ' . $e->getMessage());
            qt_out('     ' . $e->getFile() . ':' . $e->getLine());
        } finally {
            \DB::rollBack();
        }

        qt_out('');
        qt_out(sprintf('  ロールバック後  snapshot %d／公開 %d／intent %d',
            \DB::table('baganriki_snapshots')->count(),
            \DB::table('baganriki_publications')->count(),
            \DB::table('baganriki_publication_intents')->count()));
        qt_out('');
        qt_out('  判定件数 : ' . ($pass + $fail) . ' 件');
        qt_out('  合格     : ' . $pass . ' 件');
        qt_out('  不合格   : ' . $fail . ' 件');
        qt_out('');
        qt_out('════════════════════════════════════════════════════════');
        qt_out(($fail === 0 && $ok)
            ? ' 統合・公開・intent・revision は契約どおりに動きました（DBへ残る書き込み0件）'
            : ' 通らなかった箇所があります。上の × をご確認ください');
        qt_out('════════════════════════════════════════════════════════');
    
})();
