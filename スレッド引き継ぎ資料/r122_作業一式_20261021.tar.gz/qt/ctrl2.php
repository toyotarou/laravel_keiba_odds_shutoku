<?php
namespace App\Http\Controllers\Api;

class AiController {
    public const B12_RECOVERY_LOW_THRESH = 40.0;

    public const SNAPSHOT_TIMING = 6;

    public const AUDIT_JSON_BEGIN = '<<<BAGANRIKI_ALLSCORE_BEGIN>>>';
    public const CONF_ITEM_MAX = [15, 12, 8, 10, 8, 4, 3];   // 合計60
    /** 妙味4項目の配点上限 */
    public const MERIT_ITEM_MAX = [15, 12, 8, 5];            // 合計40

    /**
     * AI回答を「公開部分」と「内部監査用JSON」に分ける。
     *
     * マーカーが無い回答（旧形式・AIが出さなかった場合）は
     * 公開部分だけが返り、json は null になる。
     *
     * @return array{public: string, json: ?string}
     */
    private static function splitAuditJson(string $text): array
    {
        $b = self::AUDIT_JSON_BEGIN;
        $e = self::AUDIT_JSON_END;
        $bp = mb_strpos($text, $b);
        if ($bp === false) {
            return ['public' => $text, 'json' => null];
        }
        $public = mb_substr($text, 0, $bp);
        $rest   = mb_substr($text, $bp + mb_strlen($b));
        $ep     = mb_strpos($rest, $e);
        if ($ep === false) {
            // 終了マーカーが無い＝途中で切れた。JSONは採用しない（推測で補わない）。
            return ['public' => $public, 'json' => null];
        }
        $json = mb_substr($rest, 0, $ep);
        // 終了マーカーより後ろに本文が続く場合も公開部分として残す
        $public .= mb_substr($rest, $ep + mb_strlen($e));
        return ['public' => trim($public), 'json' => trim($json)];
    }

    /**
     * @ANCHOR-20261004-DROP-TRACE  保存済みAI回答から公開候補の馬番を取り出す
     *
     * 洗い替えでオッズが消えた過去日について、
     * 「AIは何頭出したのか」「最終候補は何頭だったのか」を突き合わせるために使う。
     * 内部監査用JSONは落としてから数えるので、全頭採点の馬番は混ざらない。
     *
     * @return array 公開候補行の馬番（重複を除き昇順）
     */
    public static function publicCandidateNums(string $text): array
    {
        $nums = [];
        foreach (explode("\n", self::publicPart($text)) as $line) {
            $line = trim($line);
            if ($line === '') continue;
            if (!preg_match(self::PUBLIC_ROW_REGEX, $line, $m)) continue;
            $nums[(int) $m[1]] = true;
        }
        $out = array_keys($nums);
        sort($out);
        return $out;
    }

    /**
     * ═════════════════════════════════════════════════════════════════════════
     * @ANCHOR-20261014-MISSED  保存済みAI回答の全頭採点に、どの馬が居たかを返す
     * ═════════════════════════════════════════════════════════════════════════
     * 10月14日（6回目）のご指摘⑤への対応です。
     *   「今回捕捉できなかった40頭について、AI全頭採点には存在したが
     *     候補化されなかった馬と、全頭採点自体が欠損・未受領だった馬を
     *     区別してください」
     *
     * 全頭採点は <<<BAGANRIKI_ALLSCORE_BEGIN>>> 〜 END で囲まれた1行のJSONで、
     * {"v":1,"horses":[{"n":馬番,...}]} の形です。ここから馬番だけを取り出します。
     *
     * @return array received（全頭採点を受け取れたか）／nums（居た馬番）／
     *               reason（受け取れなかった理由）／count（頭数）
     */
    public static function allScoreReport(string $text): array
    {
        $json = self::splitAuditJson($text)['json'];
        if ($json === null || trim($json) === '') {
            return ['received' => false, 'nums' => [], 'count' => 0, 'scores' => [], 'ranks' => [],
                    'reason' => '全頭採点のマーカーが無い（未受領、または途中で切れた）'];
        }
        $dec = json_decode($json, true);
        if (!is_array($dec)) {
            return ['received' => false, 'nums' => [], 'count' => 0, 'scores' => [], 'ranks' => [],
                    'reason' => '全頭採点のJSONが読めない（壊れている）'];
        }
        if (!is_array($dec['horses'] ?? null)) {
            return ['received' => false, 'nums' => [], 'count' => 0, 'scores' => [], 'ranks' => [],
                    'reason' => '全頭採点に horses が無い'];
        }
        // ══════════════════════════════════════════════════════════════════
        // @ANCHOR-20261014-ALLSCORE-RANK  点数と順位も返す（10/14 7回目ご指摘④⑤）
        // ══════════════════════════════════════════════════════════════════
        //   「全頭採点の段階で評価されていなかったのか、評価されていたのに
        //     選出枠・条件・フィルターで落ちたのかを区別してください」
        //   「波乱度3・4で人気薄の捕捉が0頭だった原因を優先して分析してください」
        //   どちらも「その馬が全頭採点で何点・何位だったか」が分からないと答えられません。
        //   t（総合点）を読み、同点は馬番の小さい順で順位を付けます。
        $nums = [];
        $score = [];
        foreach ($dec['horses'] as $h) {
            if (!is_array($h)) continue;
            $n = (int) ($h['n'] ?? 0);
            if ($n <= 0) continue;
            $nums[$n] = true;
            $score[$n] = isset($h['t']) && is_numeric($h['t']) ? (float) $h['t'] : null;
        }
        $out = array_keys($nums);
        sort($out);

        // 総合点の降順 → 同点は馬番の昇順で順位を付ける
        $order = $out;
        usort($order, static function ($x, $y) use ($score) {
            $sx = $score[$x]; $sy = $score[$y];
            if ($sx === null && $sy === null) return $x <=> $y;
            if ($sx === null) return 1;          // 点が無い馬は後ろ
            if ($sy === null) return -1;
            if ($sx === $sy) return $x <=> $y;
            return ($sy < $sx) ? -1 : 1;
        });
        $rank = []; $i = 0;
        foreach ($order as $n2) { $i++; $rank[$n2] = $i; }

        return ['received' => true, 'nums' => $out, 'count' => count($out), 'reason' => '',
                'scores' => $score, 'ranks' => $rank];
    }

    /**
     * AI回答の公開部分だけを返す（内部監査用JSONを落とす）。
     * Flutterへ返す文字列・候補行のパース・回答判定はすべてこれを通す。
     */
    private static function publicPart(string $text): string
    {
        return self::splitAuditJson($text)['public'];
    }

    /**
     * ═══════════════════════════════════════════════════════════════════════
     * @ANCHOR-20261005-LOCK-FALLBACK  排他ロックが取れないときの扱い
     * ═══════════════════════════════════════════════════════════════════════
     * 【見つかった不具合（2026-10-05）】
     *   Cache::lock()->block() が FileStore を使うため、
     *   storage/framework/cache/data/<hash>/ にロックファイルを作る。
     *   このサブディレクトリは Web 実行（apache）が 755 で作るので、
     *   artisan 実行（centos）からは書き込めず
     *     "Unable to create lockable file"
     *   が throw される。呼び出し元の catch (\Throwable) がこれを拾い、
     *   [RACE_PROCESSING_ERROR]「候補0件の部分結果で続行」へ落ちていた。
     *   その結果、artisan 経由の処理（補完バッチ・比較コマンド）が
     *   全レース候補0件になり、しかもHTTP200で正常終了して見えていた。
     *
     * 【方針】
     *   ・ロックが物理的に使えない場合は、ロックなしで処理を続ける。
     *     ロックは「同時リクエストでAIを二重に呼ばない」ための保険であり、
     *     これが取れないことを理由に予測そのものを捨ててはいけない。
     *     artisan 側は呼び出し元コマンドが日付単位のロックファイルを持っている。
     *   ・LockTimeoutException（先行処理が60秒以上続いている）は従来どおり
     *     呼び出し元へ投げる。こちらは「待っても取れない＝先行処理が走っている」
     *     という正常な状態なので、AIを二重に呼ばないために中断する
     *     （AI呼び出しは1レース2回までという仕様を守る）。
     *
     * @return object|null ロックオブジェクト。使えなかった場合は null
     */
    private static function acquireRaceLock(string $lockKey): ?object
    {
        try {
            // @ANCHOR-20261013-V04-HV-TIMEOUT  H/V依頼ONのときはAIの待ち時間が
            //   240秒まで伸びるので、120秒のままだと処理中にロックが失効する。
            //   OFF（本番）のときは従来どおり120秒。
            $lockTtl = self::v04HvPrompt() ? 600 : 120;
            $lock = \Illuminate\Support\Facades\Cache::lock($lockKey, $lockTtl);
            $lock->block(60);   // 先行リクエストが完了するまで最大60秒待つ
            return $lock;
        } catch (\Illuminate\Contracts\Cache\LockTimeoutException $e) {
            throw $e;           // 先行処理あり。従来どおり呼び出し元で扱う
        } catch (\Throwable $e) {
            // ══════════════════════════════════════════════════════════════════
            // @ANCHOR-20261006-LOCK-FALLBACK-FLOCK  代替の排他を必ず試す
            // ══════════════════════════════════════════════════════════════════
            // 【20261006 ご指摘・第7節】
            //   「ロックが使えなければロックなしで続ける仕様では、同時実行時の
            //     AI二重呼び出し・保存競合を防げるか確認が必要。LockTimeoutを
            //     中断することだけでは、ロック機能そのものが使えない場合の
            //     排他を説明できない」
            //   → Laravelのキャッシュロックが使えない場合は、OSのファイルロック
            //     （flock）へ切り替える。/tmp は誰でも書けるので、apache実行と
            //     centos実行のどちらからでも同じ鍵を取り合える。
            //     こちらも取れなければ、そのときだけロックなしで続ける。
            $fbPath = sys_get_temp_dir() . '/keiba_lock_' . md5($lockKey) . '.lock';
            $fbFp   = @fopen($fbPath, 'c');
            if ($fbFp !== false) {
                @chmod($fbPath, 0666);   // 別ユーザーの実行からも取り合えるようにする
                $fbWaited = 0;
                while ($fbWaited < 60) {
                    if (@flock($fbFp, LOCK_EX | LOCK_NB)) {
                        \Log::error('[LOCK_FALLBACK] キャッシュロックが使えないためファイルロックで排他した', [
                            'key'   => $lockKey,
                            'path'  => $fbPath,
                            '待ち'  => $fbWaited . '秒',
                            'message' => $e->getMessage(),
                        ]);
                        return new class ($fbFp, $fbPath) {
                            public function __construct(private $fp, private string $path) {}
                            public function release(): void
                            {
                                try { @flock($this->fp, LOCK_UN); @fclose($this->fp); }
                                catch (\Throwable $e) { /* 解放失敗は無視 */ }
                            }
                        };
                    }
                    sleep(1);
                    $fbWaited++;
                }
                @fclose($fbFp);
                // 60秒待っても取れない＝先行処理が走っている。AI二重呼び出しを避けて中断する。
                \Log::error('[LOCK_FALLBACK] ファイルロックも60秒取得できなかった → 中断する', [
                    'key' => $lockKey, 'path' => $fbPath,
                ]);
                throw new \Illuminate\Contracts\Cache\LockTimeoutException(
                    'ファイルロックを取得できませんでした: ' . $fbPath
                );
            }

            \Log::error('[LOCK_UNAVAILABLE] 排他ロックが一切使えないためロックなしで続行', [
                'key'     => $lockKey,
                'message' => $e->getMessage(),
                'store'   => config('cache.default'),
                'fallback_path' => $fbPath,
                'user'    => function_exists('posix_getpwuid') && function_exists('posix_geteuid')
                    ? (posix_getpwuid(posix_geteuid())['name'] ?? '不明') : '不明',
                '影響'    => '同時実行時のみAI二重呼び出しの可能性。単独実行なら影響なし',
                '対処'    => 'storage/framework/cache/data 配下と /tmp の書き込み権限を確認する',
            ]);
            return null;
        }
    }

    /** @ANCHOR-20261005-LOCK-FALLBACK  null でも安全に解放する */
    private static function releaseRaceLock(?object $lock): void
    {
        if ($lock === null) return;
        try { $lock->release(); } catch (\Throwable $e) { /* 解放失敗は無視して続行 */ }
    }

    private static function allocFeatureEnabled(): bool
    {
        // @ANCHOR-20261004-ALLOC-COMPARE  比較実行中は上書きを優先する
        if (self::$allocOverride !== null && array_key_exists('feature', self::$allocOverride)) {
            return (bool) self::$allocOverride['feature'];
        }
        $raw = env('KEIBA_ALLOC_20261004', null);
        if ($raw === null || $raw === '') {
            return self::ALLOC_FEATURE_DEFAULT;
        }
        $parsed = filter_var($raw, FILTER_VALIDATE_BOOLEAN, FILTER_NULL_ON_FAILURE);
        return ($parsed === null) ? self::ALLOC_FEATURE_DEFAULT : $parsed;
    }

    /**
     * ═══════════════════════════════════════════════════════════════════════
     * @ANCHOR-20260927-TARGET-COUNT   目標選出数C（上限ではなく必達）
     * ═══════════════════════════════════════════════════════════════════════
     * よっしー20260927指摘【頭数別の最大選出数を必ず満たす修正】
     *   実出走頭数Nから目標数Cを決め、必ずC頭を表示する。
     *     N≦8 → min(N,4) ／ 9〜13 → 5 ／ 14〜15 → 6 ／ N≧16 → 7
     *   旧仕様の「最大上限であり選出義務ではない」「頭数を埋めない」
     *   「候補0件を正常終了とする」は本追補により無効。
     */
    private static function targetSelectionCount(int $activeRunnerCount): int
    {
        return match (true) {
            $activeRunnerCount <= 8  => min($activeRunnerCount, 4),
            $activeRunnerCount <= 13 => 5,
            $activeRunnerCount <= 15 => 6,
            default                  => 7,
        };
    }

    /**
     * ═══════════════════════════════════════════════════════════════════════
     * @ANCHOR-20260928-TRIM-OVER-LIMIT   候補上限超過の決定論的な絞り込み
     * ═══════════════════════════════════════════════════════════════════════
     * よっしー20260928指摘【レース停止回避追補】
     *   「各AIの候補上限を超えた場合、C≧4かつ保護対象リストが非空なら、
     *     回答内にある有効な保護対象のうちAIおすすめ度最高の1頭（同点は馬番昇順）を
     *     上限枠に先に残す。残りはAIおすすめ度降順、同点は馬番昇順で選び、
     *     1st AIは最大C頭、2nd AIは最大5頭とする。超過行は不採用として
     *     原文・理由をログへ残す。過剰行や重複行があっても回答全体やレースを停止しない。」
     *
     * 旧実装は 1st AI が8頭以上でHTTP 500、2nd AI が6頭以上で回答ごと無効化していたが、
     * 本追補により「回答を捨てる／レースを止める」ことは禁止された。
     *
     * @param array  $horses         検証済みの候補配列
     * @param int    $limit          このAIの上限（1st AI = C、2nd AI = 5）
     * @param array  $protectedNums  人気薄の根拠付き保護対象の馬番
     * @param int    $cValue         目標数C（保護枠の C≧4 判定に使う）
     * @param string $aiLabel        ログ識別子
     * @param array  $logCtx         レース識別情報などの追加ログ項目
     */
    private function _trimAiCandidates(
        array  $horses,
        int    $limit,
        array  $protectedNums,
        int    $cValue,
        string $aiLabel,
        array  $logCtx = []
    ): array {
        if ($limit < 0) $limit = 0;
        if (count($horses) <= $limit) return array_values($horses);

        // AIおすすめ度降順 → 同点は馬番昇順（決定論的。同じ入力なら必ず同じ結果）
        $trSort = static function ($a, $b) {
            $sa = (float) ($a['score'] ?? 0);
            $sb = (float) ($b['score'] ?? 0);
            if ($sa !== $sb) return $sb <=> $sa;
            return ((int) $a['num']) <=> ((int) $b['num']);
        };

        $trProtected = array_map('intval', $protectedNums);
        $trKept      = [];
        $trKeptNums  = [];

        // C≧4 かつ保護対象が渡されていれば、保護対象のうちおすすめ度最高の1頭を先に確保する
        if ($cValue >= 4 && !empty($trProtected)) {
            $trPool = array_values(array_filter(
                $horses,
                fn($h) => in_array((int) $h['num'], $trProtected, true)
            ));
            if (!empty($trPool)) {
                usort($trPool, $trSort);
                $trKept[]     = $trPool[0];
                $trKeptNums[] = (int) $trPool[0]['num'];
            }
        }

        // 残りをおすすめ度降順で埋める
        $trRest = array_values(array_filter(
            $horses,
            fn($h) => !in_array((int) $h['num'], $trKeptNums, true)
        ));
        usort($trRest, $trSort);
        foreach ($trRest as $trR) {
            if (count($trKept) >= $limit) break;
            $trKept[]     = $trR;
            $trKeptNums[] = (int) $trR['num'];
        }
        usort($trKept, $trSort);

        $trDropped = array_values(array_filter(
            $horses,
            fn($h) => !in_array((int) $h['num'], $trKeptNums, true)
        ));

        \Log::warning("[B-15] {$aiLabel} 候補上限超過 → 決定論的に絞り込み（レースは継続）", $logCtx + [
            '上限'     => $limit,
            '目標数C'  => $cValue,
            '回答数'   => count($horses),
            '採用'     => $trKeptNums,
            '不採用'   => array_map(static fn($h) => [
                'num'   => (int) $h['num'],
                'name'  => $h['name']  ?? '',
                'score' => $h['score'] ?? null,
                'reason'=> mb_substr((string) ($h['reason'] ?? ''), 0, 120),
            ], $trDropped),
            '保護対象' => $trProtected,
        ]);

        return $trKept;
    }

    public function __construct(private AnthropicService $anthropic)
    {
    }



    public function getHorseOddsFinderAiAnalysisRecord()
    {
        $result = DB::table('t_horse_odds_finder_ai_analysis')
            ->orderBy('date')
            ->orderBy('kaisuu')
            ->orderBy('basho_code')
            ->orderBy('day')
            ->orderBy('race')
            ->get();

        // @ANCHOR-20261014-ALLSCORE-KEEP  画面へ内部監査用JSONを出さない
        return response()->json(['data' => self::stripAuditJsonRows($result)]);
    }
    
    public function getHorseOddsFinderAiAnalysisRecord2()
    {
        $result = DB::table('t_horse_odds_finder_ai_analysis2')
            ->orderBy('date')
            ->orderBy('kaisuu')
            ->orderBy('basho_code')
            ->orderBy('day')
            ->orderBy('race')
            ->get();

        // @ANCHOR-20261014-ALLSCORE-KEEP  画面へ内部監査用JSONを出さない
        //   DBには全頭採点を残すようにしたので、応答でだけ落とします。
        //   レース単位のAPIは以前から publicPart() を通しています。
        return response()->json(['data' => self::stripAuditJsonRows($result)]);
    }

    /**
     * @ANCHOR-20261014-ALLSCORE-KEEP  一覧の analysis_text から内部JSONを落とす
     *
     * 【ついでに直したこと】
     *   1st AI の一覧API（getHorseOddsFinderAiAnalysisRecord）は、
     *   生の回答をそのまま返していたため、内部監査用JSONが画面側へ
     *   流れていました（Flutterは候補行だけを正規表現で読むので表示は
     *   壊れていませんが、出さない約束のデータが出ていました）。
     *   2nd と同じようにここで落とします。
     */
    private static function stripAuditJsonRows($rows)
    {
        return collect($rows)->map(static function ($r) {
            if (is_object($r) && property_exists($r, 'analysis_text')) {
                $r->analysis_text = trim(self::publicPart((string) $r->analysis_text));
            }
            return $r;
        })->values();
    }




    
/**
 * 指定レースのAI分析結果を返す
 *
 * すでに分析済みのレースは t_horse_odds_finder_ai_analysis からキャッシュを返す。
 * 未分析の場合は Claude API を呼び出して分析を生成し、DBに保存してから返す。
 *
 * ＜テーブル間のカラム対応に注意＞
 *   t_horse_odds_finder_races.basho      → t_horse_odds_finder_ai_analysis.basho_code（場コード）
 *   t_horse_odds_finder_races.basho_name → t_horse_odds_finder_ai_analysis.basho    （場名称）
 *
 * @param  Request $request
 *   クエリパラメータ: date, kaisuu, basho（場コード）, day, race
 * @return \Illuminate\Http\JsonResponse
 */
public function getHorseOddsFinderAiAnalysis(Request $request)
{
    // ─── リクエストパラメータの取り出し ───────────────────────────────
    $date   = $request->query('date');
    $kaisuu = $request->query('kaisuu');
    $basho  = $request->query('basho');  // 場コード（t_horse_odds_finder_races.basho と同値）
    $day    = $request->query('day');
    $race   = $request->query('race');

    $gapHorseNums   = $request->query('gapHorseNums');
    $upsetPickupHorseNums   = $request->query('upsetPickupHorseNums');

// // ─── 注目馬の抽出ロジック ─────────────────────────────────────────
// // AIにプロンプトで "PICKUP:馬番|馬名/..." 形式の最終行を出力させているので、
// // その行だけを抜き出す。形式が固定されているため自由文のパースより確実。
// $parsePickupHorses = function (string $text): string {
//     if (preg_match('/^PICKUP:(.+)$/mu', $text, $m)) {
//         return trim($m[1]);
//     }
//     return '';
// };

    // ─── キャッシュ確認 ───────────────────────────────────────────────
    // 同一レースの分析がすでに保存済みであればDBから即返す。
    // exists() + first() の2クエリを first() 1本にまとめている。
    $cached = DB::table('t_horse_odds_finder_ai_analysis')
        ->where('date',       $date)
        ->where('kaisuu',     $kaisuu)
        ->where('basho_code', $basho)
        ->where('day',        $day)
        ->where('race',       $race)
        ->first();

    // @ANCHOR-20261004-DRY-RUN  呼び直しモードでは保存済み回答を返さない
    if ($cached && self::$dryRunForceFresh) { $cached = null; }

    if ($cached) {

        // ── 【20260928 レース停止回避追補】1st AI 失敗でも公開を止めない ────────
        //   よっしー20260928指摘【2026-09-28 レース停止回避追補】
        //     「頭数不一致、必須データ欠損、AI応答失敗、候補数不足だけを理由に
        //       該当レースをHTTP 500・公開停止にしてはならない」
        //   旧実装はここで 500 を返していたため、1st AI が失敗したレースは
        //   2nd AI も呼ばれず、レースカードごと消えていた。
        //   判定そのものは残し、警告ログだけにして HTTP 200 で返す。
        //   @ANCHOR-20260928-NO-RACE-STOP
        $firstPublishError = $this->_firstAiPublishError((string) $cached->analysis_text);
        if ($firstPublishError !== null) {
            \Log::warning('[PREDICTION_PARTIAL] 1st AI 回答に問題あり（公開は継続）', [
                'reason' => $firstPublishError,
                'date' => $date, 'kaisuu' => $kaisuu, 'basho' => $basho, 'day' => $day, 'race' => $race,
            ]);
        }

// DBの analysis_text には PICKUP: 行が含まれているので、レスポンスでは除去して返す

        return response()->json(['data' => [
            'date'          => $date,
            'kaisuu'        => $kaisuu,
            'basho_code'    => $basho,
            'day'           => $day,
            'race'          => $race,

// 'analysis_text' => trim(preg_replace('/^PICKUP:.+$/mu', '', $cached->analysis_text)),
// 'pickup_horse'  => $parsePickupHorses($cached->analysis_text),

'analysis_text' => trim(self::publicPart((string) $cached->analysis_text)),   // 【20261004】内部監査用JSONは返さない

        ]]);
    }

    // ─── 排他ロック（同一レースへの並行リクエスト防止） ──────────────
    // 初回キャッシュミス後に複数リクエストが同時に来ると API が二重呼び出しされる。
    // ロックを取得してから再度キャッシュを確認することで 1 回だけ呼び出しを保証する。
    $lockKey = "ai_analysis_{$date}_{$kaisuu}_{$basho}_{$day}_{$race}";
    // @ANCHOR-20261005-LOCK-FALLBACK  ロックが使えなくても処理を捨てない
    $lock = self::acquireRaceLock($lockKey);

    try {

        // ─── ロック後に再度キャッシュ確認（先行リクエストが保存済みの場合） ──
        $cached = DB::table('t_horse_odds_finder_ai_analysis')
            ->where('date',       $date)
            ->where('kaisuu',     $kaisuu)
            ->where('basho_code', $basho)
            ->where('day',        $day)
            ->where('race',       $race)
            ->first();

        // @ANCHOR-20261004-DRY-RUN  呼び直しモードでは保存済み回答を返さない
        if ($cached && self::$dryRunForceFresh) { $cached = null; }

        if ($cached) {
            // 【20260928 レース停止回避追補】上のキャッシュ分岐と同じく公開を止めない
            //   @ANCHOR-20260928-NO-RACE-STOP
            $firstPublishError = $this->_firstAiPublishError((string) $cached->analysis_text);
            if ($firstPublishError !== null) {
                \Log::warning('[PREDICTION_PARTIAL] 1st AI 回答に問題あり（公開は継続）', [
                    'reason' => $firstPublishError,
                    'date' => $date, 'kaisuu' => $kaisuu, 'basho' => $basho, 'day' => $day, 'race' => $race,
                ]);
            }
            return response()->json(['data' => [
                'date'          => $date,
                'kaisuu'        => $kaisuu,
                'basho_code'    => $basho,
                'day'           => $day,
                'race'          => $race,

                // 'analysis_text' => trim(preg_replace('/^PICKUP:.+$/mu', '', $cached->analysis_text)),
                // 'pickup_horse'  => $parsePickupHorses($cached->analysis_text),

'analysis_text' => trim(self::publicPart((string) $cached->analysis_text)),   // 【20261004】内部監査用JSONは返さない

            ]]);
        }

        // ─── レース基本情報の取得 ─────────────────────────────────────────
        $raceRow = DB::table('t_horse_odds_finder_races')
            ->where('date',   $date)
            ->where('kaisuu', $kaisuu)
            ->where('basho',  $basho)
            ->where('day',    $day)
            ->where('race',   intval($race))
            ->first();

        if (!$raceRow) {
            return response()->json(['error' => 'レースが見つかりません'], 404);
        }

        // ─── AIプロンプト生成 ─────────────────────────────────────────────
        $prompt = $this->_getAiAnalysisPrompt($date, $kaisuu, $basho, $day, $race, $gapHorseNums, $upsetPickupHorseNums);

        if ($prompt === null) {
            // 【20260928 レース停止回避追補】必須データ欠損でレースを止めない。
            //   空回答として保存し、候補行0件の部分結果を HTTP 200 で返す。
            //   AIは呼ばない（呼ぶだけのデータが無いため）。
            //   @ANCHOR-20260928-NO-RACE-STOP
            \Log::warning('[DATA_CORE_ERROR] 1st AI用プロンプトを生成できない（候補0件で続行）', [
                'date' => $date, 'kaisuu' => $kaisuu, 'basho' => $basho, 'day' => $day, 'race' => $race,
            ]);
            $this->_saveEmptyFirstAiAnalysis($date, $kaisuu, $basho, $day, $race, $raceRow, 'prompt_unavailable');
            return response()->json(['data' => [
                'date' => $date, 'kaisuu' => $kaisuu, 'basho_code' => $basho,
                'day'  => $day,  'race'   => $race, 'analysis_text' => '',
            ]]);
        }

        // ─── プロンプトをファイルに出力（デバッグ・履歴用） ──────────────
        //   @ANCHOR-20261004-DRY-RUN  試算モードでは既存ファイルを上書きしない。
        //     ただし、よっしー20261004のご回答にある提出物「生成済み1st・2ndプロンプト」
        //     のために、別の場所（storage/logs/rerun_prompt/）へ写しを残す。
        //     既存の public/prompt は一切触らない。
        if (self::$dryRunNoPersist) {
            self::$dryRunFirstPrompt = $prompt;   // 2nd AI 側へ受け渡す
            self::saveRerunPrompt('1st', $prompt, $date, $kaisuu, $basho, $day, $race);
        } else {
            file_put_contents(
                public_path("prompt/prompt_{$date}_{$kaisuu}_{$basho}_{$day}_{$race}.data"),
                $prompt
            );
        }

        // ─── 脳みそ（判断基準）の読み込み ────────────────────────────────────
        $brainFile = public_path('baganriki_brain/baganriki_brain.txt');
        $brain     = file_exists($brainFile) ? trim(file_get_contents($brainFile)) : '';

        // 脳みそがある場合、プロンプト末尾に参考情報として追加（システムプロンプトには使わない）
        if ($brain !== '') {
            $prompt .= "\n\n参考情報：以下は過去のレース分析から導き出した判断基準です。あくまで参考として、目の前のオッズデータを優先して判断してください。\n" . $brain;
        }

        $prompt .= "\n\n" . '※画面の表示幅の問題があるので、テーブルは使わないでください。';

        // ─── 1st AI 固定システムプロンプト（仕様書 §1より。既存プロンプトと併用せず完全置換） ─
        // ══════════════════════════════════════════════════════════════════════
        // @ANCHOR-20261004-SYSTEM-PROMPT  systemプロンプトを新仕様に合わせる
        // ══════════════════════════════════════════════════════════════════════
        // 【20261004 よっしー回答①A・③A・④A】
        //   userプロンプト側は「点数が低いという理由だけで候補を削らないでください」へ
        //   直してあったが、system側に旧仕様の文面が残っており逆の指示になっていた。
        //   【旧文面1】「最低基準点、低配当除外、回収率フィルター、断層位置別・人気帯別上限を
        //               順守し、上限を埋めるための追加をしてはいけません。」
        //     → 候補の強制除外と人気帯別上限は廃止済み（回答①A・④A）。
        //       固定配点内の評価と、低配当の妙味小計制限だけを残す。
        //   【旧文面2】形式外出力の禁止に【全頭採点（内部用）】の例外が無かった。
        //     → 回答③A「公開部分に混ぜず、内部用領域に出力する」に合わせて例外を明記。
        $firstAiSystemPrompt = 'あなたは競馬オッズ分析の専門家（1st AI）です。入力された取得開始S〜発走6分前までの全頭データだけを使用し、全頭を評価してから候補を決定してください。DB・PHP算出済みの人気順、OPI、流入ランク、推定確定オッズ、断層構造タイプ、厳選穴レース条件を再計算・変更してはいけません。3分前、確定オッズ・確定人気、実着順、払戻金その他発走後情報、入力に存在しない情報を使用・推測・創作してはいけません。主目的は的中頭数ではなく長期回収率の向上です。最低基準点、低配当、過去回収率は候補から除外する理由にせず、固定配点の中で評価してください。低配当馬の妙味小計の制限は維持します。断層位置別・人気帯別の頭数上限は廃止されています。選出する頭数は目標かつ上限であり、頭数を埋めるための追加をしてはいけません。能力・適性は時系列オッズの補強材料として評価し、能力・適性だけで候補を決めてはいけません。有料公開するため正しい日本語を使用し、ユーザープロンプトで指定されたFlutter互換フォーマット以外の前置き・後書き・見出し・補足を出力してはいけません。ただし【全頭採点（内部用）】の領域だけは例外です。指定されたマーカーで囲んだ全頭採点のJSONは、公開候補行が0頭の場合でも必ず出力してください。公開候補行の中にJSONを混ぜてはいけません。';

        // @ANCHOR-20261015-PROMPT-SENT  1st AIのシステム指示も送信直前に記録する
        //   2nd側は 2nd_system として既に記録していました。1st側が漏れていました。
        self::recordPromptHash('1st_system', $firstAiSystemPrompt);

        // ─── Claude API 呼び出し（自動再試行なし・1回のみ）───────────────────
        // 【仕様】外部AIの呼び出しは1レースにつき 1st AI + 2nd AI の合計2回まで。
        //   自動再試行は禁止。AnthropicService::sendWithRetry() は
        //   for ($attempt = 1; $attempt <= $maxAttempts; ...) のループなので、
        //   maxAttempts: 1 を渡すと送信は必ず1回だけで、429/529でも再送しない。
        //   ★ここを 2 以上にしたり、引数を省略（既定値3）したりしてはいけない。
        //   ※以前このコメントには「529時は指数バックオフでリトライ」と書かれていたが、
        //     仕様と食い違うためコメントごと是正した。コードは以前から1回のみ。
        // 【20260926】timeout 30秒では応答が間に合わず cURL error 28（接続タイムアウト）で
        //   未捕捉例外になっていたため 90秒に延長。Cloudflare の応答待ち上限(100秒)と
        //   ロック保持時間(120秒)より短くしている。再試行はしない（仕様どおり1回のみ）。
        //   それでも時間切れの場合は例外を捕捉し、制御済みエラーとして返す。
        // @ANCHOR-20261006-AI-ELAPSED  応答時間を毎回記録する
        //   20261006 ご指摘・第7節「18頭立て、JSON修正要求あり、同時処理時の
        //   最大時間・途中切れ・公開期限を確認したことにはならない」
        //   → 単発の計測ではなく、本番の全レースで自動的に蓄積する。
        $aiElapsedStart = microtime(true);
        // ══════════════════════════════════════════════════════════════════
        // @ANCHOR-20261013-V04-HV-TIMEOUT  研究用H/Vを頼むときだけ待ち時間を延ばす
        // ══════════════════════════════════════════════════════════════════
        // 【10/13の実AI送信テストで分かったこと】
        //   H/Vの依頼を足して送ったら、1st AI の応答が 90.1秒・90.0秒と
        //   ぴったり上限で切れていた（cURLのタイムアウト）。
        //   そのあと @ANCHOR-20260928-NO-RACE-STOP の経路で空回答として続行し、
        //   統合時には「保存済みの古い回答」が使われていた。
        //   そのため1st AIのH/V採点が1頭も届かず、受領できたのは2ndだけだった。
        //   2nd AI（DeepSeek）は 39.6秒・46.4秒で 16,002・19,743バイトを返しており、
        //   全頭×10項目＋証拠の出力は現行の約4倍の分量になる。
        //   1st AI も同じ分量を出すには90秒では足りない。
        // 【90秒のままにできない／本番は変えない理由】
        //   90秒は「Cloudflareの応答待ち上限100秒より短く」という理由で決めた値で、
        //   アプリからのHTTPリクエストではこれ以上延ばせない。
        //   H/V依頼はコマンドからの研究用途だけなので、ONのときだけ延ばす。
        //   OFF（本番）のときは90秒のまま、1バイトも挙動が変わらない。
        // ══════════════════════════════════════════════════════════════════
        // @ANCHOR-20261020-R122-PROMPT  r12.2 の本文へ全文置換（機能フラグ）
        // ══════════════════════════════════════════════════════════════════
        // 根拠：server_contract_r12.2.txt 6章・9章／prompts/prompt_1st.txt
        //
        //   BAGANRIKI_R122_PROMPT=1 のときだけ、
        //     system … 配布された prompt_1st.txt の全文
        //     user   … Laravel が作る INPUT_JSON 1個
        //   へ入れ替えます。既定（0）ではここを素通りし、1バイトも変わりません。
        //
        //   作れないときは<b>旧本文へ落ちません</b>。送信を止めます。
        //   契約11.2「正本が特定できないレースは公開しない」に合わせます。
        //   （中途半端な入力でAIを呼ぶと、根拠のない候補が出てしまいます）
        if (BaganrikiPrompt::enabled()) {
            $r122 = $this->r122AssembleSend($date, $kaisuu, $basho, $day, $race, '1st');
            if (!$r122['ok']) {
                \Log::error('[INPUT_INVALID] r12.2の送信文を作れないため1st AIを呼びません', [
                    'date' => $date, 'kaisuu' => $kaisuu, 'basho' => $basho,
                    'day'  => $day,  'race'   => $race,
                    'code' => $r122['code'], 'reason' => $r122['reason'],
                ]);
                $this->_saveEmptyFirstAiAnalysis($date, $kaisuu, $basho, $day, $race,
                                                 $raceRow, 'r122_input_invalid');
                return response()->json(['data' => [
                    'date' => $date, 'kaisuu' => $kaisuu, 'basho_code' => $basho,
                    'day'  => $day,  'race'   => $race, 'analysis_text' => '',
                ]]);
            }
            $prompt              = $r122['user'];
            $firstAiSystemPrompt = $r122['system'];
            self::recordPromptHash('1st_system', $firstAiSystemPrompt);
            self::recordPromptHash('1st', $prompt);
            \Log::info('[R122-PROMPT] 1st AI へ r12.2 の本文で送ります', [
                'race_id'       => $r122['race_id'],
                'system_sha256' => $r122['system_sha256'],
                'snapshot_hash' => $r122['snapshot_hash'],
                'user_bytes'    => $r122['user_bytes'],
            ]);

            // @ANCHOR-20261020-R122-QUEUE  予約を確定してから送ります。
            //   すでに枠があるとき（前回が途中で落ちた等）は<b>送りません</b>。
            //   契約10章「予約済み枠を重複キュー・期限切れ・再起動で再発行しない」
            $r122q1 = $this->r122QueueReserve($date, $kaisuu, $basho, $day, $race,
                                              '1st', $r122);
            if (!$r122q1['skip'] && !$r122q1['ok']) {
                \Log::error('[R122-QUEUE] 枠を予約できないため1st AIを呼びません', [
                    'date' => $date, 'kaisuu' => $kaisuu, 'basho' => $basho,
                    'day'  => $day,  'race'   => $race,
                    'code' => $r122q1['code'], 'reason' => $r122q1['reason'],
                ]);
                $this->_saveEmptyFirstAiAnalysis($date, $kaisuu, $basho, $day, $race,
                                                 $raceRow, 'r122_queue_blocked');
                return response()->json(['data' => [
                    'date' => $date, 'kaisuu' => $kaisuu, 'basho_code' => $basho,
                    'day'  => $day,  'race'   => $race, 'analysis_text' => '',
                ]]);
            }
        }

        $aiTimeout = self::v04HvPrompt() ? 240 : 90;
        try {
            $aiResponse = $this->anthropic->sendWithRetry(
                prompt:      $prompt,
                system:      $firstAiSystemPrompt,
                maxAttempts: 1,   // 仕様: 自動再試行禁止。2以上にしてはいけない
                sleepBase:   2,
                timeout:     $aiTimeout,
            );
        } catch (\Illuminate\Http\Client\ConnectionException $e) {
            // 【20260928 レース停止回避追補】1st AI の通信失敗でレースを止めない。
            //   空回答として保存し、2nd AI（DeepSeek）の有効候補で続行できるようにする。
            //   自動再試行は禁止。やり直す場合は ai_analysis の該当行を消して再実行する。
            //   @ANCHOR-20260928-NO-RACE-STOP
            \Log::error('[NO_VALID_CANDIDATES] 1st AI Anthropic API タイムアウト/接続失敗（空回答として続行）', [
                'date' => $date, 'kaisuu' => $kaisuu, 'basho' => $basho, 'day' => $day, 'race' => $race,
                'prompt_length' => mb_strlen($prompt),
                // @ANCHOR-20261013-V04-HV-TIMEOUT  どの待ち時間で切れたかを必ず残す
                '待ち時間'      => $aiTimeout . '秒',
                '経過'          => round(microtime(true) - $aiElapsedStart, 1) . '秒',
                'H/V依頼'       => self::v04HvPrompt() ? 'あり（出力が約4倍になる）' : 'なし',
                'message' => $e->getMessage(),
            ]);
            // @ANCHOR-20261020-R122-QUEUE  届いたかどうか分からないので結果不明にします
            if (isset($r122q1)) {
                $this->r122QueueFail($r122q1,
                    '1st AI の通信失敗・待ち時間切れ（届いたかどうか分かりません）', true);
            }
            $this->_saveEmptyFirstAiAnalysis($date, $kaisuu, $basho, $day, $race, $raceRow, 'connection_error');
            return response()->json(['data' => [
                'date' => $date, 'kaisuu' => $kaisuu, 'basho_code' => $basho,
                'day'  => $day,  'race'   => $race, 'analysis_text' => '',
            ]]);
        }

        if ($aiResponse->failed()) {
            // 【20260928 レース停止回避追補】上と同じ扱い（HTTP 500 を返さない）
            //   @ANCHOR-20260928-NO-RACE-STOP
            \Log::error('[NO_VALID_CANDIDATES] 1st AI Anthropic APIエラー（空回答として続行）', [
                'status' => $aiResponse->status(),
                'body'   => mb_substr((string) $aiResponse->body(), 0, 1000),
                'date' => $date, 'kaisuu' => $kaisuu, 'basho' => $basho, 'day' => $day, 'race' => $race,
            ]);
            // @ANCHOR-20261020-R122-QUEUE  明確な失敗が返ったので FAILED にします
            if (isset($r122q1)) {
                $this->r122QueueFail($r122q1,
                    '1st AI の API エラー status=' . $aiResponse->status(), false);
            }
            $this->_saveEmptyFirstAiAnalysis($date, $kaisuu, $basho, $day, $race, $raceRow, 'api_error');
            return response()->json(['data' => [
                'date' => $date, 'kaisuu' => $kaisuu, 'basho_code' => $basho,
                'day'  => $day,  'race'   => $race, 'analysis_text' => '',
            ]]);
        }

        // @ANCHOR-20261013-V04-HV-TOKENS  出力が上限で打ち切られたら必ず表に出す
        $aiStopReason = $aiResponse->json('stop_reason');
        if ($aiStopReason !== null && $aiStopReason !== 'end_turn') {
            \Log::error('[AI_TRUNCATED] 1st AIの回答が途中で終わっている（stop_reason）', [
                'stop_reason'   => $aiStopReason,
                '出力トークン'  => $aiResponse->json('usage.output_tokens'),
                'date' => $date, 'kaisuu' => $kaisuu, 'basho' => $basho, 'day' => $day, 'race' => $race,
                '対処' => 'max_tokens を上げる、または依頼する項目を減らす',
            ]);
        }

        // @ANCHOR-20261006-AI-ELAPSED
        $aiElapsed1st = round(microtime(true) - $aiElapsedStart, 2);
        // @ANCHOR-20261017-ELAPSED-LEVEL  info では .env の LOG_LEVEL=error に捨てられる
        //   第43章9節で直したのと同じ落とし穴なので error に戻す（内容は変えない）
        \Log::error('[AI_ELAPSED] 1st AI 応答時間', [
            'race'       => "{$date} {$kaisuu}回{$basho} {$day}日目 {$race}R",
            // 出走頭数はプロンプトの記録行から読む（この位置では変数が無いため）
            '出走頭数'   => (preg_match('/実出走頭数N:\s*(\d+)/u', $prompt, $aeM) ? (int) $aeM[1] : null),
            '秒'         => $aiElapsed1st,
            'モデル'     => 'claude-haiku-4-5',
            'プロンプト文字数' => mb_strlen($prompt),
        ]);

        $rawText = $this->anthropic->extractText($aiResponse);

        // @ANCHOR-20261020-R122-QUEUE  原応答と complete を保存します。
        //   complete は「途中で切れていない」かつ「本文が空でない」ことです。
        //   complete=false の本文はそのまま残しますが、選出には使いません。
        if (isset($r122q1)) {
            $this->r122QueueReceive($r122q1, $rawText,
                ($aiStopReason === null || $aiStopReason === 'end_turn')
                && trim($rawText) !== '');
        }

// $pickupHorse  = $parsePickupHorses($rawText);
// $analysisText = trim(preg_replace('/^PICKUP:.+$/mu', '', $rawText));

$analysisText = trim($rawText);

        // @ANCHOR-20261004-DRY-RUN  試算モードは保存せず、2nd AI側へ受け渡す
        if (self::$dryRunNoPersist) {
            self::$dryRunFirstText = $rawText;
        }

        // ─── 分析結果をDBに保存（次回以降はキャッシュから返す） ──────────
        if (!self::$dryRunNoPersist) DB::table('t_horse_odds_finder_ai_analysis')->insertOrIgnore([
            'date'          => $date,
            'kaisuu'        => $kaisuu,
            'basho_code'    => $basho,
            'basho'         => $raceRow->basho_name,
            'day'           => $day,
            'race'          => $race,
            'race_name'     => $raceRow->race_name,
            'analysis_text' => $rawText,
        ]);

        // ─── 【20260928 レース停止回避追補】1st AI の回答判定（公開は止めない）──
        //   原文は上で保存済み（ログ・再試行防止のため）。
        //   空・形式不正・上限超過でも 500 を返さず、記録だけ残して 2nd AI へ進む。
        //   仕様「1st AI失敗時は2nd AIの有効候補を使い、レース指標はPHP算出値を使う」。
        //   @ANCHOR-20260928-NO-RACE-STOP
        $firstPublishError = $this->_firstAiPublishError($rawText);
        if ($firstPublishError !== null) {
            \Log::warning('[PREDICTION_PARTIAL] 1st AI 回答に問題あり → 2nd AIの有効候補で続行', [
                'reason' => $firstPublishError,
                'date' => $date, 'kaisuu' => $kaisuu, 'basho' => $basho, 'day' => $day, 'race' => $race,
                'raw_text' => mb_substr($rawText, 0, 2000),
            ]);
        }

        // ─── 2nd AI プリフェッチ（レスポンス送信後にバックグラウンドで実行） ──
        // ユーザーが「2nd AI」ボタンを押す前にキャッシュを作っておく。
        // app()->terminating() はレスポンス送信後に呼ばれるため、
        // 1st AI のレスポンス速度には一切影響しない。
        // getHorseOddsFinderSecondAiOpinion が持つ排他ロック機構により、
        // ユーザーがボタンを押しても2重実行・エラーにはならない。
        $prefetchDate   = $date;
        $prefetchKaisuu = $kaisuu;
        $prefetchBasho  = $basho;
        $prefetchDay    = $day;
        $prefetchRace   = $race;
        $selfController = $this;
        // @ANCHOR-20261004-DRY-RUN  試算モードでは2nd AIの先読みを行わない
        if (!self::$dryRunNoPersist)
        app()->terminating(function () use ($selfController, $prefetchDate, $prefetchKaisuu, $prefetchBasho, $prefetchDay, $prefetchRace) {
            // 既にキャッシュがあれば何もしない
            $already = DB::table('t_horse_odds_finder_ai_analysis2')
                ->where('date',       $prefetchDate)
                ->where('kaisuu',     $prefetchKaisuu)
                ->where('basho_code', $prefetchBasho)
                ->where('day',        $prefetchDay)
                ->where('race',       $prefetchRace)
                ->exists();
            if ($already) return;

            try {
                $req2nd = new \Illuminate\Http\Request();
                $req2nd->query->add([
                    'date'   => $prefetchDate,
                    'kaisuu' => $prefetchKaisuu,
                    'basho'  => $prefetchBasho,
                    'day'    => $prefetchDay,
                    'race'   => $prefetchRace,
                ]);
                $selfController->getHorseOddsFinderSecondAiOpinion($req2nd);
            } catch (\Throwable $e) {
//                 \Log::info('[2nd AI prefetch] skip: ' . $e->getMessage());
            }
        });

        return response()->json(['data' => [
            'date'          => $date,
            'kaisuu'        => $kaisuu,
            'basho_code'    => $basho,
            'day'           => $day,
            'race'          => $race,
            'analysis_text' => self::publicPart($analysisText),   // 【20261004】内部監査用JSONは返さない

// 'pickup_horse'  => $pickupHorse,

        ]]);

    } catch (\Illuminate\Contracts\Cache\LockTimeoutException $e) {
        return response()->json(['error' => 'しばらくしてから再試行してください'], 503);
    } catch (\Throwable $raceE) {
        // 【20260928 レース停止回避追補】レース単位の例外境界（1st AI側）
        //   想定外の例外を次のレースへ伝播させない。AIは呼び直さない。
        //   @ANCHOR-20260928-RACE-PROCESSING-ERROR
        \Log::error('[RACE_PROCESSING_ERROR] 1st AI処理で想定外の例外（空回答の部分結果で続行）', [
            'date' => $date, 'kaisuu' => $kaisuu, 'basho' => $basho, 'day' => $day, 'race' => $race,
            'stage'   => '1st_ai',
            'message' => $raceE->getMessage(),
            'file'    => $raceE->getFile() . ':' . $raceE->getLine(),
            'trace'   => mb_substr($raceE->getTraceAsString(), 0, 2000),
        ]);
        return response()->json(['data' => [
            'date'          => $date,
            'kaisuu'        => $kaisuu,
            'basho_code'    => $basho,
            'day'           => $day,
            'race'          => $race,
            'analysis_text' => '',
        ]]);
    } finally {
        self::releaseRaceLock($lock);   // @ANCHOR-20261005-LOCK-FALLBACK
    }
}







    // ═════════════════════════════════════════════════════════════════════════
    // @ANCHOR-20261012-V03-SHADOW  第二世代 v0.3 の構造判定（記録だけ・選出に影響しない）
    // ═════════════════════════════════════════════════════════════════════════
    // よっしー20261012提出パック v0.3（config_version=v03-20261012-proposal）の
    //   01_全体設計とデータ契約.md / 02_断層構造判定と3人気帯配分.md
    // に書かれた構造判定を、現行の選出には一切使わずに計算して記録する。
    //
    // 【なぜ記録だけなのか】
    //   提出パックの全ファイルに「未実装・性能未検証の提案版」「本番へそのまま
    //   デプロイする指示ではない」と明記されている。02の冒頭も「実装はまず
    //   SHADOWのみ」。したがってここでは一切の選出判断に関与させない。
    //   本番適用はユーザーの明示承認後に、BAGANRIKI_V03_ENABLED で切り替える。
    //
    // 【2026-10-13 追記：この判定は v0.4-X に置き換わった】
    //   よっしー20261013提出の統一版v0.4-Xが、ここで計算している X1〜X6＋Z 方式を
    //   正式系列として採用した。ただし三値の集約（早期FALSE短絡・件数条件・
    //   N<7の扱い・Sのnull化）が v0.4 で変わったため、衝突する箇所は
    //   @ANCHOR-20261013-V04-CORE 側が正本である。
    //   この関数は 10/12 の AUDIT_V03_SHADOW との継続性を保つために残してあり、
    //   削除していない。差分は AUDIT_V03_SHADOW と AUDIT_V04_RACE を
    //   見比べれば追える。新しい判定を使うときは v0.4 側を使うこと。
    //
    // 【この処理が計算するもの】
    //   ・6分前単勝人気で固定した馬番ペアごとの W（単勝比）と P（複勝比）を
    //     21/18/15/12/9/6分の6時点すべてで計算（現行は21分と6分の単勝のみ）
    //   ・各境界の出現／消滅／拡大／縮小、単複の一致／不一致
    //   ・X1〜X6・Z の三値、S・S_min・S_max、mode（FIRM/MIXED/VOLATILE/UNKNOWN）
    //   ・target_count と mode から 3帯 quota(A,B,D)
    //   ・各馬の帯（A=1〜6／B=7〜10／D=11以下）と独立根拠系統・Tier
    //
    // 【現行との関係】
    //   現行の断層タイプA〜E、F/R/O資格、可変配分、選出順位のいずれにも影響しない。
    //   既存の値を書き換えない。AIへも送らない。監査ログ AUDIT_V03_SHADOW に残すだけ。
    //
    // @param  array $pHorses  6分前単勝人気の昇順に並んだ出走馬（tan_series / fuku_min_series を持つ）
    // @return array           監査ログに書き出す構造（失敗時は ['error' => ...]）
    private static function _v03StructureShadow(
        array  $pHorses,
        int    $activeRunnerCount,
        int    $targetCount,
        array  $similarStatsMap,
        array  $qualThreeState,
        string $legacyGapType
    ): array {
        $T = [21, 18, 15, 12, 9, 6];

        // ── 1. 固定馬番ペアごとの W(k,t) と P(k,t) ────────────────────────────
        //   02-1「馬番が変わったらその境界は不明にし、別の馬で比較しない」
        //   ここでは6分前人気で上下を固定し、同じ2頭を全時点で比べる。
        $ratio = static function (array $u, array $l, string $key, int $t): ?float {
            $uv = $u[$key][$t] ?? null;
            $lv = $l[$key][$t] ?? null;
            if (!is_numeric($uv) || !is_numeric($lv)) return null;
            if ((float) $uv <= 0 || (float) $lv <= 0)  return null;
            return (float) $lv / (float) $uv;   // 下側 ÷ 上側
        };

        $pairs = [];
        for ($i = 0; $i < count($pHorses) - 1; $i++) {
            $u = $pHorses[$i];
            $l = $pHorses[$i + 1];
            $k = (int) ($u['popularity'] ?? ($i + 1));

            $W = []; $P = [];
            foreach ($T as $t) {
                $W[$t] = $ratio($u, $l, 'tan_series',      $t);
                $P[$t] = $ratio($u, $l, 'fuku_min_series', $t);
            }

            // 出現／消滅／拡大／縮小（21分と6分の単勝壁で判定。欠損は不明）
            $w21 = $W[21]; $w6 = $W[6];
            $appear = $vanish = $expand = $shrink = null;   // null = 不明
            $shrinkRate = null;
            if ($w21 !== null && $w6 !== null) {
                $appear = ($w21 <  2.0 && $w6 >= 2.0);
                $vanish = ($w21 >= 2.0 && $w6 <  2.0);
                $shrinkRate = ($w21 > 0) ? (($w21 - $w6) / $w21) : null;
                $expand = ($w6 > $w21);
                $shrink = ($w6 < $w21);
            }
            // 単複の一致／不一致（6分前。W>=2.00 を単勝壁、P>=1.50 を複勝補強とする暫定閾値）
            $agree = null;
            if ($w6 !== null && $P[6] !== null) {
                $agree = (($w6 >= 2.0) === ($P[6] >= 1.5));
            }

            $pairs[$k] = [
                'k'          => $k,
                'upper_num'  => (int) $u['num'],
                'lower_num'  => (int) $l['num'],
                'W'          => array_map(static fn($v) => $v === null ? null : round($v, 4), $W),
                'P'          => array_map(static fn($v) => $v === null ? null : round($v, 4), $P),
                '出現'       => $appear,
                '消滅'       => $vanish,
                '拡大'       => $expand,
                '縮小'       => $shrink,
                '縮小率'     => $shrinkRate === null ? null : round($shrinkRate, 4),
                '単複一致'   => $agree,
                '単勝壁6分'  => $w6 === null ? null : ($w6 >= 2.0),
                '複勝補強6分'=> $P[6] === null ? null : ($P[6] >= 1.5),
            ];
        }

        // ── 2. X1〜X6・Z（三値：true / false / null=不明）──────────────────
        $or3 = static function (array $v): ?bool {
            $unk = false;
            foreach ($v as $x) { if ($x === true) return true; if ($x === null) $unk = true; }
            return $unk ? null : false;
        };

        // X1 境界弱化（重み2）: k<=6 で W(k,21)>=2.00 かつ（W(k,6)<2.00 または 縮小20%以上）
        $x1Each = [];
        foreach ($pairs as $k => $p) {
            if ($k > 6) continue;
            if ($p['W'][21] === null || $p['W'][6] === null) { $x1Each[] = null; continue; }
            $x1Each[] = ($p['W'][21] >= 2.0)
                     && ($p['W'][6] < 2.0 || ($p['縮小率'] !== null && $p['縮小率'] >= 0.20));
        }
        $X1 = $or3($x1Each);

        // X2 単複乖離（重み1）: k<=10 で W(k,6)>=2.00 かつ P(k,6)<1.50
        $x2Each = [];
        foreach ($pairs as $k => $p) {
            if ($k > 10) continue;
            if ($p['W'][6] === null) { $x2Each[] = null; continue; }
            if ($p['W'][6] < 2.0)    { $x2Each[] = false; continue; }
            $x2Each[] = ($p['P'][6] === null) ? null : ($p['P'][6] < 1.5);
        }
        $X2 = $or3($x2Each);

        // X3 中位接近（重み1）: k=3,4,5,6 の4境界すべて有効で max(W(k,6)) < 1.50。N<7 は不明
        $X3 = null;
        if ($activeRunnerCount >= 7) {
            $x3Vals = [];
            $x3Ok   = true;
            foreach ([3, 4, 5, 6] as $k) {
                if (!isset($pairs[$k]) || $pairs[$k]['W'][6] === null) { $x3Ok = false; break; }
                $x3Vals[] = $pairs[$k]['W'][6];
            }
            if ($x3Ok && count($x3Vals) === 4) $X3 = (max($x3Vals) < 1.5);
        }

        // X4 穴側の絶対支持（重み1）: 7番人気以下で、異なる2頭以上に
        //    21→6分の複勝最小が5%以上短縮 または 9→6分で3%以上短縮
        //    02-X4「相対流入1位だけを短縮に数えない」→ 絶対値の短縮率だけで判定する
        $x4Hit = 0; $x4Unknown = 0; $x4Detail = [];
        foreach ($pHorses as $h) {
            if ((int) ($h['popularity'] ?? 0) < 7) continue;
            $f21 = $h['fuku_min_series'][21] ?? null;
            $f9  = $h['fuku_min_series'][9]  ?? null;
            $f6  = $h['fuku_min_series'][6]  ?? null;
            $s216 = (is_numeric($f21) && is_numeric($f6) && $f21 > 0) ? (($f21 - $f6) / $f21) : null;
            $s96  = (is_numeric($f9)  && is_numeric($f6) && $f9  > 0) ? (($f9  - $f6) / $f9)  : null;
            if ($s216 === null && $s96 === null) { $x4Unknown++; continue; }
            $hit = (($s216 !== null && $s216 >= 0.05) || ($s96 !== null && $s96 >= 0.03));
            if ($hit) {
                $x4Hit++;
                $x4Detail[] = ['num' => (int) $h['num'], '人気' => (int) $h['popularity'],
                               '21→6短縮率' => $s216 === null ? null : round($s216, 4),
                               '9→6短縮率'  => $s96  === null ? null : round($s96, 4)];
            }
        }
        $X4 = ($x4Hit >= 2) ? true : (($x4Unknown > 0) ? null : false);

        // X5 中穴の壁（重み1）: k=7..10 の単勝で W(k,6)>=2.00 が1つ以上
        $x5Each = [];
        foreach ($pairs as $k => $p) {
            if ($k < 7 || $k > 10) continue;
            $x5Each[] = ($p['W'][6] === null) ? null : ($p['W'][6] >= 2.0);
        }
        $X5 = empty($x5Each) ? null : $or3($x5Each);

        // X6 類似統計（重み1・条件付き）
        //   02-X6「同条件の過去類似レースが50レース以上あり、7人気以下の3着内進入率が
        //          同条件の比較基準率より10パーセントポイント以上高い」
        //   【比較基準率の定義が未合意】08の未決事項B。基準率を取れないので UNKNOWN とする。
        //   判断材料として、7番人気以下の3着内率と母数だけを記録しておく。
        $X6 = null;
        $x6Note = '比較基準率の定義が未合意のため不明（提出パック08-Bの未決事項）';
        $x6Raw  = [];
        foreach ($pHorses as $h) {
            $pop = (int) ($h['popularity'] ?? 0);
            if ($pop < 7) continue;
            $st = $similarStatsMap[$pop] ?? null;
            if ($st === null) continue;
            $x6Raw[] = ['人気' => $pop,
                        '3着以内率' => isset($st->top3_rate) ? (float) $st->top3_rate : null,
                        '母数'      => isset($st->sample_count) ? (int) $st->sample_count : null];
        }

        // Z 安定上位（-2）: k=1..5 で W(k,6)>=2.00 かつ P(k,6)>=1.50 かつ W(k,21)>=2.00 が
        //                   異なる2境界以上
        $zHit = 0; $zUnknown = 0;
        foreach ($pairs as $k => $p) {
            if ($k > 5) continue;
            if ($p['W'][6] === null || $p['P'][6] === null || $p['W'][21] === null) { $zUnknown++; continue; }
            if ($p['W'][6] >= 2.0 && $p['P'][6] >= 1.5 && $p['W'][21] >= 2.0) $zHit++;
        }
        $Z = ($zHit >= 2) ? true : (($zUnknown > 0) ? null : false);

        // ── 3. S と mode ────────────────────────────────────────────────────
        //   S = 2*X1 + X2 + X3 + X4 + X5 + X6 - 2*Z
        $weights = ['X1' => 2, 'X2' => 1, 'X3' => 1, 'X4' => 1, 'X5' => 1, 'X6' => 1, 'Z' => -2];
        $flags   = ['X1' => $X1, 'X2' => $X2, 'X3' => $X3, 'X4' => $X4, 'X5' => $X5, 'X6' => $X6, 'Z' => $Z];

        $modeOf = static function (int $s): string {
            if ($s <= 1) return 'FIRM';
            if ($s <= 3) return 'MIXED';
            return 'VOLATILE';
        };

        $known = 0; $sKnown = 0; $unknownKeys = [];
        foreach ($flags as $key => $v) {
            if ($v === null) { $unknownKeys[] = $key; continue; }
            $known++;
            if ($v === true) $sKnown += $weights[$key];
        }
        // 不明を0/1の全組合せで振った時のSの範囲
        $sMin = $sKnown; $sMax = $sKnown;
        foreach ($unknownKeys as $key) {
            $w = $weights[$key];
            if ($w >= 0) { $sMax += $w; } else { $sMin += $w; }
        }
        // 不明の全組合せでモードが変わるか
        $modeVaries = ($modeOf($sMin) !== $modeOf($sMax));
        $mode = (count($unknownKeys) >= 3 || $modeVaries) ? 'UNKNOWN' : $modeOf($sKnown);

        // ── 4. 3帯 quota(A,B,D) ─────────────────────────────────────────────
        //   02-3 の配分表。UNKNOWN は MIXED の配分を使うが、ラベルは UNKNOWN のまま保持。
        //   EXTREME（研究専用）は本番から除外するため、ここでは生成しない。
        $quotaTable = [
            7 => ['FIRM' => [5, 2, 0], 'MIXED' => [4, 2, 1], 'VOLATILE' => [3, 3, 1]],
            6 => ['FIRM' => [4, 2, 0], 'MIXED' => [3, 2, 1], 'VOLATILE' => [3, 2, 1]],
            5 => ['FIRM' => [4, 1, 0], 'MIXED' => [3, 2, 0], 'VOLATILE' => [2, 2, 1]],
            4 => ['FIRM' => [3, 1, 0], 'MIXED' => [2, 2, 0], 'VOLATILE' => [2, 1, 1]],
        ];
        $quotaMode = ($mode === 'UNKNOWN') ? 'MIXED' : $mode;
        $quota     = $quotaTable[$targetCount][$quotaMode] ?? null;   // null = C=4〜7以外

        // ── 5. 各馬の帯と独立根拠系統・Tier ──────────────────────────────────
        //   01-6 の5系統。ability（能力/適性）はAIの採点が必要でPHP側では出せないため
        //   常に不明とし、Tierは「市場系4系統だけで数えた暫定値」であることを明記する。
        $bandOf = static function (int $pop): string {
            if ($pop >= 1 && $pop <= 6)  return 'A';
            if ($pop >= 7 && $pop <= 10) return 'B';
            return 'D';
        };
        // 複勝人気順（6分前・複勝最小の昇順。同値は馬番昇順）
        $fukuRank = [];
        $fr = array_values(array_filter($pHorses,
            static fn($h) => isset($h['fuku_min_6']) && is_numeric($h['fuku_min_6']) && $h['fuku_min_6'] > 0));
        usort($fr, static function ($a, $b) {
            if ((float) $a['fuku_min_6'] !== (float) $b['fuku_min_6']) {
                return (float) $a['fuku_min_6'] <=> (float) $b['fuku_min_6'];
            }
            return ((int) $a['num']) <=> ((int) $b['num']);
        });
        foreach ($fr as $i => $h) { $fukuRank[(int) $h['num']] = $i + 1; }

        // 断層境界に関係している馬番（上側・下側のどちらか）
        $gapRelated = [];
        foreach ($pairs as $p) {
            if ($p['単勝壁6分'] === true || $p['消滅'] === true
                || ($p['縮小率'] !== null && $p['縮小率'] >= 0.20)) {
                $gapRelated[$p['upper_num']] = true;
                $gapRelated[$p['lower_num']] = true;
            }
        }

        $horses = [];
        foreach ($pHorses as $h) {
            $num = (int) $h['num'];
            $pop = (int) ($h['popularity'] ?? 0);

            // market: 複勝最小の絶対短縮（21→6で5%以上、または9→6で3%以上）
            $f21 = $h['fuku_min_series'][21] ?? null;
            $f9  = $h['fuku_min_series'][9]  ?? null;
            $f6  = $h['fuku_min_series'][6]  ?? null;
            $s216 = (is_numeric($f21) && is_numeric($f6) && $f21 > 0) ? (($f21 - $f6) / $f21) : null;
            $s96  = (is_numeric($f9)  && is_numeric($f6) && $f9  > 0) ? (($f9  - $f6) / $f9)  : null;
            $market = ($s216 === null && $s96 === null)
                ? null
                : (($s216 !== null && $s216 >= 0.05) || ($s96 !== null && $s96 >= 0.03));

            // win_place: 単勝人気順 − 複勝人気順 >= 2
            $wp = isset($fukuRank[$num]) && $pop > 0 ? (($pop - $fukuRank[$num]) >= 2) : null;

            // gap: 断層境界に関係している
            $gap = !empty($gapRelated[$num]);

            // similar_value: 予測補正OPI <= 0.85、または類似統計の3着以内率が母数50件以上で取れている
            $opi = $h['estimated_opi'] ?? ($h['opi'] ?? null);
            $sv  = is_numeric($opi) ? ((float) $opi <= 0.85) : null;

            // ability: AIの能力適性採点が要るためPHPでは判定できない
            $ability = null;

            $fam = ['market' => $market, 'ability' => $ability, 'gap' => $gap,
                    'win_place' => $wp, 'similar_value' => $sv];
            $hit = 0; $unk = 0;
            foreach ($fam as $v) { if ($v === true) $hit++; elseif ($v === null) $unk++; }
            $tier = ($hit >= 2) ? 'A' : (($hit === 1) ? 'B' : 'C');

            $horses[] = [
                'num'        => $num,
                '人気'       => $pop,
                '帯'         => $bandOf($pop),
                '複勝人気'   => $fukuRank[$num] ?? null,
                '根拠系統'   => $fam,
                '成立系統数' => $hit,
                '不明系統数' => $unk,
                'Tier'       => $tier,
                '旧資格'     => array_key_exists($num, $qualThreeState) ? $qualThreeState[$num] : null,
            ];
        }

        $bandCount = ['A' => 0, 'B' => 0, 'D' => 0];
        $tierCount = ['A' => 0, 'B' => 0, 'C' => 0];
        foreach ($horses as $hr) { $bandCount[$hr['帯']]++; $tierCount[$hr['Tier']]++; }

        return [
            'config_version' => 'v03-20261012-proposal',
            '適用'           => 'シャドー（記録のみ・選出には一切使っていない）',
            'N'              => $activeRunnerCount,
            'target_count'   => $targetCount,
            '構造'           => [
                'X1' => $X1, 'X2' => $X2, 'X3' => $X3, 'X4' => $X4,
                'X5' => $X5, 'X6' => $X6, 'Z'  => $Z,
                'S'      => $sKnown,
                'S_min'  => $sMin,
                'S_max'  => $sMax,
                '不明項目' => $unknownKeys,
                '不明で判定が変わるか' => $modeVaries,
                'mode'   => $mode,
            ],
            'quota'          => $quota === null
                ? ['A' => null, 'B' => null, 'D' => null, '注記' => "target_count={$targetCount} は配分表（4〜7）の対象外"]
                : ['A' => $quota[0], 'B' => $quota[1], 'D' => $quota[2], '使用モード' => $quotaMode],
            '帯別頭数'       => $bandCount,
            'Tier別頭数'     => $tierCount,
            '境界'           => array_values($pairs),
            '全頭'           => $horses,
            'X4根拠'         => $x4Detail,
            'X6根拠'         => ['判定' => $X6, '注記' => $x6Note, '類似統計' => $x6Raw],
            '旧断層タイプ'   => $legacyGapType,
            '注意'           => [
                'ability系統はAIの能力適性採点が必要なためPHPでは判定できず、常に不明。'
                . 'Tierは市場系4系統だけで数えた暫定値であり、提出パック01-6のTierとは一致しない',
                '閾値（単勝壁2.00／複勝補強1.50／縮小20%／短縮5%・3%／類似50件・10pp）は'
                . '提出パック10の研究用初期値であり、検証済みの本番値ではない',
                'EXTREME（2/3/2）は研究専用のため生成していない',
            ],
        ];
    }


    /**
     * ═══════════════════════════════════════════════════════════════════════
     * @ANCHOR-20261014-FILL-MODE  不足枠の補充方式のスイッチ（A / B / C）
     * ═══════════════════════════════════════════════════════════════════════
     * 10月14日（3回目）のご依頼「B方式への切り替えをお願いします。ただし
     * 購入推奨とは完全に分離してください」への対応です。
     *
     *   A … 現行。資格（旧 F AND (R OR O)）未達の7番人気以下は補充に使わない。
     *        目標数Cに届かないまま公開する。
     *   B … 資格を問わず、統合おすすめ度の順位で不足枠を補充する。
     *        補充した馬は「補充枠」として区別し、購入推奨には入れない。
     *   C … v0.4の独立根拠が2系統以上ある馬だけで補充する。
     *        足りなくても根拠の弱い馬では埋めない。
     *
     * 【既定をAにしている理由】
     *   同日のご依頼②-⑥に「B方式への切替前に、PHP実装と仕様書が完全一致して
     *   いるか最終確認できる資料を提出してください」とあり、切り替えの前に
     *   よっしー側の突合を挟む段取りになっています。
     *   そのため既定は現行（A）のままにし、.env の1行で切り替えられるように
     *   しました。切り替えても戻せます。
     *
     *   .env に次の1行を足して config:clear すればB方式になります。
     *     BAGANRIKI_FILL_MODE=B
     *
     * 【どの方式でも変えないもの】
     *   ・AIへ送る文（プロンプト）… 1バイトも変わりません
     *   ・DBの元データ・オッズ      … 読むだけで書き換えません
     *   ・既存の購入回避条件        … 低配当・回収率40%未満・最低基準点の
     *                                 判定内容と閾値は一切変えていません
     *   ・1〜6番人気の候補          … 補充は7番人気以下だけなので押し出しません
     */
    public const FILL_MODE_DEFAULT = 'A';

    /**
     * @ANCHOR-20261014-FILL-PROOF  検査のためこのプロセス内だけ方式を差し替える
     *   .env は書き換えません。--fill-mode-proof が
     *   「方式を変えても送信文が1バイトも変わらない」ことを示すために使います。
     */
    private static ?string $fillModeOverride = null;
    public static function forceFillMode(?string $m): void
    {
        $m = ($m === null) ? null : strtoupper(trim($m));
        self::$fillModeOverride = in_array($m, ['A', 'B', 'C'], true) ? $m : null;
    }

    private static function fillMode(): string
    {
        if (self::$fillModeOverride !== null) return self::$fillModeOverride;
        $v = strtoupper(trim((string) env('BAGANRIKI_FILL_MODE', self::FILL_MODE_DEFAULT)));
        return in_array($v, ['A', 'B', 'C'], true) ? $v : self::FILL_MODE_DEFAULT;
    }

    /** いま効いている補充方式（報告・検査用に外から読む） */
    public static function currentFillMode(): string { return self::fillMode(); }

    /**
     * @ANCHOR-20261014-FILL-PROOF  v0.4の5スイッチの実効値（報告・検査用）
     *   「5スイッチが変更されていないこと」を毎回同じ基準で出せるようにします。
     */
    public static function v04SwitchReport(): array
    {
        return [
            'BAGANRIKI_V04_ENABLED'          => self::v04Enabled()         ? 'true' : 'false',
            'BAGANRIKI_V04_SHADOW'           => self::v04Shadow()          ? 'true' : 'false',
            'BAGANRIKI_V04_RESEARCH_EXTREME' => self::v04Bool('BAGANRIKI_V04_RESEARCH_EXTREME',
                                                   self::V04_RESEARCH_EXTREME_DEFAULT) ? 'true' : 'false',
            'BAGANRIKI_V04_ML_STAGE'         => self::v04MlStage(),
            'BAGANRIKI_V04_HV_PROMPT'        => self::v04HvPrompt()        ? 'true' : 'false',
            // @ANCHOR-20261017-LABEL-FIX
            'BAGANRIKI_LABEL_FIX'            => self::labelFix()           ? 'true' : 'false',
        ];
    }

    /**
     * ═══════════════════════════════════════════════════════════════════════
     * @ANCHOR-20261014-FILL-MODE  補充枠の馬が購入推奨に入らないようにする
     * ═══════════════════════════════════════════════════════════════════════
     * ご依頼③「補充馬を自動的に購入推奨しない。公開候補と購入判断を分離する」
     * への対応です。公開候補に出すかどうかと、買う価値があるかどうかを
     * 別の値にして、どちらも監査ログに残します。
     *
     * 購入推奨にするのは、次のすべてを満たす馬だけです。
     *   ・資格未達で補充枠に入った馬ではない
     *   ・最低基準点以上
     *   ・購入回避フラグ（低配当・回収率40%未満・大穴条件の不成立）が立っていない
     */
    /**
     * @ANCHOR-20261014-FILL-MODE  資格未達の7番人気以下を補充してよいかの判定
     *
     * 第2パスの判断をここ1か所にまとめ、受入試験（--v04-test）から
     * 直接呼べるようにしています。方式ごとの違いはこの関数だけです。
     *
     * @param string   $mode              A / B / C
     * @param int|null $independentGroups v0.4の独立群数。null = 記録が無い
     * @return array   allow（補充してよいか）／reason（監査ログに残す文）
     */
    public static function fillAllowUnqualified(string $mode, ?int $independentGroups): array
    {
        if ($mode === 'A') {
            return ['allow' => false,
                    'reason' => '資格未達の7番人気以下（数合わせには使わない）'];
        }
        if ($mode === 'C') {
            // 独立根拠が確認できない馬は頭数合わせで採用しない（ご依頼どおり）
            if ($independentGroups === null) {
                return ['allow' => false,
                        'reason' => '資格未達の7番人気以下（独立根拠の記録が無いため補充しない）'];
            }
            if ($independentGroups < 2) {
                return ['allow' => false,
                        'reason' => "資格未達の7番人気以下（独立根拠が{$independentGroups}系統で2系統未満）"];
            }
            return ['allow' => true,
                    'reason' => "選出（補充枠・C方式／独立根拠{$independentGroups}系統／購入推奨には入れない）"];
        }
        // B … 資格を問わず順位で補充する
        return ['allow' => true,
                'reason' => '選出（補充枠・B方式／購入推奨には入れない）'];
    }

    private static function fillPurchaseRecommended(array $h): bool
    {
        if (!empty($h['fill_slot_unqualified'])) return false;   // 補充枠（資格未達）
        if (!empty($h['below_min_score']))       return false;   // 最低基準点未満
        if (!empty($h['buy_avoid_longshot']))    return false;   // 大穴条件の不成立
        if (!empty($h['buy_avoid_low_payout']))  return false;   // 低配当
        if (!empty($h['buy_avoid_recovery']))    return false;   // 回収率40%未満
        return true;
    }

    /**
     * ═══════════════════════════════════════════════════════════════════════
     * @ANCHOR-20261013-V04-FLAGS  第二世代 v0.4-X のスイッチと版（既定すべてOFF）
     * ═══════════════════════════════════════════════════════════════════════
     * よっしー20261013提出「統一版v0.4-X」付録D 10_研究用設定.json の
     * switch_defaults に合わせる。
     *   BAGANRIKI_V04_ENABLED          … v0.4の3帯配分を実際の選出に使うか（既定false）
     *   BAGANRIKI_V04_SHADOW           … 構造判定を計算して監査ログに残すか（既定true）
     *   BAGANRIKI_V04_RESEARCH_EXTREME … 大波乱配分(2/3/2)。研究専用・本番禁止（既定false）
     *   BAGANRIKI_V04_ML_STAGE         … 断層学習の段階（既定COLLECT_ONLY）
     *   BAGANRIKI_V04_HV_PROMPT        … 研究用H/V10項目採点をAIへ依頼するか（既定false）
     *
     * 【HV_PROMPT を既定OFFにしている理由】
     *   付録A/Bの1st/2ndプロンプトは「そのまま実運用APIへ送信しない」と明記され、
     *   07章Dで既存のBEGIN/ENDマーカー・Flutterパーサーとの適合確認が未決。
     *   ONにすると送信文が変わる＝旧本番が変わるため、よっしーの07章D回答と
     *   ユーザーの明示承認が出るまでOFFのままにする。
     *   OFFの間、送信文は1バイトも変わらない（受入A4の最後の項目）。
     */
    public const V04_CONFIG_VERSION      = 'v04-x-unified-20261013';
    public const V04_RESEARCH_VERSION    = 'v04-x-unified-20261013';
    public const V04_SCORING_VERSION     = 'hv10-v04';
    public const V04_ALLOCATION_VERSION  = 'abd-x-v04';
    public const V04_FEATURE_VERSION     = 'x1x6z-research-20261013';
    public const V04_SCHEMA_VERSION      = 'audit-v04-x-draft-1';

    public const V04_ENABLED_DEFAULT          = false;
    public const V04_SHADOW_DEFAULT           = true;
    public const V04_RESEARCH_EXTREME_DEFAULT = false;
    public const V04_ML_STAGE_DEFAULT         = 'COLLECT_ONLY';
    public const V04_HV_PROMPT_DEFAULT        = false;

    // ══════════════════════════════════════════════════════════════════════
    // @ANCHOR-20261017-LABEL-FIX  AIへ渡すラベルの直し（既定OFF）
    // ══════════════════════════════════════════════════════════════════════
    // 10月17日 東京9R の照合検証報告（よっしーさん）§8への対応です。
    //   「この計算では、比較する時間幅が3分と6分で異なり、区間も重なっている。
    //     さらに直前変化率が負であることを要求しない」
    //   「『流入ランク』の短縮率は正が短縮、『直前流入』の変化率は正が上昇で、
    //     同じ文面内の符号の意味が逆になっている」
    //   「これを変更する場合は、事前に影響範囲を確認して別版で再検算し、
    //     週末の据え置き検証結果と混在させない」
    //
    // ■ 直すもの（2つとも【AIへ渡す入力のラベル】の話で、DB元値は触りません）
    //   (1) 直前3分の加速・減速判定を、同じ時間幅（12→9分 と 9→6分）で比べる
    //       いまは 3分幅（9→6分）と 6分幅（12→6分）を引き算していて、
    //       区間も重なっています。そのため【単勝オッズが上がっている馬でも
    //       「直前加速」と出ます】（10/17 東京9R の2番・8番が実例）。
    //   (2) 同じ馬のブロックの中で「＋」の意味が逆になっているのを直す
    //       短縮率は「＋＝買われた」、直前流入の変化率は「＋＝売られた」でした。
    //       どちらも数値のうしろに方向を言葉で書きます。
    //
    // ■ 既定OFFにしてある理由
    //   ONにすると送信文が変わるので、10月17日・18日の据え置き検証と
    //   混ざってしまいます。比較が終わるまでOFFのままにします。
    //   OFFのときは1バイトも変わりません（従来と同じ文面になります）。
    public const LABEL_FIX_DEFAULT            = false;

    /** 付録D signal_thresholds_research_only。検証済みの本番値ではない */
    public const V04_THRESHOLDS = [
        'win_wall'                       => 2.00,
        'place_wall'                     => 1.50,
        'win_wall_shrink_fraction'       => 0.20,
        'middle_close_upper_bound'       => 1.50,
        'place_shorten_21_to_6_fraction' => 0.05,
        'place_shorten_9_to_6_fraction'  => 0.03,
        'similar_min_races'              => 50,
        'similar_3in_delta_pp'           => 10.0,
    ];


        'win_wall'                       => 2.00,
        'place_wall'                     => 1.50,
        'win_wall_shrink_fraction'       => 0.20,
        'middle_close_upper_bound'       => 1.50,
        'place_shorten_21_to_6_fraction' => 0.05,
        'place_shorten_9_to_6_fraction'  => 0.03,
        'similar_min_races'              => 50,
        'similar_3in_delta_pp'           => 10.0,
    ];

    public const V04_SIGNAL_WEIGHTS = [
        'X1' => 2, 'X2' => 1, 'X3' => 1, 'X4' => 1, 'X5' => 1, 'X6' => 1, 'Z' => -2,
    ];
    public const V04_UNKNOWN_COUNT_AT_LEAST = 3;

    public const V04_QUOTA_BY_TARGET = [
        7 => ['FIRM' => [5, 2, 0], 'MIXED' => [3, 3, 1], 'VOLATILE' => [3, 3, 1]],
        6 => ['FIRM' => [4, 2, 0], 'MIXED' => [3, 2, 1], 'VOLATILE' => [3, 2, 1]],
        5 => ['FIRM' => [4, 1, 0], 'MIXED' => [3, 2, 0], 'VOLATILE' => [2, 2, 1]],
        4 => ['FIRM' => [3, 1, 0], 'MIXED' => [2, 2, 0], 'VOLATILE' => [2, 1, 1]],
    ];

    public const V04_QUOTA_EXTREME = [7 => ['EXTREME' => [2, 3, 2]]];

    /** 付録D score_cap。信頼度H=60／妙味代理V=40／合計100 */
    public const V04_SCORE_CAP = [
        'H1' => 18, 'H2' => 15, 'H3' => 12, 'H4' => 9, 'H5' => 6,
        'V1' => 12, 'V2' => 10, 'V3' => 8,  'V4' => 6, 'V5' => 4,
    ];

        'H1' => 18, 'H2' => 15, 'H3' => 12, 'H4' => 9, 'H5' => 6,
        'V1' => 12, 'V2' => 10, 'V3' => 8,  'V4' => 6, 'V5' => 4,
    ];

    public const V04_HV_JSON_BEGIN = '<<<BAGANRIKI_HV10_V04_BEGIN>>>';
    public const V04_PUBLIC_CAP_2ND = 5;

    public const V04_ML_PLAN = [
        'start_shadow_after_valid_races'    => 1000,
        'future_holdout_for_limited_live'   => 200,
        'future_holdout_for_allocation_live'=> 500,
        'requires_explicit_approval'        => true,
        'max_ai_candidate_swap_due_to_ml'   => 1,
        'max_band_slot_move_due_to_ml'      => 1,
        'current_live_ML_policy_do_not_change' => '2000+500',
    ];

    public const V04_X6_BASELINE = null;

    public const V04_ABNORMAL_FIX_LOG = [
        ['10/13', 'AIが配点の上限を超えた点数を返すと、合計が100点を超えたまま通っていた',
         '上限超過は invalid にし、合計を null にする。0点で補完しない',
         'v04ScoreTotals()／@ANCHOR-20261013-V04-HV', 'score（7項目）・AB-T11'],
        ['10/13', '採点できない項目を0点として合計していた',
         '欠損は null のままにし、score_status=partial・合計 null にする',
         'v04ScoreTotals()', 'score・AB-T08・AB-T09・AB-T10'],
        ['10/13', '仮選出が score_status=partial の馬まで通していた（02章7-4違反）',
         '検証済み（valid）だけで選出する。採点が無い間は0頭で PARTIAL_COUNT に残す',
         'v04BandSelection($strict=true)／@ANCHOR-20261013-V04-VALID-ONLY', 'valid-only（6項目）'],
        ['10/14', '出走頭数の不一致を anomalies に入れるだけで、候補生成を止めていなかった',
         'DATA_INVALID へ昇格させ、研究用の候補生成を止める',
         '@ANCHOR-20261014-COUNT-INVALID', 'count（4項目）・DATA_INVALID'],
        ['10/14', '同じ馬番が2回返ると後の行で上書きされ、黙って消えていた',
         '最初の行を残し、2回目以降は duplicated に記録して ok=false にする',
         '@ANCHOR-20261014-HV-DUP', 'hv-dup（5項目）'],
        ['10/14', 'race_id と snapshot_hash を実値で渡さず、照合していなかった',
         '実値を渡して回答と照合し、不一致なら UNDETERMINED にする',
         '@ANCHOR-20261014-ID-ECHO', 'id-echo（3項目）'],
        ['10/14', '契約検証を定義しただけで、採用処理に接続していなかった',
         '統合処理に接続し、UNDETERMINED の回答の採点を採用しない',
         '@ANCHOR-20261014-CONTRACT-GATE', 'hv-dup・id-echo・count'],
        ['10/14', '1stがタイムアウトしたとき、前レースの1st回答が使われ得た',
         'レースが変わったら控えをすべて捨てる（レースガード）',
         '@ANCHOR-20261014-RACE-GUARD／v04BeginRace()', 'race-guard（5項目）'],
        ['10/14', '2nd回答の控えをレースごとにクリアしておらず、2レースで同じ回答になった',
         '同じくレースガードで破棄。前レースと同一なら異常として表示する',
         '@ANCHOR-20261014-RACE-GUARD', 'race-guard'],
        ['10/14', 'AUDIT_MERGE にレース表記が無く、どのレースの統合か分からなかった',
         'race と race_id を記録する',
         '@ANCHOR-20261014-AUDIT-RACEID', '（実レースで確認）'],
        ['10/14', '知らない信号値（TRUE/FALSE/UNKNOWN以外）で例外を投げ、レースが止まり得た',
         '不明（UNKNOWN）へ倒して \\Log::error で表に出す。FALSE には倒さない',
         '@ANCHOR-20261014-ABNORMAL-INPUT／v04Classify()', 'AB-T01・AB-T02・AB-T03'],
        ['10/14', '出走頭数が負のとき例外を投げ、レースが止まり得た',
         '0頭として扱い、\\Log::error で表に出す',
         '@ANCHOR-20261014-ABNORMAL-INPUT／v04TargetCount()', 'AB-T04・AB-T05・AB-T06'],
        ['10/14', '公開候補に重複があると不足数を取り違え、補充すべきときに補充しなかった',
         '重複を除いてから不足数を数える',
         '@ANCHOR-20261014-ABNORMAL-INPUT／v04FillCandidates()', 'AB-T24'],
        ['10/14', '全頭採点が1頭も返っていなくても PARTIAL 止まりで、採点を採用し得た',
         '採点0頭は UNDETERMINED にして採用しない。公開は止めない',
         '@ANCHOR-20261014-ABNORMAL-INPUT／v04CheckAiContract()', 'AB-T27・AB-T28'],
        ['10/14', '2nd AIの全頭採点がDBに1件も残っていなかった（72レース全部）。'
                . '1stは生で保存しているのに、2ndだけ publicPart() を通して保存していたため',
         '2ndも生のまま保存する。画面へ出さないための publicPart() は応答側と'
         . '一覧APIの2か所で通す。あわせて1stの一覧APIが内部JSONを返していたのも閉じた。'
         . '全頭採点が入っていなければ [ALLSCORE_MISSING] を error で残す',
         '@ANCHOR-20261014-ALLSCORE-KEEP', '（10/17のレースで受領を確認）'],
    ];

    public const V04_EXCLUSION_POINTS = [
        // ── 実際に頭数が減る箇所 ─────────────────────────────────────────
        ['REDUCE', 'AI回答の行の形式不正',        '_parseAiHorses()',
         '馬番・馬名・人気順などが読めない行を候補にしない。読めた行はすべて残す'],
        ['REDUCE', 'DB照合（実在しない馬番）',    '_dbValidateHorses()',
         '6分前のDBに存在しない馬番、人気帯が矛盾する馬を落とす。馬番と理由をログに残す'],
        ['REDUCE', '上限超過の絞り込み',          '_trimAiCandidates()',
         '1stは目標数C、2ndは5頭まで。おすすめ度の降順→同点は馬番昇順で決定論的に絞る。'
         . '保護対象（人気薄の根拠付き）がいる場合は先に枠へ入れる。外した行は理由つきで記録'],
        ['REDUCE', '目標数Cでの最終絞り込み',     '_mergeAiResults() の順位確定',
         '人気側と資格ある穴側の枠を先に確保したうえで、目標数Cまで。'
         . '枠を確保してから絞るので、確保した穴馬が後段で消えることはない'],
        // ══════════════════════════════════════════════════════════════════
        // @ANCHOR-20261014-EXCLUSION-SLOT2  10/14に追記（この一覧の記載漏れ）
        // ══════════════════════════════════════════════════════════════════
        // 【記載漏れだった理由】
        //   上の「目標数Cでの最終絞り込み」を「C頭まで絞る」としか書いておらず、
        //   「C頭に届いていなくても補充しない馬がいる」ことを書いていなかった。
        //   --v04-trace の実データ（10/12）で、目標数Cに達していないのに
        //   AIの公開候補が公開されない馬が出たため、一覧に追記した。
        // 【この条件は意図した仕様】
        //   10/4の仕様書6.2「足りない枠は未選出全頭の順位で補い、
        //   根拠の弱い穴馬を数合わせで強制しない」に対応する処理。
        //   資格（旧 F AND (R OR O)）を満たさない7番人気以下は、
        //   枠が余っていても補充に使わない。結果として公開頭数がC未満になる。
        //   このとき [PREDICTION_PARTIAL] を警告ログに出し、公開は止めない。
        ['REDUCE', '資格未達の7番人気以下は数合わせに使わない',
         '_mergeAiResults() 第2パス（枠確保モードのときだけ）',
         '枠確保モード（配分フラグON かつ 人気側・穴側の目標頭数が決まっているレース）では、'
         . '資格を満たさない7番人気以下を目標数C合わせの補充に使わない。'
         . 'そのため公開頭数が目標数C未満になることがある（仕様書6.2）。'
         . '非選出の理由は「資格未達の7番人気以下（数合わせには使わない）」として'
         . '監査ログの全頭欄に残り、--v04-trace で馬番ごとに表示できる'],
        ['REDUCE', '1st AIの回答が使えない',      '@ANCHOR-20261004-NO-HTTP500-UNDETERMINED',
         'レースごと未確定（undetermined）として候補0件にする。'
         . '2nd AIだけの予想を通常の予想として出さないという現行ルール'],

        // ── 印をつけるだけで頭数を減らさない箇所（10/4〜10/6に変更済み）──
        ['FLAG', '低配当（Block 13a）',            'buy_avoid_low_payout',
         '推定確定複勝1.5倍未満かつ単勝3.0倍未満。購入回避フラグのみ。例外3条件で解除あり'],
        ['FLAG', '回収率40%未満（Block 12）',      'buy_avoid_recovery',
         'サンプル30件以上の有効値が2種類以上あり、うち2種類以上が40%未満。購入回避フラグのみ'],
        ['FLAG', '最低基準点（Block 13b）',        'buy_avoid_min_score',
         '本候補70点・補欠60点・人気薄55点。順位づけの優先材料と購入判断にのみ使う'],
        ['FLAG', '11番人気以下の大穴条件',         '4項目の確認',
         '満たさない項目があれば順位で後回しにするだけ。不明は「満たしていない」と扱わない'],
        ['FLAG', '旧資格 F AND (R OR O)',          'allocEvidence',
         '7番人気以下の穴側「優先枠」に入れるかの条件。満たさなくても候補一覧からは消えない'],

        // ── 記録だけで頭数を減らさない箇所 ───────────────────────────────
        ['LOG', '人気帯別上限（上位/中穴/大穴）',  '$mergeUpperMax／$mergeMidMax／$mergeLowerMax',
         '値は算出して監査ログ（merge_upper_max 等）に残すが、_mergeAiResults() の中では'
         . '候補を削る処理に一度も使っていない。人気帯別上限は廃止済み'],
        ['LOG', '2nd独自発見枠の採用条件',         '診断専用',
         'おすすめ度70点以上・8根拠のうち2つ以上・タイプ別頭数上限は、分類と記録にだけ使う。'
         . '満たさない2nd独自の馬も候補から落とさない'],
        ['LOG', '断層位置別の上限',                '廃止',
         '断層の上側・下側による頭数上限は設けていない。断層下側を自動で低評価・除外しない'],
        ['LOG', '大穴進入度による割り当て',        '廃止',
         '大穴進入度1〜2なら0頭といった頭数の割り当ては廃止。頭数はPHPが別途決める'],

        // ── v0.4研究経路だけで効く条件（公開候補には影響しない）──────────
        ['v0.4', 'Tier C／UNVERIFIED',             'v04BandSelection()',
         '独立根拠が無い、または全て未検証の馬は研究用の選出に採らない。頭数合わせの採用はしない'],
        ['v0.4', 'score_status が valid でない',   'v04BandSelection($strict=true)',
         '検証済みの得点が無い馬は採らない（順位を捏造しないため）。'
         . '採点が届くまで研究用の選出は0頭になり、PARTIAL_COUNT に残る'],
        ['v0.4', '契約検証 UNDETERMINED',          '@ANCHOR-20261014-CONTRACT-GATE',
         'snapshot_hash・race_idの不一致、馬番の重複があるAIの採点を採用しない'],
        ['v0.4', 'DATA_INVALID',                   '@ANCHOR-20261014-COUNT-INVALID',
         '入力破損（馬番重複・人気順重複・出走頭数の不一致）で研究用の候補生成を止める'],
    ];


    public const V04_REQ_STATUS = [
        'R01' => ['DB/PHP元値を正本とし、AIで書換えない',                 2, 5, ''],
        'R02' => ['6分前入力を固定し両AIに同じsnapshot_hashを渡す',       2, 5, ''],
        'R03' => ['21/18/15/12/9/6分前を固定馬番ペアで比較',              2, 0, '本番は21分と6分の単勝だけ。6時点のW/Pはv0.4研究経路のみ'],
        'R04' => ['X1〜X6＋Z、Q方式を混在させない',                       2, 0, '本番は旧断層A〜E'],
        'R05' => ['mode・target_count・A/B/D配分を選出前に固定',          2, 0, '本番は旧2区分の可変配分'],
        'R06' => ['H/V10項目で採点。欠損項目・partial合計はnull',          2, 0, '採点の集計とパーサーは試験済み。実AIで採点させるのは未（HV_PROMPT=false）'],
        'R07' => ['両AIは独立。1stは0〜target_count頭、2ndは0〜5頭',      2, 5, ''],
        'R08' => ['候補0頭でも内部全頭JSONを必須',                        2, 5, '本番は現行の11項目JSON。研究用H/V JSONは未受領'],
        'R09' => ['旧F AND(R OR O)は比較用。falseだけで削除しない',        2, 0, '本番は旧資格を使う方式のまま'],
        'R10' => ['Tier A/Bと検証済み得点で帯別選出',                     2, 0, '検証済み得点が無い間は適格0頭（02-7-4どおり）'],
        'R11' => ['不足帯は別帯で補充。不足はPARTIAL_COUNT',              2, 0, ''],
        'R12' => ['帯別採用後に全馬得点上位で再抽出して穴枠を消さない',    2, 5, '本番にも人気薄の保護枠あり（9月27日実装）。3帯版はv0.4研究経路のみ'],
        'R13' => ['+5一致加点は両AIの公開候補一致のみ',                   2, 5, ''],
        'R14' => ['回収率40%未満・低配当・基準点は購入判断と分離',        2, 5, ''],
        'R15' => ['UNKNOWNはSHADOWで暫定MIXED、LIVEは旧方式保持',         2, 5, '本番が旧方式のままという意味'],
        'R16' => ['DATA_INVALIDは候補生成停止。欠損でHTTP500にしない',    2, 5, '本番の500回避は10月5〜6日実装。DATA_INVALIDはv0.4研究経路のみ'],
        'R17' => ['旧DB・回答・成績を保護し、新研究結果は別保存',          2, 5, ''],
        'R18' => ['既知レースのデバッグと未使用レースの検証を分離',        1, 0, 'レポート機構は作成済み。実データは10月17日から'],
    ];
    public const V04_REQ_STAGE_LABEL = [
        0 => '該当なし（本番はv0.4を使っていない）',
        1 => 'コード作成済み',
        2 => '単体試験済み',
        3 => '実AI確認済み',
        4 => 'SHADOW稼働済み',
        5 => '本番有効化済み',
    ];



    public function getBaganrikiR122Race(string $race_id)
    {
        $parts = explode('-', $race_id);
        if (count($parts) !== 5) {
            return response()->json([
                'schema_version' => 'baganriki-v041-r12-2',
                'race_id'        => $race_id,
                'state'          => 'UNAVAILABLE',
                'diagnostics'    => [['code' => 'ENTRY_SET_MISMATCH',
                                      'message' => 'race_id の形が違います（YYYYMMDD-回-場-日-R）']],
                'buy_recommended' => false,
            ], 400);
        }
        [$ymd, $kaisuu, $basho, $day, $race] = $parts;
        $date = substr($ymd, 0, 4) . '-' . substr($ymd, 4, 2) . '-' . substr($ymd, 6, 2);

        // ── 正本のレース情報 ────────────────────────────────────────────
        $r = \DB::table('t_horse_odds_finder_races')
            ->where('date', $date)->where('kaisuu', $kaisuu)->where('basho', $basho)
            ->where('day', $day)->where('race', (int) $race)->first();
        if ($r === null) {
            return response()->json(BaganrikiPublicView::build([
                'race_id'     => $race_id,
                'state'       => 'UNAVAILABLE',
                'diagnostics' => [['code' => 'ENTRY_MISSING',
                                   'message' => 'このレースは正本に存在しません']],
            ]), 404);
        }

        // ── 保存済みの r12.2 の記録を読む ───────────────────────────────
        //   まだ凍結・公開の保存を実装していない期間は、
        //   snapshot が無い状態として PENDING / UNAVAILABLE を返します。
        // ══════════════════════════════════════════════════════════════
        // @ANCHOR-20261020-R122-API  本番の世代（generation=0）だけを読みます
        // ══════════════════════════════════════════════════════════════
        // 【直した中身】
        //   これまで orderByDesc('generation') で読んでいたので、
        //   試験で保存した REPLAY（generation=900）があると
        //   <b>公開APIがその試験用の記録を返してしまいました。</b>
        //   読取APIは本番の世代だけを見ます。
        //
        //   3つの版と公開履歴は<b>ひとつの読取取引</b>でそろえて取ります。
        //   書込ロックは持ちません（契約8章）。
        $snap = null; $live = null; $pub = null; $slots = null;
        if (\Schema::hasTable('baganriki_snapshots')) {
            [$snap, $live, $pub, $slots] = \DB::transaction(function () use ($race_id) {
                $s = \DB::table('baganriki_snapshots')->where('race_id', $race_id)
                       ->where('generation', 0)->first();
                $l = null; $p = null; $w = null;
                if ($s !== null && \Schema::hasTable('baganriki_live_states')) {
                    $l = \DB::table('baganriki_live_states')
                           ->where('snapshot_id', $s->id)->first();
                }
                if ($s !== null && \Schema::hasTable('baganriki_publications')) {
                    $p = \DB::table('baganriki_publications')
                           ->where('snapshot_id', $s->id)
                           ->orderByDesc('published_at')->first();
                }
                if ($s !== null && \Schema::hasTable('baganriki_ai_attempts')) {
                    $w = BaganrikiWorker::slots((int) $s->id);
                }
                return [$s, $l, $p, $w];
            });
        }

        $cancellations = ($live !== null && $live->cancellations !== null)
            ? (json_decode((string) $live->cancellations, true) ?: []) : [];
        $activeCount   = ($live !== null) ? $live->active_count : null;
        $allCancelled  = ($activeCount !== null && (int) $activeCount === 0);

        // 実効公開期限。投票締切の正本が無ければ期限を作らず、推測もしません。
        $effPublish = null; $pastDeadline = false;
        $salesClose = $snap->sales_close_at ?? null;
        if ($salesClose !== null) {
            $sc = BaganrikiTime::us((string) $salesClose);
            if ($sc !== null) {
                $lc = ($live !== null && $live->live_close !== null)
                    ? BaganrikiTime::us((string) $live->live_close) : null;
                $eff = BaganrikiTime::effectiveDeadlines($sc, $lc);
                $effPublish   = BaganrikiTime::toJst($eff['publish']);
                $pastDeadline = (BaganrikiTime::us(date('c')) ?? 0) > $eff['publish'];
            }
        }

        $diag = [];
        if ($salesClose === null) {
            $diag[] = ['code' => 'PUBLICATION_DEADLINE_EXCEEDED',
                       'message' => '投票締切の正本が特定できていないため公開しません'];
        }
        $inputInvalid = ($snap === null)
            ? false
            : (($snap->input_invalid_code ?? null) !== null);
        if ($inputInvalid) {
            $diag[] = ['code' => (string) $snap->input_invalid_code,
                       'message' => (string) ($snap->input_invalid_reason ?? '')];
        }

        $state = BaganrikiPublicView::state(
            $pub !== null, $allCancelled, $inputInvalid, $pastDeadline);
        if ($snap === null) { $state = 'PENDING'; }

        $pubDto = null;
        if ($pub !== null) {
            $pubDto = [
                'publication_id'           => $pub->publication_id,
                'published_at'             => $pub->published_at,
                'prediction_target_count'  => $pub->prediction_target_count ?? null,
                'prediction_quota'         => json_decode((string) ($pub->prediction_quota ?? 'null'), true),
                'publication_target_count' => $pub->publication_target_count ?? null,
                'publication_quota'        => json_decode((string) ($pub->publication_quota ?? 'null'), true),
                'candidates'               => json_decode((string) ($pub->candidates ?? '[]'), true),
                'evidence'                 => json_decode((string) ($pub->evidence ?? '[]'), true),
            ];
        }

        // @ANCHOR-20261020-R122-API  いまの取消を映した枠と候補数
        //   正式公開のリストは動かしません（取消だけで再選出しません）。
        //   取消になった馬を除いた数だけを、別の欄として返します。
        $actualQuota = null; $availableCount = null;
        if ($pubDto !== null) {
            $cans = (array) ($pubDto['candidates'] ?? []);
            $actualQuota = ['A' => 0, 'B' => 0, 'D' => 0];
            $availableCount = 0;
            foreach ($cans as $c) {
                $no = (int) ($c['horse_no'] ?? 0);
                if (in_array($no, array_map('intval', $cancellations), true)) { continue; }
                $availableCount++;
                $b = (string) ($c['band'] ?? '');
                if (isset($actualQuota[$b])) { $actualQuota[$b]++; }
            }
        }
        $effReply = null;
        if ($salesClose !== null) {
            $sc2 = BaganrikiTime::us((string) $salesClose);
            if ($sc2 !== null) {
                $lc2 = ($live !== null && $live->live_close !== null)
                    ? BaganrikiTime::us((string) $live->live_close) : null;
                $eff2 = BaganrikiTime::effectiveDeadlines($sc2, $lc2);
                $effReply = BaganrikiTime::toJst($eff2['reply']);
            }
        }

        return response()->json(BaganrikiPublicView::build([
            'race_id'         => $race_id,
            'state'           => $state,
            'response_revision'     => $live->response_revision ?? null,
            'publication_revision'  => $live->publication_revision ?? null,
            'latest_publication_id' => $live->latest_publication_id ?? null,
            'actual_quota'              => $actualQuota,
            'available_candidate_count' => $availableCount,
            'live_close'              => $live->live_close ?? null,
            'effective_reply_deadline' => $effReply,
            'worker_state'    => $slots,
            'mode'            => $snap->mode            ?? null,
            'mode_status'     => $snap->mode_status     ?? null,
            'allocation_mode' => $snap->allocation_mode ?? null,
            'mode_policy_id'  => $snap->mode_policy_id  ?? null,
            'display_rating'  => $snap->display_rating  ?? null,
            'publication'     => $pubDto,
            'state_revision'  => $live->state_revision ?? null,
            'cancellations'   => $cancellations,
            'active_count'    => $activeCount,
            'live_target_count' => $live->live_target_count ?? null,
            'live_quota'      => ($live !== null && ($live->live_quota ?? null) !== null)
                                 ? json_decode((string) $live->live_quota, true) : null,
            'effective_publish_deadline' => $effPublish,
            'collection_audit' => ($snap !== null && ($snap->collection_audit ?? null) !== null)
                                  ? json_decode((string) $snap->collection_audit, true) : null,
            'input_freeze_at' => $snap->input_freeze_at ?? null,
            'coverage'        => ($snap !== null && ($snap->coverage ?? null) !== null)
                                 ? json_decode((string) $snap->coverage, true) : null,
            'diagnostics'     => $diag,
            'shortfalls'      => ($pub !== null && ($pub->shortfalls ?? null) !== null)
                                 ? json_decode((string) $pub->shortfalls, true) : [],
        ]));
    }

    public static function r122RaceId($date, $kaisuu, $basho, $day, $race): string
    {
        return str_replace('-', '', (string) $date) . '-' . (string) $kaisuu . '-'
             . (string) $basho . '-' . (string) $day . '-' . (int) $race;
    }

    /**
     * ═══════════════════════════════════════════════════════════════════════
     * @ANCHOR-20261020-R122-RESP  応答検証と局所回復（本番接続）
     * ═══════════════════════════════════════════════════════════════════════
     * 根拠：server_contract_r12.2.txt 6章・7章・10章
     *
     * ■ 通す順番（本番と同じ）
     *   extract → checkEnvelope → isolateHorses → BaganrikiDiagnose::run
     *
     * ■ 何を正とするか
     *   凍結入力（snapshot）と、予約済みの role を正とします。
     *   <b>応答が名乗る役は照合相手を選ぶのに使いません。</b>
     *   封筒照合は、予約した role の固定入力に対してだけ行います。
     *
     * ■ 局所回復
     *   馬番欠落・重複・未知馬・局所の項目不正は、その範囲だけ隔離します。
     *   正常な他馬はそのまま残します。
     *   直してよい範囲は repair_scope として baganriki_validation_results に残します。
     *
     * @return array ['ok','stage','code','reason','accepted','needs_fix',
     *                'repair_scope','normal','row_valid','diag']
     */
    public function r122InspectResponse(int $snapshotId, string $role,
                                        int $attemptNo = 0): array
    {
        $out = ['ok' => false, 'stage' => 'start', 'code' => null, 'reason' => null,
                'accepted' => false, 'needs_fix' => false,
                'repair_scope' => null, 'normal' => [], 'row_valid' => [],
                'diag' => null, 'attempt_id' => null];

        $snap = \DB::table('baganriki_snapshots')->where('id', $snapshotId)->first();
        if ($snap === null) {
            $out['stage'] = 'snapshot'; $out['code'] = 'NO_SNAPSHOT';
            $out['reason'] = '凍結入力がありません';
            return $out;
        }
        $a = \DB::table('baganriki_ai_attempts')
               ->where('snapshot_id', $snapshotId)->where('role', $role)
               ->where('attempt_no', $attemptNo)->first();
        if ($a === null) {
            $out['stage'] = 'attempt'; $out['code'] = 'NO_ATTEMPT';
            $out['reason'] = 'その枠がありません';
            return $out;
        }
        $out['attempt_id'] = (int) $a->id;
        if ((string) $a->status !== BaganrikiWorker::RECEIVED) {
            $out['stage'] = 'attempt'; $out['code'] = 'NOT_RECEIVED';
            $out['reason'] = '原応答を受け取っていません（' . $a->status . '）';
            return $out;
        }

        $col = ($role === '2nd') ? 'input_json_2nd' : 'input_json_1st';
        $src = json_decode((string) $snap->{$col}, true);
        if (!is_array($src)) {
            $out['stage'] = 'snapshot'; $out['code'] = 'NO_INPUT';
            $out['reason'] = '固定入力（' . $col . '）を読めません';
            return $out;
        }

        // ── ① 原文から封筒を取り出す ────────────────────────────────
        $ex = BaganrikiResponse::extract((string) $a->raw_response);
        if (!$ex['ok']) {
            $out['stage'] = 'extract';
            $out['code']  = (string) ($ex['code'] ?? 'AI_FAILURE');
            $out['reason'] = (string) ($ex['reason'] ?? '');
            $this->r122SaveValidation((int) $a->id, null, $out, null, null, null);
            return $out;
        }
        $res = (array) $ex['json'];

        // ── ② 封筒照合（予約した role の固定入力だけが相手）──────────
        $env = BaganrikiResponse::checkEnvelope($res, [
            'prompt_version'  => $src['prompt_version']  ?? null,
            'schema_version'  => $src['schema_version']  ?? null,
            'race_id'         => $src['race_id']         ?? null,
            'ai_role'         => $src['ai_role']         ?? null,
            'snapshot_hash'   => $src['snapshot_hash']   ?? null,
            'mode'            => $src['mode']            ?? null,
            'mode_status'     => $src['mode_status']     ?? null,
            'allocation_mode' => $src['allocation_mode'] ?? null,
            'mode_policy_id'  => $src['mode_policy_id']  ?? null,
            'role_cap'        => $src['role_cap']        ?? null,
            'role_quota'      => $src['role_quota']      ?? null,
        ]);
        if (!$env['ok']) {
            $out['stage'] = 'envelope';
            $out['code']  = (string) ($env['code'] ?? 'ENVELOPE');
            $out['reason'] = (string) ($env['reason'] ?? '');
            $this->r122SaveValidation((int) $a->id, null, $out, null, null, null);
            return $out;
        }

        // ── ③ 馬ごとの隔離（正常な他馬を残す）───────────────────────
        $frozen = [];
        foreach ((array) ($src['runners'] ?? []) as $r) {
            $frozen[] = (int) ($r['horse_no'] ?? 0);
        }
        $iso = BaganrikiResponse::isolateHorses((array) ($res['horses'] ?? []), $frozen);

        // ── ④ 診断（inspect と resolve で同じ関数）──────────────────
        $d = BaganrikiDiagnose::run($res, $src);

        // 正常部分＝隔離に残り、かつ row_valid が true の行
        $normal = [];
        foreach ((array) $iso['kept'] as $k => $h) {
            $no = is_int($k) ? $k : (int) ($h['horse_no'] ?? 0);
            if ($no <= 0) { continue; }
            if (($d['row_valid'][$no] ?? true) !== true) { continue; }
            $normal[$no] = $h;
        }
        ksort($normal);

        $out['ok']           = true;
        $out['stage']        = 'ok';
        $out['code']         = $d['ok'] ? 'OK' : 'REPAIRABLE';
        $out['reason']       = BaganrikiDiagnose::summary($d);
        $out['accepted']     = ($normal !== []);
        $out['needs_fix']    = !$d['ok'];
        $out['repair_scope'] = $d['repair_scope'];
        $out['normal']       = $normal;
        $out['row_valid']    = $d['row_valid'];
        $out['diag']         = [
            'findings'   => $d['findings'],
            'missing'    => $d['missing'],
            'duplicated' => $d['duplicated'],
            'unknown'    => $d['unknown'],
            'isolated'   => array_keys((array) $iso['isolated']),
            'iso_missing' => (array) $iso['missing'],
        ];
        $this->r122SaveValidation((int) $a->id, $normal, $out,
            $d['repair_scope'], self::r122FieldSources($normal),
            self::r122RankSources($res));
        return $out;
    }

    /**
     * @ANCHOR-20261020-R122-RESP  訂正を解決します（最大1回）
     *   初回の原応答と complete を保存してからでないと動きません。
     *   直してよい範囲は<b>初回の診断</b>から取ります（同じ診断関数です）。
     *   採用できない訂正では、初回の正常部分をそのまま残します。
     */
    public function r122ResolveCorrection(int $snapshotId, string $role): array
    {
        $out = ['ok' => false, 'code' => null, 'reason' => null,
                'merged' => [], 'applied' => [], 'rescued' => [], 'skipped' => []];

        $first = $this->r122InspectResponse($snapshotId, $role, BaganrikiWorker::FIRST);
        if (!$first['ok']) {
            $out['code'] = 'FIRST_NOT_USABLE';
            $out['reason'] = '初回が採用できません（' . $first['stage'] . '／'
                           . $first['code'] . '）';
            return $out;
        }
        $out['merged'] = $first['normal'];        // 何があっても初回の正常部分は残します
        if (!$first['needs_fix']) {
            $out['ok'] = true; $out['code'] = 'NO_FIX_NEEDED';
            $out['reason'] = '初回に直すところがないので訂正しません';
            return $out;
        }

        $fix = $this->r122InspectResponse($snapshotId, $role, BaganrikiWorker::FIX);
        if (!$fix['ok']) {
            $out['ok'] = true; $out['code'] = 'FIX_NOT_USABLE';
            $out['reason'] = '訂正が採用できないので初回の正常部分を残します（'
                           . $fix['stage'] . '／' . $fix['code'] . '）';
            return $out;
        }

        $rowsA = \DB::table('baganriki_ai_attempts')
                   ->where('snapshot_id', $snapshotId)->where('role', $role)
                   ->whereIn('attempt_no', [BaganrikiWorker::FIRST, BaganrikiWorker::FIX])
                   ->get()->keyBy('attempt_no');
        $firstAt = self::r122DbRfc3339($rowsA[BaganrikiWorker::FIRST]->received_at ?? null);
        $fixAt   = self::r122DbRfc3339($rowsA[BaganrikiWorker::FIX]->received_at ?? null);

        $snap = \DB::table('baganriki_snapshots')->where('id', $snapshotId)->first();
        $frozen = [];
        foreach ((array) json_decode((string) ($snap->frozen_nums ?? '[]'), true) as $n) {
            $frozen[] = (int) $n;
        }

        $acc = BaganrikiResponse::acceptCorrection(
            $first['normal'], $fix['normal'], $firstAt, $fixAt,
            $frozen, $first['repair_scope'], $fix['row_valid']);
        if (($acc['ok'] ?? false) !== true) {
            $out['ok'] = true; $out['code'] = 'FIX_REJECTED';
            $out['reason'] = '訂正を採用しません（' . (string) ($acc['reason'] ?? '')
                           . '）。初回の正常部分を残します';
            return $out;
        }
        $out['merged']  = BaganrikiResponse::applyCorrection(
                              $first['normal'], $fix['normal'], $acc);
        $out['applied'] = (array) ($acc['applied'] ?? []);
        $out['rescued'] = (array) ($acc['rescued'] ?? []);
        $out['skipped'] = (array) ($acc['skipped'] ?? []);
        $out['ok']   = true;
        $out['code'] = 'FIX_APPLIED';
        $out['reason'] = '訂正を反映しました（適用 ' . count($out['applied'])
                       . '頭・救済 ' . count($out['rescued'])
                       . '頭・飛ばし ' . count($out['skipped']) . '頭）';
        return $out;
    }

    /**
     * @ANCHOR-20261020-R122-RESP  選出に渡す馬（訂正があればそれを使う）
     */
    public function r122AcceptedHorses(int $snapshotId, string $role): array
    {
        $has = \DB::table('baganriki_ai_attempts')
                 ->where('snapshot_id', $snapshotId)->where('role', $role)
                 ->where('attempt_no', BaganrikiWorker::FIX)
                 ->where('status', BaganrikiWorker::RECEIVED)->exists();
        if ($has) { return $this->r122ResolveCorrection($snapshotId, $role); }
        $f = $this->r122InspectResponse($snapshotId, $role, BaganrikiWorker::FIRST);
        return ['ok' => $f['ok'], 'code' => $f['code'], 'reason' => $f['reason'],
                'merged' => $f['normal'], 'applied' => [], 'rescued' => [],
                'skipped' => [], 'needs_fix' => $f['needs_fix'],
                'repair_scope' => $f['repair_scope']];
    }

    /** @ANCHOR-20261020-R122-RESP  各馬の事実出典hash（加点の証明とは別に残します） */
    public static function r122FieldSources(array $horses): array
    {
        $o = [];
        foreach ($horses as $no => $h) {
            $refs = [];
            foreach ((array) ($h['evidence'] ?? []) as $e) {
                foreach ((array) ($e['source_refs'] ?? []) as $r) { $refs[] = (string) $r; }
            }
            foreach ((array) ($h['family_review'] ?? []) as $fam) {
                foreach ((array) ($fam['source_refs'] ?? []) as $r) { $refs[] = (string) $r; }
            }
            $refs = array_values(array_unique($refs));
            sort($refs, SORT_STRING);
            $o[(string) $no] = ['refs' => $refs,
                                'hash' => hash('sha256', implode("\n", $refs))];
        }
        return $o;
    }

    /** @ANCHOR-20261020-R122-RESP  順位の出どころ（帯ごとの方式と並び） */
    public static function r122RankSources(array $res): array
    {
        return [
            'band_ranks'          => (array) ($res['band_ranks'] ?? []),
            'evidence_band_ranks' => (array) ($res['evidence_band_ranks'] ?? []),
            'public_candidates'   => (array) ($res['public_candidates'] ?? []),
        ];
    }

    /** @ANCHOR-20261020-R122-RESP  検証の結果を残します（表が無ければ何もしません） */
    private function r122SaveValidation(int $attemptId, ?array $normal, array $out,
                                        ?array $scope, ?array $fieldSources,
                                        ?array $rankSources): void
    {
        if (!\Schema::hasTable('baganriki_validation_results')) { return; }
        $j = static fn($v) => ($v === null) ? null : (string) json_encode($v,
            JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PRESERVE_ZERO_FRACTION);
        try {
            \DB::table('baganriki_validation_results')->insert([
                'attempt_id'        => $attemptId,
                'validator_version' => BaganrikiDiagnose::VERSION,
                'normal_part'       => $j($normal),
                'diagnostics'       => $j(['stage' => $out['stage'], 'code' => $out['code'],
                                           'reason' => $out['reason'],
                                           'diag' => $out['diag'] ?? null]),
                'repair_scope'      => $j($scope),
                'field_sources'     => $j($fieldSources),
                'rank_sources'      => $j($rankSources),
                'created_at'        => BaganrikiWorker::toDb(BaganrikiWorker::nowUs()),
            ]);
        } catch (\Throwable $e) {
            \Log::error('[R122-RESP] 検証結果を残せません', ['message' => $e->getMessage()]);
        }
    }

    /**
     * ═══════════════════════════════════════════════════════════════════════
     * @ANCHOR-20261020-R122-PUB  統合・公開・intent・revision（本番接続）
     * ═══════════════════════════════════════════════════════════════════════
     * 根拠：server_contract_r12.2.txt 7章・8章・10章・11章
     *
     * ■ 通す順番
     *   ① 読取（書込ロックを持ちません）
     *      3つの版（state／response／publication）と、両roleの検証済み全頭評価。
     *      ここで「検証開始時刻」を取ります。
     *   ② 統合（BaganrikiRanking::merge）
     *      rank_score=100×(K−r+1)/K の max。同点は 両AIの原公開一致あり →
     *      独立根拠群数の多い順 → 馬番昇順。
     *      <b>両AIの検証済み原公開候補だと証明できたときだけ +5。</b>
     *   ③ 枠を先に全帯ぶん予約し、D不足はB、B不足はD、A不足はB→D で埋めます。
     *      馬番は重複させません。
     *   ④ 「検証完了時刻」を取り、intent_hash を作ります。
     *   ⑤ <b>短いトランザクション</b>で live_state と intent をロックし、
     *      3つの版・現在時刻・期限をもう一度見ます。
     *      古い処理は拒否。同じ intent の再実行は同じ publication_id。
     *   ⑥ 「commit直前時刻」を取り、
     *      検証開始 <= 検証完了 <= commit直前 を確かめます。
     *
     * ■ 加点の証明について
     *   訂正版または初回の<b>完全な原応答</b>が、公開に使う全頭の実効内容・
     *   帯順位・公開リスト・馬別フラグ・非選出理由と一致すると確かめられた
     *   ときだけ、その role の証明として使います。
     *   初回と訂正が混ざった行は証明できないので加点しません。
     *
     * @param array $opt ['now_us'=>int, 'job_id'=>string, 'handed'=>array]
     * @return array
     */
    public function r122Publish(int $snapshotId, array $opt = []): array
    {
        $out = ['ok' => false, 'code' => null, 'reason' => null,
                'publication_id' => null, 'reused' => false,
                'candidates' => [], 'quota' => null, 'shortfalls' => [],
                'intent_hash' => null, 'job_id' => null,
                'used' => [], 'proof' => []];

        $t0 = (int) ($opt['now_us'] ?? BaganrikiWorker::nowUs());   // 検証開始時刻

        $snap = \DB::table('baganriki_snapshots')->where('id', $snapshotId)->first();
        if ($snap === null) {
            $out['code'] = 'NO_SNAPSHOT'; $out['reason'] = '凍結入力がありません';
            return $out;
        }
        // 原応答手渡しは、ジャーナルがあるレースでは受け付けません（契約10章）
        if (!empty($opt['handed'])) {
            $hasJournal = \DB::table('baganriki_ai_attempts')
                            ->where('snapshot_id', $snapshotId)->exists();
            if ($hasJournal) {
                $out['code'] = 'HANDED_REFUSED';
                $out['reason'] = 'ジャーナルがあるレースでは原応答の手渡しを受け付けません';
                return $out;
            }
        }

        BaganrikiWorker::ensureLive($snapshotId, $t0);
        $live = \DB::table('baganriki_live_states')
                  ->where('snapshot_id', $snapshotId)->first();      // ロックしません
        $readRev = [
            'state'       => ($live === null) ? 0 : (int) $live->state_revision,
            'response'    => ($live === null) ? 0 : (int) $live->response_revision,
            'publication' => ($live === null) ? 0 : (int) $live->publication_revision,
        ];
        // 呼出側が整合した読取取引で3つの版を取っているときは、その値を使います。
        //   （読取→検証→保存を分けて行う呼び方のためです。保存の直前に
        //     もう一度見比べて、古ければ保存しません）
        if (isset($opt['read_revisions']) && is_array($opt['read_revisions'])) {
            foreach (['state', 'response', 'publication'] as $k) {
                if (array_key_exists($k, $opt['read_revisions'])) {
                    $readRev[$k] = (int) $opt['read_revisions'][$k];
                }
            }
        }
        $out['used'] = $readRev;

        // ── 期限（実効）──────────────────────────────────────────────
        $dl = BaganrikiWorker::deadlines($snap, $live);
        if (!$dl['ok']) {
            $out['code'] = (string) $dl['code']; $out['reason'] = (string) $dl['reason'];
            return $out;
        }
        if ($t0 > $dl['publish']) {
            $out['code'] = 'DEADLINE_PASSED';
            $out['reason'] = '実効の公開期限を過ぎています';
            return $out;
        }

        // ── 全頭取消 ────────────────────────────────────────────────
        $cancelled = (array) json_decode((string) ($live->cancellations ?? '[]'), true);
        $cancelled = array_map('intval', $cancelled);
        $frozenBand = [];
        $src1 = json_decode((string) $snap->input_json_1st, true);
        foreach ((array) ($src1['runners'] ?? []) as $r) {
            $frozenBand[(int) $r['horse_no']] = (string) ($r['band'] ?? '');
        }
        $activeNums = array_values(array_diff(array_keys($frozenBand), $cancelled));
        if ($activeNums === []) {
            $out['code'] = 'ALL_CANCELLED'; $out['reason'] = '全頭取消です';
            return $out;
        }

        // ── ① 両roleの検証済み全頭評価（読取だけ）────────────────────
        $per = []; $proofHash = []; $accepted = [];
        foreach (['1st', '2nd'] as $role) {
            $a = $this->r122AcceptedHorses($snapshotId, $role);
            if (!($a['ok'] ?? false) || ($a['merged'] ?? []) === []) { continue; }
            $accepted[$role] = $a;
            $srcCol = ($role === '2nd') ? 'input_json_2nd' : 'input_json_1st';
            $src = json_decode((string) $snap->{$srcCol}, true);
            $resUsed = $this->r122ResponseUsed($snapshotId, $role, $a);
            if ($resUsed['proof'] !== null) { $proofHash[$role] = $resUsed['proof']; }
            $rows = [];
            foreach ((array) $a['merged'] as $num => $h) {
                $num = (int) $num;
                if (in_array($num, $cancelled, true)) { continue; }   // 取消は入れません
                $band = $frozenBand[$num] ?? ($h['band'] ?? '');
                $K = 0;
                foreach ($frozenBand as $n2 => $b2) {
                    if ($b2 === $band && !in_array((int) $n2, $cancelled, true)) { $K++; }
                }
                $order = array_map('intval',
                    (array) ($resUsed['band_ranks'][$band] ?? []));
                $order = array_values(array_filter($order,
                    static fn($n3) => !in_array((int) $n3, $cancelled, true)));
                $r = array_search($num, $order, true);
                if ($r === false) { continue; }    // 順位の分からない馬は入れません
                $sup = 0;
                foreach ((array) ($h['family_review'] ?? []) as $fam) {
                    if (($fam['status'] ?? '') === 'SUPPORTED') { $sup++; }
                }
                $rows[$num] = [
                    'r' => (int) $r + 1, 'K' => max(1, $K),
                    'public' => in_array($num,
                        array_map('intval', (array) ($resUsed['public_candidates'] ?? [])), true),
                    'groups' => $sup,
                ];
            }
            if ($rows !== []) { $per[$role] = $rows; }
        }
        if ($per === []) {
            $out['code'] = 'NO_RESPONSE';
            $out['reason'] = '検証を通った応答がありません';
            return $out;
        }

        // ── ② 統合 ─────────────────────────────────────────────────
        $merged = BaganrikiRanking::merge($per, $proofHash);
        $out['proof'] = array_keys($proofHash);

        // ── ③ 枠（先に全帯ぶん予約し、不足を規則どおりに移す）─────────
        //   構造上の不足（取消で実在しなくなった帯）と、
        //   評価後の適格馬不足は別の規則なので、2段に分けます。
        $q0 = (array) json_decode((string) $snap->quota_1st, true);
        $quota1st = isset($q0[0])
            ? ['A' => (int) $q0[0], 'B' => (int) $q0[1], 'D' => (int) $q0[2]]
            : ['A' => (int) ($q0['A'] ?? 0), 'B' => (int) ($q0['B'] ?? 0),
               'D' => (int) ($q0['D'] ?? 0)];
        $afterC = BaganrikiRanking::afterCancellation($frozenBand, $cancelled,
                      $quota1st, $snap->allocation_mode);
        if (($afterC['all_cancelled'] ?? false) === true) {
            $out['code'] = 'ALL_CANCELLED'; $out['reason'] = '全頭取消です';
            return $out;
        }
        $quota = (array) ($afterC['live_quota'] ?? $quota1st);
        if ($quota === []) { $quota = ['A' => 0, 'B' => 0, 'D' => 0]; }
        if (isset($quota[0])) {
            $quota = ['A' => (int) $quota[0], 'B' => (int) $quota[1], 'D' => (int) $quota[2]];
        }
        // 評価後の適格馬（統合に乗った馬）の帯ごとの数
        $avail = ['A' => 0, 'B' => 0, 'D' => 0];
        foreach ($merged as $m) {
            $b = $frozenBand[$m['num']] ?? '';
            if (isset($avail[$b])) { $avail[$b]++; }
        }
        $fill = BaganrikiRanking::fillShortfall($quota, $avail);
        $quota = (array) $fill['quota'];
        $out['shortfalls'] = array_merge((array) ($afterC['shortfalls'] ?? []),
                                         (array) $fill['shortfalls']);

        $taken = []; $cands = [];
        foreach (['A', 'B', 'D'] as $b) {
            $want = (int) ($quota[$b] ?? 0);
            $got = 0;
            foreach ($merged as $m) {
                if ($got >= $want) { break; }
                $num = (int) $m['num'];
                if (isset($taken[$num])) { continue; }          // 馬番は重複させません
                if (($frozenBand[$num] ?? '') !== $b) { continue; }
                $taken[$num] = true; $got++;
                $cands[] = [
                    'horse_no' => $num, 'band' => $b,
                    'score' => $m['score'], 'bonus' => $m['bonus'],
                    'both_public' => $m['both_public'],
                    'bonus_proven' => $m['bonus_proven'],
                    'independent_groups' => $m['groups'],
                    'public_proof_hash' => $m['public_proof_hash'],
                ];
            }
        }
        $out['candidates'] = $cands;
        $out['quota'] = $quota;

        // ── ④ 検証完了時刻と intent ─────────────────────────────────
        $t1 = BaganrikiWorker::nowUs();                     // 検証完了時刻
        $canon = BaganrikiPrompt::canonical([
            'snapshot_hash' => (string) $snap->snapshot_hash,
            'quota'         => $quota,
            'candidates'    => array_map(static fn($c) => [
                                   'horse_no' => $c['horse_no'],
                                   'band'     => $c['band'],
                                   'bonus'    => $c['bonus'],
                               ], $cands),
            // @ANCHOR-20261020-R122-PUB  intentに入れるのは「読んだもの」だけです。
            //   publication_revision は公開した<b>結果</b>なので入れません。
            //   入れると、同じ計算の再実行が毎回別のintentになり、
            //   「同じintentの再実行は同じpublication_id」が守れません。
            'revisions'     => ['state'    => $readRev['state'],
                                'response' => $readRev['response']],
        ]);
        if ($canon === null) {
            $out['code'] = 'CANON_FAILED'; $out['reason'] = 'intentの正本を作れません';
            return $out;
        }
        $intentHash = hash('sha256', $canon);
        $jobId = (string) ($opt['job_id'] ?? ('job-' . $snapshotId . '-' . $t1 . '-'
                 . substr(bin2hex(random_bytes(3)), 0, 6)));
        $out['intent_hash'] = $intentHash;
        $out['job_id'] = $jobId;

        // ── ⑤ 短いトランザクション（ここだけロックします）─────────────
        try {
            $res = \DB::transaction(function () use ($snapshotId, $snap, $intentHash,
                    $jobId, $readRev, $cands, $quota, $out, $t0, $t1, $cancelled,
                    $activeNums) {
                $live = \DB::table('baganriki_live_states')
                          ->where('snapshot_id', $snapshotId)->lockForUpdate()->first();
                $now = $readRev;
                if ($live !== null) {
                    $now = ['state' => (int) $live->state_revision,
                            'response' => (int) $live->response_revision,
                            'publication' => (int) $live->publication_revision];
                }
                // 同じ intent の再実行は同じ publication_id を返します
                $same = \DB::table('baganriki_publication_intents')
                          ->where('snapshot_id', $snapshotId)
                          ->where('intent_hash', $intentHash)->lockForUpdate()->first();
                if ($same !== null && $same->publication_id !== null) {
                    return ['ok' => true, 'code' => 'ALREADY', 'reused' => true,
                            'publication_id' => (string) $same->publication_id];
                }
                // 読んだあとに版が変わっていたら、古い計算は保存しません
                if ($now !== $readRev) {
                    return ['ok' => false, 'code' => 'STALE',
                            'reason' => '読取のあとに版が変わりました（state '
                                      . $readRev['state'] . '→' . $now['state']
                                      . '／response ' . $readRev['response'] . '→'
                                      . $now['response'] . '／publication '
                                      . $readRev['publication'] . '→'
                                      . $now['publication'] . '）'];
                }
                // 期限と時刻をもう一度
                $dl = BaganrikiWorker::deadlines($snap, $live);
                if (!$dl['ok']) {
                    return ['ok' => false, 'code' => (string) $dl['code'],
                            'reason' => (string) $dl['reason']];
                }
                $t2 = BaganrikiWorker::nowUs();              // commit直前時刻
                if ($t2 > $dl['publish']) {
                    return ['ok' => false, 'code' => 'DEADLINE_PASSED',
                            'reason' => 'commit直前の検査で公開期限を過ぎています'];
                }
                // 検証開始 <= 検証完了 <= commit直前（1マイクロ秒でも逆行なら拒否）
                if (!($t0 <= $t1 && $t1 <= $t2)) {
                    return ['ok' => false, 'code' => 'CLOCK_BACKWARD',
                            'reason' => '時刻が逆行しています'];
                }

                $pubId = 'pub-' . $snap->race_id . '-' . $snap->generation . '-'
                       . substr($intentHash, 0, 12);
                $intentId = \DB::table('baganriki_publication_intents')->insertGetId([
                    'snapshot_id' => $snapshotId, 'job_id' => $jobId,
                    'intent_hash' => $intentHash,
                    'read_state_revision'       => $readRev['state'],
                    'read_response_revision'    => $readRev['response'],
                    'read_publication_revision' => $readRev['publication'],
                    'state' => 'COMMITTED', 'publication_id' => $pubId,
                    'created_at' => BaganrikiWorker::toDb($t2),
                ]);
                $j = static fn($v) => (string) json_encode($v,
                    JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES
                    | JSON_PRESERVE_ZERO_FRACTION);
                $proofs = [];
                foreach ($cands as $c) {
                    if ($c['public_proof_hash'] !== null) {
                        $proofs[(string) $c['horse_no']] = $c['public_proof_hash'];
                    }
                }
                \DB::table('baganriki_publications')->insert([
                    'publication_id' => $pubId, 'snapshot_id' => $snapshotId,
                    'intent_id' => $intentId,
                    'published_at' => BaganrikiWorker::toDb($t2),
                    'prediction_target_count'  => array_sum($quota),
                    'prediction_quota'         => $j($quota),
                    'publication_target_count' => array_sum($quota),
                    'publication_quota'        => $j($quota),
                    'active_count'             => count($activeNums),
                    'candidates' => $j($cands),
                    'evidence'   => $j(['shortfalls' => $out['shortfalls'],
                                        'proof_roles' => $out['proof'],
                                        'cancelled' => $cancelled]),
                    'shortfalls' => $j($out['shortfalls']),
                    'used_state_revision'    => $readRev['state'],
                    'used_response_revision' => $readRev['response'],
                    'public_proof_hash'      => $j($proofs),
                ]);
                \DB::table('baganriki_live_states')->where('snapshot_id', $snapshotId)
                  ->update(['publication_revision' => $readRev['publication'] + 1,
                            'latest_publication_id' => $pubId,
                            'updated_at' => BaganrikiWorker::toDb($t2)]);
                BaganrikiWorker::event((string) $snap->race_id, $snapshotId,
                    'PUBLISHED', $readRev['publication'], $readRev['publication'] + 1,
                    ['publication_id' => $pubId, 'intent_hash' => $intentHash,
                     'job_id' => $jobId, 'candidates' => array_column($cands, 'horse_no'),
                     'verify_started_at'  => BaganrikiTime::toJst($t0),
                     'verify_finished_at' => BaganrikiTime::toJst($t1),
                     'committed_at'       => BaganrikiTime::toJst($t2)],
                    $pubId, $t2);
                return ['ok' => true, 'code' => 'PUBLISHED', 'reused' => false,
                        'publication_id' => $pubId];
            });
        } catch (\Throwable $e) {
            if (BaganrikiWorker::isDup($e)) {
                // 別のintentが先に入った＝こちらは stale
                $out['code'] = 'STALE';
                $out['reason'] = 'ほかの処理が先に保存しました';
                return $out;
            }
            $out['code'] = 'PUBLISH_EXCEPTION'; $out['reason'] = $e->getMessage();
            \Log::error('[R122-PUB] 公開で例外', ['message' => $e->getMessage(),
                'at' => $e->getFile() . ':' . $e->getLine()]);
            return $out;
        }

        $out['ok']     = (bool) ($res['ok'] ?? false);
        $out['code']   = (string) ($res['code'] ?? '');
        $out['reason'] = $res['reason'] ?? null;
        $out['reused'] = (bool) ($res['reused'] ?? false);
        $out['publication_id'] = $res['publication_id'] ?? null;
        return $out;
    }

    /**
     * @ANCHOR-20261020-R122-PUB  公開に使った原応答を特定します
     *   加点の証明は、<b>1本の完全な原応答</b>が公開に使う全頭と
     *   そろっているときだけ出します。初回と訂正が混ざった行は証明しません。
     *
     * @return array ['band_ranks','public_candidates','proof'=>[馬番=>hash]|null,
     *                'attempt_no'=>?int]
     */
    public function r122ResponseUsed(int $snapshotId, string $role, array $accepted): array
    {
        $o = ['band_ranks' => [], 'public_candidates' => [], 'proof' => null,
              'attempt_no' => null];
        $mixed = ((array) ($accepted['applied'] ?? []) !== []
               || (array) ($accepted['rescued'] ?? []) !== [])
               && (string) ($accepted['code'] ?? '') === 'FIX_APPLIED';
        // 訂正を当てた＝初回と訂正が混ざるので、証明は出しません
        $try = ((string) ($accepted['code'] ?? '') === 'FIX_APPLIED')
             ? [BaganrikiWorker::FIX, BaganrikiWorker::FIRST]
             : [BaganrikiWorker::FIRST];
        foreach ($try as $no) {
            $a = \DB::table('baganriki_ai_attempts')
                   ->where('snapshot_id', $snapshotId)->where('role', $role)
                   ->where('attempt_no', $no)
                   ->where('status', BaganrikiWorker::RECEIVED)->first();
            if ($a === null) { continue; }
            $ex = BaganrikiResponse::extract((string) $a->raw_response);
            if (!$ex['ok']) { continue; }
            $res = (array) $ex['json'];
            if ($o['band_ranks'] === []) {
                $o['band_ranks'] = (array) ($res['band_ranks'] ?? []);
                $o['public_candidates'] = (array) ($res['public_candidates'] ?? []);
                $o['attempt_no'] = (int) $no;
            }
            // 証明にできるのは、complete で、診断に直すところが無く、
            // 公開に使う全頭がその応答の中で一致している応答だけです。
            if ((int) $a->complete !== 1) { continue; }
            $insp = $this->r122InspectResponse($snapshotId, $role, (int) $no);
            if (!$insp['ok'] || $insp['needs_fix']) { continue; }
            if ($mixed && (int) $no === BaganrikiWorker::FIRST) { continue; }
            $want = array_keys((array) $accepted['merged']);
            $got  = array_keys((array) $insp['normal']);
            sort($want); sort($got);
            if ($want !== $got) { continue; }
            $same = true;
            foreach ($want as $num) {
                if (($accepted['merged'][$num] ?? null) !== ($insp['normal'][$num] ?? null)) {
                    $same = false; break;
                }
            }
            if (!$same) { continue; }
            $proof = [];
            foreach ($want as $num) { $proof[(int) $num] = (string) $a->response_hash; }
            $o['proof'] = $proof;
            $o['attempt_no'] = (int) $no;
            $o['band_ranks'] = (array) ($res['band_ranks'] ?? []);
            $o['public_candidates'] = (array) ($res['public_candidates'] ?? []);
            break;
        }
        return $o;
    }

    public static function r122DbRfc3339($v): ?string
    {
        if ($v === null) return null;
        $s = trim((string) $v);
        if ($s === '' || strncmp($s, '0000', 4) === 0) return null;
        if (preg_match('/^(\d{4}-\d{2}-\d{2})[ T](\d{2}:\d{2}:\d{2})(\.\d{1,6})?/', $s, $m)) {
            $frac = $m[3] ?? '';
            if ($frac === '.000000' || $frac === '.0') $frac = '';
            return $m[1] . 'T' . $m[2] . $frac . '+09:00';
        }
        return null;
    }

}
