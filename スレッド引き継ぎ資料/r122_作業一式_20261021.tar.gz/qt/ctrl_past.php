<?php
namespace App\Http\Controllers\Api;
class PastCtl
{
    public const DB_TIMEZONE = 'Asia/Tokyo';
    /**
     * ═══════════════════════════════════════════════════════════════════════
     * @ANCHOR-20261020-R122-MARKET  OPI と推定確定オッズを source_registry へ
     * ═══════════════════════════════════════════════════════════════════════
     * 根拠：server_contract_r12.2.txt 3章・5章／採点辞書 V1・V3・V4
     *
     * ■ 正本と式（いまの商品と同じものを使います。作り直しません）
     *   t_horse_odds_finder_popularity_rank_average       人気順位別の過去平均単勝
     *   t_horse_odds_finder_fuku_popularity_rank_average  人気順位別の過去平均複勝最小
     *   t_horse_odds_finder_compute_odds_correction       人気順位別の補正係数
     *
     *     OPI            = 過去平均単勝 ÷ 6分前単勝
     *     複勝OPI        = 過去平均複勝最小 ÷ 6分前複勝最小
     *     推定確定オッズ = 6分前単勝 × 補正係数
     *     推定確定複勝   = 6分前複勝最小 × 補正係数（複勝専用の係数は未実装）
     *     予測補正OPI    = 過去平均単勝 ÷ 推定確定オッズ
     *
     * ■ 使っていいかの判定（2つとも満たしたときだけ載せます）
     *   ① 集計期間の終わり（end_date）が<b>対象レースの開催日より前</b>
     *      当日を含む集計で、その当日のレースを評価しないためです。
     *   ② 算出時刻（computed_at）が情報上限より前
     *      この列が無い表は①だけで見ます。<b>無い時刻は作りません。</b>
     *      読み取った時刻（入力の凍結時刻）を observed_at に入れ、
     *      集計期間は start_date / end_date として別項目で渡します。
     *
     * ■ .env の BAGANRIKI_MARKET_PRIOR を 0 にすると載せません（既定は1）。
     *
     * @param array $frozenRank 馬番 => 凍結人気
     * @param array $cells      $cells[馬番][スロット]['win_odds'|'place_min']
     * @return array ['registry'=>..., 'coverage'=>['OPI'=>..,'estimated_odds'=>..]]
     */
    public static function r122MarketPriorRegistry(string $raceId, string $date,
                                                   array $frozenRank, array $cells,
                                                   ?string $freezeAt): array
    {
        $ng = static fn(string $o, string $e) => ['registry' => [], 'coverage' => [
            'OPI'            => ['status' => 'UNAVAILABLE', 'reason' => $o],
            'estimated_odds' => ['status' => 'UNAVAILABLE', 'reason' => $e],
        ]];

        if (!self::r122MarketPriorEnabled()) {
            $m = '.env の BAGANRIKI_MARKET_PRIOR が 0 のため載せていません';
            return $ng($m, $m);
        }
        foreach (['t_horse_odds_finder_popularity_rank_average',
                  't_horse_odds_finder_fuku_popularity_rank_average',
                  't_horse_odds_finder_compute_odds_correction'] as $t) {
            if (!\Schema::hasTable($t)) {
                $m = $t . ' がありません';
                return $ng($m, $m);
            }
        }
        if ($frozenRank === []) {
            $m = '凍結人気が出ていないので人気順位別の集計を引けません';
            return $ng($m, $m);
        }

        $freezeUs = ($freezeAt === null) ? null : BaganrikiTime::us($freezeAt);
        $day = substr($date, 0, 10);

        // 使っていいかを見る共通の道具
        $check = static function ($endDate, $computedAt) use ($day, $freezeUs, $freezeAt) {
            $ed = ($endDate === null) ? '' : substr(str_replace('/', '-', (string) $endDate), 0, 10);
            if ($ed === '') {
                return [false, '集計期間の終わりが分かりません', null];
            }
            if (strcmp($ed, $day) >= 0) {
                return [false, '集計期間の終わり（' . $ed . '）が対象レースの開催日（'
                             . $day . '）以降です。当日を含む集計で'
                             . 'その日のレースを評価しないためです。', null];
            }
            $cAt = ($computedAt === null) ? null : self::r122DbTime($computedAt);
            if ($cAt !== null && $freezeUs !== null) {
                $cu = BaganrikiTime::us($cAt);
                if ($cu === null || $cu > $freezeUs) {
                    return [false, 'この集計は情報上限より後に算出されています（算出 '
                                 . $cAt . '／情報上限 ' . ($freezeAt ?? '不明') . '）', null];
                }
            }
            return [true, null, $cAt];
        };

        // 人気順位 => その順位の馬番
        $byRank = [];
        foreach ($frozenRank as $no => $rk) {
            $byRank[(int) $rk][] = (int) $no;
        }
        foreach ($byRank as $rk => $list) { sort($list); $byRank[$rk] = $list; }

        $add = []; $refs = ['OPI' => [], 'estimated_odds' => []];
        $why = ['OPI' => null, 'estimated_odds' => null];

        // ── 表を読む ────────────────────────────────────────────────
        $load = static function (string $table, string $valueCol, string $countCol)
                use ($check) {
            $rows = []; $win = null; $bad = null; $at = null;
            foreach (\DB::table($table)->get() as $r) {
                [$ok, $reason, $cAt] = $check($r->end_date ?? null, $r->computed_at ?? null);
                if (!$ok) { if ($bad === null) { $bad = $reason; } continue; }
                $rk = (int) ($r->popularity_rank ?? 0);
                if ($rk <= 0) { continue; }
                $rows[$rk] = $r;
                if ($at === null || ($cAt !== null && strcmp($cAt, (string) $at) > 0)) {
                    $at = $cAt;
                }
                if ($win === null) {
                    $win = ['start' => substr((string) ($r->start_date ?? ''), 0, 10),
                            'end'   => substr((string) ($r->end_date ?? ''), 0, 10)];
                }
            }
            return ['rows' => $rows, 'window' => $win, 'bad' => $bad, 'computed_at' => $at];
        };

        $popAvg  = $load('t_horse_odds_finder_popularity_rank_average', 'odds_average', 'count');
        $fukuAvg = $load('t_horse_odds_finder_fuku_popularity_rank_average', 'odds_average', 'count');
        $corr    = $load('t_horse_odds_finder_compute_odds_correction', 'avg_correction_ratio', 'sample_count');

        // ══════════════════════════════════════════════════════════════
        // @ANCHOR-20261020-R122-REALTIME  10月20日006のご指摘4-1（本物の不具合）
        // ══════════════════════════════════════════════════════════════
        //   【旧】算出時刻の無い表には $readAt（＝情報上限、無ければ現在時刻）を
        //     observed_at / available_at として入れていました。
        //     これは<b>真正な取得時刻の記録ではありません。</b>
        //     「無い時刻は作らない」と書きながら、作っていました。
        //     集計期間の終わりが開催日より前でも、その版を上限前に
        //     利用できた証拠にはなりません。
        //   【いま】算出時刻の列が無い表は使いません。理由を付けて外します。
        //     列が入れば（取得・算出側で記録すれば）その日から使えます。
        $nowAt = BaganrikiPrompt::rfc3339(BaganrikiWorker::nowUs());

        $put = static function (array &$add, string $ref, $value, string $field,
                                string $unit, array $applicable, string $at,
                                array $parents = [], ?string $formula = null)
                use ($raceId) {
            $derived = ($parents !== []);
            $add[$ref] = [
                'source_ref'           => $ref,
                'race_id'              => $raceId,
                'value'                => $value,
                'scope'                => ($applicable === []) ? 'RACE' : 'COHORT',
                'horse_nos'            => [],
                'applicable_horse_nos' => $applicable,
                'field'                => $field,
                'unit'                 => $unit,
                'slot_offset'          => null,
                'observed_at'          => $at,
                'available_at'         => $at,
                'computed_at'          => $derived ? $at : null,
                'source_kind'          => $derived ? 'DERIVED' : 'OBSERVED',
                'parents'              => $parents,
                'formula_id'           => $derived ? $formula : null,
                'formula_version'      => $derived ? 'v1' : null,
                'dependency_key'       => $field,
                'dependency_role'      => 'CONTEXT',
            ];
        };

        // @ANCHOR-20261020-R122-REALTIME  算出時刻が無い表は使いません
        $noTime = [];
        foreach ([['popavg', $popAvg], ['fukuavg', $fukuAvg], ['corr', $corr]] as $pair) {
            [$tag, $t] = $pair;
            if ($t['rows'] !== [] && $t['computed_at'] === null) {
                $noTime[$tag] = true;
                $t['rows'] = [];                 // 使いません
                if ($tag === 'popavg')  { $popAvg['rows']  = []; }
                if ($tag === 'fukuavg') { $fukuAvg['rows'] = []; }
                if ($tag === 'corr')    { $corr['rows']    = []; }
            }
        }

        // ── ① 集計の窓（レース単位で1組ずつ）───────────────────────
        foreach ([['popavg', $popAvg], ['fukuavg', $fukuAvg], ['corr', $corr]] as $pair) {
            [$tag, $t] = $pair;
            if ($t['window'] === null || $t['rows'] === []) { continue; }
            $at = $t['computed_at'];
            foreach (['start_date' => $t['window']['start'],
                      'end_date'   => $t['window']['end']] as $f => $v) {
                if ($v === '') { continue; }
                $ref = $tag . '_' . $f;
                $put($add, $ref, $v, $tag . '_' . $f, 'date', [], $at);
                $refs[($tag === 'corr') ? 'estimated_odds' : 'OPI'][] = $ref;
            }
        }

        // ── ② 人気順位ごとの集計（その順位の馬にだけ当てはまります）───
        foreach ($byRank as $rk => $list) {
            $at1 = $popAvg['computed_at'];
            if (isset($popAvg['rows'][$rk])) {
                $r = $popAvg['rows'][$rk];
                $v = self::r122DecOrNull($r->odds_average ?? null);
                if ($v !== null) {
                    $ref = 'popavg_rank' . $rk . '_win_odds';
                    $put($add, $ref, $v, 'popavg_win_odds', 'odds', $list, $at1);
                    $refs['OPI'][] = $ref;
                }
                $n = self::r122IntOrNull($r->count ?? null);
                if ($n !== null) {
                    $ref = 'popavg_rank' . $rk . '_count';
                    $put($add, $ref, $n, 'popavg_count', 'races', $list, $at1);
                    $refs['OPI'][] = $ref;
                }
            }
            $at2 = $fukuAvg['computed_at'];
            if (isset($fukuAvg['rows'][$rk])) {
                $r = $fukuAvg['rows'][$rk];
                $v = self::r122DecOrNull($r->odds_average ?? null);
                if ($v !== null) {
                    $ref = 'fukuavg_rank' . $rk . '_place_min';
                    $put($add, $ref, $v, 'fukuavg_place_min', 'odds', $list, $at2);
                    $refs['OPI'][] = $ref;
                }
                $n = self::r122IntOrNull($r->count ?? null);
                if ($n !== null) {
                    $ref = 'fukuavg_rank' . $rk . '_count';
                    $put($add, $ref, $n, 'fukuavg_count', 'races', $list, $at2);
                    $refs['OPI'][] = $ref;
                }
            }
            $at3 = $corr['computed_at'];
            if (isset($corr['rows'][$rk])) {
                $r = $corr['rows'][$rk];
                foreach (['avg_correction_ratio' => 'ratio',
                          'std_correction_ratio' => 'ratio'] as $f => $unit) {
                    $v = self::r122DecOrNull($r->{$f} ?? null);
                    if ($v === null) { continue; }
                    $ref = 'corr_rank' . $rk . '_' . $f;
                    $put($add, $ref, $v, 'corr_' . $f, $unit, $list, $at3);
                    $refs['estimated_odds'][] = $ref;
                }
                $n = self::r122IntOrNull($r->sample_count ?? null);
                if ($n !== null) {
                    $ref = 'corr_rank' . $rk . '_sample_count';
                    $put($add, $ref, $n, 'corr_sample_count', 'races', $list, $at3);
                    $refs['estimated_odds'][] = $ref;
                }
            }
        }

        // ── ③ 馬ごとの値（式はいまの商品と同じ）─────────────────────
        // ══════════════════════════════════════════════════════════════
        // @ANCHOR-20261020-R122-DERIVEDAT  10月20日006のご指摘4-2（本物の不具合）
        // ══════════════════════════════════════════════════════════════
        //   【旧】observed_at / available_at / computed_at の3つに
        //     <b>同じ値（集計の算出時刻）</b>を入れていました。
        //     推定確定オッズは「今回の6分前オッズ × 補正係数」なのに、
        //     係数が前夜算出なら「今回のオッズを使った値が前夜に
        //     利用可能だった」という時刻関係になります。
        //   【いま】3つを分けます。
        //     observed_at / available_at … <b>親のうちいちばん遅い時刻</b>
        //       （親より過去へ戻しません）
        //     computed_at               … この値を実際に計算した時刻
        $later = static function (?string $a, ?string $b): ?string {
            if ($a === null) { return $b; }
            if ($b === null) { return $a; }
            $ua = BaganrikiTime::us($a); $ub = BaganrikiTime::us($b);
            if ($ua === null) { return $b; }
            if ($ub === null) { return $a; }
            return ($ub > $ua) ? $b : $a;
        };
        $putHorse = static function (array &$add, int $no, string $field, $value,
                                     string $unit, array $parents, string $formula,
                                     string $availAt, string $computedAt) use ($raceId) {
            $ref = 'h' . $no . '_' . $field;
            $add[$ref] = [
                'source_ref'           => $ref,
                'race_id'              => $raceId,
                'value'                => $value,
                'scope'                => 'HORSE',
                'horse_nos'            => [$no],
                'applicable_horse_nos' => [],
                'field'                => $field,
                'unit'                 => $unit,
                'slot_offset'          => 6,
                'observed_at'          => $availAt,
                'available_at'         => $availAt,
                'computed_at'          => $computedAt,
                'source_kind'          => 'DERIVED',
                'parents'              => $parents,
                'formula_id'           => $formula,
                'formula_version'      => 'v1',
                'dependency_key'       => 'h' . $no . '_' . $field,
                'dependency_role'      => 'CONTEXT',
            ];
            return $ref;
        };

        foreach ($frozenRank as $no => $rk) {
            $no = (int) $no; $rk = (int) $rk;
            // 6分前オッズが使えるようになった時刻（親のひとつ）
            $odds6At = ($freezeAt !== null) ? $freezeAt : $nowAt;
            $win6  = self::r122DecOrNull($cells[$no][6]['win_odds']  ?? null);
            $fuku6 = self::r122DecOrNull($cells[$no][6]['place_min'] ?? null);
            $pa = isset($popAvg['rows'][$rk])
                ? self::r122DecOrNull($popAvg['rows'][$rk]->odds_average ?? null) : null;
            $fa = isset($fukuAvg['rows'][$rk])
                ? self::r122DecOrNull($fukuAvg['rows'][$rk]->odds_average ?? null) : null;
            $cr = isset($corr['rows'][$rk])
                ? self::r122DecOrNull($corr['rows'][$rk]->avg_correction_ratio ?? null) : null;

            // OPI = 過去平均単勝 ÷ 6分前単勝
            if ($pa !== null && $win6 !== null && $win6 > 0) {
                $refs['OPI'][] = $putHorse($add, $no, 'opi',
                    round($pa / $win6, 2), 'ratio',
                    ['popavg_rank' . $rk . '_win_odds', 'h' . $no . '_win_odds_6'],
                    'OPI_AVG_WIN_DIV_WIN6',
                    $later($popAvg['computed_at'], $odds6At), $nowAt);
            }
            // 複勝OPI = 過去平均複勝最小 ÷ 6分前複勝最小
            if ($fa !== null && $fuku6 !== null && $fuku6 > 0) {
                $refs['OPI'][] = $putHorse($add, $no, 'fuku_opi',
                    round($fa / $fuku6, 2), 'ratio',
                    ['fukuavg_rank' . $rk . '_place_min', 'h' . $no . '_place_min_6'],
                    'FUKU_OPI_AVG_PLACE_DIV_PLACE6',
                    $later($fukuAvg['computed_at'], $odds6At), $nowAt);
            }
            // 推定確定オッズ = 6分前単勝 × 補正係数
            $est = null;
            if ($cr !== null && $win6 !== null && $win6 > 0) {
                $est = round($win6 * $cr, 2);
                $refs['estimated_odds'][] = $putHorse($add, $no, 'estimated_final_odds',
                    $est, 'odds',
                    ['corr_rank' . $rk . '_avg_correction_ratio', 'h' . $no . '_win_odds_6'],
                    'EST_FINAL_ODDS_WIN6_X_RATIO',
                    $later($corr['computed_at'], $odds6At), $nowAt);
            }
            // 推定確定複勝最小（複勝専用の係数は未実装なので単勝の係数を流用）
            if ($cr !== null && $fuku6 !== null && $fuku6 > 0) {
                $refs['estimated_odds'][] = $putHorse($add, $no, 'estimated_final_place_min',
                    round($fuku6 * $cr, 2), 'odds',
                    ['corr_rank' . $rk . '_avg_correction_ratio', 'h' . $no . '_place_min_6'],
                    'EST_FINAL_PLACE_MIN_PLACE6_X_WIN_RATIO',
                    $later($corr['computed_at'], $odds6At), $nowAt);
            }
            // 予測補正OPI = 過去平均単勝 ÷ 推定確定オッズ
            if ($pa !== null && $est !== null && $est > 0) {
                $refs['OPI'][] = $putHorse($add, $no, 'estimated_opi',
                    round($pa / $est, 2), 'ratio',
                    ['popavg_rank' . $rk . '_win_odds', 'h' . $no . '_estimated_final_odds'],
                    'EST_OPI_AVG_WIN_DIV_EST_FINAL',
                    $later($later($popAvg['computed_at'], $corr['computed_at']), $odds6At),
                    $nowAt);
            }
        }

        $cov = [];
        foreach (['OPI' => [$popAvg, $fukuAvg], 'estimated_odds' => [$corr]] as $k => $src) {
            $list = array_values(array_unique($refs[$k]));
            sort($list, SORT_STRING);
            if ($list !== []) {
                $cov[$k] = ['status' => 'INCLUDED', 'source_refs' => $list];
                continue;
            }
            $reason = null;
            // @ANCHOR-20261020-R122-REALTIME  算出時刻が無いことを理由に出します
            $miss = [];
            foreach (($k === 'OPI' ? ['popavg', 'fukuavg'] : ['corr']) as $tg) {
                if (!empty($noTime[$tg])) { $miss[] = $tg; }
            }
            if ($miss !== []) {
                $reason = 'この集計の表に算出時刻（computed_at）の列がありません。'
                        . '情報上限より前に利用できた証拠が無いので使いません'
                        . '（該当 ' . implode('・', $miss) . '）。'
                        . '取得・算出側で算出時刻を記録すれば、その日から使えます。';
            }
            if ($reason === null) {
                foreach ($src as $t) {
                    if ($t['bad'] !== null) { $reason = $t['bad']; break; }
                }
            }
            $cov[$k] = ['status' => 'UNAVAILABLE',
                        'reason' => $reason ?? '人気順位別の集計が見つかりませんでした'];
        }
        return ['registry' => $add, 'coverage' => $cov];
    }
    /** @ANCHOR-20261020-R122-MARKET  .env で止められます（既定は載せる） */
    public static function r122MarketPriorEnabled(): bool
    {
        $v = (string) env('BAGANRIKI_MARKET_PRIOR', '1');
        return !in_array($v, ['0', 'false', 'off', 'no'], true);
    }
    /** @ANCHOR-20261020-R122-MARKET  十進数として読めるときだけ float を返します */
    public static function r122DecOrNull($v): ?float
    {
        if ($v === null) { return null; }
        $s = trim((string) $v);
        if ($s === '' || !preg_match('/^-?\d+(?:\.\d+)?$/', $s)) { return null; }
        return (float) $s;
    }
    /**
     * ═══════════════════════════════════════════════════════════════════════
     * @ANCHOR-20261020-R122-PAST  過去走を source_registry へ載せます
     * ═══════════════════════════════════════════════════════════════════════
     * 根拠：server_contract_r12.2.txt 3章・5章
     *   「past_runs は coverage で INCLUDED または理由付き UNAVAILABLE を
     *     必須記録。利用できるデータを黙って捨てない」
     *
     * ■ 正本
     *   t_horse_odds_finder_shutsuba_history（馬名で引きます）
     *   対象レースの<b>開催日より前</b>のレースだけを使います。
     *   同じ日・後の日のものは入れません（結果の先読みを防ぎます）。
     *
     * ■ 情報上限
     *   その行を<b>いつ手に入れたか</b>で切ります。
     *   created_at と updated_at の<b>遅いほう</b>を available_at とし、
     *   情報上限（入力の凍結時刻）より後のものは載せません。
     *   後から取り直した内容で過去のレースを評価しないためです。
     *
     * ■ observed_at について
     *   過去走の行には発走時刻がありません。
     *   <b>無い時刻を作らない</b>ので、observed_at には
     *   「こちらが手に入れた時刻」を入れ、
     *   そのレースの開催日は past_date として別の項目で渡します。
     *
     * ■ 1頭あたり直近5走まで（.env で変えられます）
     *   生の事実（着順・頭数・人気・距離・馬場・上がり3F・着差・開催日）と、
     *   そこから出した3つのまとめ（走数・最高着順・3着内率）を載せます。
     *
     *   BAGANRIKI_PAST_RUNS_MAX  既定 5（0〜10）。
     *   <b>0 にすると過去走を載せません。</b>
     *   送信文が長くなると応答時間も伸びます。応答期限は発走の150秒前なので、
     *   実測を見てここで絞れるようにしてあります。
     *
     * @param array $nums   馬番 => 馬名
     * @return array ['registry'=>..., 'coverage'=>['past_runs'=>...]]
     */
    public static function r122PastRunsRegistry(string $raceId, string $date,
                                                array $nums, ?string $freezeAt): array
    {
        // @ANCHOR-20261020-R122-DERIVEDAT  1回の組み立てで1つの計算時刻にします
        //   （同じ組み立ての中で時刻がばらつくと、snapshot_hash が揺れます）
        $buildAt = BaganrikiPrompt::rfc3339(BaganrikiWorker::nowUs());
        $empty = static fn(string $why) => ['registry' => [],
            'coverage' => ['past_runs' => ['status' => 'UNAVAILABLE', 'reason' => $why]]];

        if (!\Schema::hasTable('t_horse_odds_finder_shutsuba_history')) {
            return $empty('過去走の表（shutsuba_history）がありません');
        }
        $names = [];
        foreach ($nums as $no => $nm) {
            $nm = trim((string) $nm);
            if ($nm !== '') { $names[trim((string) $nm)][] = (int) $no; }
        }
        if ($names === []) {
            return $empty('出馬表に馬名がありません');
        }

        $max = self::r122PastRunsMax();
        if ($max <= 0) {
            return $empty('.env の BAGANRIKI_PAST_RUNS_MAX が 0 のため載せていません');
        }
        $freezeUs = ($freezeAt === null) ? null : BaganrikiTime::us($freezeAt);
        $add = []; $refs = []; $late = null; $used = 0;

        // 馬名ごとに、対象レースより前の開催日のものを新しい順で取ります
        $rows = \DB::table('t_horse_odds_finder_shutsuba_history')
                  ->whereIn('name', array_keys($names))
                  ->where('date', '<', $date)
                  ->orderBy('name')->orderByDesc('date')->orderBy('race')
                  ->get(['name', 'date', 'basho_code', 'race', 'grade',
                         'finishing_position', 'num_horses', 'gate', 'popularity',
                         'dist', 'time', 'condition', 'last_3f', 'fin_time_diff',
                         'created_at', 'updated_at']);

        $byName = [];
        foreach ($rows as $r) {
            $byName[(string) $r->name][] = $r;
        }

        foreach ($names as $nm => $horseNos) {
            $list = $byName[$nm] ?? [];
            if ($list === []) { continue; }
            foreach ($horseNos as $no) {
                $i = 0; $fin = []; $parents = []; $avail = null;
                foreach ($list as $r) {
                    if ($i >= $max) { break; }
                    // 手に入れた時刻（created_at と updated_at の遅いほう）
                    $cAt = self::r122DbTime($r->created_at);
                    $uAt = self::r122DbTime($r->updated_at);
                    $av  = $cAt;
                    if ($uAt !== null && ($av === null || strcmp($uAt, $av) > 0)) { $av = $uAt; }
                    if ($av === null) { continue; }
                    if ($freezeUs !== null) {
                        $au = BaganrikiTime::us($av);
                        if ($au === null || $au > $freezeUs) {
                            if ($late === null || strcmp($av, (string) $late) < 0) { $late = $av; }
                            continue;
                        }
                    }
                    $i++;
                    if ($avail === null || strcmp($av, $avail) > 0) { $avail = $av; }

                    $pdate = substr((string) $r->date, 0, 10);
                    $vals = [
                        'past_date'       => ['v' => $pdate,                        'u' => 'date'],
                        'past_finish'     => ['v' => self::r122IntOrNull($r->finishing_position), 'u' => 'rank'],
                        'past_num_horses' => ['v' => self::r122IntOrNull($r->num_horses),         'u' => 'horses'],
                        'past_popularity' => ['v' => self::r122IntOrNull($r->popularity),         'u' => 'rank'],
                        'past_dist'       => ['v' => self::r122StrOrNull($r->dist),      'u' => 'text'],
                        'past_condition'  => ['v' => self::r122StrOrNull($r->condition), 'u' => 'text'],
                        'past_last_3f'    => ['v' => self::r122StrOrNull($r->last_3f),   'u' => 'second'],
                        'past_time_diff'  => ['v' => self::r122StrOrNull($r->fin_time_diff), 'u' => 'second'],
                    ];
                    foreach ($vals as $f => $x) {
                        if ($x['v'] === null) { continue; }
                        $ref = 'h' . $no . '_' . $f . '_' . $i;
                        $add[$ref] = [
                            'source_ref'           => $ref,
                            'race_id'              => $raceId,
                            'value'                => $x['v'],
                            'scope'                => 'HORSE',
                            'horse_nos'            => [(int) $no],
                            'applicable_horse_nos' => [],
                            'field'                => $f . '_' . $i,
                            'unit'                 => $x['u'],
                            'slot_offset'          => null,
                            // 過去走の行に発走時刻はありません。
                            // 無い時刻は作らず、手に入れた時刻を入れます。
                            'observed_at'          => $av,
                            'available_at'         => $av,
                            'computed_at'          => null,
                            'source_kind'          => 'OBSERVED',
                            'parents'              => [],
                            'formula_id'           => null,
                            'formula_version'      => null,
                            'dependency_key'       => 'h' . $no . '_past_' . $i,
                            'dependency_role'      => 'CONTEXT',
                        ];
                        $refs[] = $ref;
                        $parents[] = $ref;
                    }
                    $f0 = self::r122IntOrNull($r->finishing_position);
                    if ($f0 !== null && $f0 > 0) { $fin[] = $f0; }
                }
                if ($i === 0 || $avail === null || $parents === []) { continue; }
                $used++;

                // ── まとめ（走数・最高着順・3着内率）────────────────────
                $sum = [
                    'past_runs_count' => ['v' => $i, 'u' => 'races'],
                ];
                if ($fin !== []) {
                    $top3 = 0;
                    foreach ($fin as $x) { if ($x <= 3) { $top3++; } }
                    $sum['past_best_finish'] = ['v' => min($fin), 'u' => 'rank'];
                    // 割り切れるときに整数へ落ちないよう、十進数の文字列で渡します
                    $sum['past_top3_rate'] = [
                        'v' => number_format($top3 / count($fin), 4, '.', ''),
                        'u' => 'ratio',
                    ];
                }
                foreach ($sum as $f => $x) {
                    $ref = 'h' . $no . '_' . $f;
                    $add[$ref] = [
                        'source_ref'           => $ref,
                        'race_id'              => $raceId,
                        'value'                => $x['v'],
                        'scope'                => 'HORSE',
                        'horse_nos'            => [(int) $no],
                        'applicable_horse_nos' => [],
                        'field'                => $f,
                        'unit'                 => $x['u'],
                        'slot_offset'          => null,
                        'observed_at'          => $avail,
                        'available_at'         => $avail,
                        // @ANCHOR-20261020-R122-DERIVEDAT  006のご指摘4-2
                        //   【旧】今回まとめた値なのに、過去走を手に入れた時刻を
                        //     computed_at に入れていました。実際の計算時刻ではありません。
                        'computed_at'          => $buildAt,
                        'source_kind'          => 'DERIVED',
                        'parents'              => array_values(array_unique($parents)),
                        'formula_id'           => 'PAST_RUNS_SUMMARY',
                        'formula_version'      => 'v1',
                        'dependency_key'       => 'h' . $no . '_past_summary',
                        'dependency_role'      => 'CONTEXT',
                    ];
                    $refs[] = $ref;
                }
            }
        }

        if ($refs === []) {
            $why = '対象レースより前の過去走が見つかりませんでした';
            if ($late !== null) {
                $why = '過去走は情報上限より後に手に入れたものしかありません'
                     . '（いちばん早い取得時刻 ' . $late
                     . '／情報上限 ' . ($freezeAt ?? '不明') . '）。'
                     . '後から取り直した内容で過去のレースを評価しないためです。';
            }
            return $empty($why);
        }
        $refs = array_values(array_unique($refs));
        sort($refs, SORT_STRING);
        return [
            'registry' => $add,
            'coverage' => ['past_runs' => ['status' => 'INCLUDED', 'source_refs' => $refs]],
            'horses_with_past' => $used,
        ];
    }
    /**
     * @ANCHOR-20261020-R122-PAST  1頭あたり何走まで載せるか
     *   既定5。0 で載せません。10 を超える指定は10に丸めます。
     *   送信文の長さと応答時間の兼ね合いで絞れるようにしています。
     */
    public static function r122PastRunsMax(): int
    {
        $v = env('BAGANRIKI_PAST_RUNS_MAX', null);
        if ($v === null || !is_numeric((string) $v)) { return 5; }
        $n = (int) $v;
        if ($n < 0)  { return 0; }
        if ($n > 10) { return 10; }
        return $n;
    }
    /** @ANCHOR-20261020-R122-PAST  整数として読めるときだけ整数を返します */
    public static function r122IntOrNull($v): ?int
    {
        if ($v === null) { return null; }
        $s = trim((string) $v);
        if ($s === '' || !preg_match('/^-?\d+$/', $s)) { return null; }
        return (int) $s;
    }
    /** @ANCHOR-20261020-R122-PAST  空でない文字列のときだけ返します */
    public static function r122StrOrNull($v): ?string
    {
        if ($v === null) { return null; }
        $s = trim((string) $v);
        return ($s === '') ? null : $s;
    }
    /**
     * @ANCHOR-20261020-R122-COVERAGE  DBの日時をRFC3339（JST）へ
     *
     * ══════════════════════════════════════════════════════════════
     * @ANCHOR-20261020-R122-MICRO  10月20日006のご指摘4-3（本物の不具合）
     * ══════════════════════════════════════════════════════════════
     *   【旧】strtotime は<b>秒の整数</b>しか返しません。
     *     それに1,000,000を掛けていたので、
     *     `09:34:30.000001` が `09:34:30` へ切り捨てられ、
     *     情報上限 `09:34:30` を<b>超えているのに上限内として通り得ました。</b>
     *     取得側の r122DbRfc3339 は小数秒を保っていたのに、
     *     追加材料側のこの関数だけが落としていました。
     *   【いま】小数秒を取り出して、マイクロ秒まで保ちます。
     *     保存タイムゾーンは日本時間（DBのDATETIMEはJSTで入っています）。
     */
    public static function r122DbTime($v): ?string
    {
        if ($v === null) { return null; }
        $s = trim((string) $v);
        if ($s === '' || strncmp($s, '0000', 4) === 0) { return null; }
        // DBの DATETIME / DATE をそのまま読みます（区切りは空白でもTでも可）
        $re = '/^(\d{4})-(\d{2})-(\d{2})'
            . '(?:[ T](\d{2}):(\d{2}):(\d{2})(?:\.(\d{1,6})\d*)?)?$/';
        if (preg_match($re, $s, $m) !== 1) { return null; }
        $frac = isset($m[7]) ? (int) str_pad($m[7], 6, '0') : 0;
        $d = \DateTimeImmutable::createFromFormat(
            'Y-m-d H:i:s',
            $m[1] . '-' . $m[2] . '-' . $m[3] . ' '
            . ($m[4] ?? '00') . ':' . ($m[5] ?? '00') . ':' . ($m[6] ?? '00'),
            new \DateTimeZone(self::DB_TIMEZONE));
        if ($d === false) { return null; }
        // 繰上がり（2026-02-30 など）を受け取りません
        if ($d->format('Y-m-d') !== $m[1] . '-' . $m[2] . '-' . $m[3]) { return null; }
        return BaganrikiPrompt::rfc3339($d->getTimestamp() * 1000000 + $frac);
    }
    /** @ANCHOR-20261020-R122-COVERAGE  帯の名前を source_ref に使える形へ */
    public static function r122Slug(string $s): string
    {
        $map = ['30%以上下落' => 'dn30', '20〜30%下落' => 'dn20', '10〜20%下落' => 'dn10',
                '5〜10%下落' => 'dn05', '±5%以内' => 'flat', '5〜10%上昇' => 'up05',
                '10〜20%上昇' => 'up10', '20〜30%上昇' => 'up20', '30%以上上昇' => 'up30'];
        if (isset($map[$s])) return $map[$s];
        $h = substr(hash('sha256', $s), 0, 8);
        return 'band' . $h;
    }
    /**
     * ═══════════════════════════════════════════════════════════════════════
     * @ANCHOR-20261020-R122-COVERAGE  オッズ以外の材料を source_registry へ載せる
     * ═══════════════════════════════════════════════════════════════════════
     * 根拠：server_contract_r12.2.txt 3章「利用できるデータを黙って捨てない」
     *       10月20日004 のご判断2（A案）／21_追加材料7区分の接続表
     *
     * ■ 今回つなぐ3区分
     *   gap_history          断層（21→6分前の単勝の増減率）
     *   recovery_statistics  その増減率帯と人気帯の回収率
     *   similar_statistics   人気順位×頭数帯の過去類似成績
     *
     *   この3つを先につなぐ理由は、<b>算出時刻の列を持っているから</b>です。
     *   過去走とOPIは取得・算出時刻の列が無いので、時刻の出どころが決まるまで
     *   載せません（接続表のA/B/Cのご判断待ち）。作り話の時刻で埋めません。
     *
     * ■ 由来の残し方
     *   ・1頭ごとの増減率は <b>DERIVED</b> にし、
     *     parents にその馬の21分前と6分前の登録IDをそのまま入れます。
     *     どの元値から出したかが1件ずつ辿れます。
     *   ・帯別の統計は <b>DERIVED</b> で、parents には集計元のテーブル名を入れます。
     *     元になった18万行の履歴は入力に載せないので、個々の行IDではなく
     *     テーブル名を由来として書きます。ここは正直に書いておきます。
     *   ・computed_at は、集計テーブルが持っている実際の算出時刻です。
     *
     * ■ 情報上限
     *   増減率は21分前と6分前の値だけから出します。3分前・発走時は使いません。
     *   帯別統計の computed_at が input_freeze_at より後なら載せません。
     *
     * @param array $ctx        これまでに組み立てた文脈（registry・audit を含む）
     * @param array $frozenRank 馬番 => 凍結人気
     * @param array $cells      [馬番][スロット][項目] => 元の十進数文字列
     * @param int   $freezeUs   情報上限（マイクロ秒）
     * @return array ['registry'=>追加分, 'coverage'=>区分ごとの状態]
     */
    public static function r122ExtraRegistry(array $ctx, array $frozenRank,
                                             array $cells, ?int $freezeUs): array
    {
        // @ANCHOR-20261020-R122-DERIVEDAT  1回の組み立てで1つの計算時刻にします
        $buildAt = BaganrikiPrompt::rfc3339(BaganrikiWorker::nowUs());
        $raceId = (string) ($ctx['race_id'] ?? '');
        $add    = [];
        $refs   = ['gap_history' => [], 'recovery_statistics' => [],
                   'similar_statistics' => []];
        // @ANCHOR-20261020-R122-COVERAGE  載せなかった理由を取り違えないための控え
        //   「集計が無い」と「情報上限より後に算出された」は別の話です。
        $late   = ['recovery_statistics' => null, 'similar_statistics' => null];
        // @ANCHOR-20261020-R122-COVWIN  集計期間が対象レースの開催日を含んでいた控え
        //   OPI・推定確定オッズと同じ判定を、列を持っている回収率にも当てます。
        //   （過去類似成績の表には集計期間の列がありません。無い列は作りません）
        $covWin = ['recovery_statistics' => null];
        $freezeAt = ($freezeUs === null) ? null : BaganrikiPrompt::rfc3339($freezeUs);
        $N      = count($frozenRank);
        if ($N < 1) {
            return ['registry' => [], 'coverage' => []];
        }
        // @ANCHOR-20261020-R122-COVWIN  対象レースの開催日（race_id の先頭8桁）
        $day = '';
        if (preg_match('/^(\d{4})(\d{2})(\d{2})-/', $raceId, $mm) === 1) {
            $day = $mm[1] . '-' . $mm[2] . '-' . $mm[3];
        }
        $audit6 = $ctx['audit']['6'] ?? ($ctx['audit'][6] ?? null);
        $obs6   = is_array($audit6) ? ($audit6['response_received_at'] ?? null) : null;
        $av6    = is_array($audit6) ? ($audit6['available_at'] ?? null) : null;
        if ($obs6 === null || $av6 === null) {
            return ['registry' => [], 'coverage' => []];
        }

        // ── ① 1頭ごとの増減率（21分前 → 6分前の単勝）──────────────────
        $gapPct = [];
        foreach (array_keys($frozenRank) as $no) {
            $o21 = $cells[$no][21]['win_odds'] ?? null;
            $o6  = $cells[$no][6]['win_odds']  ?? null;
            if ($o21 === null || $o6 === null) continue;
            // @ANCHOR-20261020-R122-DEC  小数5桁以上でも落としません
            //   【旧】BaganrikiSnapshot::scale は小数4桁までで、
            //     1.23456 のオッズだと増減率を作れずに捨てていました。
            $a = AiController::r122DecOrNull($o21);
            $b = AiController::r122DecOrNull($o6);
            if ($a === null || $b === null || $a <= 0) continue;
            $pct = round((($b - $a) / $a) * 100, 4);
            $gapPct[$no] = $pct;
            $ref = 'h' . $no . '_odds_gap_pct_21_6';
            $add[$ref] = [
                'source_ref'           => $ref,
                'race_id'              => $raceId,
                'value'                => $pct,
                'scope'                => 'HORSE',
                'horse_nos'            => [(int) $no],
                'applicable_horse_nos' => [],
                'field'                => 'odds_gap_pct_21_6',
                'unit'                 => 'percent',
                'slot_offset'          => 6,
                'observed_at'          => $obs6,
                'available_at'         => $av6,
                // @ANCHOR-20261020-R122-DERIVEDAT  006のご指摘4-2
                //   【旧】今回こちらで出した増減率なのに、原オッズの
                //     利用可能時刻を computed_at に入れていました。
                'computed_at'          => $buildAt,
                'source_kind'          => 'DERIVED',
                'parents'              => ['h' . $no . '_win_odds_21', 'h' . $no . '_win_odds_6'],
                'formula_id'           => 'ODDS_GAP_PCT_21_TO_6',
                'formula_version'      => 'v1',
                'dependency_key'       => 'h' . $no . '_odds_gap_pct',
                'dependency_role'      => 'CONTEXT',
            ];
            $refs['gap_history'][] = $ref;
        }

        // ── ② 増減率帯 × 人気帯 の回収率 ────────────────────────────────
        if ($gapPct !== [] && \Schema::hasTable('t_horse_odds_finder_odds_gap_recovery')) {
            foreach (\DB::table('t_horse_odds_finder_odds_gap_recovery')->get() as $r) {
                $gmin = (float) $r->gap_min; $gmax = (float) $r->gap_max;
                $pmin = (int) $r->popularity_min; $pmax = (int) $r->popularity_max;
                $hit = [];
                foreach ($gapPct as $no => $pct) {
                    $pop = (int) $frozenRank[$no];
                    if ($pct < $gmin || $pct > $gmax) continue;
                    if ($pop < $pmin || $pop > $pmax) continue;
                    $hit[] = (int) $no;
                }
                if ($hit === []) continue;
                sort($hit);
                // @ANCHOR-20261020-R122-COVWIN  当日を含む集計でその日のレースを評価しない
                //   この表は start_date / end_date を持っているので、
                //   OPI・推定確定オッズとまったく同じ判定を当てます。
                $ed = substr(str_replace('/', '-', (string) ($r->end_date ?? '')), 0, 10);
                if ($day !== '' && $ed !== '' && strcmp($ed, $day) >= 0) {
                    if ($covWin['recovery_statistics'] === null) {
                        $covWin['recovery_statistics'] = $ed;
                    }
                    continue;
                }
                $c = self::r122DbTime($r->computed_at);
                if ($c === null) continue;
                if ($freezeUs !== null) {
                    $cu = BaganrikiTime::us($c);
                    if ($cu === null || $cu > $freezeUs) {
                        // 情報上限より後に算出された集計は載せません。
                        // 「集計が無い」のではないので、理由を分けて残します。
                        if ($late['recovery_statistics'] === null
                            || strcmp($c, (string) $late['recovery_statistics']) < 0) {
                            $late['recovery_statistics'] = $c;
                        }
                        continue;
                    }
                }
                // @ANCHOR-20261020-R122-COVWIN  使った集計の期間も残します（OPIと同じ）
                $sd = substr(str_replace('/', '-', (string) ($r->start_date ?? '')), 0, 10);
                foreach (['start_date' => $sd, 'end_date' => $ed] as $wf => $wv) {
                    if ($wv === '') { continue; }
                    $wref = 'gaprec_' . $wf;
                    if (isset($add[$wref])) { continue; }
                    $add[$wref] = [
                        'source_ref'           => $wref,
                        'race_id'              => $raceId,
                        'value'                => $wv,
                        'scope'                => 'RACE',
                        'horse_nos'            => [],
                        'applicable_horse_nos' => [],
                        'field'                => 'gaprec_' . $wf,
                        'unit'                 => 'date',
                        'slot_offset'          => null,
                        'observed_at'          => $c,
                        'available_at'         => $c,
                        'computed_at'          => null,
                        'source_kind'          => 'OBSERVED',
                        'parents'              => [],
                        'formula_id'           => null,
                        'formula_version'      => null,
                        'dependency_key'       => 'gaprec_' . $wf,
                        'dependency_role'      => 'CONTEXT',
                    ];
                    $refs['recovery_statistics'][] = $wref;
                }
                $key = self::r122Slug((string) $r->gap_band) . '_' . $pmin . '_' . $pmax;
                foreach (['recovery_rate' => 'percent', 'win_rate' => 'percent',
                          'sample_count'  => 'races'] as $f => $unit) {
                    $v = $r->{$f};
                    if ($v === null) continue;
                    $ref = 'gaprec_' . $key . '_' . $f;
                    $add[$ref] = [
                        'source_ref'           => $ref,
                        'race_id'              => $raceId,
                        'value'                => ($f === 'sample_count') ? (int) $v : (float) $v,
                        'scope'                => 'COHORT',
                        'horse_nos'            => [],
                        'applicable_horse_nos' => $hit,
                        'field'                => 'gap_recovery_' . $f,
                        'unit'                 => $unit,
                        'slot_offset'          => null,
                        'observed_at'          => $c,
                        'available_at'         => $c,
                        'computed_at'          => $c,
                        'source_kind'          => 'DERIVED',
                        'parents'              => ['t_horse_odds_finder_race_result_history'],
                        'formula_id'           => 'SummaryOddsGapRecoveryRate',
                        'formula_version'      => 'v1',
                        'dependency_key'       => 'gaprec_' . $key,
                        'dependency_role'      => 'CONTEXT',
                    ];
                    $refs['recovery_statistics'][] = $ref;
                }
            }
        }

        // ── ③ 人気順位 × 頭数帯 の過去類似成績 ──────────────────────────
        //   頭数帯は small=8以下／medium=9〜13／large=14以上
        if (\Schema::hasTable('t_horse_odds_finder_similar_race_stats')) {
            $band = ($N <= 8) ? 'small' : (($N <= 13) ? 'medium' : 'large');
            foreach (\DB::table('t_horse_odds_finder_similar_race_stats')
                        ->where('horse_count_band', $band)->get() as $r) {
                $pop = (int) $r->popularity_rank;
                $hit = [];
                foreach ($frozenRank as $no => $p) {
                    if ((int) $p === $pop) $hit[] = (int) $no;
                }
                if ($hit === []) continue;
                sort($hit);
                $c = self::r122DbTime($r->updated_at);
                if ($c === null) continue;
                if ($freezeUs !== null) {
                    $cu = BaganrikiTime::us($c);
                    if ($cu === null || $cu > $freezeUs) {
                        if ($late['similar_statistics'] === null
                            || strcmp($c, (string) $late['similar_statistics']) < 0) {
                            $late['similar_statistics'] = $c;
                        }
                        continue;
                    }
                }
                foreach (['top3_rate' => 'rate', 'top5_rate' => 'rate',
                          'avg_finishing_position' => 'position',
                          'outside_rate' => 'rate', 'sample_count' => 'races',
                          'reliability' => 'label'] as $f => $unit) {
                    $v = $r->{$f};
                    if ($v === null) continue;
                    $ref = 'similar_' . $band . '_p' . $pop . '_' . $f;
                    $val = ($f === 'sample_count') ? (int) $v
                         : (($f === 'reliability') ? (string) $v : (float) $v);
                    $add[$ref] = [
                        'source_ref'           => $ref,
                        'race_id'              => $raceId,
                        'value'                => $val,
                        'scope'                => 'COHORT',
                        'horse_nos'            => [],
                        'applicable_horse_nos' => $hit,
                        'field'                => 'similar_' . $f,
                        'unit'                 => $unit,
                        'slot_offset'          => null,
                        'observed_at'          => $c,
                        'available_at'         => $c,
                        'computed_at'          => $c,
                        'source_kind'          => 'DERIVED',
                        'parents'              => ['t_horse_odds_finder_race_result_history'],
                        'formula_id'           => 'SummarySimilarRaceStats',
                        'formula_version'      => 'v1',
                        'dependency_key'       => 'similar_' . $band . '_p' . $pop,
                        'dependency_role'      => 'CONTEXT',
                    ];
                    $refs['similar_statistics'][] = $ref;
                }
            }
        }

        // ── coverage ──────────────────────────────────────────────────
        $cov = [];
        $why = [
            'gap_history'         => '21→6分前の単勝の増減率を1頭ずつ出せませんでした',
            'recovery_statistics' => '当てはまる増減率帯・人気帯の集計がありませんでした',
            'similar_statistics'  => 'この頭数帯・人気順位の集計がありませんでした',
        ];
        foreach ($refs as $k => $list) {
            $list = array_values(array_unique($list));
            sort($list, SORT_STRING);
            if ($list !== []) {
                $cov[$k] = ['status' => 'INCLUDED', 'source_refs' => $list];
                continue;
            }
            // 「集計が無い」のか「情報上限より後に算出された」のか
            // 「当日を含む集計だった」のかを分けます。
            $reason = $why[$k];
            if (!empty($covWin[$k])) {
                $reason = '集計期間の終わり（' . $covWin[$k] . '）が対象レースの開催日（'
                        . $day . '）以降です。当日を含む集計で'
                        . 'その日のレースを評価しないためです。';
            } elseif (!empty($late[$k])) {
                $reason = 'この集計は情報上限より後に算出されたものしかありません'
                        . '（いちばん早い算出時刻 ' . $late[$k]
                        . '／情報上限 ' . ($freezeAt ?? '不明') . '）。'
                        . '過去のレースを後から作った集計で評価しないためです。';
            }
            $cov[$k] = ['status' => 'UNAVAILABLE', 'reason' => $reason];
        }
        return ['registry' => $add, 'coverage' => $cov];
    }
    /**
     * @ANCHOR-20261020-R122-PROMPT  十進数の文字列を JSON の数値へ
     *   「2.1」→ 2.1、「11」→ 11。桁を増やしたり減らしたりしません。
     *   読めないものは文字列のまま返します（作り話をしないため）。
     */
    public static function r122NumValue(string $s)
    {
        // @ANCHOR-20261020-R122-DIGITS  10月20日005のご指摘7-1
        //   契約9章は「整数・小数は最大128桁」です。
        //   【旧】'/^\d+(?:\.\d{1,4})?$/' … 小数4桁より下を黙って捨てていました。
        if (!preg_match('/^\d{1,128}(?:\.\d{1,128})?$/', $s)) return $s;
        if (strpos($s, '.') === false) {
            // PHPの整数で正確に表せる範囲だけ数値にします。
            // 超えるものは文字列のまま返し、呼び出し側が登録しません。
            return (strlen(ltrim($s, '0')) <= 18) ? (int) $s : $s;
        }
        // 小数は「floatにして文字列へ戻すと元と一致する」ものだけ数値にします。
        // 一致しないものは丸めが起きているので、数値にしません。
        //   PHPの (string)(float) は、元へ戻せる最短の表記を返します
        //   （serialize_precision=-1）。sprintf('%.17F') は
        //   2.1 を '2.10000000000000009' にしてしまうので使いません。
        $norm = rtrim(rtrim($s, '0'), '.');
        if ($norm === '') { $norm = '0'; }
        $back = (string) (float) $s;
        return ($back === $norm) ? (float) $s : $s;
    }
}
