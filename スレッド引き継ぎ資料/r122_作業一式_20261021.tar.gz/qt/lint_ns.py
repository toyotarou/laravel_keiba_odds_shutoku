# -*- coding: utf-8 -*-
"""
Command（App\\Console\\Commands）の中から、別の名前空間のクラスを
完全修飾せずに呼んでいないかを見ます。
同じ誤りを3回出したので、作るたびに機械で見ます。
  ・Baganriki* は AiController.php（App\\Http\\Controllers\\Api）にあります
  ・AiController だけは Command の先頭で use 済みなので、素のままで通ります
  ・self:: は Command 自身を指すので、AiController の静的メソッドには使えません
"""
import io, re, sys

p = sys.argv[1]
s = io.open(p, encoding='utf-8').read()
lines = s.split('\n')
bad = []
for i, l in enumerate(lines, 1):
    code = l.split('//')[0]
    if code.lstrip().startswith('*'):
        continue
    # 文字列の中（表示用の説明文）は見ません
    nostr = re.sub(r"'[^']*'", "''", code)
    nostr = re.sub(r'"[^"]*"', '""', nostr)
    for m in re.finditer(r'(?<![\\\w])(Baganriki\w+)::', nostr):
        bad.append((i, m.group(1), l.strip()[:70]))
    for m in re.finditer(r'self::(r122RaceId|r122GatherContext|r122Freeze)\b', code):
        bad.append((i, 'self::' + m.group(1), l.strip()[:70]))

if bad:
    print('× 完全修飾されていない呼び出しが %d 件あります' % len(bad))
    for b in bad:
        print('   %d: %s  | %s' % b)
    sys.exit(1)
print('○ 別の名前空間のクラスは、すべて完全修飾されています')
