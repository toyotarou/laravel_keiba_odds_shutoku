<?php

/**
 * ═══════════════════════════════════════════════════════════════════════════
 * @ANCHOR-20261020-R122-QUEUE  永続ワーカー（キューと予約枠）
 * ═══════════════════════════════════════════════════════════════════════════
 * 根拠：server_contract_r12.2.txt 10章・11章／詳細設計書 12章
 *
 * ■ 守ること
 *   ・1レース・1世代・1roleにつき枠は2つだけ（初回=0／訂正=1）
 *   ・予約を確定してから送る。初回の原応答と complete を保存してから訂正に入る
 *   ・予約済みの枠は、重複キュー・期限切れ・再起動のどれでも作り直さない
 *   ・初回が未受領・FAILED・結果不明なら訂正を予約しない
 *   ・送信許可1回につき callback は1回だけ（自動再試行は0）
 *   ・同じ token に同じ応答を保存するのは冪等。別の応答や終端の付け替えは拒否
 *   ・complete=false の本文は、そのまま残して選出には使わない
 *   ・response_revision は「予約の回数＋終端が変わった回数」の合計
 *
 * ■ 枠の状態
 *   RESERVED       枠を取った（まだ送っていない）
 *   SENT           送った（返りを待っている）
 *   RECEIVED       受け取って保存した
 *   FAILED         失敗（終端）
 *   UNKNOWN_RESULT 結果が分からない（終端・再送しない）
 *
 * ■ 再起動したとき
 *   RESERVED は枠として残します（まだ送っていないので送信許可が1回残る）。
 *   SENT は UNKNOWN_RESULT にします。受領していても未commitの応答は
 *   復元できないことがあるので、結果不明として明示し、再送を止めます。
 *
 * 外部APIとの分散取引や Exactly Once は保証しません。
 */
final class BaganrikiWorker
{
    public const FIRST = 0;        // 初回
    public const FIX   = 1;        // 訂正
    public const MAX_PER_ROLE = 2; // 枠は2つだけ

    public const RESERVED = 'RESERVED';
    public const SENT     = 'SENT';
    public const RECEIVED = 'RECEIVED';
    public const FAILED   = 'FAILED';
    public const UNKNOWN  = 'UNKNOWN_RESULT';

    /** 終端（もう動かさない状態） */
    public const TERMINAL = [self::RECEIVED, self::FAILED, self::UNKNOWN];

    private const US = 1000000;

    /**
     * @ANCHOR-20261020-R122-SHADOW  .env の BAGANRIKI_R122_QUEUE は3つの値を取ります
     *   0       … 何もしません（既定）。送信口を素通りします。
     *   shadow  … <b>記録はしますが、送信を止めません。</b>
     *             予約・凍結・原応答の保存まで本番と同じことをして、
     *             うまくいかなかったときも<b>AIの呼び出しは止めません</b>。
     *             初めて実物で動かす日に、いまの商品を落とさずに
     *             実測だけを取るための段です。
     *   1       … 契約どおりに止めます（枠が取れなければ送りません）。
     */
    public static function mode(): string
    {
        $v = strtolower(trim((string) env('BAGANRIKI_R122_QUEUE', '0')));
        if (in_array($v, ['1', 'true', 'on', 'yes'], true)) { return 'on'; }
        if (in_array($v, ['shadow', 'record', 'dry'], true)) { return 'shadow'; }
        return 'off';
    }

    /** 記録の仕組みを動かすか（shadow と on） */
    public static function enabled(): bool
    {
        return self::mode() !== 'off';
    }

    /** うまくいかなかったときに送信を止めるか（on だけ） */
    public static function blocking(): bool
    {
        return self::mode() === 'on';
    }

    /** 必要な表がそろっているか */
    public static function ready(): bool
    {
        foreach (['baganriki_snapshots', 'baganriki_ai_attempts',
                  'baganriki_live_states', 'baganriki_audit_events'] as $t) {
            if (!\Schema::hasTable($t)) { return false; }
        }
        return true;
    }

    // ── 時刻 ────────────────────────────────────────────────────────────

    public static function nowUs(): int
    {
        $t = gettimeofday();
        return $t['sec'] * self::US + $t['usec'];
    }

    /** マイクロ秒 → DATETIME(6)（日本時間） */
    public static function toDb(int $us): string
    {
        $d = (new \DateTimeImmutable('@' . intdiv($us, self::US)))
                ->setTimezone(new \DateTimeZone('Asia/Tokyo'));
        $f = $us % self::US;
        if ($f < 0) { $f += self::US; }
        return $d->format('Y-m-d H:i:s') . sprintf('.%06d', $f);
    }

    /** DATETIME(6) → マイクロ秒。マイクロ秒を落としません */
    public static function dbUs($v): ?int
    {
        if ($v === null) { return null; }
        if ($v instanceof \DateTimeInterface) {
            return $v->getTimestamp() * self::US + (int) $v->format('u');
        }
        $s = trim((string) $v);
        if ($s === '' || $s === '0000-00-00 00:00:00') { return null; }
        if (!preg_match('/^(\d{4}-\d{2}-\d{2})[ T](\d{2}:\d{2}:\d{2})(?:\.(\d{1,6}))?$/',
                        $s, $m)) {
            return null;
        }
        $d = \DateTimeImmutable::createFromFormat(
                'Y-m-d H:i:s', $m[1] . ' ' . $m[2], new \DateTimeZone('Asia/Tokyo'));
        if ($d === false) { return null; }
        $frac = isset($m[3]) ? (int) str_pad($m[3], 6, '0') : 0;
        return $d->getTimestamp() * self::US + $frac;
    }

    private static function j($v): string
    {
        return (string) json_encode($v,
            JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PRESERVE_ZERO_FRACTION);
    }

    // ── 監査 ────────────────────────────────────────────────────────────

    public static function event(string $raceId, ?int $snapshotId, string $kind,
                                 ?int $old, ?int $new, array $diag,
                                 ?string $related, int $nowUs): void
    {
        \DB::table('baganriki_audit_events')->insert([
            'race_id'      => $raceId,
            'snapshot_id'  => $snapshotId,
            'kind'         => $kind,
            'happened_at'  => self::toDb($nowUs),
            'old_revision' => $old,
            'new_revision' => $new,
            'diagnostics'  => self::j($diag),
            'related_id'   => $related,
        ]);
    }

    // ── ライブ状態 ───────────────────────────────────────────────────────

    /**
     * ライブ状態の行が無ければ作ります（あれば何もしません）。
     * 凍結のときに作られていない古いレースでも、ここで追いつきます。
     */
    public static function ensureLive(int $snapshotId, int $nowUs): void
    {
        $has = \DB::table('baganriki_live_states')
                 ->where('snapshot_id', $snapshotId)->exists();
        if ($has) { return; }
        $snap = \DB::table('baganriki_snapshots')->where('id', $snapshotId)->first();
        if ($snap === null) { return; }
        $frozen = json_decode((string) $snap->frozen_nums, true);
        \DB::table('baganriki_live_states')->insertOrIgnore([
            'snapshot_id'          => $snapshotId,
            'cancellations'        => self::j([]),
            'active_count'         => is_array($frozen) ? count($frozen) : null,
            'live_target_count'    => $snap->target_count,
            'live_quota'           => $snap->quota_1st,
            'live_close'           => null,
            'state_revision'       => 0,
            'response_revision'    => 0,
            'publication_revision' => 0,
            'latest_publication_id' => null,
            'updated_at'           => self::toDb($nowUs),
        ]);
    }

    /**
     * 実効期限を出します。
     *   publish_deadline = 凍結した投票締切 − 60秒
     *   reply_deadline   = publish_deadline − 30秒
     *   live_close で前倒しされていれば、そのぶんだけ縮めます（延ばしません）
     */
    public static function deadlines(object $snap, ?object $live): array
    {
        $sales = self::dbUs($snap->sales_close_at ?? null);
        if ($sales === null) {
            return ['ok' => false, 'code' => 'TIME_UNCOMPUTABLE',
                    'reason' => '凍結した投票締切が無いので期限を出せません',
                    'reply' => null, 'publish' => null, 'sales' => null];
        }
        $liveClose = ($live === null) ? null : self::dbUs($live->live_close ?? null);
        $d = BaganrikiTime::effectiveDeadlines($sales, $liveClose);
        return ['ok' => true, 'code' => null, 'reason' => null,
                'reply' => $d['reply'], 'publish' => $d['publish'], 'sales' => $sales,
                'live_close' => $liveClose];
    }

    // ── 枠の読み取り（token と原文は返しません）──────────────────────────

    public static function slots(int $snapshotId, ?string $role = null): array
    {
        $q = \DB::table('baganriki_ai_attempts')->where('snapshot_id', $snapshotId);
        if ($role !== null) { $q->where('role', $role); }
        $out = [];
        foreach ($q->orderBy('role')->orderBy('attempt_no')->get() as $r) {
            $out[] = [
                'role'        => (string) $r->role,
                'attempt_no'  => (int) $r->attempt_no,
                'status'      => (string) $r->status,
                'complete'    => ((int) $r->complete === 1),
                'reserved_at' => $r->reserved_at,
                'received_at' => $r->received_at,
                'response_hash'  => $r->response_hash,
                'failure_reason' => $r->failure_reason,
            ];
        }
        return $out;
    }

    /** そのroleの枠を attempt_no をキーにして返します（内部用） */
    private static function rowsOf(int $snapshotId, string $role): array
    {
        $out = [];
        foreach (\DB::table('baganriki_ai_attempts')
                    ->where('snapshot_id', $snapshotId)->where('role', $role)
                    ->get() as $r) {
            $out[(int) $r->attempt_no] = $r;
        }
        return $out;
    }

    private static function fin(bool $ok, string $code, string $reason, array $add = []): array
    {
        return array_merge(['ok' => $ok, 'code' => $code, 'reason' => $reason], $add);
    }

    // ── 訂正を予約してよいか（書き込みません）────────────────────────────

    /**
     * 「初回の原応答と complete を保存してから訂正に入る」の判定だけをします。
     * 再起動の後でもここから訂正判定を再開できます。
     */
    public static function fixAllowed(int $snapshotId, string $role): array
    {
        $rows = self::rowsOf($snapshotId, $role);
        if (!isset($rows[self::FIRST])) {
            return self::fin(false, 'FIRST_NOT_RESERVED', '初回の枠がまだありません');
        }
        $f = $rows[self::FIRST];
        $st = (string) $f->status;
        if ($st === self::FAILED || $st === self::UNKNOWN) {
            return self::fin(false, 'FIRST_FAILED',
                '初回が' . $st . 'なので訂正は予約しません');
        }
        if ($st !== self::RECEIVED) {
            return self::fin(false, 'FIRST_NOT_RECEIVED',
                '初回が未受領（' . $st . '）なので訂正は予約しません');
        }
        if ((int) $f->complete !== 1) {
            return self::fin(false, 'FIRST_NOT_COMPLETE',
                '初回が complete=false なので訂正は予約しません');
        }
        if (isset($rows[self::FIX])) {
            return self::fin(false, 'SLOT_TAKEN',
                '訂正の枠はすでにあります（' . $rows[self::FIX]->status . '）',
                ['status' => (string) $rows[self::FIX]->status]);
        }
        return self::fin(true, 'OK', '訂正を予約できます');
    }

    // ── 予約 ────────────────────────────────────────────────────────────

    /**
     * 枠を1つ予約します。予約が確定してから送ってください。
     *
     * @param array $expect  版の見張り。
     *                       ['state_revision'=>int, 'response_revision'=>int]
     *                       を渡すと、予約の直前に変わっていれば STATE_CHANGED で
     *                       予約しません（契約11章）。
     */
    public static function reserve(int $snapshotId, string $role, int $attemptNo,
                                   int $nowUs, array $expect = []): array
    {
        if ($attemptNo !== self::FIRST && $attemptNo !== self::FIX) {
            return self::fin(false, 'INVALID_ATTEMPT',
                'attempt_no は 0（初回）か 1（訂正）だけです');
        }
        self::ensureLive($snapshotId, $nowUs);
        try {
            return \DB::transaction(function () use ($snapshotId, $role, $attemptNo,
                                                     $nowUs, $expect) {
                $live = \DB::table('baganriki_live_states')
                          ->where('snapshot_id', $snapshotId)->lockForUpdate()->first();
                $snap = \DB::table('baganriki_snapshots')
                          ->where('id', $snapshotId)->first();
                if ($snap === null) {
                    return self::fin(false, 'NO_SNAPSHOT', '凍結入力がありません');
                }
                $raceId = (string) $snap->race_id;

                // ① 版の見張り（予約の直前にもう一度見ます）
                if ($live !== null) {
                    foreach (['state_revision', 'response_revision',
                              'publication_revision'] as $k) {
                        if (array_key_exists($k, $expect)
                            && (int) $expect[$k] !== (int) $live->{$k}) {
                            return self::fin(false, 'STATE_CHANGED',
                                $k . 'が変わりました（期待 ' . $expect[$k]
                                . '・現在 ' . $live->{$k} . '）');
                        }
                    }
                }

                // ② 全頭取消なら予約しません
                if ($live !== null && $live->active_count !== null
                    && (int) $live->active_count === 0) {
                    return self::fin(false, 'ALL_CANCELLED', '全頭取消なので予約しません');
                }

                // ③ 期限（同時刻は可、1マイクロ秒でも超えたら不可）
                $dl = self::deadlines($snap, $live);
                if (!$dl['ok']) {
                    return self::fin(false, (string) $dl['code'], (string) $dl['reason']);
                }
                if ($nowUs > $dl['reply']) {
                    return self::fin(false, 'DEADLINE_PASSED',
                        '実効の応答期限を超えています（期限 '
                        . BaganrikiTime::toJst((int) $dl['reply']) . '・現在 '
                        . BaganrikiTime::toJst($nowUs) . '）');
                }

                // ④ 枠の数と順番
                $rows = self::rowsOf($snapshotId, $role);
                if (isset($rows[$attemptNo])) {
                    return self::fin(false, 'SLOT_TAKEN',
                        'その枠はすでにあります（' . $rows[$attemptNo]->status
                        . '）。作り直しません',
                        ['status' => (string) $rows[$attemptNo]->status]);
                }
                if (count($rows) >= self::MAX_PER_ROLE) {
                    return self::fin(false, 'NO_SLOT', '枠は2つまでです');
                }
                if ($attemptNo === self::FIX) {
                    $gate = self::fixAllowed($snapshotId, $role);
                    if (!$gate['ok']) { return $gate; }
                    // 訂正の予約は、初回の受領時刻を下回る現在時刻ではしません
                    $firstAt = self::dbUs($rows[self::FIRST]->received_at ?? null);
                    if ($firstAt !== null && $nowUs < $firstAt) {
                        return self::fin(false, 'CLOCK_BACKWARD',
                            '現在時刻が初回の受領時刻より前です');
                    }
                }

                // ⑤ 予約します
                $token = hash('sha256', $snapshotId . '|' . $role . '|' . $attemptNo
                                        . '|' . $nowUs . '|' . bin2hex(random_bytes(16)));
                \DB::table('baganriki_ai_attempts')->insert([
                    'snapshot_id'    => $snapshotId,
                    'role'           => $role,
                    'attempt_no'     => $attemptNo,
                    'token'          => $token,
                    'status'         => self::RESERVED,
                    'reserved_at'    => self::toDb($nowUs),
                    'received_at'    => null,
                    'complete'       => 0,
                    'raw_response'   => null,
                    'response_hash'  => null,
                    'failure_reason' => null,
                ]);

                $old = ($live === null) ? null : (int) $live->response_revision;
                $new = ($old === null) ? null : ($old + 1);
                if ($live !== null) {
                    \DB::table('baganriki_live_states')
                      ->where('snapshot_id', $snapshotId)
                      ->update(['response_revision' => $new,
                                'updated_at' => self::toDb($nowUs)]);
                }
                self::event($raceId, $snapshotId, 'QUEUE_RESERVED', $old, $new,
                    ['role' => $role, 'attempt_no' => $attemptNo,
                     'reply_deadline' => BaganrikiTime::toJst((int) $dl['reply'])],
                    $role . '#' . $attemptNo, $nowUs);

                return self::fin(true, 'OK', '予約しました',
                    ['token' => $token, 'role' => $role, 'attempt_no' => $attemptNo,
                     'response_revision' => $new,
                     'reply_deadline' => BaganrikiTime::toJst((int) $dl['reply'])]);
            });
        } catch (\Throwable $e) {
            // uq_attempt / uq_token に当たった＝ほかの処理が同じ枠を取りました。
            //   PDOException でも QueryException でも拾えるようにしています。
            if (self::isDup($e)) {
                return self::fin(false, 'SLOT_TAKEN',
                    'ほかの処理が同じ枠を取りました。作り直しません');
            }
            throw $e;
        }
    }

    public static function isDup(\Throwable $e): bool
    {
        $m = $e->getMessage();
        return (strpos($m, '1062') !== false)
            || (stripos($m, 'Duplicate entry') !== false)
            || (stripos($m, 'Integrity constraint violation') !== false);
    }

    // ── 送信許可（callbackは1回だけ）─────────────────────────────────────

    /**
     * 送る直前に呼びます。RESERVED のときだけ1回だけ通ります。
     * 自動再試行は0なので、ここを2回通すことはできません。
     */
    public static function allowSend(string $token, int $nowUs): array
    {
        return \DB::transaction(function () use ($token, $nowUs) {
            $pre = \DB::table('baganriki_ai_attempts')
                     ->where('token', $token)->first(['snapshot_id']);
            if ($pre === null) {
                return self::fin(false, 'NO_TOKEN', 'その予約はありません');
            }
            \DB::table('baganriki_live_states')
              ->where('snapshot_id', $pre->snapshot_id)->lockForUpdate()->first();
            $a = \DB::table('baganriki_ai_attempts')
                   ->where('token', $token)->lockForUpdate()->first();
            if ($a === null) {
                return self::fin(false, 'NO_TOKEN', 'その予約はありません');
            }
            $st = (string) $a->status;
            if ($st === self::SENT) {
                return self::fin(false, 'ALREADY_SENT',
                    'すでに送信許可を出しています。再送しません');
            }
            if (in_array($st, self::TERMINAL, true)) {
                return self::fin(false, 'TERMINAL',
                    'すでに終わっています（' . $st . '）');
            }
            $snap = \DB::table('baganriki_snapshots')
                      ->where('id', $a->snapshot_id)->first();
            $live = \DB::table('baganriki_live_states')
                      ->where('snapshot_id', $a->snapshot_id)->first();
            if ($snap === null) {
                return self::fin(false, 'NO_SNAPSHOT', '凍結入力がありません');
            }
            $dl = self::deadlines($snap, $live);
            if (!$dl['ok']) {
                return self::fin(false, (string) $dl['code'], (string) $dl['reason']);
            }
            if ($nowUs > $dl['reply']) {
                return self::fin(false, 'DEADLINE_PASSED',
                    '送信前の期限検査で超過しています');
            }
            \DB::table('baganriki_ai_attempts')->where('token', $token)
              ->update(['status' => self::SENT]);
            self::event((string) $snap->race_id, (int) $a->snapshot_id,
                'QUEUE_SENT', null, null,
                ['role' => (string) $a->role, 'attempt_no' => (int) $a->attempt_no],
                $a->role . '#' . $a->attempt_no, $nowUs);
            return self::fin(true, 'OK', '送ってよいです',
                ['role' => (string) $a->role, 'attempt_no' => (int) $a->attempt_no]);
        });
    }

    // ── 受領 ────────────────────────────────────────────────────────────

    /**
     * 原応答を保存します。
     *   同じ token に同じ応答 → 冪等（版は増やしません）
     *   同じ token に別の応答 → 拒否（RESPONSE_MISMATCH）
     *   終端の付け替え         → 拒否（TERMINAL）
     *   complete=false の本文は、そのまま残して選出には使いません。
     */
    public static function receive(string $token, string $raw, bool $complete,
                                   int $nowUs): array
    {
        return \DB::transaction(function () use ($token, $raw, $complete, $nowUs) {
            // @ANCHOR-20261020-R122-QUEUE  ロックの順番は
            //   ライブ状態 → 枠 に統一します（予約と同じ順番。取り合いを避けます）
            $pre = \DB::table('baganriki_ai_attempts')
                     ->where('token', $token)->first(['snapshot_id']);
            if ($pre === null) {
                return self::fin(false, 'NO_TOKEN', 'その予約はありません');
            }
            $live = \DB::table('baganriki_live_states')
                      ->where('snapshot_id', $pre->snapshot_id)->lockForUpdate()->first();
            $a = \DB::table('baganriki_ai_attempts')
                   ->where('token', $token)->lockForUpdate()->first();
            if ($a === null) {
                return self::fin(false, 'NO_TOKEN', 'その予約はありません');
            }
            $hash = hash('sha256', $raw);
            $st   = (string) $a->status;

            if ($st === self::RECEIVED) {
                if ((string) $a->response_hash === $hash
                    && ((int) $a->complete === 1) === $complete) {
                    return self::fin(true, 'IDEMPOTENT', 'すでに同じ応答を保存しています',
                        ['response_hash' => $hash]);
                }
                return self::fin(false, 'RESPONSE_MISMATCH',
                    '同じ予約に別の応答は保存しません');
            }
            if ($st === self::FAILED || $st === self::UNKNOWN) {
                return self::fin(false, 'TERMINAL',
                    'すでに終わっています（' . $st . '）。付け替えません');
            }
            if ($st === self::RESERVED) {
                return self::fin(false, 'NOT_SENT',
                    'まだ送信許可を出していません');
            }

            $snap = \DB::table('baganriki_snapshots')
                      ->where('id', $a->snapshot_id)->first();
            if ($snap === null) {
                return self::fin(false, 'NO_SNAPSHOT', '凍結入力がありません');
            }
            $dl = self::deadlines($snap, $live);
            if (!$dl['ok']) {
                return self::fin(false, (string) $dl['code'], (string) $dl['reason']);
            }
            if ($nowUs > $dl['reply']) {
                return self::fin(false, 'DEADLINE_PASSED',
                    '受領時の期限検査で超過しています（遅着）');
            }

            // 訂正の受領は初回の受領以上の時刻を必須とします（同時刻は可）
            if ((int) $a->attempt_no === self::FIX) {
                $rows = self::rowsOf((int) $a->snapshot_id, (string) $a->role);
                $firstAt = self::dbUs($rows[self::FIRST]->received_at ?? null);
                if ($firstAt !== null && $nowUs < $firstAt) {
                    return self::fin(false, 'RECEIVE_ORDER',
                        '訂正の受領時刻が初回より前です');
                }
            }

            \DB::table('baganriki_ai_attempts')->where('token', $token)->update([
                'status'        => self::RECEIVED,
                'received_at'   => self::toDb($nowUs),
                'complete'      => $complete ? 1 : 0,
                'raw_response'  => $raw,
                'response_hash' => $hash,
            ]);
            $old = ($live === null) ? null : (int) $live->response_revision;
            $new = ($old === null) ? null : ($old + 1);
            if ($live !== null) {
                \DB::table('baganriki_live_states')->where('snapshot_id', $a->snapshot_id)
                  ->update(['response_revision' => $new,
                            'updated_at' => self::toDb($nowUs)]);
            }
            self::event((string) $snap->race_id, (int) $a->snapshot_id,
                'QUEUE_RECEIVED', $old, $new,
                ['role' => (string) $a->role, 'attempt_no' => (int) $a->attempt_no,
                 'complete' => $complete, 'response_hash' => $hash],
                $a->role . '#' . $a->attempt_no, $nowUs);
            return self::fin(true, 'OK', '保存しました',
                ['response_hash' => $hash, 'complete' => $complete,
                 'response_revision' => $new]);
        });
    }

    // ── 失敗・結果不明 ───────────────────────────────────────────────────

    public static function fail(string $token, string $reason, int $nowUs,
                               bool $unknown = false): array
    {
        return \DB::transaction(function () use ($token, $reason, $nowUs, $unknown) {
            $pre = \DB::table('baganriki_ai_attempts')
                     ->where('token', $token)->first(['snapshot_id']);
            if ($pre === null) {
                return self::fin(false, 'NO_TOKEN', 'その予約はありません');
            }
            $live = \DB::table('baganriki_live_states')
                      ->where('snapshot_id', $pre->snapshot_id)->lockForUpdate()->first();
            $a = \DB::table('baganriki_ai_attempts')
                   ->where('token', $token)->lockForUpdate()->first();
            if ($a === null) {
                return self::fin(false, 'NO_TOKEN', 'その予約はありません');
            }
            $st = (string) $a->status;
            if (in_array($st, self::TERMINAL, true)) {
                return self::fin(false, 'TERMINAL',
                    'すでに終わっています（' . $st . '）。付け替えません');
            }
            $to = $unknown ? self::UNKNOWN : self::FAILED;
            \DB::table('baganriki_ai_attempts')->where('token', $token)->update([
                'status' => $to, 'failure_reason' => $reason,
            ]);
            $old = ($live === null) ? null : (int) $live->response_revision;
            $new = ($old === null) ? null : ($old + 1);
            if ($live !== null) {
                \DB::table('baganriki_live_states')->where('snapshot_id', $a->snapshot_id)
                  ->update(['response_revision' => $new,
                            'updated_at' => self::toDb($nowUs)]);
            }
            $snap = \DB::table('baganriki_snapshots')
                      ->where('id', $a->snapshot_id)->first();
            self::event(($snap === null) ? '' : (string) $snap->race_id,
                (int) $a->snapshot_id, 'QUEUE_' . $to, $old, $new,
                ['role' => (string) $a->role, 'attempt_no' => (int) $a->attempt_no,
                 'reason' => $reason],
                $a->role . '#' . $a->attempt_no, $nowUs);
            return self::fin(true, 'OK', $to . 'にしました',
                ['status' => $to, 'response_revision' => $new]);
        });
    }

    // ── 再起動 ──────────────────────────────────────────────────────────

    /**
     * 再起動したあとに1回だけ呼びます。
     *   SENT     → UNKNOWN_RESULT（結果不明。再送しません）
     *   RESERVED → そのまま（まだ送っていないので送信許可が1回残ります）
     * 枠そのものは作り直しません。
     */
    public static function resume(int $snapshotId, int $nowUs): array
    {
        $kept = []; $unknown = [];
        foreach (\DB::table('baganriki_ai_attempts')
                    ->where('snapshot_id', $snapshotId)
                    ->orderBy('role')->orderBy('attempt_no')->get() as $a) {
            $st = (string) $a->status;
            $label = $a->role . '#' . $a->attempt_no;
            if ($st === self::SENT) {
                self::fail((string) $a->token,
                    '再起動をまたいだため結果が分かりません（再送しません）',
                    $nowUs, true);
                $unknown[] = $label;
            } elseif ($st === self::RESERVED) {
                $kept[] = $label;
            }
        }
        return self::fin(true, 'OK', '再起動の後始末をしました',
            ['unknown' => $unknown, 'reserved_kept' => $kept,
             'slots' => self::slots($snapshotId)]);
    }

    /**
     * 選出に使える応答だけを返します（complete=true の RECEIVED だけ）。
     * 訂正があればそちらを優先し、無ければ初回を使います。
     * 原応答は呼出側の内部処理にだけ渡します（readでは返しません）。
     */
    public static function usable(int $snapshotId, string $role): array
    {
        $rows = self::rowsOf($snapshotId, $role);
        foreach ([self::FIX, self::FIRST] as $no) {
            if (!isset($rows[$no])) { continue; }
            $r = $rows[$no];
            if ((string) $r->status === self::RECEIVED && (int) $r->complete === 1) {
                return self::fin(true, 'OK', '使えます',
                    ['attempt_no' => $no, 'raw' => (string) $r->raw_response,
                     'response_hash' => (string) $r->response_hash]);
            }
        }
        return self::fin(false, 'NONE', '選出に使える応答がありません');
    }
}
