<?php
require __DIR__ . '/time.php';
require __DIR__ . '/resp.php';
require __DIR__ . '/diag.php';

$v = __DIR__ . '/../mat/validation';
$src = json_decode(file_get_contents($v . '/normal/MIXED_N16_1st_input.json'), true);
$base = json_decode(file_get_contents($v . '/normal/MIXED_N16_1st_output.json'), true);
$frozen = array_map(fn($r) => (int) $r['horse_no'], $src['runners']);
$N = count($frozen);

function inspect(array $doc, array $src, array $frozen): array {
    $raw = BaganrikiResponse::BEGIN . json_encode($doc, JSON_UNESCAPED_UNICODE) . BaganrikiResponse::END;
    $ex = BaganrikiResponse::extract($raw);
    if (!$ex['ok']) return ['ok' => false, 'stage' => 'extract'];
    $res = $ex['json'];
    $iso = BaganrikiResponse::isolateHorses($res['horses'], $frozen);
    $d = BaganrikiDiagnose::run($res, $src);
    $normal = [];
    foreach ($iso['kept'] as $no => $h) {
        if (($d['row_valid'][$no] ?? true) !== true) continue;
        $normal[$no] = $h;
    }
    ksort($normal);
    return ['ok' => true, 'normal' => $normal, 'needs_fix' => !$d['ok'],
            'repair_scope' => $d['repair_scope'], 'row_valid' => $d['row_valid'],
            'diag' => ['unknown' => $d['unknown'], 'duplicated' => $d['duplicated']]];
}
$p = 0; $f = 0;
function ck(string $id, string $w, $got, $want) { global $p, $f;
    $o = ($got === $want); $o ? $p++ : $f++;
    printf("  %s %-7s %-44s %s\n", $o ? '○' : '×', $id, $w,
        $o ? '' : ('得=' . var_export($got, true) . ' 期待=' . var_export($want, true)));
}

$o = $base; $gone = (int) $o['horses'][2]['horse_no']; array_splice($o['horses'], 2, 1);
$r = inspect($o, $src, $frozen);
ck('R-03', '欠落しても他馬は残る', count($r['normal']), $N - 1);
ck('R-04', '欠落馬は直す範囲に入る', in_array($gone, $r['repair_scope']['horses'], true), true);

$o = $base; $x = $o['horses'][0]; $x['horse_no'] = 99; $o['horses'][] = $x;
$r = inspect($o, $src, $frozen);
ck('R-05', '未知馬を混ぜても他馬は残る', count($r['normal']), $N);
ck('R-06', '未知馬は隔離される', in_array(99, $r['diag']['unknown'], true), true);

$o = $base; $o['horses'][] = $o['horses'][0];
$r = inspect($o, $src, $frozen);
ck('R-07', '重複しても他馬は残る', count($r['normal']), $N);
ck('R-08', '重複は記録される', count($r['diag']['duplicated']), 1);

$o = $base; $bad = (int) $o['horses'][1]['horse_no']; $o['horses'][1]['observed_sum'] = 999;
$r = inspect($o, $src, $frozen);
ck('R-09', '壊れた1頭だけ落ちる', count($r['normal']), $N - 1);
ck('R-10', '壊れた行は row_valid=false', $r['row_valid'][$bad], false);
ck('R-11', '他の行は row_valid=true', $r['row_valid'][(int) $base['horses'][0]['horse_no']], true);

$o = $base; array_pop($o['public_candidates']);
$r = inspect($o, $src, $frozen);
ck('R-12', '直す範囲に公開リストが入る', $r['repair_scope']['public_candidates'], true);
ck('R-13', '評価行は広がらない', $r['repair_scope']['horses'], []);
ck('R-14', '全頭そのまま残る', count($r['normal']), $N);

// 訂正
$o1 = $base; $gone = (int) $o1['horses'][3]['horse_no']; array_splice($o1['horses'], 3, 1);
$o2 = $base; $keep = [];
foreach ($o2['horses'] as $h) { if ((int) $h['horse_no'] === $gone) $keep[] = $h; }
$o2['horses'] = $keep;
$a = inspect($o1, $src, $frozen); $b = inspect($o2, $src, $frozen);
$acc = BaganrikiResponse::acceptCorrection($a['normal'], $b['normal'],
    '2026-10-20T10:00:00+09:00', '2026-10-20T10:00:01+09:00',
    $frozen, $a['repair_scope'], $b['row_valid']);
ck('R-15', '訂正を採用する', $acc['ok'], true);
ck('R-16', '欠落した馬を救済した', $acc['rescued'], [$gone]);
$m = BaganrikiResponse::applyCorrection($a['normal'], $b['normal'], $acc);
ck('R-17', '全頭そろう', count($m), $N);

$o2 = $base; $other = [];
foreach ($o2['horses'] as $h) { if ((int) $h['horse_no'] !== $gone) { $other[] = $h; break; } }
$o2['horses'] = $other;
$b = inspect($o2, $src, $frozen);
$acc = BaganrikiResponse::acceptCorrection($a['normal'], $b['normal'],
    '2026-10-20T10:00:00+09:00', '2026-10-20T10:00:01+09:00',
    $frozen, $a['repair_scope'], $b['row_valid']);
ck('R-18', '対象外を変える訂正は採用しない', $acc['ok'], false);
$m = BaganrikiResponse::applyCorrection($a['normal'], $b['normal'], $acc);
ck('R-19', '初回の正常部分は残る', count($m), $N - 1);

$acc = BaganrikiResponse::acceptCorrection($a['normal'], $b['normal'],
    '2026-10-20T10:00:05+09:00', '2026-10-20T10:00:00+09:00',
    $frozen, $a['repair_scope'], $b['row_valid']);
ck('R-20', '訂正が初回より前なら採用しない', $acc['ok'], false);

$r = inspect($base, $src, $frozen);
ck('R-21', '直すところが無ければ訂正しない', $r['needs_fix'], false);
echo "\n  合格 $p 件 / 不合格 $f 件\n";
