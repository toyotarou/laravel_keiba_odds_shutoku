<?php
require __DIR__ . '/shim.php';
require __DIR__ . '/ai_consts.php';
require __DIR__ . '/tail_classes.php';
use App\Http\Controllers\Api\AiController as AC;
use App\Http\Controllers\Api\BaganrikiSignals as SG;
use App\Http\Controllers\Api\BaganrikiTime as TM;
use App\Http\Controllers\Api\BaganrikiRanking as RK;
use App\Http\Controllers\Api\BaganrikiAllocation as AL;

$pass=0;$fail=0;
function ok(string $n,$got,$want,string $note=''){global $pass,$fail;
  if($got===$want){$pass++;printf("  ○ %-8s %s\n",$n,$note);}
  else{$fail++;printf("  × %-8s %s  期待=%s 実際=%s\n",$n,$note,var_export($want,true),var_export($got,true));}}

echo "── ① 合成729件を v04Classify へ ──\n";
$d=json_decode(file_get_contents(__DIR__.'/../mat/validation/mode_cases.json'),true);
$cs=$d['cases'];$tri=fn($v)=>($v===null)?'UNKNOWN':($v?'TRUE':'FALSE');
$keys=['mode','mode_status','allocation_mode','mode_policy_id','selection_enabled','S','S_min','S_max','display_rating'];
$ng=0;$chk=0;$shown=0;
foreach($cs as $c){$f=[];foreach(['X1','X2','X3','X4','X5','X6','Z'] as $k){$f[$k]=$tri($c['signals'][$k]??null);}
  $r=SG::v04Classify($f);
  foreach($keys as $k){if(!array_key_exists($k,$c['expected']))continue;$chk++;
    if($c['expected'][$k]!==$r[$k]){$ng++;if($shown<5){$shown++;printf("      %s %s 期待=%s 実際=%s\n",$c['id'],$k,var_export($c['expected'][$k],true),var_export($r[$k],true));}break;}}}
printf("    %d 件（判定 %d 項目）\n",count($cs),$chk);
ok('N-01',$ng,0,'不一致');ok('N-02',count($cs),729,'件数');

echo "\n── ② 境界4件を acceptBatch へ ──\n";
$d=json_decode(file_get_contents(__DIR__.'/../mat/validation/acquisition_boundary_cases.json'),true);
$ng=0;
foreach($d['cases'] as $c){
  $frz=TM::us($c['input_freeze_at']);$anchor=$frz-TM::INPUT_FREEZE_OFFSET_SEC*1000000;
  $r=TM::acceptBatch((int)$c['slot'],['request_started_at'=>$c['request_started_at'],
    'response_received_at'=>$c['response_received_at'],'available_at'=>$c['available_at'],
    'input_freeze_at'=>$c['input_freeze_at']],$anchor);
  $got=($r['ok']?'PASS':'FAIL');
  if($got!==$c['expected']){$ng++;printf("      %s 期待=%s 実際=%s %s\n",$c['id'],$c['expected'],$got,$r['reason']??'');}
  else printf("    ○ %-18s %s\n",$c['id'],$got);}
ok('N-03',$ng,0,'不一致');ok('N-04',count($d['cases']),4,'件数');

echo "\n── ③ 正本の発走時刻との一致 ──\n";
$anchor=TM::us('2026-10-18T10:05:00+09:00');
$frzOk=TM::toJst(TM::inputFreeze($anchor));$schOk=TM::toJst(TM::slotScheduled($anchor,6));
$mk=fn(array $o)=>$o+['slot_scheduled_at'=>$schOk,'request_started_at'=>$schOk,
  'response_received_at'=>$schOk,'available_at'=>$schOk,'input_freeze_at'=>$frzOk];
ok('N-05',TM::acceptBatch(6,$mk([]),$anchor)['ok'],true,'合っていれば採用');
ok('N-06',TM::acceptBatch(6,$mk(['slot_scheduled_at'=>TM::toJst(TM::slotScheduled($anchor,6)+1000000)]),$anchor)['code'],'SCHEDULE_MISMATCH','予定1秒ずれ');
ok('N-07',TM::acceptBatch(6,$mk(['input_freeze_at'=>TM::toJst(TM::inputFreeze($anchor)+1000000)]),$anchor)['code'],'FREEZE_MISMATCH','上限1秒甘い');

echo "\n── ④ 繰上がり ──\n";
ok('N-08',TM::us('2026-02-30T10:05:00+09:00'),null,'2月30日');
ok('N-09',TM::us('2026-13-01T10:05:00+09:00'),null,'13月');
ok('N-10',TM::us('2026-10-18T25:00:00+09:00'),null,'25時');
ok('N-11',TM::us('2026-10-18T10:61:00+09:00'),null,'61分');
ok('N-12',TM::us('2025-02-29T10:05:00+09:00'),null,'平年2/29');
ok('N-13',TM::us('2024-02-29T10:05:00+09:00')!==null,true,'うるう年2/29');
ok('N-14',TM::us('2026-10-18T10:05:00.123456+09:00')!==null,true,'マイクロ秒');

echo "\n── ⑤ 取消でCが変わる例 ──\n";
$band=function(int $n,int $a,int $b){$m=[];for($i=1;$i<=$n;$i++){$m[$i]=($i<=$a)?'A':(($i<=$a+$b)?'B':'D');}return $m;};
$cases=[['16→15',16,[16],'MIXED',['A'=>3,'B'=>2,'D'=>1],6],
        ['14→13',14,[14],'MIXED',['A'=>3,'B'=>2,'D'=>0],5],
        ['9→8',  9,[9], 'MIXED',['A'=>2,'B'=>2,'D'=>0],4]];
$i=15;
foreach($cases as [$label,$n,$cancel,$mode,$wb,$wc]){
  $fb=$band($n,6,6);
  $old=RK::afterCancellation($fb,[],['A'=>3,'B'=>3,'D'=>1],$mode);
  $ac =RK::afterCancellation($fb,$cancel,['A'=>3,'B'=>3,'D'=>1],$mode);
  ok('N-'.str_pad((string)$i++,2,'0',STR_PAD_LEFT),$ac['target_count'],$wc,$label.' の目標数（取消前 '.var_export($old['target_count'],true).'）');
  ok('N-'.str_pad((string)$i++,2,'0',STR_PAD_LEFT),$ac['base_quota'],$wb,$label.' の基本配分 '.json_encode($ac['base_quota']));
  ok('N-'.str_pad((string)$i++,2,'0',STR_PAD_LEFT),$ac['active_count'],$n-count($cancel),$label.' の生存頭数');}
$ac=RK::afterCancellation($band(16,6,6),range(1,16),['A'=>3,'B'=>3,'D'=>1],'MIXED');
ok('N-24',$ac['all_cancelled'],true,'全頭取消の印');
ok('N-25',$ac['target_count'],0,'目標数0');
ok('N-26',$ac['live_quota'],null,'枠を返さない');
ok('N-27',$ac['active_count'],0,'生存0');
$ac2=RK::afterCancellation($band(16,6,6),[1],['A'=>3,'B'=>3,'D'=>1],'MIXED');
ok('N-28',$ac2['band_alive']['A'],5,'Aが1減る');
ok('N-29',$ac2['band_alive']['B'],6,'Bは動かない');

printf("\n  判定 %d 件／合格 %d／不合格 %d\n",$pass+$fail,$pass,$fail);
