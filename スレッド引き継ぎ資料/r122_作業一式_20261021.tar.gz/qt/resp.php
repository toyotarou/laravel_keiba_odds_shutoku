<?php
final class BaganrikiResponse
{
    public const BEGIN = '<<<BAGANRIKI_V041_R8_BEGIN>>>';
    public const END   = '<<<BAGANRIKI_V041_R8_END>>>';

    /** BEGIN/END に挟まれたJSONを1つだけ厳密に取り出します */
    public static function extract(string $raw): array
    {
        $i = strpos($raw, self::BEGIN);
        $j = strpos($raw, self::END);
        if ($i === false || $j === false || $j <= $i) {
            return ['ok' => false, 'code' => 'AI_FAILURE',
                    'reason' => 'BEGIN/END マーカーが揃っていない', 'json' => null];
        }
        if (strpos($raw, self::BEGIN, $i + 1) !== false) {
            return ['ok' => false, 'code' => 'AI_FAILURE',
                    'reason' => 'BEGIN が複数ある', 'json' => null];
        }
        $body = substr($raw, $i + strlen(self::BEGIN), $j - $i - strlen(self::BEGIN));
        $data = json_decode(trim($body), true, 64);
        if (!is_array($data)) {
            return ['ok' => false, 'code' => 'AI_FAILURE',
                    'reason' => 'JSONとして読めない（' . json_last_error_msg() . '）', 'json' => null];
        }
        return ['ok' => true, 'code' => null, 'reason' => null, 'json' => $data];
    }

    /**
     * 応答全体の照合。ここが合わなければ応答ごと不採用にします。
     * @param array $expect ['prompt_version','schema_version','race_id','ai_role',
     *                       'snapshot_hash','role_cap','role_quota',
     *                       'mode','mode_status','allocation_mode','mode_policy_id']
     */
    public static function checkEnvelope(array $res, array $expect): array
    {
        $bad = [];
        foreach (['prompt_version', 'schema_version', 'race_id', 'ai_role',
                  'snapshot_hash', 'mode', 'mode_status', 'allocation_mode',
                  'mode_policy_id'] as $k) {
            if (!array_key_exists($k, $expect)) { continue; }
            if (($res[$k] ?? null) !== $expect[$k]) {
                $bad[] = sprintf('%s（期待 %s / 実際 %s）', $k,
                    var_export($expect[$k], true), var_export($res[$k] ?? null, true));
            }
        }
        if (array_key_exists('role_cap', $expect)
            && (int) ($res['role_cap'] ?? -1) !== (int) $expect['role_cap']) {
            $bad[] = 'role_cap';
        }
        if (array_key_exists('role_quota', $expect)) {
            // ══════════════════════════════════════════════════════════
            // @ANCHOR-20261020-R122-NULLQUOTA  選出停止（UNRESOLVED）の扱い
            // ══════════════════════════════════════════════════════════
            // 【本物の不具合でした】
            //   role_quota が null（選出しない）のとき、
            //   ?? -1 と ?? -2 の既定値が必ず食い違うので、
            //   <b>正しい応答まで不採用になっていました。</b>
            //   UNRESOLVED のレースは全部これに当たります。
            //   10月20日005の異常例試験で、正常出力14本のうち
            //   UNRESOLVED の2本が落ちたことで分かりました。
            $rq = $res['role_quota'] ?? null;
            $eq = $expect['role_quota'];
            if ($eq === null || $rq === null) {
                if ($eq !== $rq) {
                    $bad[] = sprintf('role_quota（期待 %s / 実際 %s）',
                        ($eq === null) ? 'null' : '値あり',
                        ($rq === null) ? 'null' : '値あり');
                }
            } else {
                foreach (['A', 'B', 'D'] as $b) {
                    if ((int) ($rq[$b] ?? -1) !== (int) ($eq[$b] ?? -2)) {
                        $bad[] = 'role_quota.' . $b;
                    }
                }
            }
        }
        if (!empty($bad)) {
            return ['ok' => false, 'code' => 'AI_FAILURE',
                    'reason' => '応答の識別・版・mode・配分が合わない: ' . implode('／', $bad)];
        }
        return ['ok' => true, 'code' => null, 'reason' => null];
    }

    /**
     * 馬ごとの隔離。凍結集合に無い馬・重複・局所不正はその馬だけ外します。
     * @return array ['kept'=>正常な馬の配列, 'isolated'=>[馬番=>理由]]
     */
    public static function isolateHorses(array $horses, array $frozenNums): array
    {
        $kept = []; $iso = []; $seen = [];
        foreach ($horses as $h) {
            // @ANCHOR-20261020-R122-HORSENO  正規応答のキーは horse_no です
            //   【10月20日005のご指摘5-3】num しか読んでおらず、
            //   正規の応答をそのまま渡すと馬番を読めませんでした。
            //   どちらの綴りでも読めるようにします（horse_no を優先）。
            $num = $h['horse_no'] ?? ($h['num'] ?? null);
            if (!is_int($num) && !(is_string($num) && ctype_digit($num))) {
                $iso['?' . count($iso)] = '馬番が数値でない';
                continue;
            }
            $num = (int) $num;
            if (isset($seen[$num])) { $iso[$num] = '同じ馬番が重複している'; continue; }
            $seen[$num] = true;
            if (!in_array($num, $frozenNums, true)) { $iso[$num] = '凍結集合に無い馬番'; continue; }
            $kept[$num] = $h;
        }
        // 欠落している馬は「不足」として返します（他馬は残します）
        $missing = array_values(array_diff($frozenNums, array_keys($kept)));
        sort($missing);
        return ['kept' => $kept, 'isolated' => $iso, 'missing' => $missing];
    }

    /**
     * 訂正を採用してよいか。
     *   ・初回の正常な根拠を全部失う → 採用しない
     *   ・complete を partial へ悪化させる → 採用しない
     *   ・凍結集合に無い馬・対象外の変更 → 採用しない
     *   ・受領時刻が初回より前 → 採用しない（同一時刻は可）
     */
    public static function acceptCorrection(array $first, array $fix,
                                            ?string $firstAt = null, ?string $fixAt = null,
                                            array $frozenNums = [], ?array $repairScope = null,
                                            array $rowValid = []): array
    {
        // ══════════════════════════════════════════════════════════════
        // @ANCHOR-20261020-R122-REPAIR  10月20日005のご指摘5-1
        // ══════════════════════════════════════════════════════════════
        // 【直した中身】
        //   ・初回に無い馬番を<b>一律に拒否</b>していました。
        //     契約6章は「凍結runner集合にいて、horses訂正の対象なら救済する」です。
        //     未知馬（凍結集合にいない）と、初回から漏れた実在馬を分けます。
        //   ・repair_scope と row_valid を受け取っていませんでした。
        //     対象外の馬を変えようとする訂正は採用しません。
        //     row_valid=false の行は適用しません。
        $rescued = []; $skipped = [];
        if ($firstAt !== null && $fixAt !== null) {
            $a = BaganrikiTime::us($firstAt); $b = BaganrikiTime::us($fixAt);
            if ($a === null || $b === null) {
                return ['ok' => false, 'reason' => '受領時刻が日時として読めない'];
            }
            if ($b < $a) { return ['ok' => false, 'reason' => '訂正の受領時刻が初回より前'];
            }
        }
        foreach ($first as $num => $h0) {
            if (!array_key_exists($num, $fix)) { continue; }   // 変更なしは初回を保持
            $h1 = $fix[$num];
            $g0 = (int) ($h0['independent_groups'] ?? 0);
            $g1 = (int) ($h1['independent_groups'] ?? 0);
            if ($g0 > 0 && $g1 === 0) {
                return ['ok' => false, 'reason' => sprintf('馬番 %d の正常な根拠を全部失う訂正', $num)];
            }
            $s0 = $h0['score_state'] ?? 'partial';
            $s1 = $h1['score_state'] ?? 'partial';
            if ($s0 === 'complete' && $s1 !== 'complete') {
                return ['ok' => false, 'reason' => sprintf('馬番 %d の採点を complete から悪化させる訂正', $num)];
            }
        }
        // ── 初回に無い馬番 ────────────────────────────────────────
        //   凍結集合にいる実在馬 → 救済（初回から漏れていただけ）
        //   凍結集合にいない馬   → 未知馬。応答ごと採用しない
        $frozen  = array_map('intval', $frozenNums);
        $extra   = array_values(array_diff(array_keys($fix), array_keys($first)));
        $unknown = [];
        foreach ($extra as $num) {
            if ($frozen !== [] && in_array((int) $num, $frozen, true)) {
                $rescued[] = (int) $num;
            } else {
                $unknown[] = (int) $num;
            }
        }
        if (!empty($unknown)) {
            sort($unknown);
            return ['ok' => false, 'rescued' => [], 'applied' => [], 'skipped' => [],
                    'reason' => '凍結集合にない馬番を足している（馬番 '
                              . implode('・', $unknown) . '）'];
        }

        // ── 訂正してよい範囲（repair_scope）────────────────────────
        //   horses に挙がっていない馬を変えようとしたら採用しません。
        //   repair_scope が無いときは、この検査をしません（従来どおり）。
        if (is_array($repairScope) && isset($repairScope['horses'])
            && is_array($repairScope['horses'])) {
            $allow = array_map('intval', $repairScope['horses']);
            $out   = [];
            foreach (array_keys($fix) as $num) {
                if (!in_array((int) $num, $allow, true)) { $out[] = (int) $num; }
            }
            if (!empty($out)) {
                sort($out);
                return ['ok' => false, 'rescued' => [], 'applied' => [], 'skipped' => [],
                        'reason' => 'repair_scope の対象外を変えようとしている（馬番 '
                                  . implode('・', $out) . '）'];
            }
        }

        // ── 行の有効性（row_valid）────────────────────────────────
        //   false の行は適用しません。応答ごと落とすのではなく、その行だけ飛ばします。
        $applied = [];
        foreach (array_keys($fix) as $num) {
            if ($rowValid !== [] && array_key_exists((int) $num, $rowValid)
                && $rowValid[(int) $num] !== true) {
                $skipped[] = (int) $num;
                continue;
            }
            $applied[] = (int) $num;
        }
        sort($rescued); sort($applied); sort($skipped);
        return ['ok' => true, 'reason' => null,
                'rescued' => $rescued, 'applied' => $applied, 'skipped' => $skipped];
    }

    /** 訂正を反映した結果。対象外の正常行は初回のままにします */
    public static function applyCorrection(array $first, array $fix,
                                           ?array $accept = null): array
    {
        // @ANCHOR-20261020-R122-REPAIR  採否の結果にある行だけを反映します
        //   $accept を渡さないときは、これまでどおり $fix を全部当てます。
        $out = $first;
        if ($accept === null) {
            foreach ($fix as $num => $h) { $out[$num] = $h; }
            return $out;
        }
        if (($accept['ok'] ?? false) !== true) { return $out; }   // 不採用なら初回のまま
        $allow = array_map('intval',
            array_merge((array) ($accept['applied'] ?? []), (array) ($accept['rescued'] ?? [])));
        foreach ($fix as $num => $h) {
            if (!in_array((int) $num, $allow, true)) { continue; }   // 対象外・row_valid=false
            $out[(int) $num] = $h;
        }
        return $out;
    }
}
