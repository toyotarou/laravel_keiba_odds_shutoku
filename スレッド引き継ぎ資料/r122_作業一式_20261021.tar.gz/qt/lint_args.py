import io,re,sys,glob
# 同じファイルの中の $ok / $check の定義から引数の数を読み取り、呼び出しと突き合わせます
def params(sig):
    # 丸括弧の中をカンマで割る（入れ子と文字列は考えない。定義部は単純なので十分）
    lo=hi=0
    depth=0; cur=''; parts=[]
    for c in sig:
        if c in '([': depth+=1
        elif c in ')]': depth-=1
        if c==',' and depth==0: parts.append(cur); cur=''
        else: cur+=c
    if cur.strip(): parts.append(cur)
    hi=len(parts)
    lo=len([p for p in parts if '=' not in p])
    return lo,hi

bad=[]; checked=0
for p in sorted(glob.glob('/home/claude/r122/patch/methods_*.php')):
    s=io.open(p,encoding='utf-8').read()
    exp={}
    for m in re.finditer(r'\$(ok|check)\s*=\s*(?:static\s+)?(?:function|fn)\s*\(([^)]*)\)', s):
        exp['$'+m.group(1)] = params(m.group(2))
    if not exp: continue
    for m in re.finditer(r'\$(ok|check)\(', s):
        name='$'+m.group(1)
        if name not in exp: continue
        i=m.end(); depth=1; n=1; instr=None; esc=False
        while i < len(s) and depth>0:
            c=s[i]
            if instr:
                if esc: esc=False
                elif c=='\\': esc=True
                elif c==instr: instr=None
            else:
                if c in "'\"": instr=c
                elif c in '([{': depth+=1
                elif c in ')]}':
                    depth-=1
                    if depth==0: break
                elif c==',' and depth==1: n+=1
            i+=1
        lo,hi=exp[name]; checked+=1
        if not (lo<=n<=hi):
            line=s[:m.start()].count('\n')+1
            bad.append('%s:%d %s の引数が %d 個（期待 %d〜%d）'%(p.split('/')[-1],line,name,n,lo,hi))
if bad:
    print('× 引数の数が合わない呼び出し')
    for b in bad: print('   ', b)
    sys.exit(1)
print('○ $ok / $check の引数はすべて定義どおり（%d か所）' % checked)
