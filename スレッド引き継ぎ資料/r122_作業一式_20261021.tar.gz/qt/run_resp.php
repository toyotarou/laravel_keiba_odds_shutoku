<?php
require __DIR__ . '/time.php';
require __DIR__ . '/resp.php';
require __DIR__ . '/diag.php';

$v = __DIR__ . '/../mat/validation';
$ng = 0; $n = 0;
foreach (glob($v . '/normal/*_output.json') as $f) {
    $inF = str_replace('_output', '_input', $f);
    $src = json_decode(file_get_contents($inF), true);
    $doc = json_decode(file_get_contents($f), true);
    $raw = BaganrikiResponse::BEGIN . json_encode($doc, JSON_UNESCAPED_UNICODE) . BaganrikiResponse::END;
    $n++;
    $ex = BaganrikiResponse::extract($raw);
    if (!$ex['ok']) { $ng++; echo "× extract " . basename($f) . " {$ex['reason']}\n"; continue; }
    $res = $ex['json'];
    $env = BaganrikiResponse::checkEnvelope($res, [
        'prompt_version'  => $src['prompt_version']  ?? null,
        'schema_version'  => $src['schema_version']  ?? null,
        'race_id'         => $src['race_id']         ?? null,
        'ai_role'         => $src['ai_role']         ?? null,
        'snapshot_hash'   => $src['snapshot_hash']   ?? null,
        'mode'            => $src['mode']            ?? null,
        'mode_status'     => $src['mode_status']     ?? null,
        'allocation_mode' => $src['allocation_mode'] ?? null,
        'mode_policy_id'  => $src['mode_policy_id']  ?? null,
        'role_cap'        => $src['role_cap']        ?? null,
        'role_quota'      => $src['role_quota']      ?? null,
    ]);
    if (!$env['ok']) { $ng++; echo "× envelope " . basename($f) . " {$env['reason']}\n"; continue; }
    $frozen = array_map(fn($r) => (int) $r['horse_no'], $src['runners']);
    $iso = BaganrikiResponse::isolateHorses($res['horses'], $frozen);
    $d = BaganrikiDiagnose::run($res, $src);
    $normal = [];
    foreach ($iso['kept'] as $no => $h) {
        if (($d['row_valid'][$no] ?? true) !== true) continue;
        $normal[$no] = $h;
    }
    if (!$d['ok'] || count($normal) !== count($frozen) || $iso['isolated'] !== [] || $iso['missing'] !== []) {
        $ng++;
        echo "× " . basename($f) . " ok=" . var_export($d['ok'], true)
           . " normal=" . count($normal) . "/" . count($frozen)
           . " iso=" . count($iso['isolated']) . " missing=" . count($iso['missing']) . "\n";
        foreach (array_slice($d['findings'], 0, 4) as $x) {
            echo "    [{$x['scope']}] " . var_export($x['target'], true) . " {$x['code']} {$x['reason']}\n";
        }
    } else {
        echo "○ " . basename($f) . "  全" . count($normal) . "頭が残り、直すところなし\n";
    }
}
echo "\n正常出力 $n 本 / 落ちた $ng 本\n";
