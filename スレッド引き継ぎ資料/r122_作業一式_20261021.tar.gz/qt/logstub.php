<?php
final class Log {
    public static function __callStatic($m, $a) { /* 試験では捨てます */ }
}
function app($c = null) { return new Ctrl(); }
