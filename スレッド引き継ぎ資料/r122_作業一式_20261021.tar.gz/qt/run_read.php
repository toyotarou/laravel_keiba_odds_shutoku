<?php
require __DIR__ . '/shim.php';
require __DIR__ . '/resp_helper.php';
require __DIR__ . '/tail_classes.php';
require __DIR__ . '/ctrl3.php';
function qt_out($s = '') { echo $s . "\n"; }
QtDb::$pdo = new PDO('sqlite::memory:');
QtDb::$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
qt_schema();
QtDb::$pdo->exec('CREATE TABLE baganriki_validation_results (
    id INTEGER PRIMARY KEY AUTOINCREMENT, attempt_id INTEGER NOT NULL,
    validator_version TEXT NOT NULL, normal_part TEXT, diagnostics TEXT,
    repair_scope TEXT, field_sources TEXT, rank_sources TEXT, created_at TEXT NOT NULL)');
QtDb::$pdo->exec('CREATE TABLE baganriki_publications (
    id INTEGER PRIMARY KEY AUTOINCREMENT, publication_id TEXT NOT NULL UNIQUE,
    snapshot_id INTEGER NOT NULL, intent_id INTEGER NOT NULL, published_at TEXT NOT NULL,
    prediction_target_count INTEGER, prediction_quota TEXT,
    publication_target_count INTEGER, publication_quota TEXT, active_count INTEGER,
    candidates TEXT, evidence TEXT, shortfalls TEXT, used_state_revision INTEGER,
    used_response_revision INTEGER, public_proof_hash TEXT)');
QtDb::$pdo->exec('CREATE TABLE baganriki_publication_intents (
    id INTEGER PRIMARY KEY AUTOINCREMENT, snapshot_id INTEGER NOT NULL,
    job_id TEXT NOT NULL UNIQUE, intent_hash TEXT NOT NULL,
    read_state_revision INTEGER, read_response_revision INTEGER,
    read_publication_revision INTEGER, state TEXT NOT NULL DEFAULT "OPEN",
    publication_id TEXT, created_at TEXT NOT NULL, UNIQUE (snapshot_id, intent_hash))');
QtDb::$pdo->exec('CREATE TABLE t_horse_odds_finder_races (
    date TEXT, kaisuu TEXT, basho TEXT, day TEXT, race INTEGER, num_horses INTEGER,
    start_time TEXT, basho_name TEXT, race_name TEXT)');
QtDb::$pdo->exec("INSERT INTO t_horse_odds_finder_races VALUES
    ('2026-10-18','4','04','2',1,16,'10:05','新潟','1R')");
$root = __DIR__ . '/../mat';
(function () use ($root) {

        
        $vDir = rtrim($root, '/') . '/validation/normal';
        qt_out('════════════════════════════════════════════════════════');
        qt_out(' r12.2 読取APIの通し試験');
        qt_out('════════════════════════════════════════════════════════');
        qt_out('  実行時刻 : ' . date('c'));
        qt_out('  ※ 全部ロールバックします。DBへ残る書き込みは0件です');
        qt_out('');
        foreach (['MIXED_N16_1st_input.json', 'MIXED_N16_1st_output.json',
                  'MIXED_N16_2nd_input.json', 'MIXED_N16_2nd_output.json'] as $f) {
            if (!is_file($vDir . '/' . $f)) {
                qt_out('  × ' . $vDir . '/' . $f . ' がありません');
                return;
            }
        }
        $pass = 0; $fail = 0;
        $check = function (string $id, string $what, $got, $want) use (&$pass, &$fail) {
            $okk = ($got === $want);
            if ($okk) { $pass++; } else { $fail++; }
            qt_out(sprintf('  %s %-9s %-50s %s',
                $okk ? '○' : '×', $id, $what,
                $okk ? '' : ('得=' . var_export($got, true) . ' 期待=' . var_export($want, true))));
        };
        $rd = static fn(string $f) => json_decode((string) file_get_contents($f), true);
        $j  = static fn($v) => (string) json_encode($v,
            JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PRESERVE_ZERO_FRACTION);
        $in1  = $rd($vDir . '/MIXED_N16_1st_input.json');
        $in2  = $rd($vDir . '/MIXED_N16_2nd_input.json');
        $out1 = $rd($vDir . '/MIXED_N16_1st_output.json');
        $out2 = $rd($vDir . '/MIXED_N16_2nd_output.json');
        $BEGIN = \App\Http\Controllers\Api\BaganrikiResponse::BEGIN;
        $END   = \App\Http\Controllers\Api\BaganrikiResponse::END;
        $WK    = \App\Http\Controllers\Api\BaganrikiWorker::class;

        $r = \DB::table('t_horse_odds_finder_races')->where('date', '2026-10-18')
                ->orderBy('basho')->orderBy('race')->first();
        if ($r === null) { qt_out('  × 2026-10-18 のレースがありません'); return; }
        $raceId = \App\Http\Controllers\Api\AiController::r122RaceId(
            $r->date, $r->kaisuu, $r->basho, $r->day, $r->race);
        qt_out('  対象レース : ' . $raceId);
        qt_out('');

        $ok = true;
        \DB::beginTransaction();
        try {
            $ctrl = new \App\Http\Controllers\Api\AiController();
            $now   = $WK::nowUs();
            $sales = $now + 3600 * 1000000;
            $nums  = [];
            foreach ((array) $in1['runners'] as $x) { $nums[] = (int) $x['horse_no']; }

            $mkSnap = function (int $gen) use ($raceId, $in1, $in2, $nums, $sales,
                                               $now, $j, $WK): int {
                return (int) \DB::table('baganriki_snapshots')->insertGetId([
                    'race_id' => $raceId, 'generation' => $gen,
                    'run_id' => 'AT-' . $gen,
                    'snapshot_hash'   => (string) $in1['snapshot_hash'],
                    'input_json_1st'  => $j($in1), 'input_json_2nd' => $j($in2),
                    'frozen_nums'     => $j($nums),
                    'allocation_mode' => (string) $in1['allocation_mode'],
                    'mode'            => ($gen === 0) ? 'MIXED' : 'REPLAYMODE',
                    'mode_status'     => (string) $in1['mode_status'],
                    'mode_policy_id'  => (string) $in1['mode_policy_id'],
                    'display_rating'  => 3,
                    'target_count'    => (int) $in1['target_count'],
                    'quota_1st'       => $j($in1['quota']),
                    'coverage'        => $j(['past_runs' => ['status' => 'INCLUDED']]),
                    'collection_audit' => $j(['6' => ['status' => 'ADOPTED']]),
                    'input_freeze_at' => $WK::toDb($now - 100),
                    'sales_close_at'  => $WK::toDb($sales),
                    'created_at'      => $WK::toDb($now),
                ]);
            };
            // REPLAY を先に入れて、公開APIが拾わないことを見ます
            $sid900 = $mkSnap(900);
            $sid0   = $mkSnap(0);
            \DB::table('baganriki_live_states')->insert([
                'snapshot_id' => $sid0, 'cancellations' => $j([]),
                'active_count' => count($nums),
                'live_target_count' => (int) $in1['target_count'],
                'live_quota' => $j($in1['quota']), 'live_close' => null,
                'state_revision' => 0, 'response_revision' => 0,
                'publication_revision' => 0, 'latest_publication_id' => null,
                'updated_at' => $WK::toDb($now),
            ]);
            foreach ([['1st', $out1], ['2nd', $out2]] as $pair) {
                [$role, $doc] = $pair;
                \DB::table('baganriki_ai_attempts')->insert([
                    'snapshot_id' => $sid0, 'role' => $role, 'attempt_no' => 0,
                    'token' => hash('sha256', 'AT' . $sid0 . $role),
                    'status' => $WK::RECEIVED,
                    'reserved_at' => $WK::toDb($now), 'received_at' => $WK::toDb($now),
                    'complete' => 1, 'raw_response' => $BEGIN . $j($doc) . $END,
                    'response_hash' => hash('sha256', $j($doc)),
                ]);
            }

            // ── ① 未公開（期限内）──────────────────────────────────
            qt_out('── ① 未公開（期限内）──');
            $d = $ctrl->getBaganrikiR122Race($raceId)->getData(true);
            $check('A-01', '期限内・未公開は PENDING', $d['state'], 'PENDING');
            $check('A-02', 'REPLAY の世代を読まない', $d['mode'], 'MIXED');
            $check('A-03', '確定なら星を出す', $d['display_rating'], 3);
            $check('A-04', '購入推奨は常に false', $d['buy_recommended'], false);
            $check('A-05', '学習段階は COLLECT_ONLY', $d['learning_stage'], 'COLLECT_ONLY');
            $check('A-06', 'model_version は null', $d['model_version'], null);
            $check('A-07', '3つの版を返す',
                   [$d['live_state']['state_revision'],
                    $d['live_state']['response_revision'],
                    $d['live_state']['publication_revision']], [0, 0, 0]);
            $ws = (array) ($d['worker_state'] ?? []);
            $check('A-08', 'ワーカーの状態を2枠ぶん返す', count($ws), 2);
            $keys = ($ws === []) ? [] : array_keys($ws[0]);
            $check('A-09', '予約token を返さない',
                   in_array('token', $keys, true), false);
            $check('A-10', '原応答を返さない',
                   in_array('raw_response', $keys, true), false);
            $check('A-11', '未公開では公開欄が null', $d['publication'], null);

            // ── ② 公開したあと ────────────────────────────────────
            qt_out('── ② 公開したあと ──');
            $p = $ctrl->r122Publish($sid0);
            $check('A-12', '公開できる', $p['code'], 'PUBLISHED');
            $d = $ctrl->getBaganrikiR122Race($raceId)->getData(true);
            $check('A-13', '公開済みは PUBLISHED', $d['state'], 'PUBLISHED');
            $check('A-14', '公開IDが一致',
                   (string) $d['publication']['publication_id'],
                   (string) $p['publication_id']);
            $pq = (array) $d['publication']['publication_quota'];
            $check('A-15', '公開した枠がそのまま入る', $pq, (array) $p['quota']);
            $check('A-16', 'いまの枠も同じ（取消なし）',
                   (array) $d['live_state']['actual_quota'], $pq);
            $check('A-17', '公開候補の数', $d['live_state']['available_candidate_count'],
                   count($p['candidates']));
            $check('A-18', 'publication_revision が1になる',
                   $d['live_state']['publication_revision'], 1);

            // ── ③ 取消を入れる（正式公開は動かさない）──────────────
            qt_out('── ③ 取消を入れる ──');
            $gone = (int) $p['candidates'][0]['horse_no'];
            $goneBand = (string) $p['candidates'][0]['band'];
            \DB::table('baganriki_live_states')->where('snapshot_id', $sid0)->update([
                'cancellations' => $j([$gone]),
                'active_count'  => count($nums) - 1,
                'state_revision' => 1,
            ]);
            $d = $ctrl->getBaganrikiR122Race($raceId)->getData(true);
            $check('A-19', '正式公開の枠は動かさない',
                   (array) $d['publication']['publication_quota'], $pq);
            $want = $pq; $want[$goneBand] = (int) $want[$goneBand] - 1;
            $check('A-20', 'いまの枠は取消を映す',
                   (array) $d['live_state']['actual_quota'], $want);
            $check('A-21', '公開候補の数も1つ減る',
                   $d['live_state']['available_candidate_count'],
                   count($p['candidates']) - 1);
            $check('A-22', '取消の馬番を返す',
                   (array) $d['live_state']['cancellations'], [$gone]);
            $check('A-23', '状態は PUBLISHED のまま', $d['state'], 'PUBLISHED');

            // ── ④ 全頭取消 ────────────────────────────────────────
            qt_out('── ④ 全頭取消 ──');
            \DB::table('baganriki_live_states')->where('snapshot_id', $sid0)->update([
                'cancellations' => $j($nums), 'active_count' => 0,
            ]);
            $d = $ctrl->getBaganrikiR122Race($raceId)->getData(true);
            $check('A-24', '全頭取消は CANCELLED', $d['state'], 'CANCELLED');

            // ── ⑤ 未公開で期限超過 ────────────────────────────────
            qt_out('── ⑤ 未公開で期限超過 ──');
            \DB::table('baganriki_publications')->where('snapshot_id', $sid0)->delete();
            \DB::table('baganriki_live_states')->where('snapshot_id', $sid0)->update([
                'cancellations' => $j([]), 'active_count' => count($nums),
            ]);
            \DB::table('baganriki_snapshots')->where('id', $sid0)->update([
                'sales_close_at' => $WK::toDb($now - 7200 * 1000000),
            ]);
            $d = $ctrl->getBaganrikiR122Race($raceId)->getData(true);
            $check('A-25', '未公開で期限超過は UNAVAILABLE', $d['state'], 'UNAVAILABLE');
            $check('A-26', '実効公開期限を返す',
                   is_string($d['live_state']['effective_publish_deadline']), true);

            // ── ⑥ 暫定のときの表示 ────────────────────────────────
            qt_out('── ⑥ 暫定のときの表示 ──');
            \DB::table('baganriki_snapshots')->where('id', $sid0)->update([
                'mode_status' => 'PROVISIONAL', 'mode' => 'UNKNOWN',
                'sales_close_at' => $WK::toDb($sales),
            ]);
            $d = $ctrl->getBaganrikiR122Race($raceId)->getData(true);
            $check('A-27', '暫定では星を出さない', $d['display_rating'], null);
            $check('A-28', '暫定の表示文を出す',
                   (string) ($d['provisional']['label'] ?? ''), '混戦として暫定選出');
            $check('A-29', '暫定の理由を出す',
                   (string) ($d['provisional']['note'] ?? ''),
                   \App\Http\Controllers\Api\BaganrikiPublicView::PROVISIONAL_NOTE);

        } catch (\Throwable $e) {
            $ok = false; $fail++;
            qt_out('  × 例外: ' . $e->getMessage());
            qt_out('     ' . $e->getFile() . ':' . $e->getLine());
        } finally {
            \DB::rollBack();
        }

        qt_out('');
        qt_out(sprintf('  ロールバック後  snapshot %d／公開 %d／attempts %d',
            \DB::table('baganriki_snapshots')->count(),
            \DB::table('baganriki_publications')->count(),
            \DB::table('baganriki_ai_attempts')->count()));
        qt_out('');
        qt_out('  判定件数 : ' . ($pass + $fail) . ' 件');
        qt_out('  合格     : ' . $pass . ' 件');
        qt_out('  不合格   : ' . $fail . ' 件');
        qt_out('');
        qt_out('════════════════════════════════════════════════════════');
        qt_out(($fail === 0 && $ok)
            ? ' 読取APIは契約どおりに返しました（DBへ残る書き込み0件）'
            : ' 通らなかった箇所があります。上の × をご確認ください');
        qt_out('════════════════════════════════════════════════════════');
    
})();
