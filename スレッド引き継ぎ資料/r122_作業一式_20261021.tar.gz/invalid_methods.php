    /**
     * @ANCHOR-20261020-R122-INVALID  入力の意味検証
     *   Schemaでは分からない「数字の辻褄」を見ます。
     *   @return array 違反の説明（空なら通過）
     */
    public static function r122ContractCheckInput(array $in): array
    {
        $e = [];
        $BP = '\App\Http\Controllers\Api\BaganrikiPrompt';
        $BT = '\App\Http\Controllers\Api\BaganrikiTime';
        $BS = '\App\Http\Controllers\Api\BaganrikiSignals';
        $BA = '\App\Http\Controllers\Api\BaganrikiAllocation';

        // ── 版 ────────────────────────────────────────────────────────
        if (($in['schema_version'] ?? null) !== $BP::SCHEMA_VERSION) $e[] = '版: schema_version が違います';
        if (($in['prompt_version'] ?? null) !== $BP::PROMPT_VERSION) $e[] = '版: prompt_version が違います';
        if (($in['snapshot_hash_version'] ?? null) !== $BP::HASH_VERSION) $e[] = '版: snapshot_hash_version が違います';
        if (($in['learning_stage'] ?? null) !== 'COLLECT_ONLY') $e[] = '学習: learning_stage は COLLECT_ONLY だけです';
        if (array_key_exists('model_version', $in) && $in['model_version'] !== null) $e[] = '学習: model_version は null だけです';

        // ── 時刻の辻褄 ────────────────────────────────────────────────
        $tc = (array) ($in['time_contract'] ?? []);
        $anchor = $BT::us($tc['anchor_at'] ?? null);
        $cut    = $BT::us($in['cutoff_at'] ?? null);
        $frz    = $BT::us($in['input_freeze_at'] ?? null);
        $sales  = $BT::us($tc['sales_close_at'] ?? null);
        $pub    = $BT::us($tc['publish_deadline'] ?? null);
        $rep    = $BT::us($tc['reply_deadline'] ?? null);
        if ($anchor === null) $e[] = '時刻: anchor_at を読めません';
        if ($cut === null)    $e[] = '時刻: cutoff_at を読めません';
        if ($frz === null)    $e[] = '時刻: input_freeze_at を読めません';
        if ($anchor !== null && $cut !== null && $cut !== $BT::cutoff($anchor)) {
            $e[] = '時刻: cutoff_at が 発走−360秒 ではありません';
        }
        if ($cut !== null && $frz !== null && $frz !== $cut + 30 * 1000000) {
            $e[] = '時刻: input_freeze_at が cutoff_at＋30秒 ではありません';
        }
        if ($sales !== null && $pub !== null && $pub !== $BT::publishDeadline($sales)) {
            $e[] = '時刻: publish_deadline が 投票締切−60秒 ではありません';
        }
        if ($sales !== null && $rep !== null && $rep !== $BT::replyDeadline($sales)) {
            $e[] = '時刻: reply_deadline が 公開期限−30秒 ではありません';
        }

        // ── 取得監査 ─────────────────────────────────────────────────
        $ca = (array) ($in['collection_audit'] ?? []);
        $six = $ca['6'] ?? ($ca[6] ?? null);
        if (!is_array($six) || ($six['status'] ?? '') !== 'ADOPTED') {
            $e[] = '取得: 6分前が ADOPTED ではありません';
        }
        foreach ($BT::INPUT_SLOTS as $slot) {
            $a = $ca[(string) $slot] ?? ($ca[$slot] ?? null);
            if (!is_array($a) || ($a['status'] ?? '') !== 'ADOPTED') continue;
            $sch = $BT::us($a['slot_scheduled_at'] ?? null);
            $req = $BT::us($a['request_started_at'] ?? null);
            $res = $BT::us($a['response_received_at'] ?? null);
            $av  = $BT::us($a['available_at'] ?? null);
            $src = $BT::us($a['source_updated_at'] ?? null);
            if ($anchor !== null && $sch !== null && $sch !== $BT::slotScheduled($anchor, $slot)) {
                $e[] = "取得{$slot}: slot_scheduled_at が 発走−{$slot}分 ではありません";
            }
            if ($sch !== null && $req !== null && $req < $sch) {
                $e[] = "取得{$slot}: 予定時刻より前に要求を出しています";
            }
            if ($req !== null && $res !== null && $res < $req) {
                $e[] = "取得{$slot}: 受信が要求より前になっています";
            }
            if ($res !== null && $av !== null && $av < $res) {
                $e[] = "取得{$slot}: 利用可能が受信より前になっています";
            }
            $grace = ($BT::GRACE_MS[$slot] ?? 120000) * 1000;
            if ($sch !== null && $av !== null && $av > $sch + $grace) {
                $e[] = "取得{$slot}: 取得猶予を超えています";
            }
            if ($frz !== null && $av !== null && $av > $frz) {
                $e[] = "取得{$slot}: 情報上限（input_freeze_at）より後の値です";
            }
            if ($src !== null && $res !== null && $src > $res) {
                $e[] = "取得{$slot}: 取得元の更新時刻が受信より未来です";
            }
        }

        // ── 信号と mode ──────────────────────────────────────────────
        $sig = (array) ($in['signals'] ?? []);
        $tri = static function ($v) {
            if ($v === true)  return 'TRUE';
            if ($v === false) return 'FALSE';
            return 'UNKNOWN';
        };
        $flags = [];
        foreach (['X1', 'X2', 'X3', 'X4', 'X5', 'X6', 'Z'] as $k) {
            $flags[$k] = $tri($sig[$k] ?? null);
        }
        $N = (int) ($in['N'] ?? 0);
        if ($N >= 7 && ($sig['X6'] ?? null) !== null) {
            $e[] = 'X6: N>=7 では null だけです（決着事項①B案）';
        }
        if ($N > 0 && $N < 7 && ($sig['X6'] ?? null) !== false) {
            $e[] = 'X6: N<7 では false だけです（決着事項①B案）';
        }
        $cls = $BS::v04Classify($flags);
        foreach ([['S', 'S'], ['S_min', 'S_min'], ['S_max', 'S_max']] as [$k, $kk]) {
            if (array_key_exists($k, $in) && $in[$k] !== $cls[$kk]) {
                $e[] = "mode: {$k} が信号から計算した値と違います（"
                     . json_encode($in[$k]) . ' / ' . json_encode($cls[$kk]) . '）';
            }
        }
        foreach (['mode', 'mode_status', 'allocation_mode', 'mode_policy_id',
                  'selection_enabled', 'display_rating'] as $k) {
            if (array_key_exists($k, $in) && $in[$k] !== $cls[$k]) {
                $e[] = "mode: {$k} が信号から決まる値と違います（"
                     . json_encode($in[$k]) . ' / ' . json_encode($cls[$k]) . '）';
            }
        }

        // ── 配分 ─────────────────────────────────────────────────────
        if ($N > 0) {
            $al = $BA::v04Allocation($N, $cls);
            foreach (['target_count', 'base_quota', 'quota'] as $k) {
                $want = ($k === 'target_count') ? $al['target_count']
                      : (($k === 'base_quota') ? ($al['base_quota'] ?? null) : $al['quota']);
                if (array_key_exists($k, $in)
                    && json_encode($in[$k]) !== json_encode($want)) {
                    $e[] = "配分: {$k} が N と mode から決まる値と違います（"
                         . json_encode($in[$k]) . ' / ' . json_encode($want) . '）';
                }
            }
            $role = (string) ($in['ai_role'] ?? '1st');
            $wantRq = ($cls['selection_enabled'] === false) ? null
                    : (($role === '2nd') ? $al['quota_2nd'] : $al['quota']);
            if (array_key_exists('role_quota', $in)
                && json_encode($in['role_quota']) !== json_encode($wantRq)) {
                $e[] = '配分: role_quota が指定と違います（'
                     . json_encode($in['role_quota']) . ' / ' . json_encode($wantRq) . '）';
            }
            $wantCap = ($cls['selection_enabled'] === false) ? 0
                     : (($role === '2nd') ? min(5, (int) $al['target_count'])
                                          : (int) $al['target_count']);
            if (array_key_exists('role_cap', $in) && (int) $in['role_cap'] !== $wantCap) {
                $e[] = '配分: role_cap が指定と違います（'
                     . json_encode($in['role_cap']) . ' / ' . $wantCap . '）';
            }
        }

        // ── 凍結集合 ─────────────────────────────────────────────────
        $runners = (array) ($in['runners'] ?? []);
        if ($N > 0 && count($runners) !== $N) {
            $e[] = '頭数: runners の件数が N と違います';
        }
        $ranks = [];
        foreach ($runners as $r) {
            $ranks[] = (int) ($r['win_rank'] ?? 0);
            $want = $BA::v04Band((int) ($r['win_rank'] ?? 0));
            if (($r['band'] ?? null) !== $want) {
                $e[] = '帯: 馬番 ' . ($r['horse_no'] ?? '?') . ' の帯が人気と合いません';
            }
        }
        sort($ranks);
        if ($ranks !== range(1, count($ranks))) {
            $e[] = '順位: 凍結人気が 1..N の連番になっていません';
        }

        return $e;
    }

    /**
     * @ANCHOR-20261020-R122-INVALID  出力の意味検証
     *   対になる入力を使わず、出力だけで分かる矛盾を見ます。
     *   @return array 違反の説明（空なら通過）
     */
    public static function r122ContractCheckOutput(array $res): array
    {
        $e = [];
        $BP = '\App\Http\Controllers\Api\BaganrikiPrompt';
        $BS = '\App\Http\Controllers\Api\BaganrikiSignals';
        $BA = '\App\Http\Controllers\Api\BaganrikiAllocation';

        if (($res['schema_version'] ?? null) !== $BP::SCHEMA_VERSION) $e[] = '版: schema_version が違います';
        if (($res['prompt_version'] ?? null) !== $BP::PROMPT_VERSION) $e[] = '版: prompt_version が違います';
        if (($res['learning_stage'] ?? null) !== 'COLLECT_ONLY')      $e[] = '学習: learning_stage は COLLECT_ONLY だけです';

        // 入力専用のキーを返していないか（契約9章）
        foreach (['input_freeze_at', 'collection_audit', 'signals', 'S', 'S_min',
                  'S_max', 'buy_recommended', 'source_registry', 'field_catalog',
                  'input_indices', 'coverage', 'time_contract', 'cutoff_at',
                  'base_quota', 'runners'] as $k) {
            if (array_key_exists($k, $res)) $e[] = '出力: 入力専用のキーを返しています（' . $k . '）';
        }

        // mode 一式の内部の辻褄
        $ms = $res['mode_status'] ?? null;
        $am = $res['allocation_mode'] ?? null;
        $mp = $res['mode_policy_id'] ?? null;
        $md = $res['mode'] ?? null;
        $sel = $res['selection_enabled'] ?? null;
        if ($ms === 'PROVISIONAL') {
            if ($md !== 'UNKNOWN')                   $e[] = 'mode: 暫定では正式modeは UNKNOWN のままです';
            if ($mp !== 'X6_ONLY_UPPER_MODE_V1')     $e[] = 'mode: 暫定の mode_policy_id が違います';
            if (!in_array($am, ['MIXED', 'VOLATILE'], true)) $e[] = 'mode: 暫定の allocation_mode が違います';
        }
        if ($ms === 'CONFIRMED') {
            if ($mp !== 'BASE_TRI_STATE_V1')         $e[] = 'mode: 確定の mode_policy_id が違います';
            if ($am !== $md)                         $e[] = 'mode: 確定では allocation_mode は正式modeと同じです';
        }
        if ($ms === 'UNRESOLVED') {
            if ($am !== null)                        $e[] = 'mode: 判定不能では allocation_mode は null です';
            if ($sel !== false)                      $e[] = 'mode: 判定不能では selection_enabled は false です';
        }

        // role と枠
        $role = $res['ai_role'] ?? null;
        if (!in_array($role, ['1st', '2nd'], true)) $e[] = 'role: ai_role が 1st / 2nd ではありません';
        $rq  = $res['role_quota'] ?? null;
        $cap = $res['role_cap'] ?? null;
        if ($sel === false) {
            if ($cap !== 0 || $rq !== null) $e[] = 'role: 選出停止では role_cap=0・role_quota=null です';
        } else {
            if (!is_array($rq)) {
                $e[] = 'role: role_quota がありません';
            } else {
                $sum = (int) ($rq['A'] ?? 0) + (int) ($rq['B'] ?? 0) + (int) ($rq['D'] ?? 0);
                if ($sum !== (int) $cap) $e[] = 'role: role_quota の合計が role_cap と合いません';
            }
            if ($role === '2nd' && (int) $cap > 5) $e[] = 'role: 2ndの role_cap が5を超えています';
            $tc = $res['target_count'] ?? null;
            if ($role === '1st' && $tc !== null && (int) $cap !== (int) $tc) {
                $e[] = 'role: 1stの role_cap は target_count と同じです';
            }
            if ($role === '2nd' && $tc !== null && (int) $cap !== min(5, (int) $tc)) {
                $e[] = 'role: 2ndの role_cap は min(5, target_count) です';
            }
        }

        // 全頭と順位
        $horses = (array) ($res['horses'] ?? []);
        $br = (array) ($res['band_ranks'] ?? []);
        $er = (array) ($res['evidence_band_ranks'] ?? []);
        $inBr = []; foreach ($br as $b => $list) foreach ((array) $list as $n) $inBr[(int) $n] = (string) $b;
        $inEr = []; foreach ($er as $b => $list) foreach ((array) $list as $n) $inEr[(int) $n] = (string) $b;
        foreach ($horses as $h) {
            $no = (int) ($h['horse_no'] ?? 0);
            $el = (string) ($h['eligibility'] ?? '');
            if ($el === 'ELIGIBLE') {
                if (!isset($inBr[$no])) $e[] = '全頭: 適格馬 ' . $no . ' が band_ranks にいません';
                if (!isset($inEr[$no])) $e[] = '全頭: 適格馬 ' . $no . ' が evidence_band_ranks にいません';
                if (isset($inBr[$no]) && $inBr[$no] !== (string) ($h['band'] ?? ''))
                    $e[] = '全頭: 馬番 ' . $no . ' の帯と順位の帯が違います';
            } else {
                if (isset($inBr[$no]) || isset($inEr[$no]))
                    $e[] = '全頭: 非適格馬 ' . $no . ' が順位に入っています';
                if (($h['rank_basis'] ?? null) !== 'NOT_RANKED')
                    $e[] = '全頭: 非適格馬 ' . $no . ' の rank_basis は NOT_RANKED です';
            }
        }
        foreach (array_keys($inBr) as $no) {
            $found = false;
            foreach ($horses as $h) if ((int) ($h['horse_no'] ?? 0) === $no) { $found = true; break; }
            if (!$found) $e[] = '全頭: band_ranks の馬番 ' . $no . ' が horses にいません';
        }

        // 公開候補は帯の先頭から飛ばさずに取る
        if (is_array($rq)) {
            $eligByBand = [];
            foreach ($horses as $h) {
                if ((string) ($h['eligibility'] ?? '') !== 'ELIGIBLE') continue;
                $eligByBand[(string) ($h['band'] ?? '')][] = (int) $h['horse_no'];
            }
            $want = [];
            foreach (['A', 'B', 'D'] as $b) {
                $list = array_values(array_filter((array) ($br[$b] ?? []),
                    static fn($n) => in_array((int) $n, $eligByBand[$b] ?? [], true)));
                $take = min((int) ($rq[$b] ?? 0), count($list));
                for ($i = 0; $i < $take; $i++) $want[] = (int) $list[$i];
            }
            $got = array_map('intval', (array) ($res['public_candidates'] ?? []));
            if ($got !== $want) {
                $e[] = '公開候補: 帯の先頭から枠数ぶん取っていません（得た値 '
                     . json_encode($got) . ' / 期待値 ' . json_encode($want) . '）';
            }
            foreach ($horses as $h) {
                $no = (int) ($h['horse_no'] ?? 0);
                $isPub = (bool) ($h['public_candidate'] ?? false);
                if ($isPub !== in_array($no, $want, true)) {
                    $e[] = '公開候補: 馬番 ' . $no . ' の public_candidate が公開リストと合いません';
                }
                if ($isPub && ($h['nonselect_reason'] ?? null) !== null) {
                    $e[] = '公開候補: 選出馬 ' . $no . ' に nonselect_reason が付いています';
                }
                if (!$isPub && !is_array($h['nonselect_reason'] ?? null)) {
                    $e[] = '公開候補: 非選出馬 ' . $no . ' の nonselect_reason がオブジェクトではありません';
                }
            }
        }

        return $e;
    }
