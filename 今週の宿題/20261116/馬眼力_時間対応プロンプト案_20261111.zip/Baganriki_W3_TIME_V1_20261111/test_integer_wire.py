"""R4: JSON integer values must not depend on parser representation."""
import copy
from decimal import Decimal
import unittest
from reference_adapter import (SCHEMA, PROMPT, BEGIN, END, CAPS, ContractError,
    strict_loads, dumps_exact, validate_schema, score_totals)
from request_guard import expand_checked_request, receipt_hash, same_value
from test_contract import fixture


def request_for(frozen, reply):
    return {'response_contract': {'schema_version': SCHEMA, 'prompt_version': PROMPT,
            'request_id': reply['request_id']}, 'input': copy.deepcopy(frozen)}


class ExactIntegerWireTests(unittest.TestCase):
    def expand(self, frozen, reply):
        return expand_checked_request(request_for(frozen, reply), reply, frozen, reply['request_id'])

    def decimal_fields(self, role='2nd'):
        frozen, reply = fixture(role=role)
        for horse in reply['horses']:
            horse['horse_no'] = Decimal(str(horse['horse_no']) + '.0')
            for score in horse['scores'].values():
                if score['value'] is not None:
                    score['value'] = Decimal(str(score['value']) + '.0')
        for band in reply['evidence_band_ranks']:
            reply['evidence_band_ranks'][band] = [Decimal(str(n)+'.0') for n in reply['evidence_band_ranks'][band]]
        reply['validation_issues'] = [{'code': 'TEST', 'severity': 'INFO', 'horse_no': Decimal('1.0'),
            'field': 'scores.H1', 'reason': '数値表記9.0の構造試験'}]
        if role == '1st':
            reply['race_metrics']['wave_level'].update(value=Decimal('2.0'),
                source_refs=['h1_win_odds_12', 'h1_win_odds_6', 'h2_win_odds_12', 'h2_win_odds_6'])
        return frozen, reply

    def test_integral_score_survives_exact_json_reading(self):
        frozen, reply = fixture()
        reply['horses'][0]['scores']['H1']['value'] = Decimal('9.0')
        decoded = strict_loads(dumps_exact(reply))
        validate_schema(decoded)
        packet = self.expand(frozen, decoded)
        self.assertIs(type(packet['horses'][0]['scores']['H1']), int)
        self.assertEqual(packet['horses'][0]['scores']['H1'], 9)
        self.assertEqual(score_totals(packet['horses'][0]['scores'])['score_status'], 'partial')

    def test_all_declared_integer_fields_become_ints_in_packet(self):
        for role in ('1st', '2nd'):
            with self.subTest(role=role):
                frozen, reply = self.decimal_fields(role)
                packet = self.expand(frozen, strict_loads(dumps_exact(reply)))
                for horse in packet['horses']:
                    self.assertIs(type(horse['horse_no']), int)
                    for value in horse['scores'].values():
                        self.assertTrue(value is None or type(value) is int)
                for band in packet['evidence_band_ranks'].values():
                    self.assertTrue(all(type(n) is int for n in band))
                self.assertIs(type(packet['validation_issues'][0]['horse_no']), int)
                if role == '1st': self.assertIs(type(packet['race_metrics']['wave_level']['value']), int)

    def test_exact_source_facts_and_raw_reply_are_not_normalized(self):
        frozen, reply = self.decimal_fields()
        frozen['source_registry']['h1_win_odds_6']['value'] = Decimal('6.0000')
        before = copy.deepcopy(frozen)
        raw = dumps_exact(reply)
        packet = self.expand(frozen, reply)
        self.assertTrue(same_value(before, frozen))
        self.assertEqual(dumps_exact(reply), raw)
        fact = next(x for e in packet['horses'][0]['evidence'] for x in e['facts'] if x['source_ref']=='h1_win_odds_6')
        self.assertEqual(str(fact['value']), '6.0000')
        self.assertEqual(packet['validation_issues'][0]['reason'], '数値表記9.0の構造試験')

    def test_fractional_score_is_never_rounded_to_integer(self):
        for value in ['9.1', '9.000000000000000000000000000001', '-0.000000000000000000000000000001']:
            frozen, reply = fixture()
            reply['horses'][0]['scores']['H1']['value'] = Decimal(value)
            with self.subTest(value=value), self.assertRaisesRegex(ContractError, 'OUTPUT_SCHEMA'):
                self.expand(frozen, reply)

    def test_fractional_identifiers_metrics_and_diagnostics_are_rejected(self):
        for field in ('horse', 'rank', 'metric', 'issue'):
            frozen, reply = self.decimal_fields('1st')
            bad = Decimal('1.000000000000000000000000000001')
            if field == 'horse': reply['horses'][0]['horse_no'] = bad
            if field == 'rank': reply['evidence_band_ranks']['A'][0] = bad
            if field == 'metric': reply['race_metrics']['wave_level']['value'] = bad
            if field == 'issue': reply['validation_issues'][0]['horse_no'] = bad
            with self.subTest(field=field), self.assertRaisesRegex(ContractError, 'OUTPUT_SCHEMA'):
                self.expand(frozen, reply)

    def test_boolean_string_and_binary_float_are_not_integer_values(self):
        for value in [True, False, '9', '9.0', 9.0]:
            frozen, reply = fixture()
            reply['horses'][0]['scores']['H1']['value'] = value
            with self.subTest(value=repr(value)), self.assertRaisesRegex(ContractError, 'OUTPUT_SCHEMA'):
                self.expand(frozen, reply)

    def test_zero_caps_and_null_are_preserved(self):
        for value in [Decimal('0.000'), Decimal('-0.0'), Decimal('18.0')]:
            frozen, reply = fixture()
            reply['horses'][0]['scores']['H1']['value'] = value
            with self.subTest(value=value):
                h = self.expand(frozen, reply)['horses'][0]
                self.assertEqual(h['scores']['H1'], int(value))
                self.assertIsNone(h['scores']['H4'])
                score_totals(h['scores'])
        for value in [Decimal('19.0'), Decimal('1'+'0'*127)]:
            frozen, reply = fixture()
            reply['horses'][0]['scores']['H1']['value'] = value
            with self.subTest(value=value), self.assertRaisesRegex(ContractError, 'OUTPUT_SCHEMA'):
                self.expand(frozen, reply)

    def test_duplicate_rank_ids_remain_duplicates_across_notation(self):
        frozen, reply = fixture()
        reply['evidence_band_ranks']['A'][1] = Decimal('1.0')
        with self.assertRaisesRegex(ContractError, 'OUTPUT_SCHEMA'):
            self.expand(frozen, reply)

    def repair_case(self):
        frozen, first = self.decimal_fields()
        raw = BEGIN+'\n'+dumps_exact(first)+'\n'+END
        reply = copy.deepcopy(first); reply['request_id'] = 'REPAIR-INTEGER'
        scope = {'horses': [], 'ranking_horses': [], 'rank_bands': [], 'race_metrics': []}
        request = request_for(frozen, reply)
        request.update(first_response=copy.deepcopy(first), first_response_hash=receipt_hash(raw),
                       repair_scope=scope, errors=[{'code': 'TEST', 'reason': '整数表記の境界確認'}])
        kwargs = {'first_raw': raw, 'first_request_id': first['request_id'], 'authorized_repair_scope': copy.deepcopy(scope)}
        return frozen, request, reply, kwargs

    def test_integral_first_response_and_same_value_repair_are_accepted(self):
        frozen, request, reply, kwargs = self.repair_case()
        reply['horses'][0]['horse_no'] = 1
        reply['horses'][0]['scores']['H1']['value'] = 9
        packet = expand_checked_request(request, reply, frozen, reply['request_id'], **kwargs)
        self.assertEqual(packet['horses'][0]['scores']['H1'], 9)

    def test_integral_scope_matches_saved_permission_without_expanding_it(self):
        frozen, request, reply, kwargs = self.repair_case()
        request['repair_scope']['horses'] = [Decimal('1.0')]
        kwargs['authorized_repair_scope']['horses'] = [1]
        reply['horses'][0]['scores']['H1']['value'] = Decimal('10.0')
        packet = expand_checked_request(request, reply, frozen, reply['request_id'], **kwargs)
        self.assertEqual(packet['horses'][0]['scores']['H1'], 10)
        reply['horses'][1]['scores']['H1']['value'] = Decimal('10.0')
        with self.assertRaisesRegex(ContractError, 'REPAIR_OUT_OF_SCOPE:h2.scores'):
            expand_checked_request(request, reply, frozen, reply['request_id'], **kwargs)

    def test_fractional_scope_is_rejected(self):
        frozen, request, reply, kwargs = self.repair_case()
        request['repair_scope']['horses'] = [Decimal('1.000000000000000000000000000001')]
        with self.assertRaisesRegex(ContractError, 'REQUEST_SCHEMA'):
            expand_checked_request(request, reply, frozen, reply['request_id'], **kwargs)

    def test_actual_score_change_still_needs_scope(self):
        frozen, request, reply, kwargs = self.repair_case()
        reply['horses'][0]['scores']['H1']['value'] = Decimal('10.0')
        with self.assertRaisesRegex(ContractError, 'REPAIR_OUT_OF_SCOPE:h1.scores'):
            expand_checked_request(request, reply, frozen, reply['request_id'], **kwargs)

    def test_same_value_new_raw_text_does_not_bypass_saved_hash(self):
        frozen, request, reply, kwargs = self.repair_case()
        changed = copy.deepcopy(request['first_response'])
        changed['horses'][0]['scores']['H1']['value'] = 9
        kwargs['first_raw'] = BEGIN+'\n'+dumps_exact(changed)+'\n'+END
        with self.assertRaisesRegex(ContractError, 'FIRST_RESPONSE_HASH_MISMATCH'):
            expand_checked_request(request, reply, frozen, reply['request_id'], **kwargs)


if __name__ == '__main__': unittest.main(verbosity=2)
