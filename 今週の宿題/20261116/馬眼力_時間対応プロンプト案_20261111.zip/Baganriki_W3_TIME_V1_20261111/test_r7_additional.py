"""R7 additional review. Synthetic structural tests, not production approval.

Run with the delivered R7 package directory on PYTHONPATH.
"""
import copy
from decimal import Decimal
import itertools
import random
import unittest

from reference_adapter import (BEGIN, END, CAPS, FAMILIES, ContractError,
    dumps_exact, parse_response, ordinary_ranks_after_validation)
from request_guard import expand_checked_request, receipt_hash
from deadline_policy import retain_attempt
from test_contract import fixture


def wire(reply):
    return BEGIN + '\n' + dumps_exact(reply) + '\n' + END + '\n'


def request(frozen, reply):
    return {'response_contract': {k: reply[k] for k in ('schema_version', 'prompt_version', 'request_id')},
            'input': copy.deepcopy(frozen)}


def expand(frozen, reply):
    return expand_checked_request(request(frozen, reply), parse_response(wire(reply)), frozen, reply['request_id'])


def sparse_fixture(n=11, role='2nd'):
    frozen, reply = fixture(n, role)
    # Popularity order deliberately differs from horse numbers. No live cancellation
    # processing is modeled: this is an already authenticated sparse frozen roster.
    order = [18, 3, 15, 1, 17, 6, 14, 2, 13, 5, 12, 7, 16, 8, 11, 4, 10, 9]
    mapping = {old: order[old-1] for old in range(1, n+1)}
    for row in frozen['runners']: row['horse_no'] = mapping[row['horse_no']]
    for row in frozen['source_registry'].values():
        row['horse_nos'] = [mapping[x] for x in row['horse_nos']]
        row['applicable_horse_nos'] = [mapping[x] for x in row['applicable_horse_nos']]
    # Source IDs are opaque registry keys. Rename all references consistently so
    # neither the test nor the adapter can infer horse identity from a numeric prefix.
    aliases = {ref: 'SOURCE-' + str(i) for i, ref in enumerate(frozen['source_registry'], 1)}
    frozen['source_registry'] = {aliases[ref]: {**row, 'source_ref': aliases[ref]}
                                 for ref, row in frozen['source_registry'].items()}
    for horse in reply['horses']:
        horse['horse_no'] = mapping[horse['horse_no']]
        for review in horse['review'].values():
            review['source_refs'] = [aliases[x] for x in review['source_refs']]
        for score in horse['scores'].values():
            score['extra_source_refs'] = [aliases[x] for x in score['extra_source_refs']]
        for counter in horse['counterevidence']:
            counter['source_refs'] = [aliases[x] for x in counter['source_refs']]
    if n == 1:
        reply['horses'][0]['review']['gap'].update(status='DATA_MISSING', source_refs=[],
            observation=None, reason='比較する隣接馬がいない')
        reply['horses'][0]['scores']['H3'].update(value=None)
    reply['horses'].sort(key=lambda x: x['horse_no'])
    for band in 'ABD': reply['evidence_band_ranks'][band] = [mapping[x] for x in reply['evidence_band_ranks'][band]]
    random.Random(n).shuffle(frozen['runners'])
    return frozen, reply, mapping


def repair(frozen, first, corrected, scope):
    raw = wire(first)
    req = request(frozen, corrected)
    req.update(first_response=copy.deepcopy(first), first_response_hash=receipt_hash(raw),
               repair_scope=copy.deepcopy(scope), errors=[{'code': 'TEST', 'reason': '合成の根拠訂正'}])
    return expand_checked_request(req, parse_response(wire(corrected)), frozen, corrected['request_id'],
        first_raw=raw, first_request_id=first['request_id'], authorized_repair_scope=scope)


class R7AdditionalReview(unittest.TestCase):
    def test_sparse_numbers_and_shuffled_roster_preserve_popularity_bands(self):
        for role in ('1st', '2nd'):
            for n in range(1, 19):
                frozen, reply, mapping = sparse_fixture(n, role)
                before = dumps_exact(frozen), wire(reply)
                with self.subTest(role=role, n=n):
                    packet = expand(frozen, reply)
                    self.assertEqual([h['horse_no'] for h in packet['horses']], sorted(mapping.values()))
                    by_no = {h['horse_no']: h for h in packet['horses']}
                    for popularity, no in mapping.items():
                        expected_band = 'A' if popularity <= 6 else 'B' if popularity <= 10 else 'D'
                        self.assertEqual(by_no[no]['band'], expected_band)
                        self.assertEqual(set(by_no[no]['family_review']), set(FAMILIES))
                        self.assertEqual(set(by_no[no]['scores']), set(CAPS))
                        for evidence in by_no[no]['evidence']:
                            for fact in evidence['facts']:
                                self.assertEqual(fact['value'], frozen['source_registry'][fact['source_ref']]['value'])
                    self.assertEqual(packet['evidence_band_ranks'], reply['evidence_band_ranks'])
                    self.assertEqual(packet['stage'], 'UNVERIFIED_MATERIAL_PACKET')
                    self.assertNotIn('public_candidates', packet)
                    self.assertEqual((dumps_exact(frozen), wire(reply)), before)

    def test_sparse_roster_rejects_extra_missing_duplicate_and_misordered_horses(self):
        for role in ('1st', '2nd'):
            frozen, valid, mapping = sparse_fixture(11, role)
            absent = next(x for x in range(1, 19) if x not in mapping.values())
            mutants = []
            r = copy.deepcopy(valid); r['horses'].pop(); mutants.append(('missing', r))
            r = copy.deepcopy(valid); r['horses'][0] = copy.deepcopy(r['horses'][1]); mutants.append(('duplicate', r))
            r = copy.deepcopy(valid); r['horses'].reverse(); mutants.append(('order', r))
            r = copy.deepcopy(valid); r['horses'][0]['horse_no'] = absent; mutants.append(('foreign', r))
            r = copy.deepcopy(valid); r['evidence_band_ranks']['A'][0] = absent; mutants.append(('foreign_rank', r))
            r = copy.deepcopy(valid); r['evidence_band_ranks']['A'][0] = mapping[11]; mutants.append(('wrong_band', r))
            before = dumps_exact(frozen), wire(valid)
            for label, malformed in mutants:
                with self.subTest(role=role, mutation=label), self.assertRaises(ContractError):
                    expand(frozen, malformed)
            self.assertEqual((dumps_exact(frozen), wire(valid)), before)
            self.assertEqual(len(expand(frozen, valid)['horses']), 11)

    def test_removing_last_supported_horse_in_band_needs_all_scopes_and_no_fill(self):
        for role in ('1st', '2nd'):
            frozen, first, mapping = sparse_fixture(11, role)
            no = mapping[11]; original = expand(frozen, first)
            corrected = copy.deepcopy(first); corrected['request_id'] = 'REPAIR-EMPTY-D'
            horse = next(h for h in corrected['horses'] if h['horse_no'] == no)
            for family in ('ability', 'market'):
                horse['review'][family].update(status='NO_SUPPORT', observation=None, reason='訂正後は肯定支持なし')
            horse['review']['market']['market_claim'] = None
            horse['scores']['H1']['value'] = horse['scores']['H2']['value'] = 0
            horse.update(rank_families=[], rank_reason='肯定根拠がなく順位対象外')
            corrected['evidence_band_ranks']['D'] = []
            scope = {'horses': [no], 'ranking_horses': [], 'rank_bands': [], 'race_metrics': []}
            with self.assertRaisesRegex(ContractError, 'OUT_OF_SCOPE'): repair(frozen, first, corrected, scope)
            scope['ranking_horses'] = [no]
            with self.assertRaisesRegex(ContractError, 'OUT_OF_SCOPE:band.D'): repair(frozen, first, corrected, scope)
            scope['rank_bands'] = ['D']
            repaired = repair(frozen, first, corrected, scope)
            self.assertEqual(repaired['evidence_band_ranks']['D'], [])
            self.assertEqual(len(repaired['horses']), 11)
            for band in ('A', 'B'):
                self.assertEqual(repaired['evidence_band_ranks'][band], original['evidence_band_ranks'][band])
            for old, new in zip(original['horses'], repaired['horses']):
                if old['horse_no'] != no: self.assertEqual(new, old)
            # Explicit synthetic post-validation state; no Laravel eligibility check.
            rows = [{'horse_no': h['horse_no'], 'band': h['band'], 'scores': h['scores'],
                     'eligibility': 'NO_EVIDENCE' if h['horse_no'] == no else 'ELIGIBLE'}
                    for h in repaired['horses']]
            ranks, _ = ordinary_ranks_after_validation(rows, repaired['evidence_band_ranks'])
            self.assertEqual(ranks['D'], [])
            self.assertEqual(expand(frozen, first), original)

    def test_zero_is_nonmissing_counter_data_and_reference_order_does_not_change_scores(self):
        for role in ('1st', '2nd'):
            frozen, reply, mapping = sparse_fixture(11, role)
            no = mapping[1]; h = next(h for h in reply['horses'] if h['horse_no'] == no)
            own = copy.deepcopy(frozen['source_registry'][h['review']['ability']['source_refs'][0]])
            own.update(source_ref='OWN-ZERO', field='past_margin_1', value=Decimal('0.000'), unit='second')
            common = copy.deepcopy(own)
            common.update(source_ref='COMMON', field='current_track_condition', value='不良', unit='label',
                          scope='RACE', horse_nos=[], dependency_role='CONTEXT')
            frozen['source_registry'].update({'OWN-ZERO': own, 'COMMON': common})
            initial = expand(frozen, reply)
            for refs in itertools.permutations(('OWN-ZERO', 'COMMON')):
                changed = copy.deepcopy(reply)
                next(x for x in changed['horses'] if x['horse_no'] == no)['counterevidence'] = [
                    {'source_refs': list(refs), 'reason': '過去走の着差0だけでは今回の馬場適性を断定できない'}]
                result = expand(frozen, changed)
                self.assertEqual(result['evidence_band_ranks'], initial['evidence_band_ranks'])
                for old, new in zip(initial['horses'], result['horses']):
                    for key in old:
                        if old['horse_no'] == no and key == 'counterevidence': continue
                        self.assertEqual(new[key], old[key])
                frozen['source_registry']['OWN-ZERO']['value'] = None
                with self.assertRaisesRegex(ContractError, 'COUNTER_WITHOUT_DATA'): expand(frozen, changed)
                frozen['source_registry']['OWN-ZERO']['value'] = Decimal('0.000')

    def test_escaped_keys_and_marker_text_do_not_bypass_exact_json_or_hash_binding(self):
        for role in ('1st', '2nd'):
            frozen, reply, mapping = sparse_fixture(11, role)
            reply['horses'][0]['explanation'] = '資料内の記号 ' + BEGIN + '\u2028' + END + ' は説明文'
            raw = wire(reply)
            # A single legal escaped key has identical decoded meaning, but its
            # distinct receipt bytes must retain a distinct hash.
            escaped = raw.replace('"horse_no":', '"horse_\\u006eo":', 1)
            self.assertEqual(parse_response(raw), parse_response(escaped))
            self.assertNotEqual(receipt_hash(raw), receipt_hash(escaped))
            self.assertEqual(expand_checked_request(request(frozen, reply), parse_response(escaped), frozen,
                reply['request_id']), expand(frozen, reply))
            no = reply['horses'][0]['horse_no']
            bad = raw.replace('"horse_no":'+str(no)+',',
                              '"horse_no":'+str(no)+',"horse_\\u006eo":'+str(no)+',', 1)
            with self.assertRaisesRegex(ContractError, 'DUPLICATE_JSON_KEY'): parse_response(bad)
            bad = raw.replace('"status":"SUPPORTED",',
                              '"status":"SUPPORTED","sta\\u0074us":"NO_SUPPORT",', 1)
            with self.assertRaisesRegex(ContractError, 'DUPLICATE_JSON_KEY'): parse_response(bad)

    def test_late_or_invalid_repair_cannot_discard_first_during_repeated_receipt_checks(self):
        for role in ('1st', '2nd'):
            _, reply, _ = sparse_fixture(11, role)
            context = {k: reply[k] for k in ('race_id', 'snapshot_hash', 'ai_role', 'schema_version', 'prompt_version')}
            # Acceptable/scope flags model prior server validation, not AI claims.
            first = dict(context, request_id='FIRST', response_hash='a'*64,
                         received_at_ms=149999, acceptable=True)
            options = dict(expected_context=context, first_request_id='FIRST', repair_request_id='REPAIR',
                           first_response_hash='a'*64)
            original = copy.deepcopy(first)
            for now in (150000, 150001, 250000):
                for acceptable in (False, True):
                    candidate = dict(context, request_id='REPAIR', response_hash='b'*64,
                        first_response_hash='a'*64, received_at_ms=now, acceptable=acceptable, scope_ok=True)
                    before = copy.deepcopy(candidate)
                    expected = candidate if now == 150000 and acceptable else first
                    for _ in range(3):
                        self.assertIs(retain_attempt(first, candidate, 150000, **options), expected)
                    self.assertEqual(candidate, before)
                    self.assertEqual(first, original)


if __name__ == '__main__': unittest.main(verbosity=2)
