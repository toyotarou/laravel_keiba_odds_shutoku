"""Bind decoded requests and scope-limited repairs to saved server records.

Call AFTER authenticated INPUT decoding/hash validation. This is not a signature
validator, source decoder, semantic validator, local recovery engine or publisher.
Never take frozen/request IDs/authorized scope/first_raw from the AI response.
"""
from hashlib import sha256
from decimal import Decimal
from reference_adapter import (SCHEMA,PROMPT,need,parse_response,expand_response,
    validate_schema,visible,ExactJSONValidator,exact_json_integer,load_contract_schema)

CONTEXT_KEYS=('schema_version','prompt_version','race_id','snapshot_hash','ai_role')
EVALUATION_KEYS=('review','scores','counterevidence','explanation')
RANK_KEYS=('rank_families','rank_reason')
REPAIR_KEYS=('first_response','first_response_hash','repair_scope','errors')
MISSING=object()

def same_value(a,b):
    """Compare JSON values exactly, without confusing numbers and booleans.

    JSON has one number category. strict_loads may represent an exact number as
    int or Decimal depending on notation; fixed-notation serialization can
    change that Python type without changing the JSON value. Compare those two
    exact numeric types by value, never by float conversion or rounding. Raw
    receipt hashes remain byte-exact and are checked separately.
    """
    if type(a) in (int,Decimal) and type(b) in (int,Decimal):
        if any(type(v) is Decimal and not v.is_finite() for v in (a,b)):return False
        return a==b
    if type(a) is not type(b):return False
    if isinstance(a,dict):return set(a)==set(b) and all(same_value(a[k],b[k]) for k in a)
    if isinstance(a,list):return len(a)==len(b) and all(same_value(x,y) for x,y in zip(a,b))
    return a==b

def receipt_hash(raw):
    need(isinstance(raw,str),'FIRST_RAW_REQUIRED')
    try:return sha256(raw.encode('utf-8')).hexdigest()
    except UnicodeEncodeError:
        need(False,'INVALID_RAW_ENCODING')

def roster(frozen):
    rows=frozen.get('runners',[])
    need(isinstance(rows,list) and type(frozen.get('N')) is int and 1<=frozen['N']<=18,'INPUT_ROSTER_INVALID')
    need(all(isinstance(r,dict) and type(r.get('horse_no')) is int and 1<=r['horse_no']<=18 and r.get('band') in ('A','B','D') for r in rows),'INPUT_ROSTER_INVALID')
    nos=[r['horse_no'] for r in rows]
    need(len(nos)==len(set(nos))==frozen['N'],'INPUT_ROSTER_INVALID')
    return set(nos)

def validate_request(request,frozen,expected_request_id,*,first_raw=None,
                     first_request_id=None,authorized_repair_scope=None):
    schema=load_contract_schema('request')
    errors=list(ExactJSONValidator(schema).iter_errors(request))
    need(not errors,'REQUEST_SCHEMA')
    need(visible(expected_request_id),'EXPECTED_REQUEST_ID_REQUIRED')
    need(request['response_contract']['request_id']==expected_request_id,'REQUEST_ID_MISMATCH')
    need(same_value(request['input'],frozen),'FROZEN_INPUT_MISMATCH')
    nos=roster(frozen)
    for issue in request.get('errors',[]):need(visible(issue.get('code')) and visible(issue.get('reason')),'EMPTY_REPAIR_DIAGNOSTIC')
    if 'first_response' not in request:
        need(first_raw is None and first_request_id is None and authorized_repair_scope is None,'UNEXPECTED_REPAIR_CONTEXT')
        return None
    need(visible(first_request_id) and first_request_id!=expected_request_id,'FIRST_REQUEST_ID_REQUIRED')
    need(authorized_repair_scope is not None and same_value(request['repair_scope'],authorized_repair_scope),'REPAIR_SCOPE_NOT_AUTHORIZED')
    first=parse_response(first_raw) if isinstance(first_raw,str) else None
    need(isinstance(first,dict),'FIRST_RAW_REQUIRED')
    need(receipt_hash(first_raw)==request['first_response_hash'],'FIRST_RESPONSE_HASH_MISMATCH')
    need(same_value(first,request['first_response']),'FIRST_RESPONSE_COPY_MISMATCH')
    expected={'schema_version':SCHEMA,'prompt_version':PROMPT,'race_id':frozen['race_id'],
              'snapshot_hash':frozen['snapshot_hash'],'ai_role':frozen['ai_role']}
    for k,v in expected.items():need(first.get(k)==v,'FIRST_HEADER_MISMATCH:'+k)
    need(first.get('request_id')==first_request_id,'FIRST_REQUEST_ID_MISMATCH')
    scope=request['repair_scope']
    need(set(scope['horses'])<=nos and set(scope['ranking_horses'])<=nos,'SCOPE_HORSE_NOT_IN_ROSTER')
    need(frozen['ai_role']=='1st' or not scope['race_metrics'],'SECOND_ROLE_METRIC_SCOPE')
    return first

def enforce_repair_scope(first,repaired,scope,frozen):
    """Reject an out-of-scope whole attempt. Do not silently splice rows.

    A server's separate local-recovery route may retain unaffected material only
    with explicit provenance. Both successful and failed attempts stay archived.
    """
    validate_schema(repaired)
    for k in CONTEXT_KEYS:need(same_value(first.get(k),repaired.get(k)),'REPAIR_HEADER_CHANGED:'+k)
    nos=roster(frozen)
    def index(reply):
        rows=reply.get('horses',[])
        need(isinstance(rows,list),'UNREPAIRABLE_FIRST_ROSTER')
        need(all(isinstance(h,dict) and exact_json_integer(h.get('horse_no')) and h['horse_no'] in nos for h in rows),'UNREPAIRABLE_FIRST_ROSTER')
        result={int(h['horse_no']):h for h in rows}
        need(len(result)==len(rows),'UNREPAIRABLE_FIRST_ROSTER')
        return result
    old=index(first);new=index(repaired)
    need(set(new)==nos,'ALL_RUNNERS_REQUIRED')
    for no in sorted(nos):
        if no not in old:
            need(no in scope['horses'] and no in scope['ranking_horses'],'REPAIR_MISSING_ROW_SCOPE:'+str(no))
            continue
        for key in EVALUATION_KEYS:
            need(no in scope['horses'] or same_value(old[no].get(key,MISSING),new[no].get(key,MISSING)),'REPAIR_OUT_OF_SCOPE:h'+str(no)+'.'+key)
        for key in RANK_KEYS:
            need(no in scope['ranking_horses'] or same_value(old[no].get(key,MISSING),new[no].get(key,MISSING)),'REPAIR_OUT_OF_SCOPE:h'+str(no)+'.'+key)
        need(set(old[no])<=set(EVALUATION_KEYS+RANK_KEYS+('horse_no',)),'UNREPAIRABLE_FIRST_ROW_KEYS')
    old_ranks=first.get('evidence_band_ranks',{})
    need(isinstance(old_ranks,dict),'UNREPAIRABLE_FIRST_RANKS')
    for band in 'ABD':
        before=old_ranks.get(band,MISSING)
        after=repaired['evidence_band_ranks'][band]
        need(band in scope['rank_bands'] or same_value(before,after),'REPAIR_OUT_OF_SCOPE:band.'+band)
    if frozen['ai_role']=='1st':
        need(isinstance(first.get('race_metrics',{}),dict),'UNREPAIRABLE_FIRST_METRICS')
        for metric in ('wave_level','lower_entry','big_gap_entry'):
            need(metric in scope['race_metrics'] or same_value(first.get('race_metrics',{}).get(metric,MISSING),repaired['race_metrics'][metric]),'REPAIR_OUT_OF_SCOPE:metric.'+metric)
    # validation_issues may change: they are diagnostics, never selection inputs.

def expand_checked_request(request,reply,frozen,expected_request_id,*,first_raw=None,
                           first_request_id=None,authorized_repair_scope=None):
    """Recommended reference entry point, using a decoded immutable request."""
    first=validate_request(request,frozen,expected_request_id,first_raw=first_raw,
                           first_request_id=first_request_id,authorized_repair_scope=authorized_repair_scope)
    if first is not None:enforce_repair_scope(first,reply,request['repair_scope'],frozen)
    return expand_response(reply,frozen,expected_request_id)
