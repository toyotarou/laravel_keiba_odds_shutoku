"""R2: complete timeout/resend paths and exact JSON output boundaries."""
import copy
from decimal import Decimal
import unittest
from reference_adapter import SCHEMA,PROMPT,ContractError,dumps_exact,strict_loads
from deadline_policy import AttemptTiming,retry_decision,retain_attempt
from request_guard import expand_checked_request
from test_contract import fixture

class ResendReceiptTests(unittest.TestCase):
    def setUp(self):
        self.ctx={'race_id':'TEST','snapshot_hash':'a'*64,'ai_role':'2nd','schema_version':SCHEMA,'prompt_version':PROMPT}
        self.first={**self.ctx,'request_id':'first','response_hash':'c'*64,'acceptable':True,'received_at_ms':120000}
        self.resend={**self.ctx,'request_id':'resend','response_hash':'d'*64,'acceptable':True,'received_at_ms':140000}
        self.kw={'expected_context':self.ctx,'first_request_id':'first','resend_request_id':'resend'}
    def choose(self,first):
        return retain_attempt(first,None,150000,resend=self.resend,**self.kw)
    def test_successful_resend_after_no_first_receipt(self):
        self.assertIs(self.choose(None),self.resend)
    def test_resend_after_unacceptable_first(self):
        self.first['acceptable']=False
        self.assertIs(self.choose(self.first),self.resend)
    def test_resend_survives_malformed_first_receipt(self):
        for first in [False,[],{},'truncated raw output']:
            with self.subTest(first=first):self.assertIs(self.choose(first),self.resend)
    def test_timely_resend_survives_late_original(self):
        self.first['received_at_ms']=150001
        self.assertIs(self.choose(self.first),self.resend)
    def test_resend_needs_saved_request_id(self):
        self.kw['resend_request_id']=None
        self.assertIsNone(self.choose(None))
    def test_foreign_resend_never_replaces_first(self):
        for key,value in [('race_id','other'),('snapshot_hash','b'*64),('ai_role','1st'),('schema_version','old'),('prompt_version','old'),('request_id','other')]:
            before=copy.deepcopy(self.resend);self.resend[key]=value
            with self.subTest(key=key):self.assertIs(self.choose(self.first),self.first)
            self.resend=before
    def test_foreign_resend_without_first_is_not_accepted(self):
        self.resend['request_id']='unknown'
        self.assertIsNone(self.choose(None))
    def test_late_resend_keeps_valid_first(self):
        self.resend['received_at_ms']=150001
        self.assertIs(self.choose(self.first),self.first)
    def test_late_resend_without_first_is_not_accepted(self):
        self.resend['received_at_ms']=150001
        self.assertIsNone(self.choose(None))
    def test_exact_deadline_resend_is_timely(self):
        self.resend['received_at_ms']=150000
        self.assertIs(self.choose(None),self.resend)
    def test_invalid_resend_time_types_never_accepted(self):
        for t in [True,-1,'140000',140000.0,None]:
            self.resend['received_at_ms']=t
            with self.subTest(t=t):self.assertIsNone(self.choose(None))
    def test_resend_acceptable_must_be_true_boolean(self):
        for flag in [False,1,'true','false',None]:
            self.resend['acceptable']=flag
            with self.subTest(flag=flag):self.assertIsNone(self.choose(None))
    def test_malformed_resend_hash_is_rejected(self):
        self.resend['response_hash']='not-a-hash'
        self.assertIsNone(self.choose(None))
    def test_earliest_valid_initial_is_retained(self):
        self.assertIs(self.choose(self.first),self.first)
    def test_earliest_valid_resend_is_retained(self):
        self.first['received_at_ms']=145000
        self.assertIs(self.choose(self.first),self.resend)
    def test_equal_receipt_time_prefers_initial(self):
        self.first['received_at_ms']=140000
        self.assertIs(self.choose(self.first),self.first)
    def test_resend_does_not_require_repair_hash_or_scope(self):
        self.assertNotIn('scope_ok',self.resend)
        self.assertNotIn('first_response_hash',self.resend)
        self.assertIs(self.choose(None),self.resend)
    def test_one_extra_call_cannot_authorize_resend_and_repair(self):
        self.kw['repair_request_id']='repair'
        with self.assertRaisesRegex(ValueError,'ADDITIONAL_CALL_CAP'):self.choose(self.first)
    def test_resend_id_must_be_new_nonblank_string(self):
        for ident in ['first','',False,1,'  ']:
            self.kw['resend_request_id']=ident
            with self.subTest(ident=ident),self.assertRaisesRegex(ValueError,'INVALID_RESEND_REQUEST_ID'):self.choose(None)
    def test_resend_request_passes_same_frozen_input_guard(self):
        frozen,reply=fixture();reply['request_id']='resend'
        req={'response_contract':{'schema_version':SCHEMA,'prompt_version':PROMPT,'request_id':'resend'},'input':copy.deepcopy(frozen)}
        p=expand_checked_request(req,reply,frozen,'resend')
        self.assertEqual(p['stage'],'UNVERIFIED_MATERIAL_PACKET')
        self.assertEqual(len(p['horses']),frozen['N'])
    def test_resend_cannot_modify_frozen_input(self):
        frozen,reply=fixture();reply['request_id']='resend'
        req={'response_contract':{'schema_version':SCHEMA,'prompt_version':PROMPT,'request_id':'resend'},'input':copy.deepcopy(frozen)}
        req['input']['role_quota']['D']=0
        with self.assertRaisesRegex(ContractError,'FROZEN_INPUT_MISMATCH'):expand_checked_request(req,reply,frozen,'resend')

class RetryKindBudgetTests(unittest.TestCase):
    def args(self,kind='RESEND',p95=30000):
        return dict(now_ms=100000,reply_deadline_ms=150000,additional_calls_used=0,attempt_kind=kind,timing=AttemptTiming(kind,p95),queue_p95_ms=5000,validation_p95_ms=5000,reserve_ms=10000,retry_required=True,in_flight=False)
    def test_resend_can_use_its_own_exact_fit_budget(self):
        self.assertTrue(retry_decision(**self.args()).allowed)
    def test_longer_resend_does_not_borrow_shorter_repair_budget(self):
        self.assertFalse(retry_decision(**self.args(p95=30001)).allowed)
        kw=self.args();kw['timing']=AttemptTiming('REPAIR',10000)
        with self.assertRaisesRegex(ValueError,'TIMING_KIND_MISMATCH'):retry_decision(**kw)
    def test_repair_cannot_use_resend_profile(self):
        kw=self.args('REPAIR');kw['timing']=AttemptTiming('RESEND',30000)
        with self.assertRaisesRegex(ValueError,'TIMING_KIND_MISMATCH'):retry_decision(**kw)
    def test_unmeasured_resend_does_not_dispatch(self):
        self.assertEqual(retry_decision(**self.args(p95=None)).reason,'P95_NOT_MEASURED')
    def test_invalid_call_kind_is_rejected(self):
        for kind in ['INITIAL','resend',None,True]:
            kw=self.args();kw['attempt_kind']=kind
            with self.subTest(kind=kind),self.assertRaisesRegex(ValueError,'INVALID_ATTEMPT_KIND'):retry_decision(**kw)
    def test_untyped_profile_is_rejected(self):
        kw=self.args();kw['timing']={'kind':'RESEND','p95_ms':30000}
        with self.assertRaisesRegex(ValueError,'INVALID_TIMING_PROFILE'):retry_decision(**kw)
    def test_each_kind_requires_measured_positive_integer_duration(self):
        for kind in ['RESEND','REPAIR']:
            for p95 in [0,-1,False,30000.0,'30000']:
                with self.subTest(kind=kind,p95=p95),self.assertRaises(ValueError):retry_decision(**self.args(kind,p95))
    def test_extra_call_cap_and_inflight_apply_to_both_kinds(self):
        for kind in ['RESEND','REPAIR']:
            kw=self.args(kind);kw['additional_calls_used']=1
            with self.subTest(kind=kind):self.assertEqual(retry_decision(**kw).reason,'ADDITIONAL_CALL_CAP')
            kw=self.args(kind);kw['in_flight']=True
            self.assertEqual(retry_decision(**kw).reason,'REQUEST_IN_FLIGHT')
    def test_not_required_resend_is_not_sent(self):
        kw=self.args();kw['retry_required']=False
        self.assertEqual(retry_decision(**kw).reason,'NO_RETRY_REQUIRED')

class ExactOutputBoundaryTests(unittest.TestCase):
    def test_small_decimal_is_not_emitted_in_exponent_notation(self):
        self.assertEqual(dumps_exact({'n':Decimal('0.0000001')}),'{"n":0.0000001}')
    def test_large_decimal_is_fixed_without_value_change(self):
        self.assertEqual(dumps_exact(Decimal('1e3')),'1000')
        n=Decimal('1e127');self.assertEqual(strict_loads(dumps_exact(n)),n)
    def test_high_precision_fraction_roundtrip_unchanged(self):
        n=Decimal('0.'+'0'*110+'1234567890123456')
        self.assertEqual(strict_loads(dumps_exact(n)),n)
    def test_float_is_rejected_without_pretending_to_restore_precision(self):
        for value in [1.0,1e128,0.1,float('nan'),float('inf')]:
            with self.subTest(value=value),self.assertRaisesRegex(ContractError,'FLOAT_NOT_EXACT'):dumps_exact({'v':value})
    def test_extremely_large_integer_is_controlled_rejection(self):
        with self.assertRaisesRegex(ContractError,'NUMBER_TOO_LONG'):dumps_exact(10**5000)
    def test_nonstring_object_keys_never_emit_invalid_json(self):
        for key in [1,False,None,Decimal('2')]:
            with self.subTest(key=key),self.assertRaisesRegex(ContractError,'NONSTRING_JSON_KEY'):dumps_exact({key:'v'})
    def test_unpaired_surrogate_rejected_in_key_and_value(self):
        for obj in [{'s':'\ud800'},{'\udfff':'value'}]:
            with self.assertRaisesRegex(ContractError,'UNPAIRED_SURROGATE'):dumps_exact(obj)
    def test_serializer_depth_matches_parser_boundary(self):
        obj=0
        for _ in range(64):obj=[obj]
        self.assertEqual(strict_loads(dumps_exact(obj)),obj)
        with self.assertRaisesRegex(ContractError,'JSON_TOO_DEEP'):dumps_exact([obj])
    def test_cycle_is_controlled_rejection(self):
        obj=[];obj.append(obj)
        with self.assertRaisesRegex(ContractError,'JSON_TOO_DEEP'):dumps_exact(obj)
    def test_non_json_types_rejected(self):
        for obj in [(),set(),b'text',object()]:
            with self.subTest(type=type(obj).__name__),self.assertRaisesRegex(ContractError,'INVALID_JSON_TYPE'):dumps_exact(obj)
    def test_null_boolean_and_legal_unicode_preserved(self):
        obj={'zero':0,'null':None,'true':True,'false':False,'text':'小数\u2028比較\u2029確認😀'}
        self.assertEqual(strict_loads(dumps_exact(obj)),obj)

if __name__=='__main__':unittest.main(verbosity=2)
