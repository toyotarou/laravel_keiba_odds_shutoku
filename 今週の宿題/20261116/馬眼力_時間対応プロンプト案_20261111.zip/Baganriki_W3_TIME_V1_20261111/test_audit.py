"""Adversarial regression tests added in the R1 audit; no live API calls."""
import copy
from decimal import Decimal
import json
from pathlib import Path
import unittest
from jsonschema import Draft202012Validator
from reference_adapter import (SCHEMA,PROMPT,BEGIN,END,ContractError,strict_loads,
    dumps_exact,expand_response,CAPS,parse_response)
from request_guard import (receipt_hash,expand_checked_request,validate_request,same_value)
from deadline_policy import AttemptTiming,retry_decision,retain_attempt
from test_contract import fixture

class RequestRepairAuditTests(unittest.TestCase):
    def setUp(self):
        self.f,self.first=fixture()
        self.request={'response_contract':{'schema_version':SCHEMA,'prompt_version':PROMPT,'request_id':self.first['request_id']},'input':copy.deepcopy(self.f)}
    def prepare(self,role='2nd'):
        if role=='1st':
            self.f,self.first=fixture(role=role);self.request['input']=copy.deepcopy(self.f)
        self.raw=BEGIN+'\n'+dumps_exact(self.first)+'\n'+END+'\n'
        self.scope={'horses':[],'ranking_horses':[],'rank_bands':[],'race_metrics':[]}
        self.request.update(first_response=copy.deepcopy(self.first),first_response_hash=receipt_hash(self.raw),repair_scope=self.scope,errors=[{'code':'TEST','reason':'再現試験の対象'}])
        self.request['response_contract']['request_id']='REPAIR-002'
        self.reply=copy.deepcopy(self.first);self.reply['request_id']='REPAIR-002'
    def check(self):
        return expand_checked_request(self.request,self.reply,self.f,'REPAIR-002',first_raw=self.raw,first_request_id=self.first['request_id'],authorized_repair_scope=self.scope)
    def test_initial_request_checked_entry(self):
        self.assertEqual(len(expand_checked_request(self.request,self.first,self.f,self.first['request_id'])['horses']),18)
    def test_invalid_request_contract_version_rejected(self):
        self.request['response_contract']['prompt_version']='old'
        with self.assertRaisesRegex(ContractError,'REQUEST_SCHEMA'):validate_request(self.request,self.f,self.first['request_id'])
    def test_frozen_quota_mutation_rejected(self):
        self.request['input']['role_quota']['D']=0
        with self.assertRaisesRegex(ContractError,'FROZEN_INPUT'):validate_request(self.request,self.f,self.first['request_id'])
    def test_scalar_boolean_and_integer_not_equal(self):
        self.assertFalse(same_value({'a':True},{'a':1}))
    def test_incomplete_repair_envelope_rejected(self):
        self.request['first_response']={}
        with self.assertRaisesRegex(ContractError,'REQUEST_SCHEMA'):validate_request(self.request,self.f,self.first['request_id'])
    def test_unchanged_repair_is_valid(self):
        self.prepare();self.check()
    def test_wrong_first_hash_rejected(self):
        self.prepare();self.request['first_response_hash']='f'*64
        with self.assertRaisesRegex(ContractError,'HASH_MISMATCH'):self.check()
    def test_raw_newline_is_hash_significant(self):
        self.prepare();self.raw=self.raw.rstrip('\n')
        with self.assertRaisesRegex(ContractError,'HASH_MISMATCH'):self.check()
    def test_first_response_copy_mutation_rejected(self):
        self.prepare();self.request['first_response']['horses'][0]['explanation']='別の初回'
        with self.assertRaisesRegex(ContractError,'COPY_MISMATCH'):self.check()
    def test_cross_role_first_response_rejected(self):
        self.first['ai_role']='1st';self.prepare()
        with self.assertRaisesRegex(ContractError,'FIRST_HEADER'):self.check()
    def test_missing_stored_scope_is_not_authority(self):
        self.prepare()
        with self.assertRaisesRegex(ContractError,'SCOPE_NOT_AUTHORIZED'):
            expand_checked_request(self.request,self.reply,self.f,'REPAIR-002',first_raw=self.raw,first_request_id=self.first['request_id'])
    def test_supplied_scope_cannot_expand_server_permission(self):
        self.prepare();self.request['repair_scope']=copy.deepcopy(self.scope);self.request['repair_scope']['horses']=[1]
        with self.assertRaisesRegex(ContractError,'SCOPE_NOT_AUTHORIZED'):self.check()
    def test_unknown_horse_scope_rejected(self):
        self.f,self.first=fixture(n=15);self.request['input']=copy.deepcopy(self.f);self.prepare();self.scope['horses']=[18]
        with self.assertRaisesRegex(ContractError,'SCOPE_HORSE'):self.check()
    def test_second_role_cannot_repair_metrics(self):
        self.prepare();self.scope['race_metrics']=['wave_level']
        with self.assertRaisesRegex(ContractError,'SECOND_ROLE'):self.check()
    def test_score_only_repair_keeps_evidence_order(self):
        self.prepare();self.scope['horses']=[1];self.reply['horses'][0]['scores']['H1']['value']=10
        p=self.check();self.assertEqual(p['evidence_band_ranks'],self.first['evidence_band_ranks'])
    def test_horse_scope_does_not_authorize_rank_reason(self):
        self.prepare();self.scope['horses']=[1];self.reply['horses'][0]['rank_reason']='勝手に変更'
        with self.assertRaisesRegex(ContractError,'OUT_OF_SCOPE:h1.rank_reason'):self.check()
    def test_rank_band_does_not_authorize_all_rank_reasons(self):
        self.prepare();self.scope['rank_bands']=['A'];self.reply['horses'][0]['rank_reason']='勝手に変更'
        with self.assertRaisesRegex(ContractError,'OUT_OF_SCOPE:h1.rank_reason'):self.check()
    def test_ranking_horse_scope_cannot_change_score(self):
        self.prepare();self.scope['ranking_horses']=[1];self.reply['horses'][0]['scores']['H1']['value']=10
        with self.assertRaisesRegex(ContractError,'OUT_OF_SCOPE:h1.scores'):self.check()
    def test_explicit_rank_scope_allows_reordering(self):
        self.prepare();self.scope['rank_bands']=['A'];self.scope['ranking_horses']=[1,2]
        self.reply['evidence_band_ranks']['A'][:2]=[2,1]
        self.reply['horses'][0]['rank_reason']='条件比較で二番手';self.reply['horses'][1]['rank_reason']='条件比較で先頭'
        self.assertEqual(self.check()['evidence_band_ranks']['A'][:2],[2,1])
    def test_other_band_cannot_change(self):
        self.prepare();self.scope['rank_bands']=['A'];self.reply['evidence_band_ranks']['D'].reverse()
        with self.assertRaisesRegex(ContractError,'OUT_OF_SCOPE:band.D'):self.check()
    def test_missing_row_can_be_repaired_only_with_both_permissions(self):
        saved=copy.deepcopy(self.first['horses'][0]);self.first['horses'].pop(0);self.prepare()
        self.reply['horses'].insert(0,saved);self.scope['horses']=[1]
        with self.assertRaisesRegex(ContractError,'MISSING_ROW_SCOPE'):self.check()
        self.scope['ranking_horses']=[1];self.check()
    def test_metric_only_repair_keeps_horses(self):
        self.prepare(role='1st');self.scope['race_metrics']=['wave_level'];self.reply['race_metrics']['wave_level']['reason']='資料不足の項目を明確化'
        p=self.check();self.assertEqual(len(p['horses']),18)
        self.reply['horses'][0]['explanation']='ついでに変更'
        with self.assertRaisesRegex(ContractError,'OUT_OF_SCOPE:h1.explanation'):self.check()
    def test_empty_diagnostic_rejected(self):
        self.prepare();self.request['errors']=[{}]
        with self.assertRaisesRegex(ContractError,'REQUEST_SCHEMA'):self.check()

class NumericAndSourceAuditTests(unittest.TestCase):
    def test_exponent_cannot_bypass_128_digits(self):
        for number in ['1e128','1e9999','1e-128','0e9999','1e'+'9'*100]:
            with self.subTest(number=number),self.assertRaisesRegex(ContractError,'NUMBER_TOO_LONG'):
                strict_loads('{"n":'+number+'}')
    def test_boundary_128_digits_preserved_exactly(self):
        for number in ['1e127','1e-127','9'*128]:
            with self.subTest(number=number):
                obj=strict_loads('{"n":'+number+'}');self.assertEqual(strict_loads(dumps_exact(obj)),obj)
    def test_serializer_rejects_overlong_values(self):
        for n in [10**128,Decimal('1e128')]:
            with self.subTest(n=n),self.assertRaisesRegex(ContractError,'NUMBER_TOO_LONG'):dumps_exact({'n':n})
    def test_unicode_line_separator_preserved_inside_json(self):
        _,reply=fixture();reply['horses'][0]['explanation']='事実 比較 条件'
        raw=BEGIN+'\r\n'+dumps_exact(reply)+'\r\n'+END
        self.assertEqual(parse_response(raw),reply)
    def test_depth_64_boundary(self):
        strict_loads('['*64+'0'+']'*64)
        with self.assertRaisesRegex(ContractError,'TOO_DEEP'):strict_loads('['*65+'0'+']'*65)
    def acceleration_fixture(self):
        f,r=fixture();rv=r['horses'][0]['review']['market']
        rv.update(observation='支持加速（12→9→6分）',market_claim={'kind':'ACCELERATION','metric':'win_odds'})
        return f,r,rv
    def test_duplicate_slot_cannot_overwrite_contradiction(self):
        for alias_first in [False,True]:
            with self.subTest(alias_first=alias_first):
                f,r,rv=self.acceleration_fixture();reg=f['source_registry'];reg['h1_win_odds_6']['value']=Decimal('10')
                a=copy.deepcopy(reg['h1_win_odds_6']);a.update(source_ref='alias_win6',value=Decimal('6'));reg['alias_win6']=a
                rv['source_refs'].insert(0 if alias_first else len(rv['source_refs']),'alias_win6')
                with self.assertRaisesRegex(ContractError,'AMBIGUOUS_SLOT'):expand_response(r,f,r['request_id'])
    def test_numeric_string_and_bool_cannot_be_odds(self):
        for v in ['6',True]:
            f,r,_=self.acceleration_fixture();f['source_registry']['h1_win_odds_6']['value']=v
            with self.subTest(value=v),self.assertRaisesRegex(ContractError,'NONNUMERIC'):expand_response(r,f,r['request_id'])
    def test_zero_supported_score_cannot_use_only_missing_data(self):
        f,r=fixture();a=copy.deepcopy(f['source_registry']['h1_win_odds_6']);a.update(source_ref='null_ref',value=None);f['source_registry']['null_ref']=a
        r['horses'][0]['scores']['H4'].update(value=0,basis_families=[],extra_source_refs=['null_ref'])
        with self.assertRaisesRegex(ContractError,'KNOWN_SCORE_WITHOUT_DATA'):expand_response(r,f,r['request_id'])
    def test_unknown_score_with_missing_refs_remains_null(self):
        f,r=fixture();p=expand_response(r,f,r['request_id']);self.assertIsNone(p['horses'][0]['scores']['H4'])

class DeadlineAuditTests(unittest.TestCase):
    def args(self):
        return dict(now_ms=100000,reply_deadline_ms=150000,additional_calls_used=0,attempt_kind='REPAIR',timing=AttemptTiming('REPAIR',30000),queue_p95_ms=5000,validation_p95_ms=5000,reserve_ms=10000,retry_required=True,in_flight=False)
    def attempts(self):
        ctx={'race_id':'TEST','snapshot_hash':'a'*64,'ai_role':'2nd','schema_version':SCHEMA,'prompt_version':PROMPT}
        f={**ctx,'request_id':'first','response_hash':'c'*64,'acceptable':True,'received_at_ms':120000}
        r={**ctx,'request_id':'repair','response_hash':'d'*64,'acceptable':True,'received_at_ms':140000,'scope_ok':True,'first_response_hash':'c'*64}
        kw=dict(expected_context=ctx,first_request_id='first',repair_request_id='repair',first_response_hash='c'*64)
        return f,r,kw
    def test_invalid_types_never_allow_dispatch(self):
        for key,val in [('retry_required','false'),('in_flight',0),('now_ms',1.5),('now_ms',True),('reply_deadline_ms',None),('additional_calls_used',False),('reserve_ms',-1),('timing',AttemptTiming('REPAIR',0)),('queue_p95_ms',-2)]:
            kw=self.args();kw[key]=val
            with self.subTest(key=key,val=val),self.assertRaises(ValueError):retry_decision(**kw)
    def test_invalid_budget_is_rejected_even_when_expired(self):
        kw=self.args();kw.update(now_ms=200000,timing=AttemptTiming('REPAIR',-1))
        with self.assertRaises(ValueError):retry_decision(**kw)
    def test_zero_queue_measurement_is_valid(self):
        kw=self.args();kw['queue_p95_ms']=0;self.assertTrue(retry_decision(**kw).allowed)
    def test_bad_flag_cannot_replace_good_first(self):
        for key in ['acceptable','scope_ok']:
            f,r,kw=self.attempts();r[key]='false'
            with self.subTest(key=key):self.assertIs(retain_attempt(f,r,150000,**kw),f)
    def test_foreign_context_cannot_replace_good_first(self):
        for key,value in [('race_id','other'),('snapshot_hash','b'*64),('ai_role','1st'),('prompt_version','old'),('schema_version','old'),('request_id','other'),('first_response_hash','e'*64)]:
            f,r,kw=self.attempts();r[key]=value
            with self.subTest(key=key):self.assertIs(retain_attempt(f,r,150000,**kw),f)
    def test_malformed_receipt_keeps_first(self):
        for repair in [[],{},False,{'acceptable':True}]:
            f,_,kw=self.attempts()
            with self.subTest(repair=repair):self.assertIs(retain_attempt(f,repair,150000,**kw),f)
    def test_invalid_receipt_times_keep_first(self):
        for received in [True,-1,'140000',140000.5,119999,150001]:
            f,r,kw=self.attempts();r['received_at_ms']=received
            with self.subTest(received=received):self.assertIs(retain_attempt(f,r,150000,**kw),f)
    def test_exact_deadline_valid_repair(self):
        f,r,kw=self.attempts();r['received_at_ms']=150000;self.assertIs(retain_attempt(f,r,150000,**kw),r)
    def test_valid_repair_can_fix_unacceptable_first(self):
        f,r,kw=self.attempts();f['acceptable']=False;self.assertIs(retain_attempt(f,r,150000,**kw),r)
    def test_first_hash_chain_mismatch_keeps_first(self):
        f,r,kw=self.attempts();f['response_hash']='f'*64;self.assertIs(retain_attempt(f,r,150000,**kw),f)
    def test_repair_without_saved_first_hash_keeps_first(self):
        f,r,kw=self.attempts();kw['first_response_hash']=None;self.assertIs(retain_attempt(f,r,150000,**kw),f)
    def test_foreign_first_cannot_anchor_repair(self):
        f,r,kw=self.attempts();f['ai_role']='1st';self.assertIsNone(retain_attempt(f,r,150000,**kw))
    def test_missing_first_receipt_cannot_anchor_repair(self):
        _,r,kw=self.attempts();self.assertIsNone(retain_attempt(None,r,150000,**kw))
    def test_foreign_first_not_accepted(self):
        f,r,kw=self.attempts();f['ai_role']='1st';self.assertIsNone(retain_attempt(f,None,150000,**kw))

if __name__=='__main__':unittest.main(verbosity=2)
