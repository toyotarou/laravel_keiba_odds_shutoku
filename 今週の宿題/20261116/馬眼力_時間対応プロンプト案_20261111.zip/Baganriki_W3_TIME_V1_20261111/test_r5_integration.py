"""Integration regressions on unchanged R5; synthetic data, no live approval.

Clock transformations below are independent fixtures, not edits to authenticated
production snapshots. Receipt acceptable flags model prior server validation.
"""
import copy
from datetime import datetime, timedelta, timezone
from decimal import Decimal
import unittest

from reference_adapter import (SCHEMA, PROMPT, BEGIN, END, ContractError, instant,
    dumps_exact, parse_response)
from request_guard import expand_checked_request, receipt_hash
from deadline_policy import retry_decision, retain_attempt, AttemptTiming
from test_contract import fixture


def expand(frozen, reply):
    request = {'response_contract': {'schema_version': SCHEMA, 'prompt_version': PROMPT,
                                    'request_id': reply['request_id']},
               'input': copy.deepcopy(frozen)}
    raw = BEGIN+'\n'+dumps_exact(reply)+'\n'+END+'\n'
    return expand_checked_request(request, parse_response(raw), frozen, reply['request_id'])


def transform_clock(frozen, transform):
    frozen['input_freeze_at'] = transform(frozen['input_freeze_at'])
    frozen['time_contract']['anchor_at'] = transform(frozen['time_contract']['anchor_at'])
    for source in frozen['source_registry'].values():
        for key in ('available_at', 'observed_at', 'computed_at'):
            if source.get(key) is not None: source[key] = transform(source[key])


class R5IntegrationReviewTests(unittest.TestCase):
    def test_all_source_clock_offsets_preserve_material_for_both_roles(self):
        for role in ('1st', '2nd'):
            f, r = fixture(role=role)
            expected = expand(f, r)
            for offset in (0, 345, -210):
                with self.subTest(role=role, offset_minutes=offset):
                    transformed = copy.deepcopy(f)
                    zone = timezone(timedelta(minutes=offset))
                    transform_clock(transformed, lambda s: instant(s).astimezone(zone).isoformat())
                    self.assertEqual(expand(transformed, r), expected)
                    self.assertEqual(expand(f, r), expected)

    def test_midnight_and_year_boundary_keep_all_six_slot_cutoffs(self):
        for anchor in ('2026-11-12T00:02:00+09:00', '2027-01-01T00:02:00+09:00'):
            for slot in (21, 18, 15, 12, 9, 6):
                with self.subTest(anchor=anchor, slot=slot):
                    f, r = fixture()
                    shift = instant(anchor)-instant(f['time_contract']['anchor_at'])
                    transform_clock(f, lambda s: (instant(s)+shift).isoformat())
                    boundary = instant(anchor)-timedelta(minutes=slot)+timedelta(seconds=60 if slot == 6 else 120)
                    ref = 'synthetic_cutoff_source'
                    source = copy.deepcopy(f['source_registry']['h1_win_odds_6'])
                    source.update(source_ref=ref, slot_offset=slot,
                                  observed_at=(boundary-timedelta(seconds=1)).isoformat(),
                                  available_at=boundary.isoformat())
                    f['source_registry'][ref] = source
                    r['horses'][0]['scores']['V4']['extra_source_refs'] = [ref]
                    self.assertEqual(len(expand(f, r)['horses']), 18)
                    f['source_registry'][ref]['available_at'] = (boundary+timedelta(microseconds=1)).isoformat()
                    with self.assertRaisesRegex(ContractError, 'SOURCE_AFTER_(FREEZE|SLOT_DEADLINE)'):
                        expand(f, r)

    def test_acceleration_handles_each_market_measure_without_rounding(self):
        for metric in ('win_odds', 'place_min', 'place_max'):
            for scale in (Decimal('1'), Decimal('1.001'), Decimal('10')):
                with self.subTest(metric=metric, scale=scale):
                    f, r = fixture()
                    review = r['horses'][0]['review']['market']
                    refs = ['h1_'+metric+'_'+str(slot) for slot in (12, 9, 6)]
                    review.update(source_refs=refs, observation='支持加速（12→9→6分）',
                                  market_claim={'kind': 'ACCELERATION', 'metric': metric})
                    for slot, value in zip((12, 9, 6), ('12', '10', '8')):
                        f['source_registry']['h1_'+metric+'_'+str(slot)]['value'] = Decimal(value)*scale
                    packet = expand(f, r)
                    market = next(e for e in packet['horses'][0]['evidence'] if e['family'] == 'market')
                    self.assertEqual(market['market_claim']['metric'], metric)
                    self.assertEqual([x['value'] for x in market['facts']], [Decimal(v)*scale for v in ('12', '10', '8')])
            for values in [('4', '2', '1'), ('6', '5', '4.5'), ('6', '5', '5.1')]:
                f, r = fixture()
                r['horses'][0]['review']['market'].update(
                    source_refs=['h1_'+metric+'_'+str(s) for s in (12, 9, 6)],
                    observation='支持加速（12→9→6分）', market_claim={'kind': 'ACCELERATION', 'metric': metric})
                for slot, value in zip((12, 9, 6), values):
                    f['source_registry']['h1_'+metric+'_'+str(slot)]['value'] = Decimal(value)
                with self.subTest(metric=metric, nonacceleration=values), self.assertRaisesRegex(ContractError, 'FALSE_ACCELERATION'):
                    expand(f, r)

    def test_acceleration_cannot_mix_market_measure_horse_or_unsupported_slot(self):
        for bad_ref, error in [('h1_win_odds_6', 'ACCELERATION_MISSING_SLOTS'),
                               ('h2_place_min_6', 'SOURCE_NOT_APPLICABLE'),
                               ('synthetic_slot3', 'UNKNOWN_SLOT')]:
            f, r = fixture()
            ref = copy.deepcopy(f['source_registry']['h1_place_min_6'])
            ref.update(source_ref='synthetic_slot3', slot_offset=3)
            f['source_registry']['synthetic_slot3'] = ref
            r['horses'][0]['review']['market'].update(
                source_refs=['h1_place_min_12', 'h1_place_min_9', bad_ref],
                observation='支持加速（12→9→6分）', market_claim={'kind': 'ACCELERATION', 'metric': 'place_min'})
            with self.subTest(bad_ref=bad_ref), self.assertRaisesRegex(ContractError, error): expand(f, r)

    def test_prior_prompt_revision_cannot_enter_r5_response_route(self):
        for role in ('1st', '2nd'):
            for old_revision in ('r3', 'r4'):
                f, r = fixture(role=role)
                r['prompt_version'] = 'baganriki-w3-time-v1-20261111-'+old_revision
                before = dumps_exact(r)
                with self.subTest(role=role, old_revision=old_revision), self.assertRaisesRegex(ContractError, 'OUTPUT_SCHEMA'):
                    expand(f, r)
                self.assertEqual(dumps_exact(r), before)

    def test_material_packet_does_not_alias_saved_reply_or_source_in_either_direction(self):
        for role in ('1st', '2nd'):
            f, r = fixture(role=role)
            r['validation_issues'] = [{'code': 'SYNTHETIC', 'severity': 'INFO', 'horse_no': None,
                                       'field': None, 'reason': '構造試験の診断'}]
            raw = BEGIN+'\n'+dumps_exact(r)+'\n'+END+'\n'
            before_f, before_r, raw_hash = dumps_exact(f), dumps_exact(r), receipt_hash(raw)
            packet = expand(f, r)
            h = packet['horses'][0]
            h['evidence'][0]['facts'][0]['value'] = 999
            h['family_review']['ability']['source_refs'].append('packet_only')
            h['score_evidence']['H1']['source_refs'].append('packet_only')
            h['scores']['H1'] = 0
            h['counterevidence'][0]['source_refs'].append('packet_only')
            packet['evidence_band_ranks']['A'].reverse()
            packet['validation_issues'][0]['reason'] = 'packet-only edit'
            if role == '1st': packet['race_metrics']['wave_level']['source_refs'].append('packet_only')
            self.assertEqual((dumps_exact(f), dumps_exact(r), receipt_hash(raw)), (before_f, before_r, raw_hash))
            packet = expand(f, r)
            saved_packet = dumps_exact(packet)
            r['horses'][0]['scores']['H1']['value'] = 0
            r['horses'][0]['review']['ability']['source_refs'].clear()
            f['source_registry']['h1_past_finish_1']['value'] = 999
            self.assertEqual(dumps_exact(packet), saved_packet)

    def test_rejected_repair_preserves_first_and_does_not_poison_later_valid_validation(self):
        f, first = fixture()
        raw = BEGIN+'\n'+dumps_exact(first)+'\n'+END+'\n'
        scope = {'horses': [18], 'ranking_horses': [], 'rank_bands': [], 'race_metrics': []}
        request = {'response_contract': {'schema_version': SCHEMA, 'prompt_version': PROMPT, 'request_id': 'R5-REPAIR'},
                   'input': copy.deepcopy(f), 'first_response': copy.deepcopy(first),
                   'first_response_hash': receipt_hash(raw), 'repair_scope': copy.deepcopy(scope),
                   'errors': [{'code': 'SYNTHETIC', 'reason': '18番の採点資料を確認'}]}
        reply = copy.deepcopy(first)
        reply['request_id'] = 'R5-REPAIR'
        reply['horses'][17]['scores']['V4']['extra_source_refs'] = ['h1_win_odds_6']
        kwargs = {'first_raw': raw, 'first_request_id': first['request_id'], 'authorized_repair_scope': scope}
        with self.assertRaisesRegex(ContractError, 'SOURCE_NOT_APPLICABLE'):
            expand_checked_request(request, reply, f, 'R5-REPAIR', **kwargs)
        ctx = {k: first[k] for k in ('schema_version', 'prompt_version', 'race_id', 'snapshot_hash', 'ai_role')}
        first_receipt = {**ctx, 'request_id': first['request_id'], 'response_hash': receipt_hash(raw),
                         'acceptable': True, 'received_at_ms': 100000}
        repair_receipt = {**ctx, 'request_id': 'R5-REPAIR', 'response_hash': 'b'*64,
                          'acceptable': False, 'received_at_ms': 120000, 'scope_ok': True,
                          'first_response_hash': receipt_hash(raw)}
        retained = retain_attempt(first_receipt, repair_receipt, 150000, expected_context=ctx,
                                  first_request_id=first['request_id'], repair_request_id='R5-REPAIR',
                                  first_response_hash=receipt_hash(raw))
        self.assertIs(retained, first_receipt)
        reply['horses'][17]['scores']['V4']['extra_source_refs'] = ['h18_win_odds_6']
        packet = expand_checked_request(request, reply, f, 'R5-REPAIR', **kwargs)
        self.assertEqual(len(packet['horses']), 18)
        self.assertEqual(receipt_hash(raw), request['first_response_hash'])

    def test_advanced_live_deadline_controls_retry_and_receipt_retention_together(self):
        f, r = fixture()
        ctx = {k: r[k] for k in ('schema_version', 'prompt_version', 'race_id', 'snapshot_hash', 'ai_role')}
        first = {**ctx, 'request_id': 'first', 'response_hash': 'c'*64, 'acceptable': True, 'received_at_ms': 110000}
        repair = {**ctx, 'request_id': 'repair', 'response_hash': 'd'*64, 'acceptable': True,
                  'scope_ok': True, 'first_response_hash': 'c'*64, 'received_at_ms': 130000}
        retry_args = dict(now_ms=100000, additional_calls_used=0, attempt_kind='REPAIR',
                          timing=AttemptTiming('REPAIR', 30000), queue_p95_ms=5000,
                          validation_p95_ms=5000, reserve_ms=10000, retry_required=True, in_flight=False)
        retain_args = dict(expected_context=ctx, first_request_id='first', repair_request_id='repair', first_response_hash='c'*64)
        self.assertTrue(retry_decision(reply_deadline_ms=150000, **retry_args).allowed)
        self.assertIs(retain_attempt(first, repair, 150000, **retain_args), repair)
        self.assertFalse(retry_decision(reply_deadline_ms=120000, **retry_args).allowed)
        self.assertIs(retain_attempt(first, repair, 120000, **retain_args), first)
        self.assertFalse(retry_decision(reply_deadline_ms=100000, **retry_args).allowed)
        self.assertIsNone(retain_attempt(first, repair, 100000, **retain_args))


if __name__ == '__main__': unittest.main(verbosity=2)
