"""Reproduce the archived R4/R5 resource-ID collision without live services."""
import json
from pathlib import Path
from jsonschema import Draft202012Validator
from referencing import Registry, Resource

ROOT = Path(__file__).parent
records = []
for kind, filename in [('output', 'synthetic_2nd_wire.json'), ('request', 'synthetic_request.json')]:
    old = json.loads((ROOT / 'historical_schemas' / ('r4_' + kind + '_schema.json')).read_text())
    new = json.loads((ROOT / 'historical_schemas' / ('r5_' + kind + '_schema.json')).read_text())
    data = json.loads((ROOT / 'examples' / filename).read_text())
    target = data if kind == 'output' else data['response_contract']
    target['prompt_version'] = 'baganriki-w3-time-v1-20261111-r5'
    assert old['$id'] == new['$id']
    assert Draft202012Validator(new).is_valid(data)
    for revisions, ordered in [(('R4', 'R5'), (old, new)), (('R5', 'R4'), (new, old))]:
        reg = Registry().with_resources((s['$id'], Resource.from_contents(s)) for s in ordered)
        validator = Draft202012Validator({'$ref': new['$id']}, registry=reg)
        errors = list(validator.iter_errors(data))
        records.append({'kind': kind, 'registered_order': revisions, 'requested_id': new['$id'],
                        'r5_instance_valid': not errors,
                        'errors': [{'path': list(e.absolute_path), 'message': e.message} for e in errors]})
assert [r['r5_instance_valid'] for r in records] == [True, False, True, False]
print(json.dumps({'issue': 'SCHEMA_RESOURCE_ID_COLLISION', 'cases': records,
                  'production_incident_verified': False}, ensure_ascii=False, indent=2))
