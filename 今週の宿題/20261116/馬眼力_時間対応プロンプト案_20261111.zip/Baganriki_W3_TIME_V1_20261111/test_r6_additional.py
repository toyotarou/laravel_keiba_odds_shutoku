"""Tests originally added in R6, retained for the currently loaded revision.

Synthetic score-comparator rows and receipt flags represent already validated
server state; these tests do not execute Laravel semantics or live AI calls.
"""
import copy
from functools import cmp_to_key
import itertools
import json
from pathlib import Path
import random
import unittest

from jsonschema import Draft202012Validator
from referencing import Registry, Resource
import reference_adapter
from reference_adapter import (BEGIN, END, SCHEMA, PROMPT, CAPS, ContractError,
    dumps_exact, parse_response, ordinary_ranks_after_validation, score_totals)
from request_guard import expand_checked_request, receipt_hash
from deadline_policy import AttemptTiming, retry_decision, retain_attempt
from test_contract import fixture


def wire(reply):
    return BEGIN + '\n' + dumps_exact(reply) + '\n' + END + '\n'


def request(frozen, reply):
    return {'response_contract': {k: reply[k] for k in ('schema_version', 'prompt_version', 'request_id')},
            'input': copy.deepcopy(frozen)}


def expand(frozen, reply):
    return expand_checked_request(request(frozen, reply), parse_response(wire(reply)), frozen, reply['request_id'])


def repair(frozen, first, reply, scope):
    raw = wire(first)
    req = request(frozen, reply)
    req.update(first_response=copy.deepcopy(first), first_response_hash=receipt_hash(raw),
               repair_scope=copy.deepcopy(scope), errors=[{'code': 'SYNTHETIC_REPAIR', 'reason': '構造確認用の訂正'}])
    return expand_checked_request(req, parse_response(wire(reply)), frozen, reply['request_id'],
                                  first_raw=raw, first_request_id=first['request_id'],
                                  authorized_repair_scope=scope)


class R6AdditionalReview(unittest.TestCase):
    def test_band_comparator_matches_pairwise_oracle_and_row_permutations(self):
        rng = random.Random(2026111106)
        for case in range(160):
            rows = []
            numbers = sorted(rng.sample(range(1, 19), rng.randint(1, 18)))
            for rank, no in enumerate(numbers, 1):
                scores = {key: rng.randint(0, cap) for key, cap in CAPS.items()}
                if case % 4 and rng.randrange(3) == 0:
                    scores[rng.choice(list(CAPS))] = None
                rows.append({'horse_no': no, 'band': 'A' if rank <= 6 else 'B' if rank <= 10 else 'D',
                             'eligibility': 'ELIGIBLE' if rng.randrange(4) else 'NO_EVIDENCE', 'scores': scores})
            evidence = {band: [h['horse_no'] for h in rows if h['band'] == band and h['eligibility'] == 'ELIGIBLE'] for band in 'ABD'}
            for rank in evidence.values(): rng.shuffle(rank)
            expected = {}; modes = {}
            for band in 'ABD':
                eligible = [h for h in rows if h['band'] == band and h['eligibility'] == 'ELIGIBLE']
                if not eligible or any(None in h['scores'].values() for h in eligible):
                    expected[band] = list(evidence[band]); modes[band] = 'EVIDENCE'
                    continue
                def compare(left, right):
                    for group in (tuple(CAPS), ('V1', 'V2', 'V3', 'V4', 'V5'), ('H1', 'H2', 'H3', 'H4', 'H5')):
                        a = sum(left['scores'][k] for k in group)
                        b = sum(right['scores'][k] for k in group)
                        if a != b: return -1 if a > b else 1
                    return (left['horse_no'] > right['horse_no']) - (left['horse_no'] < right['horse_no'])
                expected[band] = [h['horse_no'] for h in sorted(eligible, key=cmp_to_key(compare))]
                modes[band] = 'SCORE'
            before = copy.deepcopy((rows, evidence))
            with self.subTest(case=case):
                self.assertEqual(ordinary_ranks_after_validation(rows, evidence), (expected, modes))
                rng.shuffle(rows)
                self.assertEqual(ordinary_ranks_after_validation(rows, evidence), (expected, modes))
                self.assertEqual(evidence, before[1])
                self.assertEqual({h['horse_no']: h for h in rows}, {h['horse_no']: h for h in before[0]})

    def test_one_band_partial_complete_transition_does_not_change_other_bands(self):
        # Synthetic post-validation comparator states, not AI score validation.
        rows = []
        for no, band, points in [(1, 'A', 1), (2, 'A', 4), (7, 'B', 2), (8, 'B', 3), (11, 'D', 5), (12, 'D', 6)]:
            scores = dict.fromkeys(CAPS, 0); scores['H1'] = points
            rows.append(dict(horse_no=no, band=band, eligibility='ELIGIBLE', scores=scores))
        evidence = {'A': [1, 2], 'B': [8, 7], 'D': [11, 12]}
        rows[2]['scores']['V1'] = None
        initial, modes = ordinary_ranks_after_validation(rows, evidence)
        self.assertEqual(modes, {'A': 'SCORE', 'B': 'EVIDENCE', 'D': 'SCORE'})
        self.assertEqual(initial['B'], [8, 7])
        rows[2]['scores']['V1'] = 10
        complete, complete_modes = ordinary_ranks_after_validation(rows, evidence)
        self.assertEqual(complete_modes['B'], 'SCORE'); self.assertEqual(complete['B'], [7, 8])
        for band in ('A', 'D'): self.assertEqual(complete[band], initial[band])
        rows[3]['scores']['H1'] = 18
        improved, _ = ordinary_ranks_after_validation(rows, evidence)
        self.assertEqual(improved['B'], [8, 7])
        rows[2]['scores']['V1'] = None
        partial, partial_modes = ordinary_ranks_after_validation(rows, evidence)
        self.assertEqual(partial['B'], evidence['B']); self.assertEqual(partial_modes, modes)
        self.assertEqual(evidence, {'A': [1, 2], 'B': [8, 7], 'D': [11, 12]})

    def test_newly_supported_horse_requires_all_affected_repair_permissions(self):
        for role in ('1st', '2nd'):
            frozen, template = fixture(role=role)
            first = copy.deepcopy(template); horse = first['horses'][10]
            for family in ('ability', 'market'):
                horse['review'][family].update(status='NO_SUPPORT', observation=None, reason='初回は肯定根拠なし')
            horse['review']['market']['market_claim'] = None
            horse['scores']['H1']['value'] = horse['scores']['H2']['value'] = 0
            horse.update(rank_families=[], rank_reason='肯定根拠がなく順位対象外')
            first['evidence_band_ranks']['D'].remove(11)
            original = expand(frozen, first)
            corrected = copy.deepcopy(first); corrected['request_id'] = 'REPAIR-NEW-SUPPORT'
            horse = corrected['horses'][10]
            horse['review']['ability'] = copy.deepcopy(template['horses'][10]['review']['ability'])
            horse['scores']['H1']['value'] = 9
            horse.update(rank_families=['ability'], rank_reason='訂正後の能力根拠を比較')
            corrected['evidence_band_ranks']['D'].insert(0, 11)
            scope = {'horses': [11], 'ranking_horses': [], 'rank_bands': [], 'race_metrics': []}
            with self.subTest(role=role):
                with self.assertRaisesRegex(ContractError, 'OUT_OF_SCOPE:h11.rank_families'): repair(frozen, first, corrected, scope)
                scope['ranking_horses'] = [11]
                with self.assertRaisesRegex(ContractError, 'OUT_OF_SCOPE:band.D'): repair(frozen, first, corrected, scope)
                scope['rank_bands'] = ['D']
                result = repair(frozen, first, corrected, scope)
                self.assertEqual(result['evidence_band_ranks']['D'], list(range(11, 19)))
                self.assertEqual([e['family'] for e in result['horses'][10]['evidence']], ['ability'])
                for i in range(18):
                    if i != 10: self.assertEqual(result['horses'][i], original['horses'][i])
                self.assertEqual(expand(frozen, first), original)

    def test_missing_last_horse_and_rank_need_separate_permissions(self):
        for role in ('1st', '2nd'):
            frozen, full = fixture(role=role)
            first = copy.deepcopy(full); first['horses'].pop(); first['evidence_band_ranks']['D'].pop()
            corrected = copy.deepcopy(full); corrected['request_id'] = 'REPAIR-LAST-ROW'
            scope = {'horses': [18], 'ranking_horses': [], 'rank_bands': [], 'race_metrics': []}
            original_raw = wire(first)
            with self.subTest(role=role):
                with self.assertRaisesRegex(ContractError, 'REPAIR_MISSING_ROW_SCOPE:18'): repair(frozen, first, corrected, scope)
                scope['ranking_horses'] = [18]
                with self.assertRaisesRegex(ContractError, 'OUT_OF_SCOPE:band.D'): repair(frozen, first, corrected, scope)
                scope['rank_bands'] = ['D']
                result = repair(frozen, first, corrected, scope)
                self.assertEqual([h['horse_no'] for h in result['horses']], list(range(1, 19)))
                self.assertEqual(result['evidence_band_ranks']['D'], list(range(11, 19)))
                self.assertEqual(wire(first), original_raw)
                self.assertEqual(len(first['horses']), 17)

    def test_full_wire_duplicate_keys_and_concatenated_answers_are_rejected(self):
        for role in ('1st', '2nd'):
            frozen, reply = fixture(role=role); raw = wire(reply)
            pairs = [
                ('"request_id":"TEST-REQUEST-001",', '"request_id":"OTHER","request_id":"TEST-REQUEST-001",'),
                ('"request_id":"TEST-REQUEST-001",', '"request_id":"TEST-REQUEST-001","request_id":"OTHER",'),
                ('"status":"SUPPORTED",', '"status":"NO_SUPPORT","status":"SUPPORTED",'),
                ('"H1":{"value":9,', '"H1":{"value":18,"value":9,'),
                ('"horse_no":1,', '"horse_no":18,"horse_no":1,')]
            for old, new in pairs:
                self.assertIn(old, raw)
                with self.subTest(role=role, field=old), self.assertRaisesRegex(ContractError, 'DUPLICATE_JSON_KEY'):
                    parse_response(raw.replace(old, new, 1))
            for bad in (raw + raw, raw + 'trailing text', BEGIN+'\n'+dumps_exact(reply)+dumps_exact(reply)+'\n'+END):
                with self.assertRaises(ContractError): parse_response(bad)
            self.assertEqual(expand(frozen, reply)['request_id'], reply['request_id'])

    def test_four_schema_resources_coexist_in_all_registration_orders(self):
        root = Path(reference_adapter.__file__).parent
        current_revision = PROMPT.rsplit('-', 1)[-1]
        specs = []
        for revision in ('r5', current_revision):
            for kind in ('request', 'output'):
                path = root/(kind+'_schema.json') if revision == current_revision else root/'historical_schemas'/('r5_'+kind+'_schema.json')
                specs.append((revision, kind, json.loads(path.read_text())))
        self.assertEqual(len({s['$id'] for _, _, s in specs}), 4)
        data = {}
        for role in ('1st', '2nd'):
            frozen, reply = fixture(n=3, role=role)
            for revision in ('r5', current_revision):
                r = copy.deepcopy(reply); r['prompt_version'] = 'baganriki-w3-time-v1-20261111-'+revision
                data[(revision, 'output', role)] = r
                data[(revision, 'request', role)] = request(frozen, r)
        for order in itertools.permutations(specs):
            reg = Registry().with_resources((s['$id'], Resource.from_contents(s)) for _, _, s in order)
            for revision, kind, s in specs:
                validator = Draft202012Validator({'$ref': s['$id']}, registry=reg)
                for role in ('1st', '2nd'):
                    with self.subTest(order=[(x[0], x[1]) for x in order], revision=revision, kind=kind, role=role):
                        validator.validate(data[(revision, kind, role)])
                        other = 'r5' if revision == current_revision else current_revision
                        self.assertFalse(validator.is_valid(data[(other, kind, role)]))

    def test_epoch_millisecond_shift_preserves_budget_and_receipt_boundaries(self):
        frozen, reply = fixture()
        context = {k: reply[k] for k in ('race_id', 'snapshot_hash', 'ai_role', 'schema_version', 'prompt_version')}
        for shift in (0, 1794351600000, 4102444800000):
            for kind in ('REPAIR', 'RESEND'):
                decision = dict(now_ms=shift+100000, reply_deadline_ms=shift+150000,
                                additional_calls_used=0, attempt_kind=kind, timing=AttemptTiming(kind, 30000),
                                queue_p95_ms=5000, validation_p95_ms=5000, reserve_ms=10000,
                                retry_required=True, in_flight=False)
                self.assertTrue(retry_decision(**decision).allowed)
                decision['now_ms'] += 1
                self.assertFalse(retry_decision(**decision).allowed)
            first = dict(context, request_id='FIRST', response_hash='c'*64, acceptable=True, received_at_ms=shift+120000)
            follow = dict(context, request_id='REPAIR', response_hash='d'*64, first_response_hash='c'*64,
                          acceptable=True, scope_ok=True, received_at_ms=shift+150000)
            options = dict(expected_context=context, first_request_id='FIRST', repair_request_id='REPAIR', first_response_hash='c'*64)
            self.assertIs(retain_attempt(first, follow, shift+150000, **options), follow)
            follow['received_at_ms'] += 1
            self.assertIs(retain_attempt(first, follow, shift+150000, **options), first)

    def test_measured_zero_return_and_missing_return_stay_distinct(self):
        for role in ('1st', '2nd'):
            frozen, reply = fixture(role=role); horse = reply['horses'][10]
            refs = []
            for field, value in [('v3_place_return_pct', 0), ('v3_place_sample_count', 20)]:
                ref = 'h11_'+field
                source = copy.deepcopy(frozen['source_registry']['h11_past_finish_1'])
                source.update(source_ref=ref, field=field, value=value, unit='percent' if field.endswith('pct') else 'count')
                frozen['source_registry'][ref] = source; refs.append(ref)
            horse['review']['similar_value'].update(status='NO_SUPPORT', source_refs=refs, observation=None, reason='実測回収率0で肯定支持なし')
            horse['scores']['V3'].update(value=0, basis_families=['similar_value'], extra_source_refs=[], reason='同集計の実測回収率0')
            zero = expand(frozen, reply)
            self.assertEqual(zero['horses'][10]['scores']['V3'], 0)
            self.assertEqual(zero['horses'][10]['family_review']['similar_value']['status'], 'NO_SUPPORT')
            known = score_totals(zero['horses'][10]['scores'])
            for ref in refs: frozen['source_registry'][ref]['value'] = None
            with self.assertRaisesRegex(ContractError, 'NO_SUPPORT_WITHOUT_DATA'): expand(frozen, reply)
            horse['review']['similar_value'].update(status='DATA_MISSING', reason='当該集計を取得できない')
            horse['scores']['V3'].update(value=None, reason='回収率と母数が欠損')
            missing = expand(frozen, reply)
            self.assertIsNone(missing['horses'][10]['scores']['V3'])
            unknown = score_totals(missing['horses'][10]['scores'])
            self.assertEqual(known['observed_sum'], unknown['observed_sum'])
            self.assertEqual(known['observed_cap']-unknown['observed_cap'], CAPS['V3'])
            self.assertEqual(missing['evidence_band_ranks'], zero['evidence_band_ranks'])


if __name__ == '__main__': unittest.main(verbosity=2)
