"""Reject blank output diagnostic identifiers without changing prediction data."""
import copy
import unittest

from reference_adapter import (SCHEMA, PROMPT, BEGIN, END, ContractError,
    dumps_exact, parse_response)
from request_guard import expand_checked_request, receipt_hash
from deadline_policy import retain_attempt
from test_contract import fixture


def wire(reply):
    return BEGIN + '\n' + dumps_exact(reply) + '\n' + END + '\n'


def request(frozen, request_id):
    return {'response_contract': {'schema_version': SCHEMA,
        'prompt_version': PROMPT, 'request_id': request_id},
        'input': copy.deepcopy(frozen)}


def issue(code):
    return {'code': code, 'severity': 'WARNING', 'horse_no': 1,
        'field': 'scores.H4', 'reason': '対応する類似統計が不足している'}


def check_initial(frozen, reply):
    return expand_checked_request(request(frozen, 'TEST-REQUEST-001'),
        parse_response(wire(reply)), frozen, 'TEST-REQUEST-001')


def repair_parts(frozen, first, repaired):
    raw = wire(first)
    scope = {'horses': [], 'ranking_horses': [], 'rank_bands': [], 'race_metrics': []}
    req = request(frozen, 'DIAGNOSTIC-REPAIR')
    req.update(first_response=copy.deepcopy(first), first_response_hash=receipt_hash(raw),
        repair_scope=copy.deepcopy(scope), errors=[{'code': 'DIAGNOSTIC_CODE',
        'reason': '問題の種類を識別できるコードを返す必要がある'}])
    repaired['request_id'] = 'DIAGNOSTIC-REPAIR'
    options = {'first_raw': raw, 'first_request_id': first['request_id'],
        'authorized_repair_scope': copy.deepcopy(scope)}
    return req, options


class DiagnosticCodeTests(unittest.TestCase):
    def test_blank_diagnostic_codes_rejected_on_checked_entry(self):
        for role in ('1st', '2nd'):
            frozen, good = fixture(3, role)
            for code in (' ', '\t\n', '\u200b', '\u2800', '\u3164', '\ufe0f', '\u3000\u2800\u200b'):
                bad = copy.deepcopy(good)
                bad['validation_issues'] = [issue(code)]
                with self.subTest(role=role, code=ascii(code)), self.assertRaises(ContractError):
                    check_initial(frozen, bad)

    def test_valid_neighbors_do_not_hide_one_blank_diagnostic_code(self):
        for role in ('1st', '2nd'):
            frozen, good = fixture(3, role)
            for position in range(3):
                bad = copy.deepcopy(good)
                bad['validation_issues'] = [issue('MISSING_DATA') for _ in range(3)]
                bad['validation_issues'][position]['code'] = '\u2800'
                with self.subTest(role=role, position=position), self.assertRaises(ContractError):
                    check_initial(frozen, bad)

    def test_valid_codes_are_preserved_without_changing_horses_or_ranks(self):
        for role in ('1st', '2nd'):
            frozen, reply = fixture(18, role)
            baseline = check_initial(frozen, reply)
            for code in ('MISSING_DATA', '資料不足', 'か\u3099_確認', 'CHECK\u200b_OK', '⚠️確認'):
                changed = copy.deepcopy(reply)
                changed['validation_issues'] = [issue(code)]
                before = dumps_exact(frozen), wire(changed)
                result = check_initial(frozen, changed)
                self.assertEqual(result['validation_issues'], changed['validation_issues'])
                self.assertEqual(result['horses'], baseline['horses'])
                self.assertEqual(result['evidence_band_ranks'], baseline['evidence_band_ranks'])
                self.assertEqual(result.get('race_metrics'), baseline.get('race_metrics'))
                self.assertEqual((dumps_exact(frozen), wire(changed)), before)
                self.assertEqual(result['stage'], 'UNVERIFIED_MATERIAL_PACKET')

    def test_blank_diagnostic_repair_cannot_replace_or_mutate_valid_first(self):
        for role in ('1st', '2nd'):
            frozen, first = fixture(3, role)
            repaired = copy.deepcopy(first)
            repaired['validation_issues'] = [issue('\u2800')]
            req, options = repair_parts(frozen, first, repaired)
            before = [dumps_exact(value) for value in (frozen, first, req, repaired, options)]
            with self.assertRaises(ContractError):
                expand_checked_request(req, parse_response(wire(repaired)), frozen,
                    'DIAGNOSTIC-REPAIR', **options)
            self.assertEqual([dumps_exact(value) for value in (frozen, first, req, repaired, options)], before)
            context = {key: first[key] for key in ('race_id', 'snapshot_hash', 'ai_role', 'schema_version', 'prompt_version')}
            initial = dict(context, request_id=first['request_id'], response_hash=receipt_hash(options['first_raw']), received_at_ms=100000, acceptable=True)
            # A simulated server receipt whose structural check just failed;
            # no assertion that Laravel semantic validation was executed here.
            failed = dict(context, request_id='DIAGNOSTIC-REPAIR', response_hash=receipt_hash(wire(repaired)),
                first_response_hash=initial['response_hash'], received_at_ms=140000, acceptable=False, scope_ok=False)
            self.assertIs(retain_attempt(initial, failed, 150000, expected_context=context,
                first_request_id=first['request_id'], repair_request_id='DIAGNOSTIC-REPAIR',
                first_response_hash=initial['response_hash']), initial)

    def test_blank_first_diagnostic_can_be_fixed_without_evaluation_permission(self):
        for role in ('1st', '2nd'):
            frozen, first = fixture(3, role)
            first['validation_issues'] = [issue('\u2800')]
            repaired = copy.deepcopy(first)
            repaired['validation_issues'][0]['code'] = 'MISSING_SIMILAR_STATS'
            req, options = repair_parts(frozen, first, repaired)
            saved_hash = receipt_hash(options['first_raw'])
            result = expand_checked_request(req, parse_response(wire(repaired)), frozen,
                'DIAGNOSTIC-REPAIR', **options)
            self.assertEqual(result['validation_issues'], repaired['validation_issues'])
            self.assertEqual(first['validation_issues'][0]['code'], '\u2800')
            self.assertEqual(receipt_hash(options['first_raw']), saved_hash)
            self.assertEqual(req['first_response_hash'], saved_hash)
            self.assertEqual(repaired['horses'], first['horses'])
            self.assertEqual(repaired['evidence_band_ranks'], first['evidence_band_ranks'])

    def test_diagnostic_fix_does_not_authorize_any_score_change(self):
        for role in ('1st', '2nd'):
            frozen, first = fixture(3, role)
            first['validation_issues'] = [issue(' ')]
            repaired = copy.deepcopy(first)
            repaired['validation_issues'][0]['code'] = 'MISSING_SIMILAR_STATS'
            repaired['horses'][0]['scores']['H1']['value'] = 10
            req, options = repair_parts(frozen, first, repaired)
            with self.assertRaisesRegex(ContractError, 'REPAIR_OUT_OF_SCOPE:h1.scores'):
                expand_checked_request(req, parse_response(wire(repaired)), frozen,
                    'DIAGNOSTIC-REPAIR', **options)


if __name__ == '__main__':
    unittest.main(verbosity=2)
