"""Additional structural/repair-path tests on unchanged R4, no live semantics."""
import copy
from decimal import Decimal
import unittest

from reference_adapter import (BEGIN, END, SCHEMA, PROMPT, ContractError,
    dumps_exact, parse_response, expand_response, score_totals,
    ordinary_ranks_after_validation)
from request_guard import expand_checked_request, receipt_hash, same_value
from test_contract import fixture


def initial_request(frozen, reply):
    return {'response_contract': {'schema_version': SCHEMA, 'prompt_version': PROMPT,
                                 'request_id': reply['request_id']},
            'input': copy.deepcopy(frozen)}


def repair_request(frozen, first, scope):
    raw = BEGIN + '\n' + dumps_exact(first) + '\n' + END + '\n'
    request = initial_request(frozen, first)
    request['response_contract']['request_id'] = 'SECOND-REVIEW-REPAIR'
    request.update(first_response=copy.deepcopy(first), first_response_hash=receipt_hash(raw),
                   repair_scope=copy.deepcopy(scope),
                   errors=[{'code': 'SYNTHETIC_CHECK', 'reason': '構造試験用の明示された訂正'}])
    reply = copy.deepcopy(first)
    reply['request_id'] = request['response_contract']['request_id']
    kwargs = {'first_raw': raw, 'first_request_id': first['request_id'],
              'authorized_repair_scope': copy.deepcopy(scope)}
    return request, reply, kwargs


def check_repair(request, reply, frozen, kwargs):
    return expand_checked_request(request, reply, frozen,
                                  request['response_contract']['request_id'], **kwargs)


class SecondR4ReviewTests(unittest.TestCase):
    def test_selection_disabled_keeps_all_material_and_claim_ranks_without_publication(self):
        for role in ('1st', '2nd'):
            for n in (6, 13, 18):
                with self.subTest(role=role, n=n):
                    f, r = fixture(n=n, role=role)
                    f.update(selection_enabled=False, role_cap=0, role_quota=None)
                    before = dumps_exact(f)
                    request = initial_request(f, r)
                    packet = expand_checked_request(request, parse_response(BEGIN+'\n'+dumps_exact(r)+'\n'+END), f, r['request_id'])
                    self.assertEqual(len(packet['horses']), n)
                    self.assertEqual(packet['evidence_band_ranks'], r['evidence_band_ranks'])
                    self.assertEqual(packet['stage'], 'UNVERIFIED_MATERIAL_PACKET')
                    self.assertTrue({'public_candidates', 'buy_recommended', 'publish'}.isdisjoint(packet))
                    self.assertEqual(dumps_exact(f), before)

    def test_no_supported_family_has_empty_ranks_without_invented_candidates(self):
        for role in ('1st', '2nd'):
            f, r = fixture(role=role)
            for h in r['horses']:
                for name, review in h['review'].items():
                    if review['status'] == 'SUPPORTED':
                        review.update(status='NO_SUPPORT', observation=None, reason='資料を比較したが肯定根拠なし')
                        if name == 'market': review['market_claim'] = None
                h.update(rank_families=[], rank_reason='肯定根拠がなく順位の対象外')
                h['scores']['H1']['value'] = 0
                h['scores']['H2']['value'] = 0
            r['evidence_band_ranks'] = {b: [] for b in 'ABD'}
            packet = expand_response(r, f, r['request_id'])
            self.assertTrue(all(h['evidence'] == [] for h in packet['horses']))
            self.assertEqual(packet['evidence_band_ranks'], {b: [] for b in 'ABD'})
            rows = [dict(h, eligibility='NO_EVIDENCE') for h in packet['horses']]
            ranks, basis = ordinary_ranks_after_validation(rows, packet['evidence_band_ranks'])
            self.assertEqual(ranks, {b: [] for b in 'ABD'})
            self.assertEqual(set(basis.values()), {'EVIDENCE'})

    def test_single_supported_family_is_preserved_for_every_band(self):
        for family in ('ability', 'market'):
            f, r = fixture()
            for h in r['horses']:
                other = 'market' if family == 'ability' else 'ability'
                h['review'][other].update(status='NO_SUPPORT', observation=None, reason='もう一方の系統は支持なし')
                if other == 'market': h['review'][other]['market_claim'] = None
                h['scores']['H2' if other == 'market' else 'H1']['value'] = 0
                h['rank_families'] = [family]
            packet = expand_response(r, f, r['request_id'])
            self.assertEqual(packet['evidence_band_ranks'], r['evidence_band_ranks'])
            for h in packet['horses']:
                self.assertEqual([e['family'] for e in h['evidence']], [family])
                self.assertEqual(h['evidence_rank_evidence_ids'], ['h'+str(h['horse_no'])+'_'+family])

    def test_more_than_four_sources_keep_complete_facts_and_reused_score_union(self):
        f, r = fixture()
        h = r['horses'][10]
        refs = h['review']['ability']['source_refs']
        value = {'decimal': Decimal('0.123456789012345678901234567890123456789'),
                 'text': '比較条件\u2028二行目', 'observed_zero': 0, 'missing': None}
        for number in range(31):
            ref = 'h11_additional_condition_'+str(number)
            row = copy.deepcopy(f['source_registry']['h11_past_finish_1'])
            row.update(source_ref=ref, field='synthetic_condition_'+str(number), value=copy.deepcopy(value))
            f['source_registry'][ref] = row
            refs.append(ref)
        h['scores']['V2']['extra_source_refs'].extend(refs[:3])
        request = initial_request(f, r)
        packet = expand_checked_request(request, parse_response(BEGIN+'\n'+dumps_exact(r)+'\n'+END), f, r['request_id'])
        material = packet['horses'][10]
        ability = next(e for e in material['evidence'] if e['family'] == 'ability')
        self.assertEqual(len(ability['facts']), 35)
        self.assertEqual(ability['source_refs'], refs)
        self.assertTrue(same_value(ability['facts'][-1]['value'], value))
        self.assertEqual(material['score_evidence']['V2']['source_refs'], refs+['h11_win_odds_6'])
        self.assertIsNone(material['scores']['H4'])
        self.assertIsNone(score_totals(material['scores'])['total_score'])

    def test_removing_only_support_needs_evaluation_ranking_and_band_permissions(self):
        for role in ('1st', '2nd'):
            f, first = fixture(role=role)
            scope = {'horses': [11], 'ranking_horses': [], 'rank_bands': [], 'race_metrics': []}
            request, reply, kw = repair_request(f, first, scope)
            horse = reply['horses'][10]
            for family in ('ability', 'market'):
                horse['review'][family].update(status='NO_SUPPORT', observation=None, reason='訂正で肯定根拠の誤りを確認')
            horse['review']['market']['market_claim'] = None
            horse['scores']['H1']['value'] = 0
            horse['scores']['H2']['value'] = 0
            horse.update(rank_families=[], rank_reason='訂正後は順位の対象外')
            reply['evidence_band_ranks']['D'].remove(11)
            with self.assertRaisesRegex(ContractError, 'OUT_OF_SCOPE:h11.rank_families'):
                check_repair(request, reply, f, kw)
            for holder in (request['repair_scope'], kw['authorized_repair_scope']):
                holder['ranking_horses'] = [11]
            with self.assertRaisesRegex(ContractError, 'OUT_OF_SCOPE:band.D'):
                check_repair(request, reply, f, kw)
            for holder in (request['repair_scope'], kw['authorized_repair_scope']):
                holder['rank_bands'] = ['D']
            packet = check_repair(request, reply, f, kw)
            before = expand_response(first, f, first['request_id'])
            self.assertEqual(packet['horses'][10]['evidence'], [])
            self.assertEqual(packet['evidence_band_ranks']['D'], [12, 13, 14, 15, 16, 17, 18])
            for i in range(18):
                if i != 10: self.assertEqual(packet['horses'][i], before['horses'][i])
            self.assertEqual(receipt_hash(kw['first_raw']), request['first_response_hash'])

    def test_parseable_invalid_first_score_and_missing_band_can_be_repaired_explicitly(self):
        f, first = fixture()
        first['horses'][6]['scores']['H1']['value'] = True
        del first['evidence_band_ranks']['B']
        scope = {'horses': [7], 'ranking_horses': [], 'rank_bands': ['B'], 'race_metrics': []}
        request, reply, kw = repair_request(f, first, scope)
        reply['horses'][6]['scores']['H1']['value'] = 9
        reply['evidence_band_ranks']['B'] = [7, 8, 9, 10]
        packet = check_repair(request, reply, f, kw)
        self.assertIs(type(packet['horses'][6]['scores']['H1']), int)
        self.assertIs(request['first_response']['horses'][6]['scores']['H1']['value'], True)
        self.assertNotIn('B', request['first_response']['evidence_band_ranks'])
        request['repair_scope']['rank_bands'] = []
        kw['authorized_repair_scope']['rank_bands'] = []
        with self.assertRaisesRegex(ContractError, 'OUT_OF_SCOPE:band.B'):
            check_repair(request, reply, f, kw)

    def test_failed_last_horse_or_metric_reference_does_not_mutate_any_saved_material(self):
        for place in ('last_horse', 'metric'):
            f, first = fixture(role='1st')
            scope = {'horses': [18], 'ranking_horses': [], 'rank_bands': [], 'race_metrics': ['wave_level']}
            request, reply, kw = repair_request(f, first, scope)
            if place == 'last_horse':
                reply['horses'][17]['scores']['V4']['extra_source_refs'] = ['NONEXISTENT']
            else:
                reply['race_metrics']['wave_level']['source_refs'] = ['NONEXISTENT']
            saved = [dumps_exact(x) for x in (f, first, request, reply, kw)]
            with self.assertRaises(ContractError):check_repair(request, reply, f, kw)
            self.assertEqual([dumps_exact(x) for x in (f, first, request, reply, kw)], saved)

    def test_legacy_publication_and_server_derived_fields_are_not_accepted_from_ai(self):
        for key, value in [('public_candidates', [1]), ('selection_ranks', {'A': [1], 'B': [], 'D': []}),
                           ('buy_recommended', True), ('expected_v01', {}), ('role_quota', {'A': 6, 'B': 0, 'D': 0})]:
            f, r = fixture()
            r[key] = value
            with self.subTest(key=key), self.assertRaisesRegex(ContractError, 'OUTPUT_SCHEMA'):
                expand_response(r, f, r['request_id'])
        for key, value in [('tier', 'A'), ('eligibility', 'ELIGIBLE'), ('total_score', 100)]:
            f, r = fixture()
            r['horses'][0][key] = value
            with self.subTest(key=key), self.assertRaisesRegex(ContractError, 'OUTPUT_SCHEMA'):
                expand_response(r, f, r['request_id'])


if __name__ == '__main__':
    unittest.main(verbosity=2)
