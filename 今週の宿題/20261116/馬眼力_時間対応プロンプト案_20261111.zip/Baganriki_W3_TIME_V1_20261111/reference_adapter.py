"""W3 wire expansion reference. NOT a production validator or publisher.

The caller supplies an authenticated, decoded frozen INPUT_JSON. Run the full
versioned Laravel evidence/score/rank validator after this structural layer.
No tier, eligibility, expected-value swap or public candidate is authorized here.
"""
from copy import deepcopy
from datetime import datetime, timedelta
from decimal import Decimal
from fractions import Fraction
from pathlib import Path
import json
import re
import unicodedata
from jsonschema import Draft202012Validator, validators

SCHEMA='baganriki-w3-time-v1'
PROMPT='baganriki-w3-time-v1-20261111-r9'
BEGIN='<<<BAGANRIKI_W3_TIME_V1_BEGIN>>>'
END='<<<BAGANRIKI_W3_TIME_V1_END>>>'
FAMILIES=('ability','market','gap','win_place','similar_value')
CAPS={'H1':18,'H2':15,'H3':12,'H4':9,'H5':6,'V1':12,'V2':10,'V3':8,'V4':6,'V5':4}

class ContractError(ValueError): pass

def need(ok, code):
    if not ok: raise ContractError(code)

def exact_json_integer(value):
    """Recognize an exact JSON integer without float conversion or rounding.

    strict_loads represents 9.0 as Decimal while JSON Schema's integer is a
    mathematical integer. Inspect fractional coefficient digits directly;
    even a nonzero digit beyond the Decimal context precision must reject.
    """
    if type(value) is int:return True
    if type(value) is not Decimal or not value.is_finite():return False
    parts=value.as_tuple()
    return parts.exponent>=0 or not any(parts.digits[parts.exponent:])

ExactJSONValidator=validators.extend(Draft202012Validator,
    type_checker=Draft202012Validator.TYPE_CHECKER.redefine('integer',
        lambda checker,value:exact_json_integer(value)))

def bounded_decimal(value):
    """128 digits in fixed notation, including leading integer zero.

    Exponent notation must not bypass the limit or create enormous Fractions.
    This does not round, rescale, or rewrite the source value.
    """
    need(value.is_finite(),'NONFINITE_JSON_NUMBER')
    integer_digits=max(value.adjusted()+1,1)
    fraction_digits=max(-value.as_tuple().exponent,0)
    need(integer_digits+fraction_digits<=128,'NUMBER_TOO_LONG')
    return value

def strict_loads(raw):
    def pairs(items):
        out={}
        for k,v in items:
            need(k not in out,'DUPLICATE_JSON_KEY')
            out[k]=v
        return out
    def integer(s):
        need(len(s.lstrip('-'))<=128,'NUMBER_TOO_LONG')
        return int(s)
    def decimal(s):
        need(sum(c.isdigit() for c in s)<=128,'NUMBER_TOO_LONG')
        if 'e' in s.lower():need(abs(int(s.lower().split('e',1)[1]))<=128,'NUMBER_TOO_LONG')
        return bounded_decimal(Decimal(s))
    def constant(_): raise ContractError('NONFINITE_JSON_NUMBER')
    try:
        data=json.loads(raw,object_pairs_hook=pairs,parse_int=integer,parse_float=decimal,parse_constant=constant)
    except (json.JSONDecodeError,RecursionError) as exc:
        raise ContractError('INVALID_JSON') from exc
    def walk(x,depth=0):
        need(depth<=64,'JSON_TOO_DEEP')
        if isinstance(x,str):
            need(not any(0xD800<=ord(c)<=0xDFFF for c in x),'UNPAIRED_SURROGATE')
        elif isinstance(x,dict):
            for k,v in x.items(): walk(k,depth+1);walk(v,depth+1)
        elif isinstance(x,list):
            for v in x:walk(v,depth+1)
    walk(data)
    return data

def dumps_exact(x):
    """Emit bounded, fixed-notation JSON from exact decoded values.

    Use strict_loads for input numbers. A float has already lost its original
    decimal representation; do not pretend a conversion restores exactness.
    The whole serializer enforces the same depth/string/number limits as input.
    """
    def emit(value,depth=0):
        need(depth<=64,'JSON_TOO_DEEP')
        if isinstance(value,Decimal):return format(bounded_decimal(value),'f')
        if type(value) is int:
            need(-10**128<value<10**128,'NUMBER_TOO_LONG')
            return str(value)
        if isinstance(value,str):
            need(not any(0xD800<=ord(c)<=0xDFFF for c in value),'UNPAIRED_SURROGATE')
            return json.dumps(value,ensure_ascii=False)
        if isinstance(value,dict):
            need(all(isinstance(k,str) for k in value),'NONSTRING_JSON_KEY')
            return '{'+','.join(emit(k,depth+1)+':'+emit(v,depth+1) for k,v in value.items())+'}'
        if isinstance(value,list):return '['+','.join(emit(v,depth+1) for v in value)+']'
        if value is None or type(value) is bool:return json.dumps(value)
        need(not isinstance(value,float),'FLOAT_NOT_EXACT')
        raise ContractError('INVALID_JSON_TYPE')
    return emit(x)

def parse_response(raw):
    need(isinstance(raw,str),'WIRE_TEXT_REQUIRED')
    # JSON strings can legally contain U+2028/U+2029. splitlines() corrupts them.
    lines=raw.strip().split('\n')
    need(len(lines)>=3 and lines[0].removesuffix('\r')==BEGIN and lines[-1].removesuffix('\r')==END,'WIRE_MARKERS')
    return strict_loads('\n'.join(lines[1:-1]))

def instant(s):
    """Read the source contract's zoned RFC3339 time, never losing precision.

    datetime.fromisoformat accepts and truncates fractional seconds past six
    digits. Reject those strings before conversion; even an all-zero suffix is
    outside this microsecond contract. Also reject basic/week dates, arbitrary
    separators and second-precision offsets rather than normalizing them.
    """
    need(isinstance(s,str),'MISSING_TIMESTAMP')
    need(re.fullmatch(
        r'[0-9]{4}-[0-9]{2}-[0-9]{2}[Tt]'
        r'(?:[01][0-9]|2[0-3]):[0-5][0-9]:[0-5][0-9]'
        r'(?:\.[0-9]{1,6})?'
        r'(?:[Zz]|[+-](?:[01][0-9]|2[0-3]):[0-5][0-9])',s) is not None,
        'INVALID_TIMESTAMP')
    normalized=s[:10]+'T'+s[11:]
    if normalized[-1] in 'Zz':normalized=normalized[:-1]+'+00:00'
    try:value=datetime.fromisoformat(normalized)
    except ValueError as exc:raise ContractError('INVALID_TIMESTAMP') from exc
    need(value.tzinfo is not None,'NAIVE_TIMESTAMP')
    return value

# Additional blank glyphs and nonrendering modifiers covered by the existing
# BaganrikiText policy but not by Unicode whitespace/control categories alone.
# This is a presence check only: never strip, normalize, or rewrite saved text.
NONVISIBLE_TEXT_RANGES=((0x034F,0x034F),(0x115F,0x1160),(0x17B4,0x17B5),
    (0x180B,0x180F),(0x2800,0x2800),(0x3164,0x3164),(0xFE00,0xFE0F),
    (0xFFA0,0xFFA0),(0xE0000,0xE0FFF))

def visible(s):
    return isinstance(s,str) and any(
        not c.isspace() and unicodedata.category(c)[0] not in 'CZ'
        and not any(lo<=ord(c)<=hi for lo,hi in NONVISIBLE_TEXT_RANGES)
        for c in s)

def unique(items):return list(dict.fromkeys(items))

def applicable(row,no):
    return (row.get('scope') in ('HORSE','PAIR') and no in row.get('horse_nos',[])) or (row.get('scope')=='COHORT' and no in row.get('applicable_horse_nos',[]))

def checked_ref(reg,ref,no,frozen,allow_race=False):
    need(ref in reg,'UNKNOWN_SOURCE_REF')
    r=reg[ref]
    need(r.get('source_ref',ref)==ref and r.get('race_id')==frozen['race_id'],'SOURCE_ID_MISMATCH')
    need(applicable(r,no) or (allow_race and r.get('scope')=='RACE'),'SOURCE_NOT_APPLICABLE')
    upper=instant(frozen['input_freeze_at'])
    need(instant(r['available_at'])<=upper,'SOURCE_AFTER_FREEZE')
    if r.get('observed_at') is not None:need(instant(r['observed_at'])<=upper,'OBSERVATION_AFTER_FREEZE')
    slot=r.get('slot_offset')
    if slot is not None:
        tc=frozen['time_contract'];key=str(slot)
        need(key in tc['acquisition_grace_ms'],'UNKNOWN_SLOT')
        limit=instant(tc['anchor_at'])-timedelta(minutes=slot)+timedelta(milliseconds=tc['acquisition_grace_ms'][key])
        need(instant(r['available_at'])<=limit,'SOURCE_AFTER_SLOT_DEADLINE')
    return r

def load_contract_schema(kind):
    """Bind a schema resource to this exact prompt revision and direction.

    Wire shape may remain the same while prompt_version constants change.
    Reusing one resource ID would let a shared registry shadow another release.
    Older schemas keep their original IDs in isolated legacy registries.
    """
    need(kind in ('request','output'),'SCHEMA_RESOURCE_KIND')
    schema=json.loads((Path(__file__).parent/(kind+'_schema.json')).read_text())
    expected_id='urn:baganriki:'+PROMPT.removeprefix('baganriki-')+':'+kind
    need(isinstance(schema,dict) and schema.get('$id')==expected_id,
         kind.upper()+'_SCHEMA_RESOURCE_ID')
    return schema

def validate_schema(reply):
    schema=load_contract_schema('output')
    errors=list(ExactJSONValidator(schema).iter_errors(reply))
    need(not errors,'OUTPUT_SCHEMA:'+(';'.join('/'.join(map(str,e.absolute_path)) for e in errors[:5])))
    # minLength alone accepts blank/invisible diagnostic identifiers. Check
    # presence without normalizing the original text or changing saved hashes.
    for issue in reply['validation_issues']:
        need(visible(issue['code']),'EMPTY_DIAGNOSTIC_CODE')
    def walk(x):
        if isinstance(x,dict):
            for k,v in x.items():
                if k in ('reason','rank_reason','explanation') or (k=='observation' and v is not None):need(visible(v),'EMPTY_VISIBLE_TEXT')
                walk(v)
        elif isinstance(x,list):
            for v in x:walk(v)
    walk(reply)

def canonical_reply_integers(reply):
    """Copy declared integer fields AFTER schema validation; retain raw input.

    Never apply this to frozen source data or stored response text. Nulls,
    explanation strings, reference names and source facts stay unchanged.
    """
    out=deepcopy(reply)
    for horse in out['horses']:
        horse['horse_no']=int(horse['horse_no'])
        for score in horse['scores'].values():
            if score['value'] is not None:score['value']=int(score['value'])
    for band in out['evidence_band_ranks']:
        out['evidence_band_ranks'][band]=[int(n) for n in out['evidence_band_ranks'][band]]
    for issue in out['validation_issues']:
        if issue['horse_no'] is not None:issue['horse_no']=int(issue['horse_no'])
    if out['ai_role']=='1st':
        for metric in out['race_metrics'].values():
            if metric['value'] is not None:metric['value']=int(metric['value'])
    return out

def expand_response(reply,frozen,request_id):
    """Expand exact facts/ref reuse; return an explicitly UNVERIFIED packet.

    Eligibility and family support are CLAIMS at this boundary. The ordinary
    ranking must be chosen only AFTER the existing semantic checks complete.
    """
    validate_schema(reply)
    reply=canonical_reply_integers(reply)
    need(reply['request_id']==request_id,'REQUEST_ID_MISMATCH')
    for k in ('race_id','snapshot_hash','ai_role'):need(reply[k]==frozen[k],'HEADER_MISMATCH:'+k)
    roster={r['horse_no']:r for r in frozen['runners']}
    need(len(roster)==frozen['N'],'INPUT_ROSTER_INVALID')
    nos=[h['horse_no'] for h in reply['horses']]
    need(nos==sorted(roster),'ALL_RUNNERS_REQUIRED')
    reg=frozen['source_registry'];horses=[];claimed={b:[] for b in 'ABD'}
    for h in reply['horses']:
        no=h['horse_no'];review=h['review'];ev=[];fr={};scores={};proof={}
        for f in FAMILIES:
            r=review[f];refs=r['source_refs']
            rows=[checked_ref(reg,x,no,frozen,allow_race=True) for x in refs]
            supp=r['status']=='SUPPORTED';eid=f'h{no}_{f}'
            if supp:
                need(any(x.get('value') is not None and x.get('dependency_role')=='SIGNAL' and applicable(x,no) for x in rows),'NO_APPLICABLE_SIGNAL')
                e={'evidence_id':eid,'family':f,'dependency_group':f'w3:{no}:{f}','source_refs':deepcopy(refs),'facts':[{'source_ref':ref,'value':deepcopy(reg[ref]['value'])} for ref in refs],'observation':r['observation'],'interpretation':r['reason']}
                if f=='market':
                    e['market_claim']=deepcopy(r['market_claim'])
                    claim=r['market_claim']
                    need((claim['kind']=='OTHER' and claim['metric'] is None) or (claim['kind']=='ACCELERATION' and claim['metric'] is not None),'MARKET_CLAIM_SHAPE')
                    if claim['kind']=='ACCELERATION':
                        need(r['observation']=='支持加速（12→9→6分）','ACCELERATION_LABEL')
                        seq={}
                        for x in rows:
                            if x.get('field')!=claim['metric'] or x.get('scope')!='HORSE' or x.get('horse_nos')!=[no] or x.get('slot_offset') not in (12,9,6) or x.get('value') is None:
                                continue
                            slot=x['slot_offset'];value=x['value']
                            need(slot not in seq,'ACCELERATION_AMBIGUOUS_SLOT')
                            need(type(value) is int or isinstance(value,Decimal),'ACCELERATION_NONNUMERIC_SOURCE')
                            seq[slot]=Fraction(bounded_decimal(Decimal(value)))
                        need(all(s in seq for s in (12,9,6)),'ACCELERATION_MISSING_SLOTS')
                        a,b,c=(seq[s] for s in (12,9,6))
                        need(a>b>c>0 and b*b>a*c,'FALSE_ACCELERATION')
                    else:need(r['observation']=='市場比較（支持加速を根拠にしない）','MARKET_OTHER_LABEL')
                ev.append(e)
            elif r['status']=='NO_SUPPORT':
                need(any(x.get('value') is not None and applicable(x,no) for x in rows),'NO_SUPPORT_WITHOUT_DATA')
            fr[f]={'status':r['status'],'source_refs':deepcopy(refs),'evidence_ids':[eid] if supp else [],'reason':r['reason']}
        for key,x in h['scores'].items():
            refs=unique([ref for f in x['basis_families'] for ref in review[f]['source_refs']]+x['extra_source_refs'])
            rows=[checked_ref(reg,ref,no,frozen,allow_race=True) for ref in refs]
            need(x['value'] is None or bool(refs),'KNOWN_SCORE_WITHOUT_REFS')
            need(x['value'] is None or any(r.get('value') is not None and applicable(r,no) for r in rows),'KNOWN_SCORE_WITHOUT_DATA')
            scores[key]=x['value'];proof[key]={'source_refs':refs,'reason':x['reason']}
        for x in h['counterevidence']:
            # Shared race conditions can contextualize this horse's data, but
            # cannot replace it or act as a standalone individual counterclaim.
            rows=[checked_ref(reg,ref,no,frozen,
                allow_race=reg.get(ref,{}).get('dependency_role')=='CONTEXT')
                for ref in x['source_refs']]
            need(any(r.get('value') is not None and applicable(r,no) for r in rows),
                 'COUNTER_WITHOUT_DATA')
        supported={f for f in FAMILIES if review[f]['status']=='SUPPORTED'}
        need(set(h['rank_families'])<=supported,'RANK_FAMILY_NOT_SUPPORTED')
        need(bool(h['rank_families'])==bool(ev),'RANK_PROOF_REQUIRED')
        band=roster[no]['band']
        if ev:claimed[band].append(no)
        horses.append({'horse_no':no,'band':band,'family_review':fr,'evidence':ev,'counterevidence':deepcopy(h['counterevidence']),'scores':scores,'score_evidence':proof,'evidence_rank_evidence_ids':[f'h{no}_{f}' for f in h['rank_families']],'evidence_rank_reason':h['rank_reason'],'explanation':h['explanation']})
    for band in 'ABD':
        need(sorted(reply['evidence_band_ranks'][band])==sorted(claimed[band]),'RANK_SET_MISMATCH:'+band)
    packet={'stage':'UNVERIFIED_MATERIAL_PACKET','wire_schema_version':SCHEMA,'prompt_version':PROMPT,'request_id':request_id,'race_id':reply['race_id'],'snapshot_hash':reply['snapshot_hash'],'ai_role':reply['ai_role'],'horses':horses,'evidence_band_ranks':deepcopy(reply['evidence_band_ranks']),'validation_issues':deepcopy(reply['validation_issues'])}
    if reply['ai_role']=='1st':
        # Strict temporal/applicability guards here; complete RACE_METRICS_V1
        # requirements (band, slots, threshold) remain with Laravel.
        for m in reply['race_metrics'].values():
            for ref in m['source_refs']:
                need(ref in reg,'UNKNOWN_METRIC_REF');r=reg[ref]
                need(r.get('scope')=='HORSE' and r.get('field') in ('win_odds','place_min','place_max') and len(r.get('horse_nos',[]))==1,'BAD_METRIC_SOURCE')
                no=r['horse_nos'][0];need(no in roster,'METRIC_HORSE_MISMATCH');checked_ref(reg,ref,no,frozen)
        packet['race_metrics']=deepcopy(reply['race_metrics'])
    return packet

def score_totals(scores):
    """Call after material validation; never supplies missing subjective points."""
    need(set(scores)==set(CAPS),'SCORE_KEYS')
    for k,v in scores.items():need(v is None or (type(v) is int and 0<=v<=CAPS[k]),'SCORE_RANGE')
    complete=all(v is not None for v in scores.values())
    observed=sum(v for v in scores.values() if v is not None)
    return {'score_status':'complete' if complete else 'partial','total_score':observed if complete else None,'observed_sum':observed,'observed_cap':sum(CAPS[k] for k,v in scores.items() if v is not None)}

def ordinary_ranks_after_validation(validated_horses,evidence_ranks):
    """Pure comparator. Caller must supply semantically validated horses.

    This has no publication side effects and does not validate free-text claims.
    A failed evidence rank is raised for existing local recovery, not auto-fixed.
    """
    result={};basis={}
    for b in 'ABD':
        rows=[h for h in validated_horses if h['band']==b and h['eligibility']=='ELIGIBLE']
        need(set(evidence_ranks[b])=={h['horse_no'] for h in rows} and len(evidence_ranks[b])==len(rows),'VALIDATED_RANK_SET')
        complete=bool(rows) and all(score_totals(h['scores'])['score_status']=='complete' for h in rows)
        basis[b]='SCORE' if complete else 'EVIDENCE'
        if complete:
            def key(h):
                s=h['scores'];return (-sum(s.values()),-sum(v for k,v in s.items() if k.startswith('V')),-sum(v for k,v in s.items() if k.startswith('H')),h['horse_no'])
            result[b]=[h['horse_no'] for h in sorted(rows,key=key)]
        else:result[b]=list(evidence_ranks[b])
    return result,basis
