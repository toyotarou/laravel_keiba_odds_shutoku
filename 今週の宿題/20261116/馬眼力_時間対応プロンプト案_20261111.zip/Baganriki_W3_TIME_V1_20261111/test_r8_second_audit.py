"""Independent R8 follow-up: synthetic structural tests, no live AI/publication.

The ranking/receipt tests explicitly assume prior semantic server validation.
The reference adapter is not used to assert predictive accuracy.
"""
import copy
import itertools
import random
import unittest
from decimal import Decimal, localcontext
from fractions import Fraction

from reference_adapter import (SCHEMA, PROMPT, CAPS, FAMILIES, BEGIN, END,
    ContractError, dumps_exact, parse_response, ordinary_ranks_after_validation)
from request_guard import expand_checked_request, receipt_hash
from deadline_policy import retain_attempt, retry_decision, AttemptTiming
from test_contract import fixture


def request(frozen, reply):
    return {'response_contract': {'schema_version': SCHEMA,
        'prompt_version': PROMPT, 'request_id': reply['request_id']},
        'input': copy.deepcopy(frozen)}


def expand(frozen, reply):
    # Expected ID belongs to the saved server request, never a malformed reply.
    expected_request_id = 'TEST-REQUEST-001'
    req = request(frozen, {'request_id': expected_request_id})
    raw = BEGIN + '\n' + dumps_exact(reply) + '\n' + END
    return expand_checked_request(req, parse_response(raw), frozen, expected_request_id)


def at_path(value, path):
    for key in path:
        value = value[key]
    return value


def required_paths(value, path=()):
    # Every property present in this fixture response is a required property.
    if isinstance(value, dict):
        for key, child in value.items():
            yield path + (key,)
            yield from required_paths(child, path + (key,))
    elif isinstance(value, list):
        for index, child in enumerate(value):
            yield from required_paths(child, path + (index,))


class R8SecondAudit(unittest.TestCase):
    def test_acceleration_against_exact_rate_oracle_across_scales(self):
        # The oracle computes the two rates directly; implementation uses
        # products. Include an equality boundary +/- 10^-60 without rounding.
        delta = Fraction(1, 10**60)
        triples = [(10, 8, 6), (10, 8, Fraction(32, 5)), (10, 8, 7),
            (10, 10, 9), (10, 11, 8), (10, 8, 8), (10, 8, 0),
            (10, 8, Fraction(32, 5)-delta),
            (10, 8, Fraction(32, 5)+delta)]
        for role, metric, scale in itertools.product(('1st', '2nd'),
                ('win_odds', 'place_min', 'place_max'),
                (Fraction(1, 10**18), Fraction(1), Fraction(10**18))):
            for triple in triples:
                values = [Fraction(v)*scale for v in triple]
                a, b, c = values
                expected = a > 0 and b > 0 and c > 0 and (a-b)/a > 0 and (b-c)/b > (a-b)/a
                frozen, reply = fixture(1, role)
                review = reply['horses'][0]['review']['market']
                review.update(source_refs=[f'h1_{metric}_{s}' for s in (12, 9, 6)],
                    observation='支持加速（12→9→6分）',
                    market_claim={'kind': 'ACCELERATION', 'metric': metric})
                with localcontext() as ctx:
                    ctx.prec = 300
                    for slot, value in zip((12, 9, 6), values):
                        frozen['source_registry'][f'h1_{metric}_{slot}']['value'] = Decimal(value.numerator)/Decimal(value.denominator)
                before = dumps_exact(frozen), dumps_exact(reply)
                with self.subTest(role=role, metric=metric, scale=str(scale), triple=str(triple)):
                    with localcontext() as ctx:
                        ctx.prec = 6
                        if expected:
                            packet = expand(frozen, reply)
                            self.assertEqual(packet['stage'], 'UNVERIFIED_MATERIAL_PACKET')
                        else:
                            with self.assertRaisesRegex(ContractError, 'FALSE_ACCELERATION'):
                                expand(frozen, reply)
                    self.assertEqual((dumps_exact(frozen), dumps_exact(reply)), before)

    def test_deleting_each_required_response_property_fails_closed(self):
        for role in ('1st', '2nd'):
            frozen, good = fixture(1, role)
            original = dumps_exact(frozen), dumps_exact(good)
            for path in required_paths(good):
                bad = copy.deepcopy(good)
                del at_path(bad, path[:-1])[path[-1]]
                with self.subTest(role=role, path=path), self.assertRaises(ContractError):
                    expand(frozen, bad)
            self.assertEqual((dumps_exact(frozen), dumps_exact(good)), original)
            self.assertEqual(len(expand(frozen, good)['horses']), 1)

    def test_no_sources_preserves_all_unassessed_horses_without_inventing_zero(self):
        for role, count in itertools.product(('1st', '2nd'), range(1, 19)):
            frozen, reply = fixture(count, role)
            frozen['source_registry'] = {}
            for horse in reply['horses']:
                for family, item in horse['review'].items():
                    item.update(status='DATA_MISSING', source_refs=[], observation=None, reason='利用可能な対応資料がない')
                    if family == 'market':
                        item['market_claim'] = None
                for item in horse['scores'].values():
                    item.update(value=None, basis_families=[], extra_source_refs=[], reason='採点に必要な資料がない')
                horse.update(counterevidence=[], rank_families=[], rank_reason='資料不足で順位対象外', explanation='必要な評価資料がなく、未評価のまま保持する。')
            reply['evidence_band_ranks'] = {b: [] for b in 'ABD'}
            with self.subTest(role=role, count=count):
                packet = expand(frozen, reply)
                self.assertEqual(len(packet['horses']), count)
                self.assertEqual(packet['evidence_band_ranks'], {'A': [], 'B': [], 'D': []})
                self.assertNotIn('public_candidates', packet)
                for horse in packet['horses']:
                    self.assertEqual(horse['scores'], {key: None for key in CAPS})
                    self.assertFalse(horse['evidence'])
                    self.assertEqual(set(horse['family_review']), set(FAMILIES))

    def test_missingness_changes_only_its_band_and_never_promotes_ineligible_horse(self):
        # Simulated, semantically validated rows. Compare to a fixed explicit
        # ordering rather than invoking the production score aggregator.
        rows = []
        for no in range(1, 19):
            scores = {key: 0 for key in CAPS}
            scores['H1'] = 9
            rows.append({'horse_no': no, 'band': 'A' if no <= 6 else 'B' if no <= 10 else 'D',
                'eligibility': 'ELIGIBLE' if no != 18 else 'NO_EVIDENCE', 'scores': scores})
        rows[1]['scores'].update(H1=8, V1=1)  # equal total, larger V wins
        rows[2]['scores'].update(H1=10)
        rows[6]['scores']['V4'] = None
        rows[17]['scores'] = dict(CAPS)      # ineligible, even at maximum points
        evidence = {'A': [6, 5, 4, 3, 2, 1], 'B': [10, 9, 8, 7], 'D': list(range(17, 10, -1))}
        original = copy.deepcopy((rows, evidence))
        for seed in range(20):
            shuffled = copy.deepcopy(rows)
            random.Random(seed).shuffle(shuffled)
            ranks, basis = ordinary_ranks_after_validation(shuffled, evidence)
            self.assertEqual(ranks, {'A': [3, 2, 1, 4, 5, 6], 'B': [10, 9, 8, 7], 'D': list(range(11, 18))})
            self.assertEqual(basis, {'A': 'SCORE', 'B': 'EVIDENCE', 'D': 'SCORE'})
        self.assertEqual((rows, evidence), original)

    def test_visible_non_ascii_reference_ids_remain_exact_after_json_escape(self):
        for role in ('1st', '2nd'):
            frozen, reply = fixture(1, role)
            old, new = 'h1_past_finish_1', '資料/か\u3099/１/"引用"'
            row = frozen['source_registry'].pop(old)
            row['source_ref'] = new
            frozen['source_registry'][new] = row
            reply['horses'][0]['review']['ability']['source_refs'][0] = new
            expected = expand(frozen, reply)
            raw = BEGIN + '\n' + dumps_exact(reply) + '\n' + END
            escaped = raw.replace('資料', '\\u8cc7\\u6599')
            self.assertNotEqual(receipt_hash(raw), receipt_hash(escaped))
            req = request(frozen, reply)
            self.assertEqual(expand_checked_request(req, parse_response(escaped), frozen, reply['request_id']), expected)
            bad = copy.deepcopy(reply)
            bad['horses'][0]['review']['ability']['source_refs'][0] = new.replace('か\u3099', 'が')
            with self.assertRaisesRegex(ContractError, 'UNKNOWN_SOURCE_REF'):
                expand(frozen, bad)

    def test_initial_resend_receipt_matrix_preserves_earliest_valid_whole_answer(self):
        deadline = 150000
        states = ('absent', 'invalid', 'foreign', 'bad_hash', 'early', 'exact', 'late')
        for role in ('1st', '2nd'):
            context = dict(race_id='SYNTHETIC', snapshot_hash='a'*64, ai_role=role, schema_version=SCHEMA, prompt_version=PROMPT)
            def receipt(state, request_id, marker):
                if state == 'absent': return None
                value = dict(context, request_id=request_id, response_hash=marker*64,
                    received_at_ms={'early': 149999, 'exact': 150000, 'late': 150001}.get(state, 149999), acceptable=True)
                if state == 'invalid': value['acceptable'] = False
                if state == 'foreign': value['race_id'] = 'OTHER'
                if state == 'bad_hash': value['response_hash'] = marker*64+'\n'
                return value
            for first_state, resend_state in itertools.product(states, repeat=2):
                first = receipt(first_state, 'FIRST', 'b')
                resend = receipt(resend_state, 'RESEND', 'c')
                expected = None
                if first_state == 'early': expected = first
                elif resend_state == 'early': expected = resend
                elif first_state == 'exact': expected = first
                elif resend_state == 'exact': expected = resend
                before = copy.deepcopy((first, resend))
                with self.subTest(role=role, first=first_state, resend=resend_state):
                    for _ in range(2):
                        self.assertIs(retain_attempt(first, None, deadline, expected_context=context,
                            first_request_id='FIRST', resend=resend, resend_request_id='RESEND'), expected)
                    self.assertEqual((first, resend), before)

    def test_repair_cannot_forgo_chronology_hash_scope_or_deadline(self):
        context = dict(race_id='SYNTHETIC', snapshot_hash='a'*64, ai_role='1st', schema_version=SCHEMA, prompt_version=PROMPT)
        first = dict(context, request_id='FIRST', response_hash='b'*64, received_at_ms=100000, acceptable=True)
        for received, scope_ok, correct_hash, acceptable in itertools.product(
                (99999, 100000, 150000, 150001), (False, True), (False, True), (False, True)):
            repair = dict(context, request_id='REPAIR', response_hash='c'*64,
                received_at_ms=received, acceptable=acceptable, scope_ok=scope_ok,
                first_response_hash='b'*64 if correct_hash else 'd'*64)
            expected = repair if 100000 <= received <= 150000 and scope_ok and correct_hash and acceptable else first
            before = copy.deepcopy((first, repair))
            with self.subTest(received=received, scope_ok=scope_ok, correct_hash=correct_hash, acceptable=acceptable):
                self.assertIs(retain_attempt(first, repair, 150000, expected_context=context,
                    first_request_id='FIRST', repair_request_id='REPAIR', first_response_hash='b'*64), expected)
                self.assertEqual((first, repair), before)

    def test_retry_budget_is_bound_to_kind_and_shared_extra_call_limit(self):
        for kind in ('REPAIR', 'RESEND'):
            base = dict(reply_deadline_ms=150000, additional_calls_used=0, attempt_kind=kind,
                timing=AttemptTiming(kind, 70000), queue_p95_ms=1000, validation_p95_ms=2000,
                reserve_ms=10000, retry_required=True, in_flight=False)
            self.assertTrue(retry_decision(now_ms=67000, **base).allowed)
            self.assertFalse(retry_decision(now_ms=67001, **base).allowed)
            for count in (1, 2, 99):
                blocked = dict(base, additional_calls_used=count)
                self.assertEqual(retry_decision(now_ms=0, **blocked).reason, 'ADDITIONAL_CALL_CAP')
            with self.assertRaisesRegex(ValueError, 'TIMING_KIND_MISMATCH'):
                retry_decision(now_ms=0, **dict(base, timing=AttemptTiming('RESEND' if kind == 'REPAIR' else 'REPAIR', 1)))


if __name__ == '__main__':
    unittest.main(verbosity=2)
