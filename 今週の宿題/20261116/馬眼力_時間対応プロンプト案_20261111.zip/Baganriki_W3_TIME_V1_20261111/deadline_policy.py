"""Pure scheduling/receipt guards. No API calls, locks, or publication approval.

All attempt metadata comes from server records, never the AI's JSON. The caller
must reserve the call atomically before dispatch; a decision is not a reservation.
"""
from dataclasses import dataclass
import re

@dataclass(frozen=True)
class RetryDecision:
    allowed: bool
    reason: str
    remaining_ms: int

@dataclass(frozen=True)
class AttemptTiming:
    """Server-measured timings for exactly one additional-call kind.

    Profiles must also match model/headcount/wire/load in the caller. This
    reference checks kind binding, not whether a measurement is genuine.
    """
    kind: str
    p95_ms: int | None

def nonnegative_int(x):
    return type(x) is int and x>=0

def hash_value(x):
    return isinstance(x,str) and re.fullmatch(r'[0-9a-f]{64}',x) is not None

def retry_decision(*,now_ms,reply_deadline_ms,additional_calls_used,attempt_kind,timing,
                   queue_p95_ms,validation_p95_ms,reserve_ms=10000,
                   retry_required=False,in_flight=False):
    """Use effective live deadlines, measured durations and server clock.

    At most one extra call per role INCLUDING resends and corrections. Unknown
    duration is not permission to retry. Nonpublic benchmark runs are separate.
    REPAIR requires a saved parseable first response and a permitted scope;
    RESEND repeats the initial evaluation without using a first response.
    Pass the measured profile for that kind; never substitute repair p95 for
    resend p95. No coercion of strings, bool-as-int or fractional durations.
    """
    if attempt_kind not in ('REPAIR','RESEND'):
        raise ValueError('INVALID_ATTEMPT_KIND')
    if not isinstance(timing,AttemptTiming):raise ValueError('INVALID_TIMING_PROFILE')
    if timing.kind!=attempt_kind:raise ValueError('TIMING_KIND_MISMATCH')
    required_ints=[now_ms,reply_deadline_ms,additional_calls_used,reserve_ms]
    optional_ints=[timing.p95_ms,queue_p95_ms,validation_p95_ms]
    if not all(nonnegative_int(x) for x in required_ints) or not all(x is None or nonnegative_int(x) for x in optional_ints):
        raise ValueError('INVALID_BUDGET')
    if type(retry_required) is not bool or type(in_flight) is not bool:
        raise ValueError('INVALID_FLAGS')
    if timing.p95_ms==0:
        raise ValueError('INVALID_ATTEMPT_P95')
    remaining=reply_deadline_ms-now_ms
    if remaining<=0:return RetryDecision(False,'DEADLINE',remaining)
    if not retry_required:return RetryDecision(False,'NO_RETRY_REQUIRED',remaining)
    if in_flight:return RetryDecision(False,'REQUEST_IN_FLIGHT',remaining)
    if additional_calls_used>=1:return RetryDecision(False,'ADDITIONAL_CALL_CAP',remaining)
    if any(x is None for x in optional_ints):return RetryDecision(False,'P95_NOT_MEASURED',remaining)
    required=timing.p95_ms+queue_p95_ms+validation_p95_ms+reserve_ms
    if remaining<required:return RetryDecision(False,'INSUFFICIENT_BUDGET',remaining)
    return RetryDecision(True,'MEASURED_BUDGET_FITS',remaining)

def retain_attempt(first,repair,reply_deadline_ms,*,expected_context,
                   first_request_id,repair_request_id=None,first_response_hash=None,
                   resend=None,resend_request_id=None):
    """Choose a whole, server-validated attempt bound to this request chain.

    expected_context has race_id, snapshot_hash, ai_role, schema_version and
    prompt_version. Attempts additionally carry request_id, response_hash,
    acceptable (bool), received_at_ms (nonnegative int). A repair also carries
    scope_ok (bool) and first_response_hash from the saved receipt chain.
    Malformed/foreign/late repair metadata never discards a valid first receipt.
    A saved RESEND request has its own request ID and identical frozen input;
    it does not require a missing first receipt or a repair hash/scope. Only one
    extra request kind may be authorized. Among valid initial/resend receipts,
    keep the earliest received (tie: initial), without comparing predictions.
    This guard cannot establish semantic correctness or verify response bytes.
    """
    keys={'race_id','snapshot_hash','ai_role','schema_version','prompt_version'}
    if (not nonnegative_int(reply_deadline_ms) or not isinstance(expected_context,dict)
        or set(expected_context)!=keys or not all(isinstance(v,str) and v.strip() for v in expected_context.values())
        or not hash_value(expected_context['snapshot_hash']) or expected_context['ai_role'] not in ('1st','2nd')
        or not isinstance(first_request_id,str) or not first_request_id.strip()):
        raise ValueError('INVALID_EXPECTED_CONTEXT')
    if repair_request_id is not None and (not isinstance(repair_request_id,str) or not repair_request_id.strip() or repair_request_id==first_request_id):
        raise ValueError('INVALID_REPAIR_REQUEST_ID')
    if resend_request_id is not None and (not isinstance(resend_request_id,str) or not resend_request_id.strip() or resend_request_id==first_request_id):
        raise ValueError('INVALID_RESEND_REQUEST_ID')
    if repair_request_id is not None and resend_request_id is not None:
        raise ValueError('ADDITIONAL_CALL_CAP')
    if first_response_hash is not None and not hash_value(first_response_hash):
        raise ValueError('INVALID_FIRST_RESPONSE_HASH')

    def bound(x,request_id):
        return (isinstance(x,dict) and request_id is not None
                and nonnegative_int(x.get('received_at_ms'))
                and x.get('request_id')==request_id and hash_value(x.get('response_hash'))
                and all(x.get(k)==v for k,v in expected_context.items()))

    def valid(x,request_id):
        return bound(x,request_id) and x.get('acceptable') is True and x['received_at_ms']<=reply_deadline_ms

    first_hash_ok=bound(first,first_request_id) and first.get('response_hash')==first_response_hash
    chronology_ok=(bound(first,first_request_id) and bound(repair,repair_request_id)
                   and repair['received_at_ms']>=first['received_at_ms'])
    if (valid(repair,repair_request_id) and repair.get('scope_ok') is True
        and first_response_hash is not None and repair.get('first_response_hash')==first_response_hash
        and first_hash_ok and chronology_ok):
        return repair
    valid_receipts=[x for x,ident in ((first,first_request_id),(resend,resend_request_id)) if valid(x,ident)]
    if valid_receipts:return min(valid_receipts,key=lambda x:x['received_at_ms'])
    return None
