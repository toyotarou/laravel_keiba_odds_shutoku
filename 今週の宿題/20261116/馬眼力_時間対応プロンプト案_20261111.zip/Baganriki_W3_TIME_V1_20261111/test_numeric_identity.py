"""R3: immutable JSON values survive exact numeric serialization round trips."""
import copy
from decimal import Decimal
import unittest
from reference_adapter import SCHEMA,PROMPT,BEGIN,END,ContractError,strict_loads,dumps_exact
from request_guard import same_value,expand_checked_request,receipt_hash
from test_contract import fixture

class ExactJsonIdentityTests(unittest.TestCase):
    def test_equal_integer_and_decimal_are_same_json_number(self):
        for a,b in [(1000,Decimal('1e3')),(1000,Decimal('1000.0')),(0,Decimal('-0.00')),(-12,Decimal('-12.0')),(10**127,Decimal('1e127'))]:
            with self.subTest(a=a,b=b):
                self.assertTrue(same_value(a,b));self.assertTrue(same_value(b,a))
    def test_decimal_comparison_does_not_round(self):
        for a,b in [(Decimal('1.000000000000000000000000000001'),1),(Decimal('0.100000000000000000000000000001'),Decimal('0.1')),(10**127,Decimal('9'*128))]:
            with self.subTest(a=a,b=b):self.assertFalse(same_value(a,b))
    def test_boolean_never_equals_integer_or_decimal(self):
        for a,b in [(True,1),(False,0),(True,Decimal('1')),(False,Decimal('0'))]:
            with self.subTest(a=a,b=b):
                self.assertFalse(same_value(a,b));self.assertFalse(same_value(b,a))
    def test_numeric_strings_remain_strings(self):
        for a,b in [('1000',1000),('1000.0',Decimal('1000.0')),('0',0)]:
            with self.subTest(a=a,b=b):self.assertFalse(same_value(a,b))
    def test_float_is_not_coerced_to_exact_number(self):
        for a,b in [(1.0,1),(0.1,Decimal('0.1')),(1000.0,Decimal('1e3'))]:
            with self.subTest(a=a,b=b):self.assertFalse(same_value(a,b))
    def test_nonfinite_decimal_does_not_crash_or_match(self):
        for a in [Decimal('NaN'),Decimal('sNaN'),Decimal('Infinity')]:
            with self.subTest(a=a):self.assertFalse(same_value(a,a))
    def test_null_never_equals_zero_or_false(self):
        for b in [0,Decimal('0'),False,'null']:
            with self.subTest(b=b):self.assertFalse(same_value(None,b))
    def test_array_order_and_mapping_keys_remain_bound(self):
        self.assertTrue(same_value({'a':Decimal('2.0'),'b':[1,2]},{'b':[1,Decimal('2')],'a':2}))
        self.assertFalse(same_value({'a':[1,2]},{'a':[2,1]}))
        self.assertFalse(same_value({'a':1},{'b':1}))
    def test_serialized_initial_request_matches_saved_frozen_input(self):
        for n in [6,7,13,15,18]:
            for role in ['1st','2nd']:
                f,r=fixture(n=n,role=role)
                f['source_registry']['h1_win_odds_21']['value']=Decimal('1e1')
                req={'response_contract':{'schema_version':SCHEMA,'prompt_version':PROMPT,'request_id':r['request_id']},'input':copy.deepcopy(f)}
                wire=strict_loads(dumps_exact(req))
                with self.subTest(n=n,role=role):
                    p=expand_checked_request(wire,strict_loads(dumps_exact(r)),f,r['request_id'])
                    self.assertEqual(len(p['horses']),n)
                    self.assertEqual(p['stage'],'UNVERIFIED_MATERIAL_PACKET')
    def test_real_number_change_after_roundtrip_is_rejected(self):
        f,r=fixture();req={'response_contract':{'schema_version':SCHEMA,'prompt_version':PROMPT,'request_id':r['request_id']},'input':copy.deepcopy(f)}
        req=strict_loads(dumps_exact(req));req['input']['source_registry']['h1_win_odds_6']['value']=Decimal('6.000000000000000000000000000001')
        with self.assertRaisesRegex(ContractError,'FROZEN_INPUT_MISMATCH'):expand_checked_request(req,r,f,r['request_id'])
    def test_selection_boolean_cannot_be_replaced_by_number(self):
        f,r=fixture();req={'response_contract':{'schema_version':SCHEMA,'prompt_version':PROMPT,'request_id':r['request_id']},'input':copy.deepcopy(f)}
        req['input']['selection_enabled']=1
        with self.assertRaisesRegex(ContractError,'FROZEN_INPUT_MISMATCH'):expand_checked_request(req,r,f,r['request_id'])
    def repair_case(self):
        f,first=fixture();raw=BEGIN+'\n'+dumps_exact(first)+'\n'+END
        scope={'horses':[],'ranking_horses':[],'rank_bands':[],'race_metrics':[]}
        req={'response_contract':{'schema_version':SCHEMA,'prompt_version':PROMPT,'request_id':'repair'},'input':copy.deepcopy(f),'first_response':copy.deepcopy(first),'first_response_hash':receipt_hash(raw),'repair_scope':scope,'errors':[{'code':'TEST','reason':'数値表記の往復確認'}]}
        reply=copy.deepcopy(first);reply['request_id']='repair'
        args={'first_raw':raw,'first_request_id':first['request_id'],'authorized_repair_scope':scope}
        return f,first,req,reply,args
    def test_repair_envelope_survives_same_numeric_value_copy(self):
        f,first,req,reply,args=self.repair_case()
        req['first_response']['horses'][0]['scores']['H1']['value']=Decimal('9.0')
        req=strict_loads(dumps_exact(req))
        p=expand_checked_request(req,reply,f,'repair',**args)
        self.assertEqual(p['horses'][0]['scores']['H1'],9)
    def test_equal_json_number_never_bypasses_raw_receipt_hash(self):
        f,first,req,reply,args=self.repair_case()
        changed=copy.deepcopy(first);changed['horses'][0]['scores']['H1']['value']=Decimal('9.0')
        args['first_raw']=BEGIN+'\n'+dumps_exact(changed)+'\n'+END
        self.assertNotEqual(receipt_hash(args['first_raw']),req['first_response_hash'])
        with self.assertRaisesRegex(ContractError,'FIRST_RESPONSE_HASH_MISMATCH'):expand_checked_request(req,reply,f,'repair',**args)
    def test_real_change_to_saved_first_copy_is_rejected(self):
        f,first,req,reply,args=self.repair_case()
        req['first_response']['horses'][0]['scores']['H1']['value']=Decimal('9.000000000000000000000000000001')
        with self.assertRaisesRegex(ContractError,'FIRST_RESPONSE_COPY_MISMATCH'):expand_checked_request(req,reply,f,'repair',**args)

if __name__=='__main__':unittest.main(verbosity=2)
