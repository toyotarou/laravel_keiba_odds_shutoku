"""Invisible-only text must not satisfy an explanation requirement.

Synthetic structural tests. No semantic or publication approval is implied.
"""
import copy
import itertools
import unittest

from reference_adapter import (BEGIN, END, CAPS, FAMILIES, ContractError,
    dumps_exact, parse_response)
from request_guard import expand_checked_request, receipt_hash
from deadline_policy import retain_attempt
from test_contract import fixture


# Representative blank glyphs and nonrendering modifiers that are not all
# Unicode whitespace/control categories. These are input cases, not a copy
# of the production range predicate.
BLANKS = ('\u034f', '\u115f\u1160', '\u17b4\u17b5', '\u180b',
          '\u2800', '\u3164', '\ufe0f', '\uffa0', '\U000e0100',
          ' \u2800\u3164\u200d\ufe0f\n')


def wire(reply):
    return BEGIN + '\n' + dumps_exact(reply) + '\n' + END + '\n'


def request(frozen, reply):
    return {'response_contract': {k: reply[k] for k in
        ('schema_version', 'prompt_version', 'request_id')}, 'input': copy.deepcopy(frozen)}


def expand(frozen, reply):
    return expand_checked_request(request(frozen, reply), parse_response(wire(reply)),
                                  frozen, reply['request_id'])


def repair(frozen, first, corrected, scope, errors=None):
    raw = wire(first)
    req = request(frozen, corrected)
    req.update(first_response=copy.deepcopy(first), first_response_hash=receipt_hash(raw),
        repair_scope=copy.deepcopy(scope),
        errors=errors if errors is not None else [{'code': 'TEXT', 'reason': '説明文の修正'}])
    return expand_checked_request(req, parse_response(wire(corrected)), frozen,
        corrected['request_id'], first_raw=raw, first_request_id=first['request_id'],
        authorized_repair_scope=scope)


class VisibleTextTests(unittest.TestCase):
    def test_invisible_only_review_and_score_reasons_rejected(self):
        for role in ('1st', '2nd'):
            frozen, valid = fixture(3, role)
            targets = [('review', k) for k in FAMILIES] + [('scores', k) for k in CAPS]
            for (section, key), blank in zip(targets, itertools.cycle(BLANKS)):
                changed = copy.deepcopy(valid)
                changed['horses'][0][section][key]['reason'] = blank
                with self.subTest(role=role, section=section, key=key), self.assertRaisesRegex(ContractError, 'EMPTY_VISIBLE_TEXT'):
                    expand(frozen, changed)

    def test_blank_observation_counter_rank_explanation_and_issue_rejected(self):
        for role in ('1st', '2nd'):
            frozen, valid = fixture(3, role)
            for blank in BLANKS:
                variants = []
                r = copy.deepcopy(valid); r['horses'][0]['review']['ability']['observation'] = blank; variants.append(r)
                r = copy.deepcopy(valid); r['horses'][0]['counterevidence'][0]['reason'] = blank; variants.append(r)
                for key in ('rank_reason', 'explanation'):
                    r = copy.deepcopy(valid); r['horses'][0][key] = blank; variants.append(r)
                r = copy.deepcopy(valid)
                r['validation_issues'] = [{'code': 'TEST', 'severity': 'WARNING', 'horse_no': 1, 'field': None, 'reason': blank}]
                variants.append(r)
                for index, changed in enumerate(variants):
                    with self.subTest(role=role, blank=ascii(blank), field=index), self.assertRaisesRegex(ContractError, 'EMPTY_VISIBLE_TEXT'):
                        expand(frozen, changed)

    def test_blank_request_identity_and_repair_diagnostics_rejected(self):
        for role in ('1st', '2nd'):
            frozen, first = fixture(3, role)
            r = copy.deepcopy(first); r['request_id'] = '\u2800\ufe0f'
            with self.subTest(role=role, field='request_id'), self.assertRaisesRegex(ContractError, 'EXPECTED_REQUEST_ID_REQUIRED'):
                expand(frozen, r)
            corrected = copy.deepcopy(first); corrected['request_id'] = 'REPAIR'
            scope = {'horses': [], 'ranking_horses': [], 'rank_bands': [], 'race_metrics': []}
            for key in ('code', 'reason'):
                errors = [{'code': 'TEXT', 'reason': '説明の確認'}]; errors[0][key] = '\u3164\uffa0'
                with self.subTest(role=role, field=key), self.assertRaisesRegex(ContractError, 'EMPTY_REPAIR_DIAGNOSTIC'):
                    repair(frozen, first, corrected, scope, errors)

    def test_legitimate_combining_text_retained_without_normalization(self):
        texts = ('能力は比較可能。が・か\u3099、é・e\u0301。',
                 '支持を確認。\u2764\ufe0f \U0001f469\u200d\U0001f4bb',
                 '\u115f\u1161 조건\u3164比較。',
                 '\u2800\u034f実績あり\ufe0f\U000e0100\n')
        for role in ('1st', '2nd'):
            frozen, original = fixture(3, role)
            for text in texts:
                r = copy.deepcopy(original); h = r['horses'][0]
                h['review']['ability']['reason'] = text
                h['review']['ability']['observation'] = text
                h['scores']['H1']['reason'] = text
                h['counterevidence'][0]['reason'] = text
                h['rank_reason'] = h['explanation'] = text
                before = dumps_exact(frozen), wire(r), receipt_hash(wire(r))
                packet = expand(frozen, r); row = packet['horses'][0]
                self.assertEqual(row['family_review']['ability']['reason'], text)
                self.assertEqual(row['evidence'][0]['observation'], text)
                self.assertEqual(row['score_evidence']['H1']['reason'], text)
                self.assertEqual(row['counterevidence'][0]['reason'], text)
                self.assertEqual(row['evidence_rank_reason'], text)
                self.assertEqual(row['explanation'], text)
                self.assertEqual((dumps_exact(frozen), wire(r), receipt_hash(wire(r))), before)
                self.assertEqual(packet['stage'], 'UNVERIFIED_MATERIAL_PACKET')
                self.assertNotIn('public_candidates', packet)

    def test_repair_can_replace_blank_first_text_only_with_evaluation_scope(self):
        for role in ('1st', '2nd'):
            frozen, first = fixture(3, role)
            first['horses'][0]['explanation'] = '\u2800\u3164'
            corrected = copy.deepcopy(first); corrected['request_id'] = 'REPAIR'
            corrected['horses'][0]['explanation'] = '能力資料を確認したが、条件の再現性には不確実性がある。'
            scope = {'horses': [], 'ranking_horses': [], 'rank_bands': [], 'race_metrics': []}
            with self.assertRaisesRegex(ContractError, 'REPAIR_OUT_OF_SCOPE'):
                repair(frozen, first, corrected, scope)
            before = wire(first), dumps_exact(frozen)
            scope['horses'] = [1]
            packet = repair(frozen, first, corrected, scope)
            self.assertEqual(packet['horses'][0]['explanation'], corrected['horses'][0]['explanation'])
            self.assertEqual(packet['evidence_band_ranks'], first['evidence_band_ranks'])
            self.assertEqual((wire(first), dumps_exact(frozen)), before)

    def test_blank_repair_does_not_discard_valid_first_or_mutate_raw_hash(self):
        for role in ('1st', '2nd'):
            frozen, first = fixture(3, role); original = expand(frozen, first)
            corrected = copy.deepcopy(first); corrected['request_id'] = 'REPAIR'
            corrected['horses'][0]['explanation'] = '\ufe0f\U000e0100'
            scope = {'horses': [1], 'ranking_horses': [], 'rank_bands': [], 'race_metrics': []}
            before = wire(first), receipt_hash(wire(first)), dumps_exact(frozen)
            with self.assertRaisesRegex(ContractError, 'EMPTY_VISIBLE_TEXT'):
                repair(frozen, first, corrected, scope)
            self.assertEqual(expand(frozen, first), original)
            self.assertEqual((wire(first), receipt_hash(wire(first)), dumps_exact(frozen)), before)
            context = {k: first[k] for k in ('race_id', 'snapshot_hash', 'ai_role', 'schema_version', 'prompt_version')}
            # First acceptable=True models prior semantic validation. The repair
            # has already failed the actual structural check above.
            saved = dict(context, request_id=first['request_id'], response_hash=before[1],
                         received_at_ms=100000, acceptable=True)
            failed = dict(context, request_id='REPAIR', response_hash=receipt_hash(wire(corrected)),
                first_response_hash=before[1], received_at_ms=120000, acceptable=False, scope_ok=True)
            self.assertIs(retain_attempt(saved, failed, 150000, expected_context=context,
                first_request_id=first['request_id'], repair_request_id='REPAIR', first_response_hash=before[1]), saved)

    def test_frozen_source_strings_are_not_sanitized(self):
        for role in ('1st', '2nd'):
            frozen, reply = fixture(3, role)
            value = '良\u2800\u3164\ufe0f\U000e0100'
            frozen['source_registry']['h1_past_condition_1']['value'] = value
            before = dumps_exact(frozen), wire(reply)
            packet = expand(frozen, reply)
            facts = packet['horses'][0]['evidence'][0]['facts']
            self.assertEqual(next(x['value'] for x in facts if x['source_ref'] == 'h1_past_condition_1'), value)
            self.assertEqual((dumps_exact(frozen), wire(reply)), before)

    def test_blank_metric_reason_rejected_without_mutating_other_material(self):
        frozen, valid = fixture(3, '1st'); original = expand(frozen, valid)
        before = dumps_exact(frozen), wire(valid)
        for metric, blank in zip(valid['race_metrics'], ('\u3164', '\u2800', '\u034f\ufe0f')):
            changed = copy.deepcopy(valid); changed['race_metrics'][metric]['reason'] = blank
            with self.subTest(metric=metric), self.assertRaisesRegex(ContractError, 'EMPTY_VISIBLE_TEXT'):
                expand(frozen, changed)
        self.assertEqual(expand(frozen, valid), original)
        self.assertEqual((dumps_exact(frozen), wire(valid)), before)


if __name__ == '__main__': unittest.main(verbosity=2)
