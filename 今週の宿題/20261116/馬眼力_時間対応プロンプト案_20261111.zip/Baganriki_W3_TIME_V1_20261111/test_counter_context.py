"""R7 counterevidence context regression; synthetic, no semantic approval."""
import copy
from datetime import timedelta
import json
from pathlib import Path
import unittest

from reference_adapter import (SCHEMA, PROMPT, BEGIN, END, ContractError,
    dumps_exact, parse_response, instant)
from request_guard import expand_checked_request, receipt_hash
from deadline_policy import retain_attempt
from test_contract import fixture


def wire(reply): return BEGIN+'\n'+dumps_exact(reply)+'\n'+END+'\n'


def request(frozen, reply):
    return {'response_contract': {k: reply[k] for k in ('schema_version', 'prompt_version', 'request_id')},
            'input': copy.deepcopy(frozen)}


def expand(frozen, reply):
    return expand_checked_request(request(frozen, reply), parse_response(wire(reply)), frozen, reply['request_id'])


def setup(role='2nd', scope='HORSE'):
    frozen, reply = fixture(role=role)
    own = 'h1_past_condition_1'
    if scope != 'HORSE':
        own = 'applicable_'+scope.lower()
        row = copy.deepcopy(frozen['source_registry']['h1_past_condition_1'])
        row.update(source_ref=own, scope=scope,
                   horse_nos=[1, 2] if scope == 'PAIR' else [],
                   applicable_horse_nos=[1] if scope == 'COHORT' else [])
        frozen['source_registry'][own] = row
    common = 'current_race_condition'
    row = copy.deepcopy(frozen['source_registry']['h1_past_condition_1'])
    row.update(source_ref=common, scope='RACE', horse_nos=[], applicable_horse_nos=[],
               field='current_track_condition', value='不良', dependency_role='CONTEXT')
    frozen['source_registry'][common] = row
    reply['horses'][0]['counterevidence'] = [
        {'source_refs': [own, common], 'reason': '過去の良馬場実績を今回の不良馬場へ同条件で適用できない'}]
    return frozen, reply, own, common


def repair(frozen, first, corrected, scope):
    raw = wire(first)
    req = request(frozen, corrected)
    req.update(first_response=copy.deepcopy(first), first_response_hash=receipt_hash(raw),
               repair_scope=copy.deepcopy(scope), errors=[{'code': 'TEST', 'reason': '合成の反証訂正'}])
    return expand_checked_request(req, parse_response(wire(corrected)), frozen, corrected['request_id'],
                                  first_raw=raw, first_request_id=first['request_id'], authorized_repair_scope=scope)


class CounterContextTests(unittest.TestCase):
    def test_applicable_horse_pair_and_cohort_can_add_race_context(self):
        for role in ('1st', '2nd'):
            for scope in ('HORSE', 'PAIR', 'COHORT'):
                frozen, reply, own, common = setup(role, scope)
                before = dumps_exact(frozen), wire(reply)
                with self.subTest(role=role, scope=scope):
                    packet = expand(frozen, reply)
                    self.assertEqual(packet['horses'][0]['counterevidence'], reply['horses'][0]['counterevidence'])
                    self.assertEqual(packet['evidence_band_ranks'], reply['evidence_band_ranks'])
                    self.assertEqual(packet['stage'], 'UNVERIFIED_MATERIAL_PACKET')
                    self.assertNotIn('public_candidates', packet)
                    self.assertEqual((dumps_exact(frozen), wire(reply)), before)

    def test_race_context_cannot_replace_nonmissing_applicable_horse_data(self):
        for role in ('1st', '2nd'):
            frozen, reply, own, common = setup(role)
            reply['horses'][0]['counterevidence'][0]['source_refs'] = [common]
            with self.subTest(role=role, missing='absent'), self.assertRaisesRegex(ContractError, 'COUNTER_WITHOUT_DATA'):
                expand(frozen, reply)
            reply['horses'][0]['counterevidence'][0]['source_refs'] = [own, common]
            frozen['source_registry'][own]['value'] = None
            with self.subTest(role=role, missing='null'), self.assertRaisesRegex(ContractError, 'COUNTER_WITHOUT_DATA'):
                expand(frozen, reply)

    def test_common_source_requires_context_role_and_same_source_identity(self):
        for role in ('1st', '2nd'):
            for field, value, error in [
                ('dependency_role', 'SIGNAL', 'SOURCE_NOT_APPLICABLE'),
                ('dependency_role', None, 'SOURCE_NOT_APPLICABLE'),
                ('race_id', 'OTHER-RACE', 'SOURCE_ID_MISMATCH'),
                ('source_ref', 'ANOTHER-REF', 'SOURCE_ID_MISMATCH')]:
                frozen, reply, own, common = setup(role)
                frozen['source_registry'][common][field] = value
                with self.subTest(role=role, field=field, value=value), self.assertRaisesRegex(ContractError, error):
                    expand(frozen, reply)
            frozen, reply, own, common = setup(role)
            del frozen['source_registry'][common]
            with self.assertRaisesRegex(ContractError, 'UNKNOWN_SOURCE_REF'): expand(frozen, reply)

    def test_common_context_does_not_authorize_another_horses_data(self):
        for scope in ('HORSE', 'PAIR', 'COHORT'):
            frozen, reply, own, common = setup(scope=scope)
            source = frozen['source_registry'][own]
            if scope == 'HORSE':
                reply['horses'][0]['counterevidence'][0]['source_refs'] = ['h2_past_condition_1', common]
            elif scope == 'PAIR': source['horse_nos'] = [2, 3]
            else: source['applicable_horse_nos'] = [2, 3]
            with self.subTest(scope=scope), self.assertRaisesRegex(ContractError, 'SOURCE_NOT_APPLICABLE'):
                expand(frozen, reply)

    def test_race_context_obeys_freeze_observation_and_slot_deadlines(self):
        for role in ('1st', '2nd'):
            for field in ('available_at', 'observed_at'):
                frozen, reply, own, common = setup(role)
                source = frozen['source_registry'][common]
                source[field] = frozen['input_freeze_at']
                expand(frozen, reply)
                source[field] = (instant(frozen['input_freeze_at'])+timedelta(microseconds=1)).isoformat()
                error = 'SOURCE_AFTER_FREEZE' if field == 'available_at' else 'OBSERVATION_AFTER_FREEZE'
                with self.subTest(role=role, field=field), self.assertRaisesRegex(ContractError, error):
                    expand(frozen, reply)
            frozen, reply, own, common = setup(role)
            source = frozen['source_registry'][common]
            limit = instant(frozen['time_contract']['anchor_at'])-timedelta(minutes=9)+timedelta(milliseconds=120000)
            source.update(slot_offset=9, available_at=limit.isoformat(), observed_at=limit.isoformat())
            expand(frozen, reply)
            source['available_at'] = (limit+timedelta(microseconds=1)).isoformat()
            with self.assertRaisesRegex(ContractError, 'SOURCE_AFTER_SLOT_DEADLINE'): expand(frozen, reply)

    def test_context_addition_repair_needs_horse_scope_and_preserves_other_material(self):
        for role in ('1st', '2nd'):
            frozen, corrected, own, common = setup(role)
            first = copy.deepcopy(corrected)
            first['horses'][0]['counterevidence'] = [{'source_refs': [own], 'reason': '過去の実績だけで再現を断定しない'}]
            initial = expand(frozen, first)
            corrected['request_id'] = 'REPAIR-COMMON-CONTEXT'
            scope = {'horses': [], 'ranking_horses': [], 'rank_bands': [], 'race_metrics': []}
            with self.assertRaisesRegex(ContractError, 'OUT_OF_SCOPE:h1.counterevidence'):
                repair(frozen, first, corrected, scope)
            scope['horses'] = [1]
            result = repair(frozen, first, corrected, scope)
            for i in range(18):
                if i == 0:
                    for key in initial['horses'][i]:
                        if key != 'counterevidence': self.assertEqual(result['horses'][i][key], initial['horses'][i][key])
                else: self.assertEqual(result['horses'][i], initial['horses'][i])
            self.assertEqual(result['evidence_band_ranks'], initial['evidence_band_ranks'])
            if role == '1st': self.assertEqual(result['race_metrics'], initial['race_metrics'])
            self.assertEqual(expand(frozen, first), initial)

    def test_rejected_counter_repair_keeps_timely_first_and_saved_raw_hash(self):
        frozen, first, own, common = setup()
        first_packet = expand(frozen, first); first_raw = wire(first)
        corrected = copy.deepcopy(first); corrected['request_id'] = 'REPAIR-FOREIGN-COUNTER'
        corrected['horses'][0]['counterevidence'][0]['source_refs'] = ['h2_past_condition_1', common]
        scope = {'horses': [1], 'ranking_horses': [], 'rank_bands': [], 'race_metrics': []}
        with self.assertRaisesRegex(ContractError, 'SOURCE_NOT_APPLICABLE'): repair(frozen, first, corrected, scope)
        context = {k: first[k] for k in ('race_id', 'snapshot_hash', 'ai_role', 'schema_version', 'prompt_version')}
        first_meta = dict(context, request_id=first['request_id'], response_hash=receipt_hash(first_raw),
                          received_at_ms=120000, acceptable=True)
        bad_meta = dict(context, request_id=corrected['request_id'], response_hash=receipt_hash(wire(corrected)),
                        first_response_hash=first_meta['response_hash'], received_at_ms=130000,
                        acceptable=False, scope_ok=True)
        # False models the rejection above; this is not production semantic validation.
        chosen = retain_attempt(first_meta, bad_meta, 150000, expected_context=context,
                                first_request_id=first['request_id'], repair_request_id=corrected['request_id'],
                                first_response_hash=first_meta['response_hash'])
        self.assertIs(chosen, first_meta)
        self.assertEqual(expand(frozen, first), first_packet)
        self.assertEqual(wire(first), first_raw)

    def test_r6_response_and_request_cannot_enter_r7_route(self):
        for role in ('1st', '2nd'):
            frozen, current = fixture(role=role)
            older = copy.deepcopy(current); older['prompt_version'] = 'baganriki-w3-time-v1-20261111-r6'
            with self.subTest(role=role, part='request'), self.assertRaisesRegex(ContractError, 'REQUEST_SCHEMA'):
                expand_checked_request(request(frozen, older), current, frozen, current['request_id'])
            with self.subTest(role=role, part='reply'), self.assertRaisesRegex(ContractError, 'OUTPUT_SCHEMA'):
                expand_checked_request(request(frozen, current), older, frozen, current['request_id'])


if __name__ == '__main__': unittest.main(verbosity=2)
