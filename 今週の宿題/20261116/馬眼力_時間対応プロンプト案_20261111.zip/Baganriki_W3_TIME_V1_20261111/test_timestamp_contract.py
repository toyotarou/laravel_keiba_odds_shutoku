"""Timestamp-format and lossless deadline guards; synthetic local tests only."""
import copy
from datetime import datetime, timedelta, timezone
from decimal import Decimal
import unittest

from reference_adapter import (BEGIN, END, SCHEMA, PROMPT, ContractError, instant,
    expand_response, dumps_exact, parse_response)
from request_guard import expand_checked_request
from test_contract import fixture


def guarded(frozen, reply):
    request = {'response_contract': {'schema_version': SCHEMA, 'prompt_version': PROMPT,
                                    'request_id': reply['request_id']},
               'input': copy.deepcopy(frozen)}
    return expand_checked_request(request, parse_response(BEGIN+'\n'+dumps_exact(reply)+'\n'+END),
                                  frozen, reply['request_id'])


class TimestampContractTests(unittest.TestCase):
    def test_submicrosecond_after_freeze_is_rejected_without_truncation(self):
        for role in ('1st', '2nd'):
            for fraction in ('0000001', '0000009', '0000000000000000001'):
                with self.subTest(role=role, fraction=fraction):
                    f, r = fixture(role=role)
                    f['source_registry']['h1_win_odds_6']['available_at'] = '2026-11-11T14:25:00.'+fraction+'+09:00'
                    with self.assertRaisesRegex(ContractError, 'INVALID_TIMESTAMP'):
                        guarded(f, r)

    def test_submicrosecond_after_earlier_slot_deadline_is_rejected(self):
        for slot in (21, 18, 15, 12, 9):
            with self.subTest(slot=slot):
                f, r = fixture()
                ref = 'synthetic_slot_'+str(slot)
                source = copy.deepcopy(f['source_registry']['h1_win_odds_6'])
                limit = datetime(2026, 11, 11, 14, 30, tzinfo=timezone(timedelta(hours=9)))-timedelta(minutes=slot)+timedelta(seconds=120)
                source.update(source_ref=ref, slot_offset=slot,
                              observed_at=(limit-timedelta(seconds=1)).isoformat(),
                              available_at=limit.strftime('%Y-%m-%dT%H:%M:%S')+'.0000001+09:00')
                f['source_registry'][ref] = source
                r['horses'][0]['scores']['V4']['extra_source_refs'] = [ref]
                with self.assertRaisesRegex(ContractError, 'INVALID_TIMESTAMP'):
                    guarded(f, r)

    def test_observed_timestamp_cannot_hide_fraction_after_freeze(self):
        f, r = fixture()
        f['source_registry']['h1_win_odds_6']['observed_at'] = '2026-11-11T14:25:00.0000001+09:00'
        with self.assertRaisesRegex(ContractError, 'INVALID_TIMESTAMP'):
            guarded(f, r)

    def test_excess_precision_is_rejected_even_when_extra_digits_are_zero(self):
        for fraction in ('0000000', '1234560', '1234560000000000'):
            with self.subTest(fraction=fraction), self.assertRaisesRegex(ContractError, 'INVALID_TIMESTAMP'):
                instant('2026-11-11T14:25:00.'+fraction+'+09:00')

    def test_basic_and_week_dates_are_not_silently_accepted(self):
        for value in ('20261111T142500+0900', '2026-W46-3T14:25:00+09:00',
                      '2026-11-11 14:25:00+09:00', '2026-11-11X14:25:00+09:00'):
            with self.subTest(value=value), self.assertRaisesRegex(ContractError, 'INVALID_TIMESTAMP'):
                instant(value)

    def test_offset_seconds_and_noncontract_fraction_formats_are_rejected(self):
        for value in ('2026-11-11T14:25:00+09:00:00', '2026-11-11T14:25:00+09:00:00.1',
                      '2026-11-11T14:25:00,1+09:00', '2026-11-11T14:25:00+0900',
                      '2026-11-11T14:25:00+09', '2026-11-11T14:25:00+09:60'):
            with self.subTest(value=value), self.assertRaisesRegex(ContractError, 'INVALID_TIMESTAMP'):
                instant(value)

    def test_valid_fraction_lengths_preserve_exact_microseconds(self):
        for fraction, microseconds in [('', 0), ('1', 100000), ('12', 120000), ('123', 123000),
                                       ('1234', 123400), ('12345', 123450), ('123456', 123456)]:
            text = '2026-11-11T14:25:00'+('.'+fraction if fraction else '')+'+09:00'
            parsed = instant(text)
            self.assertEqual(parsed, datetime(2026, 11, 11, 5, 25, 0, microseconds, tzinfo=timezone.utc))
            self.assertEqual(parsed.microsecond, microseconds)

    def test_allowed_rfc3339_timezone_spellings_are_equivalent(self):
        values = ['2026-11-11T14:25:00.123456+09:00', '2026-11-11T05:25:00.123456Z',
                  '2026-11-11t05:25:00.123456z', '2026-11-11T10:55:00.123456+05:30',
                  '2026-11-11T00:25:00.123456-05:00']
        expected = datetime(2026, 11, 11, 5, 25, 0, 123456, tzinfo=timezone.utc)
        for value in values:
            with self.subTest(value=value): self.assertEqual(instant(value), expected)

    def test_calendar_errors_and_unzoned_or_nonstring_times_remain_rejected(self):
        for value in ['2026-02-30T10:00:00Z', '2026-13-11T10:00:00Z', '2026-11-11T24:00:00Z',
                      '2026-11-11T10:00:60Z', '2026-11-11T10:00:00+24:00',
                      '2026-11-11T10:00:00', ' 2026-11-11T10:00:00Z', '2026-11-11T10:00:00Z\n',
                      None, 0, Decimal('0'), True]:
            with self.subTest(value=value), self.assertRaises(ContractError): instant(value)

    def test_valid_microsecond_boundaries_keep_exact_deadline_decisions(self):
        for role in ('1st', '2nd'):
            for shift in (-1, 0, 1):
                f, r = fixture(role=role)
                value = datetime(2026, 11, 11, 5, 25, tzinfo=timezone.utc)+timedelta(microseconds=shift)
                f['source_registry']['h1_win_odds_6']['available_at'] = value.isoformat()
                with self.subTest(role=role, shift=shift):
                    if shift > 0:
                        with self.assertRaisesRegex(ContractError, 'SOURCE_AFTER_FREEZE'): guarded(f, r)
                    else: self.assertEqual(len(guarded(f, r)['horses']), 18)

    def test_invalid_precision_in_freeze_or_anchor_is_rejected(self):
        for location in ('freeze', 'anchor'):
            f, r = fixture()
            if location == 'freeze': f['input_freeze_at'] = '2026-11-11T14:25:00.0000001+09:00'
            else: f['time_contract']['anchor_at'] = '2026-11-11T14:30:00.0000001+09:00'
            with self.subTest(location=location), self.assertRaisesRegex(ContractError, 'INVALID_TIMESTAMP'):
                guarded(f, r)

    def test_invalid_timestamp_is_checked_in_every_reference_consumer_without_mutation(self):
        for consumer in ('review', 'score', 'counter', 'metric'):
            f, r = fixture(role='1st')
            ref = 'synthetic_bad_time'
            source = copy.deepcopy(f['source_registry']['h1_win_odds_6'])
            source.update(source_ref=ref, available_at='2026-11-11T14:25:00.0000001+09:00')
            f['source_registry'][ref] = source
            h = r['horses'][0]
            if consumer == 'review': h['review']['similar_value']['source_refs'] = [ref]
            elif consumer == 'score': h['scores']['V4']['extra_source_refs'] = [ref]
            elif consumer == 'counter': h['counterevidence'].append({'source_refs': [ref], 'reason': '合成の時刻検査'})
            else: r['race_metrics']['wave_level']['source_refs'] = [ref]
            saved = (dumps_exact(f), dumps_exact(r))
            with self.subTest(consumer=consumer), self.assertRaisesRegex(ContractError, 'INVALID_TIMESTAMP'):
                guarded(f, r)
            self.assertEqual((dumps_exact(f), dumps_exact(r)), saved)


if __name__ == '__main__': unittest.main(verbosity=2)
