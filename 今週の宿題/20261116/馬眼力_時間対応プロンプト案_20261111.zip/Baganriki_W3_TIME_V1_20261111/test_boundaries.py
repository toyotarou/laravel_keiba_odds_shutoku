"""Independent R3 boundary checks. Synthetic inputs only; no public approval."""
import copy
from datetime import timedelta
from decimal import Decimal
from pathlib import Path
import sys
import unittest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent / 'Baganriki_W3_TIME_V1_20261111'))
from reference_adapter import (SCHEMA, PROMPT, BEGIN, END, ContractError,
    dumps_exact, strict_loads, instant, checked_ref, score_totals,
    ordinary_ranks_after_validation)
from request_guard import expand_checked_request, receipt_hash, same_value
from deadline_policy import AttemptTiming, retry_decision, retain_attempt
from test_contract import fixture


def envelope(frozen, reply):
    return {'response_contract': {'schema_version': SCHEMA, 'prompt_version': PROMPT,
                                  'request_id': reply['request_id']},
            'input': copy.deepcopy(frozen)}


class R3BoundaryReview(unittest.TestCase):
    def test_all_supported_roster_sizes_preserve_all_rows(self):
        for n in range(1, 19):
            for role in ('1st', '2nd'):
                with self.subTest(n=n, role=role):
                    frozen, reply = fixture(n, role)
                    # N=1 has no real adjacent pair; remove the synthetic self-pair.
                    if n == 1:
                        reply['horses'][0]['review']['gap'].update(status='DATA_MISSING',
                            source_refs=[], observation=None, reason='相手となる出走馬がいない')
                        reply['horses'][0]['scores']['H3'].update(value=None)
                    request = strict_loads(dumps_exact(envelope(frozen, reply)))
                    packet = expand_checked_request(request, strict_loads(dumps_exact(reply)),
                                                    frozen, reply['request_id'])
                    self.assertEqual([h['horse_no'] for h in packet['horses']], list(range(1, n+1)))
                    self.assertEqual(len(packet['horses']), n)
                    self.assertEqual(packet['stage'], 'UNVERIFIED_MATERIAL_PACKET')
                    self.assertNotIn('public_candidates', packet)
                    self.assertEqual('race_metrics' in packet, role == '1st')

    def test_expansion_does_not_alias_or_mutate_frozen_sources(self):
        frozen, reply = fixture()
        request = envelope(frozen, reply)
        before = copy.deepcopy((frozen, reply, request))
        packet = expand_checked_request(request, reply, frozen, reply['request_id'])
        self.assertTrue(same_value(list(before), [frozen, reply, request]))
        packet['horses'][0]['evidence'][0]['facts'][0]['value'] = -999
        packet['horses'][0]['family_review']['ability']['source_refs'].clear()
        packet['evidence_band_ranks']['A'].reverse()
        self.assertTrue(same_value(list(before), [frozen, reply, request]))

    def test_all_six_slot_cutoffs_and_timezone_equivalence(self):
        frozen, reply = fixture()
        base = copy.deepcopy(frozen['source_registry']['h1_win_odds_6'])
        anchor = instant(frozen['time_contract']['anchor_at'])
        for slot in (21, 18, 15, 12, 9, 6):
            deadline = anchor - timedelta(minutes=slot) + timedelta(milliseconds=
                frozen['time_contract']['acquisition_grace_ms'][str(slot)])
            for delta in (-1, 0, 1):
                row = copy.deepcopy(base)
                row['slot_offset'] = slot
                row['observed_at'] = (anchor - timedelta(minutes=slot)).isoformat()
                row['available_at'] = (deadline + timedelta(microseconds=delta)).isoformat()
                reg = {row['source_ref']: row}
                with self.subTest(slot=slot, microseconds=delta):
                    if delta > 0:
                        with self.assertRaises(ContractError):
                            checked_ref(reg, row['source_ref'], 1, frozen)
                    else:
                        checked_ref(reg, row['source_ref'], 1, frozen)
                        from datetime import timezone
                        row['available_at'] = instant(row['available_at']).astimezone(timezone.utc).isoformat()
                        checked_ref(reg, row['source_ref'], 1, frozen)

    def test_repair_for_last_horse_does_not_authorize_first_horse(self):
        for role in ('1st', '2nd'):
            frozen, first = fixture(18, role)
            raw = BEGIN + '\n' + dumps_exact(first) + '\n' + END
            scope = {'horses': [18], 'ranking_horses': [], 'rank_bands': [], 'race_metrics': []}
            reply = copy.deepcopy(first)
            reply['request_id'] = 'REPAIR-LAST'
            reply['horses'][-1]['explanation'] = '対象馬の説明だけを訂正した構造試験'
            request = envelope(frozen, reply)
            request.update(first_response=copy.deepcopy(first), first_response_hash=receipt_hash(raw),
                           repair_scope=scope, errors=[{'code': 'TEST', 'reason': '対象馬の説明を訂正'}])
            kwargs = dict(first_raw=raw, first_request_id=first['request_id'], authorized_repair_scope=scope)
            with self.subTest(role=role):
                packet = expand_checked_request(request, reply, frozen, reply['request_id'], **kwargs)
                self.assertEqual(len(packet['horses']), 18)
                self.assertEqual(packet['evidence_band_ranks'], first['evidence_band_ranks'])
                reply['horses'][0]['explanation'] = '許可対象ではない馬も変更'
                with self.assertRaisesRegex(ContractError, 'REPAIR_OUT_OF_SCOPE:h1.explanation'):
                    expand_checked_request(request, reply, frozen, reply['request_id'], **kwargs)

    def test_every_missing_score_preserves_null_and_changes_only_eligible_band(self):
        from reference_adapter import CAPS
        full = {k: 0 for k in CAPS}
        rows = [{'horse_no': n, 'band': b, 'eligibility': 'ELIGIBLE', 'scores': copy.deepcopy(full)}
                for n, b in ((1, 'A'), (2, 'A'), (7, 'B'), (11, 'D'))]
        ranks = {'A': [2, 1], 'B': [7], 'D': [11]}
        baseline, basis = ordinary_ranks_after_validation(rows, ranks)
        self.assertEqual(baseline['A'], [1, 2])
        for key in CAPS:
            with self.subTest(item=key):
                changed = copy.deepcopy(rows)
                changed[0]['scores'][key] = None
                totals = score_totals(changed[0]['scores'])
                self.assertIsNone(totals['total_score'])
                self.assertEqual(totals['observed_sum'], 0)
                self.assertEqual(totals['observed_cap'], 100 - CAPS[key])
                result, basis = ordinary_ranks_after_validation(changed, ranks)
                self.assertEqual(result['A'], [2, 1])
                self.assertEqual(basis, {'A': 'EVIDENCE', 'B': 'SCORE', 'D': 'SCORE'})
                changed[0]['eligibility'] = 'UNVERIFIED'
                result, basis = ordinary_ranks_after_validation(changed, {**ranks, 'A': [2]})
                self.assertEqual(basis['A'], 'SCORE')

    def test_retry_budget_is_monotonic_and_receipts_obey_deadline(self):
        ctx = {'race_id': 'TEST', 'snapshot_hash': 'a'*64, 'ai_role': '2nd',
               'schema_version': SCHEMA, 'prompt_version': PROMPT}
        for kind in ('RESEND', 'REPAIR'):
            for offset in (-1, 0, 1):
                args = dict(now_ms=100000 + offset, reply_deadline_ms=150000,
                    additional_calls_used=0, attempt_kind=kind, timing=AttemptTiming(kind, 30000),
                    queue_p95_ms=5000, validation_p95_ms=5000, reserve_ms=10000,
                    retry_required=True, in_flight=False)
                self.assertEqual(retry_decision(**args).allowed, offset <= 0)
                for spent in (1, 2):
                    self.assertFalse(retry_decision(**{**args, 'additional_calls_used': spent}).allowed)
        for ftime in (149999, 150000, 150001):
            for stime in (149999, 150000, 150001):
                for fa in (False, True):
                    for sa in (False, True):
                        first = {**ctx, 'request_id': 'first', 'response_hash': 'b'*64,
                                 'acceptable': fa, 'received_at_ms': ftime}
                        resend = {**ctx, 'request_id': 'resend', 'response_hash': 'c'*64,
                                  'acceptable': sa, 'received_at_ms': stime}
                        chosen = retain_attempt(first, None, 150000, expected_context=ctx,
                            first_request_id='first', resend=resend, resend_request_id='resend')
                        expected = [x for x in (first, resend) if x['acceptable'] and x['received_at_ms'] <= 150000]
                        expected = min(expected, key=lambda x:x['received_at_ms']) if expected else None
                        self.assertIs(chosen, expected)


if __name__ == '__main__':
    unittest.main(verbosity=2)
