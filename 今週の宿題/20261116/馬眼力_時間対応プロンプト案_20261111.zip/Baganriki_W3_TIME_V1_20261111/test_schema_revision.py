"""Regression tests for concurrent schema revisions and full-roster handling.

Historical schemas are immutable evidence. R4 and R5 share legacy IDs and must
stay in separate registries. Current resources must not shadow either version.
Synthetic inputs do not establish semantic validity or publication approval.
"""
import copy
import json
from pathlib import Path
import unittest
from unittest.mock import patch

from jsonschema import Draft202012Validator
from referencing import Registry, Resource
from reference_adapter import (PROMPT, SCHEMA, BEGIN, END, ContractError,
    dumps_exact, expand_response, validate_schema, ordinary_ranks_after_validation)
from request_guard import expand_checked_request, receipt_hash
from test_contract import fixture

ROOT = Path(__file__).parent


def schema(kind, revision=None):
    path = ROOT / (kind + '_schema.json') if revision is None else ROOT / 'historical_schemas' / (revision + '_' + kind + '_schema.json')
    return json.loads(path.read_text())


def instance(kind, role='2nd', revision=None):
    frozen, reply = fixture(role=role)
    if revision is not None:
        reply['prompt_version'] = 'baganriki-w3-time-v1-20261111-' + revision
    if kind == 'output': return reply
    return {'response_contract': {k: reply[k] for k in ('schema_version', 'prompt_version', 'request_id')}, 'input': frozen}


def registry(*schemas):
    return Registry().with_resources((s['$id'], Resource.from_contents(s)) for s in schemas)


class SchemaRevisionTests(unittest.TestCase):
    def test_resource_identifiers_bind_revision_and_direction(self):
        ids = []
        for kind in ('request', 'output'):
            current = schema(kind)
            ids.append(current['$id'])
            self.assertEqual(current['$id'], 'urn:baganriki:' + PROMPT.removeprefix('baganriki-') + ':' + kind)
            self.assertNotEqual(current['$id'], schema(kind, 'r4')['$id'])
            self.assertNotEqual(current['$id'], schema(kind, 'r5')['$id'])
        self.assertNotEqual(*ids)
        contract = json.loads((ROOT / 'contract.json').read_text())
        self.assertEqual(contract['json_schema_resources'], dict(zip(('request', 'output'), ids)))

    def check_registry_order(self, kind):
        current = schema(kind)
        for revision in ('r4', 'r5', 'r6', 'r7', 'r8'):
            legacy = schema(kind, revision)
            for ordered in ((legacy, current), (current, legacy)):
                reg = registry(*ordered)
                for role in ('1st', '2nd'):
                    with self.subTest(kind=kind, revision=revision, role=role, last=ordered[-1]['$id']):
                        validator = Draft202012Validator({'$ref': current['$id']}, registry=reg)
                        validator.validate(instance(kind, role))
                        self.assertFalse(validator.is_valid(instance(kind, role, revision)))
                        historical = Draft202012Validator({'$ref': legacy['$id']}, registry=reg)
                        historical.validate(instance(kind, role, revision))
                        self.assertFalse(historical.is_valid(instance(kind, role)))

    def test_output_registry_order_does_not_change_version_routing(self):
        self.check_registry_order('output')

    def test_request_registry_order_does_not_change_version_routing(self):
        self.check_registry_order('request')

    def test_old_r4_r5_remain_valid_in_isolated_legacy_registries(self):
        for kind in ('request', 'output'):
            self.assertEqual(schema(kind, 'r4')['$id'], schema(kind, 'r5')['$id'])
            for revision in ('r4', 'r5'):
                old = schema(kind, revision)
                validator = Draft202012Validator({'$ref': old['$id']}, registry=registry(old))
                for role in ('1st', '2nd'):
                    validator.validate(instance(kind, role, revision))
                    other = 'r5' if revision == 'r4' else 'r4'
                    self.assertFalse(validator.is_valid(instance(kind, role, other)))

    def test_output_loader_rejects_wrong_resource_identifier(self):
        frozen, reply = fixture()
        changed = schema('output')
        for bad in (schema('output', 'r5')['$id'], schema('request')['$id'], None):
            changed['$id'] = bad
            with self.subTest(bad=bad), patch('pathlib.Path.read_text', return_value=json.dumps(changed)):
                with self.assertRaisesRegex(ContractError, 'OUTPUT_SCHEMA_RESOURCE_ID'):
                    validate_schema(reply)

    def test_request_loader_rejects_wrong_resource_identifier(self):
        frozen, reply = fixture()
        request = instance('request')
        changed = schema('request')
        for bad in (schema('request', 'r5')['$id'], schema('output')['$id'], None):
            changed['$id'] = bad
            with self.subTest(bad=bad), patch('pathlib.Path.read_text', return_value=json.dumps(changed)):
                with self.assertRaisesRegex(ContractError, 'REQUEST_SCHEMA_RESOURCE_ID'):
                    expand_checked_request(request, reply, frozen, reply['request_id'])

    def test_old_response_cannot_anchor_current_repair(self):
        for role in ('1st', '2nd'):
            frozen, reply = fixture(role=role)
            first = copy.deepcopy(reply)
            first['prompt_version'] = 'baganriki-w3-time-v1-20261111-r5'
            raw = BEGIN + '\n' + dumps_exact(first) + '\n' + END + '\n'
            scope = {'horses': [1], 'ranking_horses': [], 'rank_bands': [], 'race_metrics': []}
            repaired = copy.deepcopy(reply)
            repaired['request_id'] = 'REPAIR-NEW-REVISION'
            request = {'response_contract': {k: repaired[k] for k in ('schema_version', 'prompt_version', 'request_id')},
                       'input': frozen, 'first_response': first, 'first_response_hash': receipt_hash(raw),
                       'repair_scope': scope, 'errors': [{'code': 'TEST', 'reason': 'Synthetic mismatch'}]}
            with self.subTest(role=role), self.assertRaisesRegex(ContractError, 'FIRST_HEADER_MISMATCH:prompt_version'):
                expand_checked_request(request, repaired, frozen, repaired['request_id'], first_raw=raw,
                                       first_request_id=first['request_id'], authorized_repair_scope=scope)

    def test_nonconsecutive_horse_numbers_keep_last_runner(self):
        for role in ('1st', '2nd'):
            frozen, reply = fixture(role=role)
            removed = {3, 8, 13}
            frozen['runners'] = [r for r in frozen['runners'] if r['horse_no'] not in removed]
            frozen['N'] = len(frozen['runners'])
            bands = {}
            for rank, runner in enumerate(frozen['runners'], 1):
                runner['win_rank'] = rank
                runner['band'] = 'A' if rank <= 6 else 'B' if rank <= 10 else 'D'
                bands[runner['horse_no']] = runner['band']
            reply['horses'] = [h for h in reply['horses'] if h['horse_no'] not in removed]
            reply['evidence_band_ranks'] = {b: [n for n, band in bands.items() if band == b] for b in 'ABD'}
            request = {'response_contract': {k: reply[k] for k in ('schema_version', 'prompt_version', 'request_id')}, 'input': copy.deepcopy(frozen)}
            packet = expand_checked_request(request, reply, frozen, reply['request_id'])
            self.assertEqual([h['horse_no'] for h in packet['horses']], list(bands))
            self.assertEqual(packet['horses'][-1]['horse_no'], 18)
            self.assertEqual(len(packet['horses']), 15)
            self.assertEqual(packet['evidence_band_ranks'], reply['evidence_band_ranks'])

    def test_disabled_selection_does_not_omit_all_runner_evaluation(self):
        for role in ('1st', '2nd'):
            frozen, reply = fixture(role=role)
            frozen.update(selection_enabled=False, role_cap=0, role_quota=None)
            request = {'response_contract': {k: reply[k] for k in ('schema_version', 'prompt_version', 'request_id')}, 'input': copy.deepcopy(frozen)}
            packet = expand_checked_request(request, reply, frozen, reply['request_id'])
            self.assertEqual(len(packet['horses']), 18)
            self.assertEqual(packet['evidence_band_ranks'], reply['evidence_band_ranks'])
            self.assertNotIn('public_candidates', packet)
            self.assertEqual(packet['stage'], 'UNVERIFIED_MATERIAL_PACKET')


if __name__ == '__main__': unittest.main(verbosity=2)
