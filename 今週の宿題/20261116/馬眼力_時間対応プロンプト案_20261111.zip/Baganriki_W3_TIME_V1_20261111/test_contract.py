"""Structural and timing regression tests. No live AI, betting or deployment."""
import copy
from datetime import datetime, timedelta
from decimal import Decimal
from pathlib import Path
import json
import unittest
from reference_adapter import (SCHEMA,PROMPT,FAMILIES,CAPS,ContractError,strict_loads,dumps_exact,
    expand_response,score_totals,ordinary_ranks_after_validation,parse_response,BEGIN,END)
from deadline_policy import AttemptTiming,retry_decision,retain_attempt

def fixture(n=18,role='2nd'):
    reg={};runners=[];horses=[];ranks={b:[] for b in 'ABD'}
    anchor=datetime.fromisoformat('2026-11-11T14:30:00+09:00')
    frozen={'race_id':'TEST-W3-18','snapshot_hash':'a'*64,'ai_role':role,'N':n,
            'input_freeze_at':'2026-11-11T14:25:00+09:00','selection_enabled':True,
            'mode':'UNKNOWN','mode_status':'PROVISIONAL','allocation_mode':'VOLATILE',
            'role_quota':{'A':2 if role=='2nd' else 3,'B':2,'D':1},
            'time_contract':{'anchor_at':anchor.isoformat(),'acquisition_grace_ms':{str(s):60000 if s==6 else 120000 for s in (21,18,15,12,9,6)}}}
    def add(ref,value,no,field,slot=None,scope='HORSE',pair=None):
        at=(anchor-timedelta(minutes=slot)+timedelta(seconds=10)).isoformat() if slot else '2026-11-10T20:00:00+09:00'
        reg[ref]={'source_ref':ref,'value':value,'field':field,'scope':scope,
                  'horse_nos':pair or [no],'applicable_horse_nos':[], 'race_id':frozen['race_id'],
                  'slot_offset':slot,'observed_at':at,'available_at':at,'computed_at':None,
                  'dependency_role':'SIGNAL','dependency_key':ref,'parents':[],'unit':'odds' if 'odds' in field or field.startswith('place') else 'rank'}
    for no in range(1,n+1):
        band='A' if no<=6 else 'B' if no<=10 else 'D';ranks[band].append(no)
        runners.append({'horse_no':no,'win_rank':no,'band':band})
        for slot,delta in [(21,4),(12,3),(9,2),(6,0)]:
            add(f'h{no}_win_odds_{slot}',Decimal(no+5+delta),no,'win_odds',slot)
            add(f'h{no}_place_min_{slot}',Decimal('1.4')+Decimal(no)/10+Decimal(delta)/10,no,'place_min',slot)
            add(f'h{no}_place_max_{slot}',Decimal('2.0')+Decimal(no)/10+Decimal(delta)/10,no,'place_max',slot)
        for field,value in [('past_finish_1',1),('past_date_1','2026-10-01'),('past_dist_1','1800ダ'),('past_condition_1','良')]:add(f'h{no}_{field}',value,no,field)
        # Explicit pair is fixture data, not a claimed measured production gap.
        pair=[no,no+1] if no<n else [no-1,no]
        if n==1:pair=[1,1]
        add(f'g{pair[0]}_{pair[1]}_win_ratio_6',Decimal('1.1'),no,'fixed_gap_win_ratio',6,'PAIR',pair)
        a=[f'h{no}_{f}' for f in ['past_finish_1','past_date_1','past_dist_1','past_condition_1']]
        m=[f'h{no}_win_odds_{s}' for s in [21,12,9,6]]
        wp=[f'h{no}_win_odds_6',f'h{no}_place_min_6']
        review={
            'ability':{'status':'SUPPORTED','source_refs':a,'observation':'過去走の勝利を確認','reason':'能力比較に使える実績'},
            'market':{'status':'SUPPORTED','source_refs':m,'observation':'市場比較（支持加速を根拠にしない）','reason':'単勝短縮を確認','market_claim':{'kind':'OTHER','metric':None}},
            'gap':{'status':'NO_SUPPORT','source_refs':[f'g{pair[0]}_{pair[1]}_win_ratio_6'],'observation':None,'reason':'当該馬の上側断層の支持なし'},
            'win_place':{'status':'NO_SUPPORT','source_refs':wp,'observation':None,'reason':'単複差の追加支持なし'},
            'similar_value':{'status':'DATA_MISSING','source_refs':[],'observation':None,'reason':'対応する統計がない'}}
        defs={'H1':(9,['ability'],[]),'H2':(8,['market'],[]),'H3':(0,['gap'],[]),'H4':(None,['similar_value'],[]),'H5':(0,['win_place'],[]),'V1':(None,['similar_value'],[]),'V2':(5,['ability'],[f'h{no}_win_odds_6']),'V3':(None,['similar_value'],[]),'V4':(None,[],[]),'V5':(2,['win_place'],[f'h{no}_place_max_6'])}
        scores={k:{'value':v,'basis_families':b,'extra_source_refs':refs,'reason':'材料に対する試験用評価' if v is not None else '必要な統計または推定値なし'} for k,(v,b,refs) in defs.items()}
        horses.append({'horse_no':no,'review':review,'scores':scores,'counterevidence':[{'source_refs':[f'h{no}_past_date_1'],'reason':'過去実績だけで今回の再現を断定しない'}],'rank_families':['ability','market'],'rank_reason':'比較結果を置く構造試験用の順位','explanation':'構造試験の仮データ。実予想ではない。'})
    frozen['runners']=runners;frozen['source_registry']=reg
    reply={'schema_version':SCHEMA,'prompt_version':PROMPT,'request_id':'TEST-REQUEST-001','race_id':frozen['race_id'],'snapshot_hash':frozen['snapshot_hash'],'ai_role':role,'horses':horses,'evidence_band_ranks':ranks,'validation_issues':[]}
    if role=='1st':reply['race_metrics']={k:{'value':None,'source_refs':[],'reason':'構造試験用。表示判定は対象外'} for k in ['wave_level','lower_entry','big_gap_entry']}
    return frozen,reply

class WireContractTests(unittest.TestCase):
    def setUp(self):self.f,self.r=fixture()
    def expand(self):return expand_response(self.r,self.f,'TEST-REQUEST-001')
    def test_all_18_horses_and_exact_facts(self):
        p=self.expand();self.assertEqual(len(p['horses']),18)
        for h in p['horses']:
            self.assertEqual(set(h['family_review']),set(FAMILIES));self.assertEqual(set(h['scores']),set(CAPS))
            for e in h['evidence']:
                self.assertEqual(e['source_refs'],[x['source_ref'] for x in e['facts']])
                for fact in e['facts']:self.assertEqual(fact['value'],self.f['source_registry'][fact['source_ref']]['value'])
        self.assertNotIn('public_candidates',p);self.assertEqual(p['stage'],'UNVERIFIED_MATERIAL_PACKET')
    def test_high_precision_value_preserved(self):
        value=Decimal('12.123456789012345678901234567890123456789')
        self.f['source_registry']['h1_win_odds_6']['value']=value
        p=strict_loads(dumps_exact(self.expand()))
        facts=p['horses'][0]['evidence'][1]['facts'];self.assertEqual(facts[-1]['value'],value)
    def test_ref_reuse_expands_and_deduplicates(self):
        s=self.r['horses'][0]['scores']['V2'];s['extra_source_refs']+=['h1_past_finish_1']
        p=self.expand();refs=p['horses'][0]['score_evidence']['V2']['source_refs']
        self.assertEqual(len(refs),5);self.assertEqual(refs.count('h1_past_finish_1'),1)
    def test_missing_runner_rejected(self):
        self.r['horses'].pop()
        with self.assertRaisesRegex(ContractError,'ALL_RUNNERS'):self.expand()
    def test_duplicate_runner_rejected(self):
        self.r['horses'][-1]=copy.deepcopy(self.r['horses'][0])
        with self.assertRaisesRegex(ContractError,'ALL_RUNNERS'):self.expand()
    def test_wrong_request_rejected(self):
        self.r['request_id']='other'
        with self.assertRaisesRegex(ContractError,'REQUEST_ID'):self.expand()
    def test_wrong_snapshot_rejected(self):
        self.r['snapshot_hash']='b'*64
        with self.assertRaisesRegex(ContractError,'HEADER_MISMATCH'):self.expand()
    def test_cross_horse_reference_rejected(self):
        self.r['horses'][0]['review']['ability']['source_refs'][0]='h2_past_finish_1'
        with self.assertRaisesRegex(ContractError,'SOURCE_NOT_APPLICABLE'):self.expand()
    def test_cross_race_reference_rejected(self):
        self.f['source_registry']['h1_past_finish_1']['race_id']='other'
        with self.assertRaisesRegex(ContractError,'SOURCE_ID'):self.expand()
    def test_unknown_reference_rejected(self):
        self.r['horses'][0]['review']['ability']['source_refs'][0]='missing'
        with self.assertRaisesRegex(ContractError,'UNKNOWN_SOURCE'):self.expand()
    def test_freeze_late_reference_rejected(self):
        self.f['source_registry']['h1_win_odds_6']['available_at']='2026-11-11T14:25:00.001+09:00'
        with self.assertRaisesRegex(ContractError,'AFTER_FREEZE'):self.expand()
    def test_other_slot_late_reference_rejected(self):
        self.f['source_registry']['h1_win_odds_21']['available_at']='2026-11-11T14:11:00.001+09:00'
        with self.assertRaisesRegex(ContractError,'SLOT_DEADLINE'):self.expand()
    def test_6_minute_60_second_boundary_kept(self):
        self.f['source_registry']['h1_win_odds_6']['available_at']='2026-11-11T14:25:00+09:00'
        self.expand()
    def test_supported_without_signal_rejected(self):
        for ref in self.r['horses'][0]['review']['ability']['source_refs']:self.f['source_registry'][ref]['dependency_role']='CONTEXT'
        with self.assertRaisesRegex(ContractError,'NO_APPLICABLE_SIGNAL'):self.expand()
    def test_empty_visible_reason_rejected(self):
        self.r['horses'][0]['review']['ability']['reason']='\u200b\u3000'
        with self.assertRaisesRegex(ContractError,'EMPTY_VISIBLE'):self.expand()
    def test_non_supported_observation_rejected(self):
        self.r['horses'][0]['review']['gap']['observation']='肯定'
        with self.assertRaisesRegex(ContractError,'OUTPUT_SCHEMA'):self.expand()
    def test_rank_proof_must_be_supported(self):
        self.r['horses'][0]['rank_families']=['gap']
        with self.assertRaisesRegex(ContractError,'RANK_FAMILY'):self.expand()
    def test_rank_cannot_drop_eligible_claim(self):
        self.r['evidence_band_ranks']['D'].pop()
        with self.assertRaisesRegex(ContractError,'RANK_SET'):self.expand()
    def test_rank_cannot_move_b_horse_into_a(self):
        self.r['evidence_band_ranks']['A'].append(self.r['evidence_band_ranks']['B'].pop())
        with self.assertRaisesRegex(ContractError,'RANK_SET'):self.expand()
    def test_unknown_null_not_zero_or_normalized(self):
        s=self.expand()['horses'][0]['scores'];tot=score_totals(s)
        self.assertEqual(tot,{'score_status':'partial','total_score':None,'observed_sum':24,'observed_cap':65})
        self.assertIsNone(s['H4']);self.assertEqual(s['H3'],0)
    def test_score_range_rejected(self):
        self.r['horses'][0]['scores']['H1']['value']=19
        with self.assertRaisesRegex(ContractError,'OUTPUT_SCHEMA'):self.expand()
    def test_numeric_string_score_rejected(self):
        self.r['horses'][0]['scores']['H1']['value']='9'
        with self.assertRaisesRegex(ContractError,'OUTPUT_SCHEMA'):self.expand()
    def test_acceleration_requires_shortening_and_increase(self):
        r=self.r['horses'][0]['review']['market'];r['market_claim']={'kind':'ACCELERATION','metric':'win_odds'};r['observation']='支持加速（12→9→6分）'
        self.expand() # 9 -> 8 -> 6, rates increase
        self.f['source_registry']['h1_win_odds_6']['value']=Decimal('10')
        with self.assertRaisesRegex(ContractError,'FALSE_ACCELERATION'):self.expand()
    def test_equal_shortening_rates_not_acceleration(self):
        r=self.r['horses'][0]['review']['market'];r['market_claim']={'kind':'ACCELERATION','metric':'win_odds'};r['observation']='支持加速（12→9→6分）'
        for s,v in [(12,'10'),(9,'8'),(6,'6.4')]:self.f['source_registry'][f'h1_win_odds_{s}']['value']=Decimal(v)
        with self.assertRaisesRegex(ContractError,'FALSE_ACCELERATION'):self.expand()
    def test_acceleration_uses_exact_products_beyond_decimal_context(self):
        r=self.r['horses'][0]['review']['market'];r['market_claim']={'kind':'ACCELERATION','metric':'win_odds'};r['observation']='支持加速（12→9→6分）'
        for s,v in [(12,'1.000000000000000000000000000001'),(9,'1'),(6,'0.999999999999999999999999999998')]:self.f['source_registry'][f'h1_win_odds_{s}']['value']=Decimal(v)
        self.expand()
    def test_one_role_does_not_receive_other_role_metrics(self):
        f,r=fixture(role='1st');expand_response(r,f,'TEST-REQUEST-001')
        self.r['race_metrics']=r['race_metrics']
        with self.assertRaisesRegex(ContractError,'OUTPUT_SCHEMA'):self.expand()
    def test_strict_parser_and_markers(self):
        parsed=parse_response(BEGIN+'\n'+dumps_exact(self.r)+'\n'+END)
        self.assertEqual(parsed,self.r)
        for bad in ['{"a":1,"a":2}','{"a":NaN}','{"a":Infinity}','{"a":"\\ud800"}']:
            with self.subTest(bad=bad),self.assertRaises(ContractError):strict_loads(bad)
    def test_partial_eligible_selects_evidence_without_score_sort(self):
        rows=[{'horse_no':1,'band':'A','eligibility':'ELIGIBLE','scores':{k:0 for k in CAPS}}, {'horse_no':2,'band':'A','eligibility':'ELIGIBLE','scores':{k:None for k in CAPS}}]
        ranks,basis=ordinary_ranks_after_validation(rows,{'A':[2,1],'B':[],'D':[]})
        self.assertEqual(ranks['A'],[2,1]);self.assertEqual(basis['A'],'EVIDENCE')
    def test_partial_ineligible_does_not_change_score_mode(self):
        rows=[{'horse_no':1,'band':'A','eligibility':'ELIGIBLE','scores':{k:0 for k in CAPS}},{'horse_no':2,'band':'A','eligibility':'NO_EVIDENCE','scores':{k:None for k in CAPS}}]
        _,basis=ordinary_ranks_after_validation(rows,{'A':[1],'B':[],'D':[]})
        self.assertEqual(basis['A'],'SCORE')
    def test_complete_tie_break_prefers_v_then_number(self):
        rows=[]
        for no,k in [(3,'H1'),(2,'V1'),(1,'V1')]:
            s={x:0 for x in CAPS};s[k]=5;rows.append({'horse_no':no,'band':'A','eligibility':'ELIGIBLE','scores':s})
        ranks,_=ordinary_ranks_after_validation(rows,{'A':[3,2,1],'B':[],'D':[]})
        self.assertEqual(ranks['A'],[1,2,3])

class DeadlineTests(unittest.TestCase):
    def retain(self,first,repair,deadline):
        ctx={'race_id':'TEST-W3-18','snapshot_hash':'a'*64,'ai_role':'2nd','schema_version':SCHEMA,'prompt_version':PROMPT}
        for attempt,ident,hsh in [(first,'first','c'*64),(repair,'repair','d'*64)]:
            if attempt is not None:
                for key,value in {**ctx,'request_id':ident,'response_hash':hsh}.items():attempt.setdefault(key,value)
        if repair is not None:repair.setdefault('first_response_hash','c'*64)
        return retain_attempt(first,repair,deadline,expected_context=ctx,first_request_id='first',repair_request_id='repair',first_response_hash='c'*64)
    def d(self,**kw):
        x=dict(now_ms=100000,reply_deadline_ms=150000,additional_calls_used=0,attempt_kind='REPAIR',timing=AttemptTiming('REPAIR',30000),queue_p95_ms=5000,validation_p95_ms=5000,reserve_ms=10000,retry_required=True,in_flight=False);x.update(kw);return retry_decision(**x)
    def test_exact_budget_fit(self):self.assertTrue(self.d().allowed)
    def test_no_retry_when_one_millisecond_short(self):self.assertFalse(self.d(now_ms=100001).allowed)
    def test_unknown_p95_blocks_guess(self):self.assertEqual(self.d(timing=AttemptTiming('REPAIR',None)).reason,'P95_NOT_MEASURED')
    def test_resend_and_repair_share_one_extra_call(self):self.assertFalse(self.d(additional_calls_used=1).allowed)
    def test_valid_answer_does_not_retry(self):self.assertFalse(self.d(retry_required=False).allowed)
    def test_inflight_does_not_duplicate(self):self.assertFalse(self.d(in_flight=True).allowed)
    def test_deadline_uses_actual_remaining_time(self):self.assertEqual(self.d(now_ms=150000).reason,'DEADLINE')
    def test_late_better_answer_keeps_timely_first(self):
        first={'acceptable':True,'received_at_ms':120000};repair={'acceptable':True,'received_at_ms':150001,'scope_ok':True}
        self.assertIs(self.retain(first,repair,150000),first)
    def test_bad_repair_keeps_first(self):
        first={'acceptable':True,'received_at_ms':120000};repair={'acceptable':True,'received_at_ms':140000,'scope_ok':False}
        self.assertIs(self.retain(first,repair,150000),first)
    def test_timely_scope_checked_repair_replaces(self):
        first={'acceptable':True,'received_at_ms':120000};repair={'acceptable':True,'received_at_ms':140000,'scope_ok':True}
        self.assertIs(self.retain(first,repair,150000),repair)
    def test_no_timely_valid_answer_means_no_answer(self):
        self.assertIsNone(self.retain({'acceptable':True,'received_at_ms':160000},None,150000))

if __name__=='__main__':unittest.main(verbosity=2)
