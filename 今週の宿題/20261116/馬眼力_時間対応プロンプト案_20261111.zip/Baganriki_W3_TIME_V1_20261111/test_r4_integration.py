"""Additional R4 regression: synthetic structure and linkage, not publication.

Put the unchanged R4 package on PYTHONPATH. The synthetic score comparator rows
and receipt acceptable flags are explicit fixtures; no semantic production
validation or prospective horse-prediction accuracy is claimed by these tests.
"""
import copy
from decimal import Decimal, localcontext
from fractions import Fraction
import random
import unittest

from reference_adapter import (BEGIN, END, SCHEMA, PROMPT, CAPS, ContractError,
    exact_json_integer, strict_loads, dumps_exact, parse_response, score_totals,
    ordinary_ranks_after_validation)
from request_guard import expand_checked_request, receipt_hash, same_value
from deadline_policy import retain_attempt
from test_contract import fixture


def envelope(frozen, reply):
    return {'response_contract': {'schema_version': SCHEMA, 'prompt_version': PROMPT,
            'request_id': reply['request_id']}, 'input': copy.deepcopy(frozen)}


def wire(reply):
    return BEGIN + '\n' + dumps_exact(reply) + '\n' + END


def material(frozen, reply):
    return expand_checked_request(envelope(frozen, reply), reply, frozen, reply['request_id'])


def repair_request(frozen, first, repaired, scope):
    raw = wire(first)
    request = envelope(frozen, repaired)
    request.update(first_response=copy.deepcopy(first), first_response_hash=receipt_hash(raw),
                   repair_scope=copy.deepcopy(scope), errors=[{'code': 'TEST', 'reason': '合成構造試験'}])
    kwargs = {'first_raw': raw, 'first_request_id': first['request_id'],
              'authorized_repair_scope': copy.deepcopy(scope)}
    return request, kwargs


class R4IntegrationTests(unittest.TestCase):
    def test_integer_decision_matches_rational_value_under_low_precision(self):
        rng = random.Random(20261111)
        values = [Decimal('0'), Decimal('-0.000'), Decimal('9.0'),
                  Decimal('9.000000000000000000000000000001'), Decimal('1E-60'), Decimal('1E60')]
        for _ in range(300):
            coefficient = ''.join(str(rng.randrange(10)) for _ in range(rng.randint(1, 60)))
            exponent = rng.randint(-60, 60)
            values.append(Decimal(('-' if rng.randrange(2) else '') + coefficient + 'e' + str(exponent)))
        expected = [Fraction(v).denominator == 1 for v in values]
        for precision in (1, 7, 28, 100):
            with localcontext() as context:
                context.prec = precision
                self.assertEqual([exact_json_integer(v) for v in values], expected)
        for value in (Decimal('NaN'), Decimal('sNaN'), Decimal('Infinity'), Decimal('-Infinity')):
            self.assertFalse(exact_json_integer(value))

    def test_r4_wire_forms_preserve_all_material_scores_and_evidence(self):
        for role in ('1st', '2nd'):
            frozen, reply = fixture(role=role)
            original = material(frozen, reply)
            raw = wire(reply)
            # Alter only exact integer score literals; never pass through float.
            for alternate in ('9.0', '9.000', '9.000000000000000000000000000000'):
                changed = raw.replace('"value":9,', '"value":' + alternate + ',')
                decoded = parse_response(changed)
                packet = material(frozen, decoded)
                self.assertTrue(same_value(original, packet))
                self.assertEqual([score_totals(h['scores']) for h in original['horses']],
                                 [score_totals(h['scores']) for h in packet['horses']])
                self.assertNotEqual(receipt_hash(changed), receipt_hash(raw))
                self.assertEqual(packet['stage'], 'UNVERIFIED_MATERIAL_PACKET')
                self.assertNotIn('public_candidates', packet)

    def test_normalized_scores_keep_complete_ties_and_partial_band_isolation(self):
        frozen, reply = fixture()
        # Explicit synthetic comparator input, not a simulated semantic validator.
        for h in reply['horses']:
            for score in h['scores'].values():
                score.update(value=Decimal('0.0'), basis_families=['ability'], extra_source_refs=[])
        reply['horses'][0]['scores']['H1']['value'] = Decimal('5.0')
        reply['horses'][1]['scores']['V1']['value'] = Decimal('5.00')
        reply['horses'][2]['scores']['V1']['value'] = Decimal('5E0')
        reply['horses'][6]['scores']['H1']['value'] = None
        reply['evidence_band_ranks']['A'] = [3, 1, 2, 6, 5, 4]
        reply['evidence_band_ranks']['B'] = [10, 9, 8, 7]
        reply['evidence_band_ranks']['D'] = list(range(18, 10, -1))
        packet = material(frozen, parse_response(wire(reply)))
        rows = [dict(h, eligibility='ELIGIBLE') for h in packet['horses']]
        normal, basis = ordinary_ranks_after_validation(rows, packet['evidence_band_ranks'])
        self.assertEqual(normal, {'A': [2, 3, 1, 4, 5, 6], 'B': [10, 9, 8, 7], 'D': list(range(11, 19))})
        self.assertEqual(basis, {'A': 'SCORE', 'B': 'EVIDENCE', 'D': 'SCORE'})
        self.assertIsNone(rows[6]['scores']['H1'])
        self.assertEqual(packet['evidence_band_ranks']['A'], [3, 1, 2, 6, 5, 4])

    def test_decimal_repair_scope_changes_only_named_band_and_horse(self):
        frozen, first = fixture()
        repaired = copy.deepcopy(first); repaired['request_id'] = 'REPAIR-B'
        scope = {'horses': [Decimal('7.0')], 'ranking_horses': [Decimal('7.0')],
                 'rank_bands': ['B'], 'race_metrics': []}
        repaired['horses'][6]['scores']['H1']['value'] = Decimal('10.0')
        repaired['horses'][6]['rank_reason'] = '合成構造試験：B帯内の指定修正'
        repaired['evidence_band_ranks']['B'] = [10, 9, 8, 7]
        request, kwargs = repair_request(frozen, first, repaired, scope)
        request = strict_loads(dumps_exact(request))
        packet = expand_checked_request(request, parse_response(wire(repaired)), frozen,
                                        repaired['request_id'], **kwargs)
        original = material(frozen, first)
        for no in range(1, 19):
            if no != 7: self.assertTrue(same_value(packet['horses'][no-1], original['horses'][no-1]))
        for band in ('A', 'D'):
            self.assertEqual(packet['evidence_band_ranks'][band], original['evidence_band_ranks'][band])
        for no in (1, 11, 18):
            bad = copy.deepcopy(repaired); bad['horses'][no-1]['explanation'] = '指定外の変更'
            with self.assertRaisesRegex(ContractError, 'REPAIR_OUT_OF_SCOPE:h'+str(no)):
                expand_checked_request(request, bad, frozen, repaired['request_id'], **kwargs)

    def test_parsed_repair_chain_uses_raw_hash_after_integer_normalization(self):
        frozen, first = fixture()
        first['horses'][0]['scores']['H1']['value'] = Decimal('9.0')
        repaired = copy.deepcopy(first); repaired['request_id'] = 'REPAIR-RAW-CHAIN'
        repaired['horses'][0]['scores']['H1']['value'] = 9
        scope = {'horses': [], 'ranking_horses': [], 'rank_bands': [], 'race_metrics': []}
        request, kwargs = repair_request(frozen, first, repaired, scope)
        packet = expand_checked_request(request, parse_response(wire(repaired)), frozen,
                                        repaired['request_id'], **kwargs)
        self.assertIs(type(packet['horses'][0]['scores']['H1']), int)
        context = {k: first[k] for k in ('race_id', 'snapshot_hash', 'ai_role', 'schema_version', 'prompt_version')}
        first_meta = dict(context, request_id=first['request_id'], response_hash=receipt_hash(wire(first)),
                          acceptable=True, received_at_ms=100000)
        repair_meta = dict(context, request_id=repaired['request_id'], response_hash=receipt_hash(wire(repaired)),
                           first_response_hash=first_meta['response_hash'], scope_ok=True,
                           acceptable=True, received_at_ms=110000)
        options = dict(expected_context=context, first_request_id=first['request_id'],
                       repair_request_id=repaired['request_id'], first_response_hash=first_meta['response_hash'])
        self.assertIs(retain_attempt(first_meta, repair_meta, 110000, **options), repair_meta)
        self.assertIs(retain_attempt(first_meta, repair_meta, 109999, **options), first_meta)
        same_value_first = copy.deepcopy(first)
        same_value_first['horses'][0]['scores']['H1']['value'] = 9
        self.assertTrue(same_value(first, same_value_first))
        wrong = dict(repair_meta, first_response_hash=receipt_hash(wire(same_value_first)))
        self.assertIs(retain_attempt(first_meta, wrong, 110000, **options), first_meta)

    def test_foreign_valid_receipts_cannot_cross_role_or_snapshot_chain(self):
        frozen, first = fixture()
        context = {k: first[k] for k in ('race_id', 'snapshot_hash', 'ai_role', 'schema_version', 'prompt_version')}
        original = dict(context, request_id=first['request_id'], response_hash=receipt_hash(wire(first)),
                        acceptable=True, received_at_ms=120000)
        resend = dict(original, request_id='RESEND', received_at_ms=100000)
        kwargs = dict(expected_context=context, first_request_id=first['request_id'], resend_request_id='RESEND')
        self.assertIs(retain_attempt(original, None, 130000, resend=resend, **kwargs), resend)
        for key, value in [('race_id', 'OTHER-RACE'), ('snapshot_hash', 'b'*64), ('ai_role', '1st'),
                           ('schema_version', 'OTHER-SCHEMA'), ('prompt_version', 'OLD-PROMPT')]:
            wrong = dict(resend); wrong[key] = value
            self.assertIs(retain_attempt(original, None, 130000, resend=wrong, **kwargs), original)
            self.assertIsNone(retain_attempt(None, None, 130000, resend=wrong, **kwargs))

    def test_late_cohort_reference_is_checked_in_each_consuming_section(self):
        for consumer in ('review', 'score', 'counter'):
            frozen, reply = fixture()
            row = copy.deepcopy(frozen['source_registry']['h1_past_finish_1'])
            row.update(source_ref='cohort_h1', scope='COHORT', horse_nos=[], applicable_horse_nos=[1],
                       available_at='2026-11-11T14:25:00+09:00')
            frozen['source_registry']['cohort_h1'] = row
            if consumer == 'review': reply['horses'][0]['review']['ability']['source_refs'].append('cohort_h1')
            if consumer == 'score': reply['horses'][0]['scores']['V2']['extra_source_refs'].append('cohort_h1')
            if consumer == 'counter': reply['horses'][0]['counterevidence'][0]['source_refs'] = ['cohort_h1']
            material(frozen, reply)
            row['available_at'] = '2026-11-11T14:25:00.000001+09:00'
            with self.assertRaisesRegex(ContractError, 'SOURCE_AFTER_FREEZE'): material(frozen, reply)

    def test_race_only_signal_never_substitutes_for_applicable_horse_data(self):
        for consumer in ('review', 'score', 'counter'):
            frozen, reply = fixture()
            row = copy.deepcopy(frozen['source_registry']['h1_past_finish_1'])
            row.update(source_ref='race_context', scope='RACE', horse_nos=[], applicable_horse_nos=[])
            frozen['source_registry']['race_context'] = row
            if consumer == 'review':
                reply['horses'][0]['review']['ability']['source_refs'] = ['race_context']
                expected = 'NO_APPLICABLE_SIGNAL'
            if consumer == 'score':
                reply['horses'][0]['scores']['V2'].update(basis_families=[], extra_source_refs=['race_context'])
                expected = 'KNOWN_SCORE_WITHOUT_DATA'
            if consumer == 'counter':
                reply['horses'][0]['counterevidence'][0]['source_refs'] = ['race_context']
                expected = 'SOURCE_NOT_APPLICABLE'
            with self.assertRaisesRegex(ContractError, expected): material(frozen, reply)


if __name__ == '__main__': unittest.main(verbosity=2)
