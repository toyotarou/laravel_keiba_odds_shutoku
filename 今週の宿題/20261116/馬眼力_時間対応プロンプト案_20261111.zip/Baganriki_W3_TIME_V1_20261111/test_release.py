"""Checks delivered prompt/schema/examples agree on the same revision."""
from pathlib import Path
import json,hashlib,unittest
from jsonschema import Draft202012Validator
from reference_adapter import SCHEMA,PROMPT,CAPS,strict_loads
from request_guard import EVALUATION_KEYS,RANK_KEYS,expand_checked_request
ROOT=Path(__file__).parent

class ReleaseContractTests(unittest.TestCase):
    def test_schemas_are_valid_json_schema(self):
        for name in ['output_schema.json','request_schema.json']:
            with self.subTest(name=name):Draft202012Validator.check_schema(json.loads((ROOT/name).read_text()))
    def test_prompts_and_schemas_and_contract_share_revision(self):
        c=json.loads((ROOT/'contract.json').read_text())
        self.assertEqual(c['prompt_version'],PROMPT);self.assertEqual(c['wire_schema_version'],SCHEMA)
        for role in ['1st','2nd']:
            text=(ROOT/f'prompt_{role}.txt').read_text();self.assertIn(PROMPT,text);self.assertIn('repair_scope.horses',text);self.assertIn('ranking_horses',text)
        out=json.loads((ROOT/'output_schema.json').read_text());req=json.loads((ROOT/'request_schema.json').read_text())
        self.assertEqual(out['properties']['prompt_version']['const'],PROMPT)
        self.assertEqual(req['properties']['response_contract']['properties']['prompt_version']['const'],PROMPT)
    def test_system_hashes_match_bytes(self):
        c=json.loads((ROOT/'contract.json').read_text())
        for name,h in c['system_file_sha256'].items():
            with self.subTest(name=name):self.assertEqual(hashlib.sha256((ROOT/name).read_bytes()).hexdigest(),h)
    def test_output_score_caps_match_reference(self):
        s=json.loads((ROOT/'output_schema.json').read_text())['properties']['horses']['items']['properties']['scores']['properties']
        self.assertEqual({k:v['properties']['value']['maximum'] for k,v in s.items()},CAPS)
    def test_scope_contract_matches_code(self):
        c=json.loads((ROOT/'contract.json').read_text())['repair_scope_policy']
        self.assertEqual(c['horses'],list(EVALUATION_KEYS));self.assertEqual(c['ranking_horses'],list(RANK_KEYS))
    def test_both_role_examples_pass_checked_entry(self):
        for role,request_name in [('1st','synthetic_1st_request.json'),('2nd','synthetic_request.json')]:
            with self.subTest(role=role):
                req=strict_loads((ROOT/'examples'/request_name).read_text());reply=strict_loads((ROOT/'examples'/f'synthetic_{role}_wire.json').read_text())
                p=expand_checked_request(req,reply,req['input'],req['response_contract']['request_id'])
                self.assertEqual(p['stage'],'UNVERIFIED_MATERIAL_PACKET');self.assertNotIn('public_candidates',p)

if __name__=='__main__':unittest.main(verbosity=2)
