"""Normalized reference model only; source/receipt verification belongs to PHP.

market_supported is computed by the exact per-horse evidence checks in 01.
Pools contain only active, verified ELIGIBLE horses in the existing merged order.
This model never calls an AI, database, or external service.
"""
from copy import deepcopy

POLICY = 'RACE_METRICS_SELECTION_V1'
BANDS = ('A', 'B', 'D')


def select(case):
    q = deepcopy(case['base_quota'])
    pools = case['pools']
    c = case['target_count']
    assert sum(q.values()) == c
    assert all(type(q[b]) is int and q[b] >= 0 for b in BANDS)
    all_horses = [n for b in BANDS for n in pools[b]]
    assert len(all_horses) == len(set(all_horses))
    before = [n for b in BANDS for n in pools[b][:q[b]]]
    result = {'policy': POLICY, 'status': 'KEEP', 'reason': None,
              'base_quota': q, 'effective_quota': deepcopy(q),
              'before': before, 'after': before[:],
              'removed': None, 'added': None, 'attempts': []}

    def keep(reason):
        result['reason'] = reason
        return result

    def metric(key):
        row = case['metrics'].get(key, {})
        v = row.get('value')
        return v if row.get('valid') is True and type(v) is int and 1 <= v <= 5 else None

    if not case.get('selection_enabled', True):
        return keep('SELECTION_DISABLED')
    if not case.get('first_adopted', True):
        return keep('FIRST_NOT_ADOPTED')
    if c <= 3:
        return keep('SMALL_FIELD')
    if case.get('has_base_fill', False) or any(len(pools[b]) < q[b] for b in BANDS):
        return keep('BASE_NOT_REGULAR_FULL')
    if case.get('e35_swapped', False):
        return keep('E35_SWAP_PRIORITY')
    if metric('wave') not in (4, 5):
        return keep('WAVE_NOT_HIGH')
    values = {'B': metric('lower'), 'D': metric('big')}
    targets = [b for b in ('B', 'D') if values[b] in (4, 5)]
    targets.sort(key=lambda b: (-values[b], 0 if b == 'B' else 1))
    if not targets:
        return keep('NO_HIGH_ENTRY')
    a_floor = 2 if c in (4, 5) else 3
    supports = case['market_supported']
    for dest in targets:
        attempt = {'target_band': dest, 'reason': None}
        result['attempts'].append(attempt)
        if q[dest] >= {'B': 4, 'D': 2}[dest]:
            attempt['reason'] = 'TARGET_CAP'
            continue
        if len(pools[dest]) <= q[dest]:
            attempt['reason'] = 'NO_NEXT_CANDIDATE'
            continue
        candidate = pools[dest][q[dest]]
        if candidate not in supports.get(dest, []):
            attempt['reason'] = 'NEXT_MARKET_NOT_SUPPORTED'
            continue
        donor = None
        if q['A'] > a_floor:
            donor = 'A'
        elif dest == 'D' and values['B'] in (1, 2) and q['B'] > 1:
            donor = 'B'
        elif dest == 'B' and values['D'] in (1, 2) and q['D'] > 0:
            donor = 'D'
        if donor is None:
            attempt['reason'] = 'NO_DONOR'
            continue
        removed = pools[donor][q[donor] - 1]
        changed_q = deepcopy(q)
        changed_q[donor] -= 1
        changed_q[dest] += 1
        after = [n for b in BANDS for n in pools[b][:changed_q[b]]]
        assert len(after) == c and len(after) == len(set(after))
        assert set(before) - set(after) == {removed}
        assert set(after) - set(before) == {candidate}
        assert changed_q['A'] >= a_floor
        assert changed_q['B'] <= 4 and changed_q['D'] <= 2
        attempt['reason'] = 'APPLIED'
        result.update(status='APPLIED', reason='ONE_SLOT_ADJUSTMENT',
                      effective_quota=changed_q, after=after,
                      removed=removed, added=candidate,
                      source_band=donor, target_band=dest)
        return result
    return keep('NO_FEASIBLE_ADJUSTMENT')


if __name__ == '__main__':
    import json
    import sys
    from pathlib import Path
    path = Path(sys.argv[1]) if len(sys.argv) > 1 else Path(__file__).with_name('04_試験ケース.json')
    cases = json.loads(path.read_text(encoding='utf-8'))['cases']
    failures = []
    rows = []
    for item in cases:
        actual = select(item['input'])
        for key, expected in item['expected'].items():
            if actual.get(key) != expected:
                failures.append({'case': item['id'], 'key': key,
                                 'expected': expected, 'actual': actual.get(key)})
        rows.append({'id': item['id'], 'description': item['description'], 'actual': actual})
    print(json.dumps({'scope': 'Normalized policy model; not PHP integration tests',
                      'total': len(cases), 'failed': len(failures),
                      'failures': failures, 'results': rows}, ensure_ascii=False, indent=2))
    if failures:
        raise SystemExit(1)
