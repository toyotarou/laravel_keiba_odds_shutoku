<?php
spl_autoload_register(function ($c) { $p = strrpos($c, '\\'); $ns = $p === false ? '' : substr($c, 0, $p); $n = $p === false ? $c : substr($c, $p + 1); eval(($ns ? "namespace $ns; " : '') . "class $n {}"); });
require '/home/claude/ms/AiController.php';
use App\Http\Controllers\Api\BaganrikiMetricsSelection as MS;
$d = json_decode(file_get_contents(glob('/home/claude/ms/nz/*/04_*.json')[0]), true);
$ok = 0; $ng = 0;
foreach ($d['cases'] as $c) {
    $in = $c['input'];
    $m = [];
    foreach (['wave','lower','big'] as $k) { $row = $in['metrics'][$k] ?? []; $m[$k] = (($row['valid'] ?? false) === true && is_int($row['value'] ?? null)) ? $row['value'] : null; }
    $in['metrics'] = $m;
    $got = MS::decide($in);
    $bad = [];
    foreach ($c['expected'] as $k => $v) { if (($got[$k] ?? null) !== $v) { $bad[] = $k . ' 期待' . json_encode($v) . ' 結果' . json_encode($got[$k] ?? null); } }
    $bad ? $ng++ : $ok++;
    printf("%-6s %-40s %s\n", $c['id'], mb_substr($c['description'], 0, 30), $bad ? '★' . implode(' ', $bad) : 'OK');
}
echo "合計 OK $ok / 違う $ng\n";
