<?php
// 20261116 早期凍結の確認の続き（11/15の全レース）。試験の時計をそのレースの時刻に合わせて、保存しない凍結を作る
require '/var/www/horse_odds_finder/vendor/autoload.php';
$app = require '/var/www/horse_odds_finder/bootstrap/app.php';
$app->make(Illuminate\Contracts\Console\Kernel::class)->bootstrap();
use App\Http\Controllers\Api\AiController;
use App\Http\Controllers\Api\BaganrikiTime as T;
use App\Http\Controllers\Api\BaganrikiWorker as W;
use Illuminate\Support\Facades\DB;
class_exists(AiController::class);
$c = app(AiController::class);
$res = ['T300' => [], 'EARLY' => []]; $offs = [];
foreach (DB::table('t_horse_odds_finder_races')->where('date', '2026-11-15')->orderBy('basho')->orderBy('race')->get() as $r) {
    $rid = AiController::buildPredictionRaceId($r->date, $r->kaisuu, $r->basho, $r->day, (int) $r->race);
    $anchor = T::us('2026-11-15T' . T::normalizeRaceStartClock((string) $r->start_time) . '+09:00');
    $first = null;
    foreach (DB::table('baganriki_acquisition_batches')->where('race_id', $rid)->where('slot', 6)->where('committed', 1)->get(['available_at']) as $b) {
        $at = T::us((string) AiController::dbTimeToRfc3339($b->available_at)); if ($at !== null && ($first === null || $at < $first)) { $first = $at; }
    }
    $name = "{$r->basho}_{$r->race}R";
    foreach (['T300' => $anchor - 290 * 1000000, 'EARLY' => ($first === null ? null : $first + 1000000)] as $kind => $now) {
        if ($now === null) { $res[$kind]['6分前のバッチなし'][] = $name; continue; }
        DB::beginTransaction();
        try {
            DB::table('baganriki_snapshots')->where('race_id', $rid)->where('generation', 0)->update(['generation' => 990]);
            W::setTestNow($now);
            $o = $c->freezePredictionInput($r->date, $r->kaisuu, $r->basho, $r->day, $r->race, [], 'PRODUCTION', true);
            $k = $o['ok'] ? 'OK' : ((string) $o['code'] . '：' . mb_substr((string) $o['reason'], 0, 70));
            if ($kind === 'EARLY' && $o['ok']) { $offs[] = intdiv(T::freezeFor($anchor, $now, T::TIME_CONTRACT_V2) - $anchor, 1000000); }
        } catch (\Throwable $e) { $k = '例外：' . mb_substr($e->getMessage(), 0, 70); }
        finally { W::setTestNow(null); DB::rollBack(); }
        $res[$kind][$k][] = $name;
    }
}
foreach (['T300' => '【3】T−300秒より後（今までと同じ時刻）', 'EARLY' => '【4】6分前のバッチが届いた1秒後（早期凍結）'] as $kind => $title) {
    echo $title . "\n";
    foreach ($res[$kind] as $k => $l) { echo "  {$k} : " . count($l) . ($k !== 'OK' ? '（' . implode(' ', $l) . '）' : '') . "\n"; }
}
if ($offs) { echo '  早期凍結の時刻（発走の何秒前）：最も早い T' . min($offs) . ' ／ 最も遅い T' . max($offs) . ' ／ 平均 T' . round(array_sum($offs) / count($offs), 1) . "\n"; }
echo '  保存済みの凍結が元のまま（11/15 の generation 0）: ' . DB::table('baganriki_snapshots')->where('race_id', 'like', '20261115-%')->where('generation', 0)->count()
   . ' ／ generation 990: ' . DB::table('baganriki_snapshots')->where('generation', 990)->count() . "\n";
