<?php
spl_autoload_register(function ($c) {
    $p = strrpos($c, '\\'); $ns = $p === false ? '' : substr($c, 0, $p); $n = $p === false ? $c : substr($c, $p + 1);
    eval(($ns ? "namespace $ns; " : '') . "class $n {}");
});
require '/mnt/user-data/uploads/KEIBA/_____laravel/app/Http/Controllers/Api/AiController.php';
use App\Http\Controllers\Api\BaganrikiRaceMetrics as M;
use App\Http\Controllers\Api\BaganrikiTime as T;
$d = json_decode(file_get_contents(glob('naru/*/05_3指標の検証ケース.json')[0]), true);
$ok = 0; $ng = 0;
foreach ($d['cases'] as $c) {
    try { M::entry($c['input'], $c['metric_key'], $c['entry']); $got = 'ACCEPT'; }
    catch (\InvalidArgumentException $e) { $got = $e->getMessage(); }
    $pass = $got === $c['expected_entry_result'];
    $pass ? $ok++ : $ng++;
    printf("%-28s 期待 %-28s 結果 %-28s %s\n", $c['id'], $c['expected_entry_result'], $got, $pass ? 'OK' : '★違う');
}
echo "合計 OK $ok / 違う $ng\n";
// enabled
foreach (['COMPACT_TEXT_20261109_04','COMPACT_TEXT_20261109_05','COMPACT_TEXT_20261109_03','X',null] as $r) echo "enabled($r)=" . var_export(M::enabled(['prompt_text_revision'=>$r]), true) . "\n";
// time window
$a = T::us('2026-11-21T10:05:00+09:00');
$cases = [['v1 T-300', $a-300*1000000, T::TIME_CONTRACT_V1, true], ['v1 T-330', $a-330*1000000, T::TIME_CONTRACT_V1, false],
          ['v2 T-330', $a-330*1000000, T::TIME_CONTRACT_V2, true], ['v2 T-360', $a-360*1000000, T::TIME_CONTRACT_V2, true],
          ['v2 T-361', $a-361*1000000, T::TIME_CONTRACT_V2, false], ['v2 T-299', $a-299*1000000, T::TIME_CONTRACT_V2, false],
          ['null T-330', $a-330*1000000, null, true]];
foreach ($cases as [$n, $f, $v, $want]) { $g = T::freezeInWindow($a, $f, $v); echo "freezeInWindow $n => " . var_export($g, true) . ($g === $want ? ' OK' : ' ★違う') . "\n"; }
foreach ([['今がT-400', -400], ['今がT-350', -350], ['今がT-200', -200]] as [$n, $o]) {
    $f = T::freezeFor($a, $a + $o*1000000, T::TIME_CONTRACT_V2); echo "freezeFor v2 $n => T" . (($f-$a)/1000000) . "秒\n";
}
echo 'freezeFor v1 今がT-350 => T' . ((T::freezeFor($a, $a-350*1000000, T::TIME_CONTRACT_V1)-$a)/1000000) . "秒\n";
