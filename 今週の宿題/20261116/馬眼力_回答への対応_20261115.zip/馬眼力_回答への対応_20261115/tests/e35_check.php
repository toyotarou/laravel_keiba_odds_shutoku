<?php
// 20261116 作業2の確認：古い過去レース（取得時刻の記録なし）を足すと、本番と同じ E3・E5 の計算で何が変わるか。保存しない・AIへ送らない
require '/var/www/horse_odds_finder/vendor/autoload.php';
$app = require '/var/www/horse_odds_finder/bootstrap/app.php';
$app->make(Illuminate\Contracts\Console\Kernel::class)->bootstrap();
use App\Http\Controllers\Api\AiController;
use App\Http\Controllers\Api\BaganrikiTime as T;
use App\Http\Controllers\Api\BaganrikiWorker as W;
use App\Http\Controllers\Api\BaganrikiInput;
use App\Http\Controllers\Api\BaganrikiPrompt;
use Illuminate\Support\Facades\DB;
class_exists(AiController::class);
$ref = new ReflectionMethod(AiController::class, 'expectedAssemble'); $ref->setAccessible(true);
echo '方針（contract.json）: ' . var_export(AiController::expectedOldHistoryEnabled(), true) . "（本番はまだ false のまま）\n";
foreach (['2026-11-14', '2026-11-15'] as $d) {
    $sum = ['off' => ['ready' => 0, 'rows' => 0, 'sec' => 0.0, 'ng' => 0], 'on' => ['ready' => 0, 'rows' => 0, 'sec' => 0.0, 'ng' => 0]];
    $byN = []; $races = 0; $ngList = [];
    foreach (DB::table('t_horse_odds_finder_races')->where('date', $d)->orderBy('basho')->orderBy('race')->get() as $r) {
        $anchor = T::us($d . 'T' . T::normalizeRaceStartClock((string) $r->start_time) . '+09:00');
        W::setTestNow($anchor - 290 * 1000000);
        try {
            AiController::$expectedOldHistoryForce = false;
            $g = BaganrikiInput::gatherPredictionContext($r->date, $r->kaisuu, $r->basho, $r->day, $r->race);
            if (!$g['ok']) { $ngList[] = "{$r->basho}_{$r->race}R:" . $g['code']; continue; }
            $a1 = BaganrikiPrompt::assemble($g['ctx'], '1st'); $a2 = BaganrikiPrompt::assemble($g['ctx'], '2nd');
            if (!$a1['ok'] || !$a2['ok']) { $ngList[] = "{$r->basho}_{$r->race}R:assemble"; continue; }
            $races++;
            foreach (['off' => false, 'on' => true] as $k => $flag) {
                AiController::$expectedOldHistoryForce = $flag;
                $t0 = microtime(true); $ex = $ref->invoke(null, $a1, $a2, $g['ctx']); $sum[$k]['sec'] += microtime(true) - $t0;
                if (!$ex['ok']) { $sum[$k]['ng']++; $ngList[] = "{$r->basho}_{$r->race}R({$k}):" . mb_substr($ex['reason'], 0, 60); continue; }
                foreach ($ex['common']['expected_v01']['rows'] as $row) {
                    $sum[$k]['rows']++;
                    if ($row['status'] === 'COMPARISON_READY') { $sum[$k]['ready']++; }
                    $n = (string) count($ex['common']['runners']) . ($g['ctx']['registry'] ? '' : '');
                    $byN[$k][$n]['M'] = max($byN[$k][$n]['M'] ?? 0, (int) ($row['M'] ?? 0));
                    if ($row['status'] === 'COMPARISON_READY') { $byN[$k][$n]['ready'] = ($byN[$k][$n]['ready'] ?? 0) + 1; }
                }
            }
        } catch (\Throwable $e) { $ngList[] = "{$r->basho}_{$r->race}R 例外:" . mb_substr($e->getMessage(), 0, 60); }
        finally { W::setTestNow(null); AiController::$expectedOldHistoryForce = null; }
    }
    echo "{$d} : 計算できたレース {$races}\n";
    foreach (['off' => '今（10/24以降だけ）', 'on' => '古いデータを足す'] as $k => $t) {
        printf("  %s：比べられる馬 %d／%d頭 ／ E3・E5の計算 合計%.1f秒（1レース平均%.2f秒）／ 作れなかった %d\n", $t, $sum[$k]['ready'], $sum[$k]['rows'], $sum[$k]['sec'], $races ? $sum[$k]['sec'] / $races : 0, $sum[$k]['ng']);
    }
    $ns = array_unique(array_merge(array_keys($byN['off'] ?? []), array_keys($byN['on'] ?? []))); sort($ns, SORT_NUMERIC);
    echo '  頭数ごとの最大M（今→足す）と比べられる馬（足す）: ';
    foreach ($ns as $n) { echo "{$n}頭 " . ($byN['off'][$n]['M'] ?? '-') . '→' . ($byN['on'][$n]['M'] ?? '-') . '(' . ($byN['on'][$n]['ready'] ?? 0) . ') '; }
    echo "\n";
    if ($ngList) { echo '  止まったもの: ' . implode(' ', array_slice($ngList, 0, 10)) . "\n"; }
}
$a = AiController::$expectedOldHistoryAudit;
echo '古い過去レースの監査: 採用 ' . ($a['adopted'] ?? '-') . ' ／ 外した ' . json_encode($a['excluded'] ?? [], JSON_UNESCAPED_UNICODE) . "\n";
$same = $a['excluded_races']['ODDS21_EQUALS_ODDS6'] ?? [];
$m = []; foreach ($same as $rid) { $mo = substr($rid, 0, 6); $m[$mo] = ($m[$mo] ?? 0) + 1; }
echo '  21分前＝6分前で外したレース（月ごと）: ' . json_encode($m) . "\n";
echo '  6分前＝確定単勝で外したレース: ' . implode(' ', array_slice($a['excluded_races']['ODDS6_EQUALS_FINAL'] ?? [], 0, 20)) . "\n";
