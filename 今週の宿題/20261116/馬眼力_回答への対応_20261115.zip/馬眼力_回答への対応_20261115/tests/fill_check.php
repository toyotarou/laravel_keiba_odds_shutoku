<?php
// 20261115 補充の直し（検証済みの順位・頭数の区分）の確認。読み取りだけ（アプリと同じ読み出しを呼ぶ。答えはキャッシュに入る）
require '/var/www/horse_odds_finder/vendor/autoload.php';
$app = require '/var/www/horse_odds_finder/bootstrap/app.php';
$app->make(Illuminate\Contracts\Console\Kernel::class)->bootstrap();
use App\Http\Controllers\Api\AiController;
use Illuminate\Support\Facades\DB;
$find = function ($v, string $k) use (&$find) {
    if (!is_array($v)) { return null; }
    if (array_key_exists($k, $v)) { return $v[$k]; }
    foreach ($v as $x) { $r = $find($x, $k); if ($r !== null) { return $r; } }
    return null;
};
$c = app(AiController::class);
foreach (['2026-11-14', '2026-11-15'] as $d) {
    $st = []; $short = [];
    foreach (DB::table('t_horse_odds_finder_races')->where('date', $d)->orderBy('basho')->orderBy('race')->get() as $r) {
        $a = $c->predictionAnswerFor($r->date, $r->kaisuu, $r->basho, $r->day, $r->race);
        $fs = $find($a, 'fill_status') ?? 'なし';
        $st[$fs] = ($st[$fs] ?? 0) + 1;
        $t = $find($a, 'target_count'); $s = $find($a, 'shown_count');
        if ($fs !== 'REGULAR_FULL' && $fs !== 'WITH_FILL') { $short[] = "{$r->basho}_{$r->race}R:{$fs}(" . ($s ?? '-') . '/' . ($t ?? '-') . ')'; }
    }
    ksort($st);
    echo $d . ' : ' . json_encode($st, JSON_UNESCAPED_UNICODE) . PHP_EOL;
    echo '  頭数どおりでないレース : ' . ($short ? implode(' ', $short) : 'なし') . PHP_EOL;
}
