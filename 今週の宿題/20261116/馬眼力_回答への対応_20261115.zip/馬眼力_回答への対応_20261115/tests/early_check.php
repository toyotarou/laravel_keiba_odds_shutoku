<?php
// 20261116 _05（本文の版）と早期凍結の確認。DBには書きません（凍結は dryRun、早期凍結は材料集めと組み立てだけ）。AIへは送りません。
require '/var/www/horse_odds_finder/vendor/autoload.php';
$app = require '/var/www/horse_odds_finder/bootstrap/app.php';
$app->make(Illuminate\Contracts\Console\Kernel::class)->bootstrap();
use App\Http\Controllers\Api\AiController;
use App\Http\Controllers\Api\BaganrikiTime as T;
use App\Http\Controllers\Api\BaganrikiDispatch as D;
use App\Http\Controllers\Api\BaganrikiInput;
use App\Http\Controllers\Api\BaganrikiPrompt;
use App\Http\Controllers\Api\BaganrikiFrozenInput;
use App\Http\Controllers\Api\BaganrikiRaceMetrics;
use Illuminate\Support\Facades\DB;
class_exists(AiController::class);
$E = '/var/www/horse_odds_finder/storage/app/baganriki/prompts/expected/prompts/';
$sha = fn($s) => hash('sha256', $s);

echo "【1】本文の版\n";
echo '  本番の版: ' . D::activeRevision() . ' ／ 早期凍結: ' . var_export(T::earlyFreezeActive(), true) . ' ／ 時刻契約: ' . T::timeContractVersion() . "\n";
$w1 = $sha(file_get_contents($E . 'prompt_1st.txt') . "\n\n" . file_get_contents($E . 'SOURCE_DICT_V3_ADDENDUM_V1.txt'));
$w2 = $sha(file_get_contents($E . 'prompt_2nd.txt') . "\n\n" . file_get_contents($E . 'SOURCE_TABLE_V1_ADDENDUM_V2.txt'));
echo '  _05 1st ' . ($sha(D::system('1st', 'SOURCE_DICT_V3')) === $w1 ? 'OK' : '★NG') . ' ／ 2nd ' . ($sha(D::system('2nd', 'SOURCE_TABLE_V1')) === $w2 ? 'OK' : '★NG') . "\n";
echo '  _04 1st ' . ($sha(D::system('1st', 'SOURCE_DICT_V3', 'COMPACT_TEXT_20261109_04')) === '18f97c15417c843589c95b853e7814f04e1708c9cbfd9903dd64acb3f67a85bc' ? 'OK（11/14・15に送った本文と同じ）' : '★NG')
   . ' ／ 2nd ' . ($sha(D::system('2nd', 'SOURCE_TABLE_V1', 'COMPACT_TEXT_20261109_04')) === '3f91c0a8844e0c74333d5c6fce72bf9201da96e1e5e84301283884ddff85f1be' ? 'OK' : '★NG') . "\n";
try { D::system('1st', 'SOURCE_DICT_V3', 'COMPACT_TEXT_20261109_99'); echo "  未知の版 ★通ってしまった\n"; } catch (\Throwable $e) { echo '  未知の版は拒否 OK（' . $e->getMessage() . "）\n"; }

echo "【2】_04 の保存済みの予想の3指標（11/14・15）\n";
$cnt = []; $err = 0;
foreach (DB::table('baganriki_publications as p')->join('baganriki_snapshots as s', 's.id', '=', 'p.snapshot_id')
           ->where('p.published_at', '>=', '2026-11-14')->get(['p.evidence', 's.*']) as $r) {
    try {
        $in = BaganrikiFrozenInput::forInspection($r, '1st');
        $v = BaganrikiRaceMetrics::publicValues($in, json_decode($r->evidence, true)['race_metrics'] ?? null);
        foreach ($v as $k => $x) { if ($x !== null) { $cnt[$k] = ($cnt[$k] ?? 0) + 1; } }
    } catch (\Throwable $e) { $err++; }
}
echo '  値が出た件数 ' . json_encode($cnt, JSON_UNESCAPED_UNICODE) . ' ／ 読めなかった ' . $err . "（11/14・15の実測：波乱度37・下位進入度40・大穴進入度32 なら一致）\n";

$c = app(AiController::class);
$ref = new ReflectionMethod(AiController::class, 'expectedAssemble'); $ref->setAccessible(true);
foreach (['2026-11-15'] as $d) {
    echo "【3】{$d} の全レースを凍結し直す（dryRun・保存しない。T−300秒・時刻契約 v2）\n";
    $res = [];
    foreach (DB::table('t_horse_odds_finder_races')->where('date', $d)->orderBy('basho')->orderBy('race')->get() as $r) {
        $o = $c->freezePredictionInput($r->date, $r->kaisuu, $r->basho, $r->day, $r->race, [], 'REPLAY', true);
        $k = !empty($o['skipped']) ? 'SKIPPED（試験用の世代900が既にある）' : ($o['ok'] ? 'OK' : (string) $o['code']); $res[$k][] = "{$r->basho}_{$r->race}R";
    }
    foreach ($res as $k => $l) { echo "  {$k} : " . count($l) . ($k !== 'OK' ? '（' . implode(' ', $l) . '）' : '') . "\n"; }

    echo "【4】{$d} 早期凍結の試し（6分前のバッチが利用可能になった1秒後に凍結したことにして、材料集め→組み立て→E3・E5まで。保存しない）\n";
    $sum = []; $lines = [];
    foreach (DB::table('t_horse_odds_finder_races')->where('date', $d)->orderBy('basho')->orderBy('race')->get() as $r) {
        $rid = AiController::buildPredictionRaceId($r->date, $r->kaisuu, $r->basho, $r->day, (int) $r->race);
        $st = T::normalizeRaceStartClock((string) $r->start_time); $anchor = T::us($d . 'T' . $st . '+09:00');
        $first = null;
        foreach (DB::table('baganriki_acquisition_batches')->where('race_id', $rid)->where('slot', 6)->where('committed', 1)->get(['available_at']) as $b) {
            $at = T::us((string) AiController::dbTimeToRfc3339($b->available_at)); if ($at !== null && ($first === null || $at < $first)) { $first = $at; }
        }
        if ($first === null) { $sum['6分前のバッチなし'][] = "{$r->basho}_{$r->race}R"; continue; }
        $fz = T::freezeFor($anchor, $first + 1000000, T::TIME_CONTRACT_V2);
        $g = BaganrikiInput::gatherPredictionContext($r->date, $r->kaisuu, $r->basho, $r->day, $r->race, ['input_freeze_us' => $fz]);
        $k = null;
        if (!$g['ok']) { $k = 'gather:' . $g['code']; }
        else {
            $a1 = BaganrikiPrompt::assemble($g['ctx'], '1st'); $a2 = BaganrikiPrompt::assemble($g['ctx'], '2nd');
            if (!$a1['ok']) { $k = 'assemble:' . $a1['code']; }
            elseif (!$a2['ok']) { $k = 'assemble2:' . $a2['code']; }
            elseif ($a1['snapshot_hash'] !== $a2['snapshot_hash']) { $k = 'HASH_MISMATCH'; }
            else {
                $ex = $ref->invoke(null, $a1, $a2, $g['ctx']);
                $k = $ex['ok'] ? 'OK' : 'expected:' . $ex['reason'];
                if ($ex['ok']) {
                    $in = $a1['input'];
                    $lines[] = sprintf('%s_%02dR 凍結 T%+d秒（情報上限 %s）版 %s', $r->basho, $r->race, intdiv($fz - $anchor, 1000000),
                        substr((string) $in['input_freeze_at'], 11, 12), $in['time_contract']['version']);
                }
            }
        }
        $sum[$k][] = "{$r->basho}_{$r->race}R";
    }
    foreach ($sum as $k => $l) { echo "  {$k} : " . count($l) . ($k !== 'OK' ? '（' . implode(' ', $l) . '）' : '') . "\n"; }
    echo '  例 : ' . implode(' ／ ', array_slice($lines, 0, 4)) . "\n";
    $offs = array_map(fn($x) => (int) preg_replace('/^.*凍結 T([+-]\d+)秒.*$/u', '$1', $x), $lines);
    if ($offs) { echo '  凍結の時刻（発走の何秒前）：最も早い ' . min($offs) . ' ／ 最も遅い ' . max($offs) . ' ／ 平均 ' . round(array_sum($offs) / count($offs), 1) . "\n"; }
}

echo "【5】本番と同じ入口（freezePredictionInput・PRODUCTION・dryRun）で早期凍結の判定を試す（11/15 京都の3レース。保存済みの凍結を一時的に別の世代へ移し、最後に必ず元に戻す）\n";
use App\Http\Controllers\Api\BaganrikiWorker as W;
foreach (DB::table('t_horse_odds_finder_races')->where('date', '2026-11-15')->where('basho', '08')->whereIn('race', [1, 5, 9])->orderBy('race')->get() as $r) {
    $rid = AiController::buildPredictionRaceId($r->date, $r->kaisuu, $r->basho, $r->day, (int) $r->race);
    $anchor = T::us('2026-11-15T' . T::normalizeRaceStartClock((string) $r->start_time) . '+09:00');
    $first = null;
    foreach (DB::table('baganriki_acquisition_batches')->where('race_id', $rid)->where('slot', 6)->where('committed', 1)->get(['available_at']) as $b) {
        $at = T::us((string) AiController::dbTimeToRfc3339($b->available_at)); if ($at !== null && ($first === null || $at < $first)) { $first = $at; }
    }
    if ($first === null) { echo "  {$rid} 6分前のバッチなし\n"; continue; }
    foreach ([['バッチの1秒前', $first - 1000000], ['バッチの1秒後', $first + 1000000], ['T−300秒の後', $anchor - 290 * 1000000]] as [$label, $now]) {
        DB::beginTransaction();
        try {
            DB::table('baganriki_snapshots')->where('race_id', $rid)->where('generation', 0)->update(['generation' => 990]);
            W::setTestNow($now);
            $o = $c->freezePredictionInput($r->date, $r->kaisuu, $r->basho, $r->day, $r->race, [], 'PRODUCTION', true);
            printf("  %s 今=T%+d秒（%s）→ %s %s\n", $rid, intdiv($now - $anchor, 1000000), $label, $o['ok'] ? 'OK（凍結できる）' : (string) $o['code'], $o['ok'] ? '' : mb_substr((string) $o['reason'], 0, 60));
        } catch (\Throwable $e) {
            echo "  {$rid} {$label} 例外 " . $e->getMessage() . "\n";
        } finally {
            W::setTestNow(null);
            DB::rollBack();
        }
    }
}
echo '  保存済みの凍結が元のまま（11/15 の generation 0 の件数）: ' . DB::table('baganriki_snapshots')->where('race_id', 'like', '20261115-%')->where('generation', 0)->count()
   . ' ／ generation 990 の件数: ' . DB::table('baganriki_snapshots')->where('generation', 990)->count() . "\n";
