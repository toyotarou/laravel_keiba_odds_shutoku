<?php
// 20261116 作業2の確認：古い過去レースを足したとき、保存済みのAIの順位（検査済み）に E3・E5 の境目の比べを当て直すと、入れ替え（SWAP）がいくつ起きるか。保存しない・AIへ送らない
require '/var/www/horse_odds_finder/vendor/autoload.php';
$app = require '/var/www/horse_odds_finder/bootstrap/app.php';
$app->make(Illuminate\Contracts\Console\Kernel::class)->bootstrap();
use App\Http\Controllers\Api\AiController;
use App\Http\Controllers\Api\BaganrikiTime as T;
use App\Http\Controllers\Api\BaganrikiWorker as W;
use App\Http\Controllers\Api\BaganrikiInput;
use App\Http\Controllers\Api\BaganrikiPrompt;
use App\Http\Controllers\Api\BaganrikiFrozenInput;
use App\Http\Controllers\Api\BaganrikiCandidateSelection as S;
use Illuminate\Support\Facades\DB;
class_exists(AiController::class);
$c = app(AiController::class);
$ref = new ReflectionMethod(AiController::class, 'expectedAssemble'); $ref->setAccessible(true);
foreach (['2026-11-14', '2026-11-15'] as $d) {
    $dec = ['old' => [], 'new' => []]; $changed = []; $roles = 0; $ng = [];
    foreach (DB::table('t_horse_odds_finder_races')->where('date', $d)->orderBy('basho')->orderBy('race')->get() as $r) {
        $rid = AiController::buildPredictionRaceId($r->date, $r->kaisuu, $r->basho, $r->day, (int) $r->race);
        $snap = DB::table('baganriki_snapshots')->where('race_id', $rid)->where('generation', 0)->first();
        if ($snap === null) { continue; }
        $anchor = T::us($d . 'T' . T::normalizeRaceStartClock((string) $r->start_time) . '+09:00');
        $new = null;
        try {
            W::setTestNow($anchor - 290 * 1000000); AiController::$expectedOldHistoryForce = true;
            $g = BaganrikiInput::gatherPredictionContext($r->date, $r->kaisuu, $r->basho, $r->day, $r->race);
            if ($g['ok']) {
                $a1 = BaganrikiPrompt::assemble($g['ctx'], '1st'); $a2 = BaganrikiPrompt::assemble($g['ctx'], '2nd');
                if ($a1['ok'] && $a2['ok']) { $new = $ref->invoke(null, $a1, $a2, $g['ctx']); }
            }
        } catch (\Throwable $e) { $ng[] = "{$r->basho}_{$r->race}R:" . mb_substr($e->getMessage(), 0, 50); }
        finally { W::setTestNow(null); AiController::$expectedOldHistoryForce = null; }
        if (!is_array($new) || !($new['ok'] ?? false)) { $ng[] = "{$r->basho}_{$r->race}R:新しい入力を作れない"; continue; }
        foreach (['1st', '2nd'] as $role) {
            try {
                $acc = $c->acceptedHorsesOf((int) $snap->id, $role);
                if (!($acc['ok'] ?? false) || ($acc['complete'] ?? null) !== true) { continue; }
                $rk = $c->markResponseUsed((int) $snap->id, $role, $acc);
                $base = $rk['band_ranks'] ?? [];
                if (!is_array($base) || $base === []) { continue; }
                $horses = array_values((array) $acc['merged']);
                $oldIn = BaganrikiFrozenInput::forInspection($snap, $role);
                $o = S::apply($oldIn, $horses, $base);
                $frozen = BaganrikiFrozenInput::fromStored($new['json'], $role === '1st' ? $new['user1'] : $new['user2'], $new['hash'], $role, $new['proof']);
                $n = S::apply($frozen, $horses, $base);
                $roles++;
                foreach (['old' => $o, 'new' => $n] as $k => $x) {
                    foreach ((array) $x['expected_reviews'] as $band => $rv) { $dc = (string) ($rv['decision'] ?? '?'); $dec[$k][$dc] = ($dec[$k][$dc] ?? 0) + 1; }
                }
                if ($o['public_candidates'] !== $n['public_candidates']) {
                    $sw = [];
                    foreach ((array) $n['expected_reviews'] as $band => $rv) { if (($rv['decision'] ?? '') === 'SWAP') { $sw[] = "{$band}帯 {$rv['incumbent']}番→{$rv['challenger']}番"; } }
                    $changed[] = "{$r->basho}_{$r->race}R({$role}) " . implode('・', $sw);
                }
            } catch (\Throwable $e) { $ng[] = "{$r->basho}_{$r->race}R({$role}):" . mb_substr($e->getMessage(), 0, 50); }
        }
    }
    ksort($dec['old']); ksort($dec['new']);
    echo "{$d} : 当て直したAIの返事 {$roles}件（帯ごとの判定の数）\n";
    echo '  今　　　 : ' . json_encode($dec['old'], JSON_UNESCAPED_UNICODE) . "\n";
    echo '  足した後 : ' . json_encode($dec['new'], JSON_UNESCAPED_UNICODE) . "\n";
    echo '  候補が変わった : ' . count($changed) . '件 ' . implode(' ／ ', $changed) . "\n";
    if ($ng) { echo '  止まったもの : ' . implode(' ', array_slice($ng, 0, 8)) . "\n"; }
}
