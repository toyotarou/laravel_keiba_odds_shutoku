"""Read-only release checks in a temporary copy; never calls a live AI provider."""
from pathlib import Path
from tempfile import TemporaryDirectory
from hashlib import sha256
import argparse, difflib, importlib.util, json, shutil, subprocess

p=argparse.ArgumentParser()
p.add_argument('--release',type=Path,required=True)
p.add_argument('--php',required=True)
p.add_argument('--bootstrap',type=Path,required=True)
p.add_argument('--fixtures',type=Path,required=True)
args=p.parse_args()
kit=Path(__file__).resolve().parents[1]
source=args.release.resolve();fixtures=args.fixtures.resolve();bootstrap=args.bootstrap.resolve()
out=kit/'checks';out.mkdir(exist_ok=True)
digest=lambda b:sha256(b).hexdigest()
required=['E35_BAND_BOUNDARY_V1','p0(k,r)=(B(k,r)+1)/(M+2)','E(k,i)=100×g(p_raw(k,i))',
          'W=Σw','COMPARISON_READY','expected_v01','selection_ranks','expected_reviews',
          'E5[j]>E5[i]','E3[j]>E3[i]','PENDING_VALIDATION','role_quota','7頭立ての目標は4頭',
          '総合点・V小計・H小計を再計算','SOURCE_TABLE_V1_ADDENDUM_V2']
old_common=(source/'prompts/common_prompt.txt').read_bytes()
new_common=(kit/'prompts/common_prompt.txt').read_bytes()
config_raw=(source/'config/w2_contract.json').read_text()
cfg=json.loads(config_raw);new_hashes={};metrics={'unit':'Unicode code points and UTF-8 bytes, not model tokens','prompts':{},'synthetic_requests':[]}
for name in ['prompt_1st.txt','prompt_2nd.txt','SOURCE_TABLE_V1_ADDENDUM_V2.txt']:
    old=(source/'prompts'/name).read_bytes();new=(kit/'prompts'/name).read_bytes()
    assert digest(old)==cfg['system_file_sha256'][name]
    if name.startswith('prompt_'):
        assert new.endswith(new_common) and new.count(new_common)==1 and not new.startswith(b'\xef\xbb\xbf')
        assert old[:-len(old_common)]==new[:-len(new_common)]
        text=new.decode()
        assert all(s in text for s in required)
        assert cfg['prompt_version'] in text and cfg['schema_version'] in text
        for key in json.loads((source/'schemas/output_schema.json').read_text())['required']:assert key in text,key
    else:assert old==new
    new_hashes[name]=digest(new)
    cfg['system_file_sha256'][name]=digest(new)
    metrics['prompts'][name]={'before_chars':len(old.decode()),'after_chars':len(new.decode()),'chars_reduction_pct':round(100*(1-len(new.decode())/len(old.decode())),2),
                             'before_bytes':len(old),'after_bytes':len(new),'before_sha256':digest(old),'after_sha256':digest(new)}
assert set(k for k in json.loads(config_raw) if json.loads(config_raw)[k]!=cfg[k])=={'system_file_sha256'}
new_config=json.dumps(cfg,ensure_ascii=False,indent=2)+'\n'
(kit/'config_hash_patch.json').write_text(json.dumps({'system_file_sha256':new_hashes},indent=2)+'\n')
(kit/'config_w2_contract.diff').write_text(''.join(difflib.unified_diff(config_raw.splitlines(True),new_config.splitlines(True),fromfile='a/config/w2_contract.json',tofile='b/config/w2_contract.json')))
with TemporaryDirectory() as temp:
    stage=Path(temp)/'W2';shutil.copytree(source,stage)
    for f in (kit/'prompts').glob('*.txt'):shutil.copy2(f,stage/'prompts'/f.name)
    (stage/'config/w2_contract.json').write_text(new_config)
    spec=importlib.util.spec_from_file_location('compact_dispatch_check',stage/'validation/verify_r9_dispatch.py')
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
    module.run(args.php,bootstrap,fixtures,20261109)
    command=[args.php,str(stage/'validation/r9_wire_probe.php'),str(bootstrap),str(fixtures)]
    with subprocess.Popen(command,stdin=subprocess.PIPE,stdout=subprocess.PIPE,text=True) as worker:
        for role in ['1st','2nd']:
            for fmt in ['FULL','SOURCE_TABLE_V1']:
                worker.stdin.write(json.dumps({'role':role,'format':fmt})+'\n');worker.stdin.flush()
                reply=json.loads(worker.stdout.readline());user=reply['input']
                suffix=b'' if fmt=='FULL' else b'\n\n'+(kit/'prompts/SOURCE_TABLE_V1_ADDENDUM_V2.txt').read_bytes()
                old=(source/f'prompts/prompt_{role}.txt').read_bytes()+suffix
                new=(kit/f'prompts/prompt_{role}.txt').read_bytes()+suffix
                before=len(old)+len(user.encode());after=len(new)+len(user.encode())
                metrics['synthetic_requests'].append({'role':role,'format':fmt,'N':16,'user_bytes_unchanged':len(user.encode()),'request_before_bytes':before,'request_after_bytes':after,'bytes_reduction_pct':round(100*(1-after/before),2)})
        worker.stdin.close();assert worker.wait()==0
metrics['validation']={'static_required_phrases':'passed','schema_required_names':'present','role_prefixes':'unchanged','addendum':'byte_identical',
                       'dispatch_initial_pairs':4,'dispatch_correction_cases':32,'live_ai_tested':False,'latency_measured':False,'predictive_accuracy_measured':False,
                       'source_modified':False,'known_validator_findings_fixed':False,'output_schema_changed':False}
(out/'metrics.json').write_text(json.dumps(metrics,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(metrics,ensure_ascii=False,indent=2))
