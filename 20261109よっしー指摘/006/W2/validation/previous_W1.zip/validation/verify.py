"""馬眼力 W1 の無課金参照試験。標準ライブラリのみ。実AI・実PHPは呼ばない。"""
import argparse
import hashlib
import json
from decimal import Decimal
from fractions import Fraction
from itertools import product
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
FIXTURES = ROOT / 'validation'
VERSION = 'baganriki-v041-r12-2-w1-20261101'
CAPS = {'H1':18, 'H2':15, 'H3':12, 'H4':9, 'H5':6,
        'V1':12, 'V2':10, 'V3':8, 'V4':6, 'V5':4}
SIX = 4  # slot order in market_inputs.json: S, 21, 12, 9, 6


def require(ok, message):
    if not ok:
        raise ValueError(message)


def load_json(path):
    return json.loads(path.read_text(encoding='utf-8'))


def compact_equal(a, b):
    """Compare canonical decoded JSON, treating distinct JSON types distinctly."""
    if isinstance(a, dict) and isinstance(b, dict):
        return a.keys() == b.keys() and all(compact_equal(v, b[k]) for k,v in a.items())
    if isinstance(a, list) and isinstance(b, list):
        return len(a) == len(b) and all(compact_equal(x,y) for x,y in zip(a,b))
    return type(a) is type(b) and a == b


def precise_json(path):
    def unique(pairs):
        d = dict(pairs)
        require(len(d) == len(pairs), 'duplicate JSON key')
        return d
    def nonfinite(v):
        raise ValueError('nonfinite JSON number '+v)
    return json.loads(path.read_text(encoding='utf-8'), object_pairs_hook=unique,
                      parse_int=Decimal, parse_float=Decimal, parse_constant=nonfinite)


def check_roundtrip(left, right):
    schema=load_json(ROOT/'schemas/input_schema.json')
    required=set(schema['required'])
    require(isinstance(left,dict) and set(left)==required, 'full frozen INPUT_JSON with 35 keys required')
    require(left['schema_version']=='baganriki-v041-r12-2' and
            left['prompt_version'] in (VERSION,'baganriki-v041-r12-2-20261020'), 'input version')
    reg=left['source_registry']
    require(isinstance(reg,dict) and reg and all(k==v['source_ref'] for k,v in reg.items()), 'source map')
    for refs in left['input_indices'].values():
        require(isinstance(refs,list) and len(refs)==len(set(refs)) and all(ref in reg for ref in refs), 'index refs')
    for entry in left['coverage'].values():
        if entry['status']=='INCLUDED':
            refs=entry.get('source_refs',[])
            require(refs and all(ref in reg for ref in refs),'coverage refs')
        else:
            require(entry['status']=='UNAVAILABLE' and entry['reason'].strip(),'coverage reason')
    require(compact_equal(left,right),'decoded fields differ')


def atleast(values, count=1):
    """Three-valued cardinality. Missing evidence remains unknown."""
    known = sum(x is True for x in values)
    unknown = sum(x is None for x in values)
    if known >= count:
        return True
    if known + unknown < count:
        return False
    return None


def both(*values):
    return atleast(values, len(values))


def ratio(a, b):
    if a is None or b is None or Fraction(b) <= 0:
        return None
    return Fraction(a) / Fraction(b)


def shorten(before, after):
    r = ratio(after, before)
    return None if r is None else 1-r


def compare(value, op, bound):
    if value is None:
        return None
    return value >= Fraction(bound) if op == '>=' else value < Fraction(bound)


def market_signals(horses):
    heads = sorted(horses, key=lambda h: h['rank'])
    require([h['rank'] for h in heads] == list(range(1,len(heads)+1)), 'frozen ranks invalid')
    n = len(heads)
    def boundary(k, field, slot):
        return ratio(heads[k][field][slot], heads[k-1][field][slot])
    def w(k, slot):
        return boundary(k, 'win', slot)
    def p(k, slot):
        return boundary(k, 'place_min', slot)
    hi = range(1,min(6,n-1)+1)
    x1 = atleast([both(compare(w(k,1),'>=',2),
                       atleast([compare(w(k,SIX),'<',2),compare(shorten(w(k,1),w(k,SIX)),'>=','0.20')])) for k in hi])
    x2 = atleast([both(compare(w(k,SIX),'>=',2),compare(p(k,SIX),'<','1.50'))
                  for k in range(1,min(10,n-1)+1)])
    x3 = both(*(compare(w(k,SIX),'<','1.50') for k in [3,4,5,6])) if n >= 7 else False
    x4 = atleast([atleast([compare(shorten(h['place_min'][1],h['place_min'][SIX]),'>=','0.05'),
                            compare(shorten(h['place_min'][3],h['place_min'][SIX]),'>=','0.03')])
                  for h in heads[6:]], 2)
    x5 = atleast([compare(w(k,SIX),'>=',2) for k in range(7,min(10,n-1)+1)])
    z = atleast([both(compare(w(k,1),'>=',2),compare(w(k,SIX),'>=',2),compare(p(k,SIX),'>=','1.50'))
                 for k in range(1,min(5,n-1)+1)], 2)
    return [x1,x2,x3,x4,x5,None if n>=7 else False,z]


def mode_for(s):
    if s <= 1:
        return 'FIRM'
    return 'MIXED' if s <= 3 else 'VOLATILE'


def allocate(signals):
    weights = [2,1,1,1,1,1,-2]
    possible = [sum(w*v for w,v in zip(weights, option))
                for option in product(*[[0,1] if x is None else [int(x)] for x in signals])]
    states = {mode_for(s) for s in possible}
    if len(states)==1:
        status,mode='CONFIRMED',states.pop()
    elif signals.count(None)==1 and signals[5] is None and min(possible) in (1,3):
        status,mode='PROVISIONAL',mode_for(max(possible))
    else:
        status,mode='UNRESOLVED',None
    return status,mode,min(possible),max(possible)


def price_flag(place, win):
    if place is None or win is None:
        return None
    return Fraction(place)<Fraction('1.5') and Fraction(win)<3


def old_score(h):
    """Legacy audit only. Count same-horse statistics with N>=30."""
    rates = [Fraction(rate) for rate,n in h['returns'] if n>=30]
    min_place=Fraction(h['estimated_place_min'])
    trigger=price_flag(min_place,h['estimated_win'])
    under90=sum(r<90 for r in rates)
    high=sum(r>=110 for r in rates)
    # Absolute ceiling when the legacy categories force a zero or prohibit an exception.
    if trigger and high<2:
        ceiling=5
    elif under90>=2 and Fraction('1.5')<=min_place<Fraction('2.5'):
        ceiling=7+0+8+5
    else:
        ceiling=None
    return trigger,high,under90>=2,ceiling


def summarize_scores(scores):
    require(set(scores)==set(CAPS), 'score items')
    for k, v in scores.items():
        require(v is None or (type(v) is int and 0<=v<=CAPS[k]), 'invalid score '+k)
    vals = {k:v for k,v in scores.items() if v is not None}
    return (sum(vals.values()), sum(CAPS[k] for k in vals),
            sum(vals.values()) if len(vals)==len(CAPS) else None)


def direction(a,b):
    v=shorten(a,b)
    if v is None:
        return 'UNKNOWN'
    return 'SHORTENING' if v>0 else 'RISING' if v<0 else 'FLAT'


def accelerated(a,b,c):
    early,late=shorten(a,b),shorten(b,c)
    return None if early is None or late is None else 0<early<late


def check_contract(cfg):
    common=(ROOT/'prompts/common_prompt.txt').read_bytes()
    require(cfg['prompt_version']==VERSION and cfg['implementation_version']==VERSION,'release config')
    require(cfg['score_caps']==CAPS and cfg['buy_recommended'] is False,'policy')
    for role in ('1st','2nd'):
        t=(ROOT/f'prompts/prompt_{role}.txt').read_bytes()
        require(t.endswith(common) and t.count(common)==1,'self-contained '+role)
        require(t.count(VERSION.encode())==1 and b'<<<BAGANRIKI_V041_R8_BEGIN>>>' in t and b'<<<BAGANRIKI_V041_R8_END>>>' in t,'identity '+role)
        require(not t.startswith(b'\xef\xbb\xbf') and t.decode().startswith('あなたは'+role+' AI。'),'system '+role)
    for kind, keys in [('input',35),('output',21)]:
        sc=load_json(ROOT/f'schemas/{kind}_schema.json')
        require(sc['properties']['prompt_version']['const']==VERSION and len(sc['required'])==keys, 'schema '+kind)
    for k,v in CAPS.items():
        schema=load_json(ROOT/'schemas/output_schema.json')
        upper=schema['properties']['horses']['items']['properties']['scores']['properties'][k]['anyOf'][0]['maximum']
        require(upper==v,'schema cap '+k)
    a=(ROOT/'prompts/SOURCE_TABLE_V1_ADDENDUM_V2.txt').read_bytes()
    require(hashlib.sha256(a).hexdigest()=='459bdb081b5b1a5a28e8b96065da8140e42f55e026233189debbcaabfbe1d1a4','wire addendum')


def legacy_negative_cases():
    fixture = load_json(FIXTURES/'legacy_negative_cases.json')
    mismatch_expected = {'1st':{1,5,7,10}, '2nd':{2,7,9,16}}
    zeros_expected = {1,2,3,4,6,7,8,9,11,12,13,14,15,16}
    for role,rows in fixture['roles'].items():
        mismatch=set()
        zeros=set()
        require(len(rows)==16 and len({h['horse'] for h in rows})==16,'old roster')
        for h in rows:
            n=h['horse']
            require(sum(h['c'])==h['cs'] and sum(h['m'])==h['ms'] and h['cs']+h['ms']==h['internal_total'], 'old arithmetic')
            if h['public_total'] is not None and h['public_total']!=h['internal_total']:
                mismatch.add(n)
            rates=[Fraction(r) for r,samples in h['returns'] if samples>=30]
            if sum(r<90 for r in rates)>=2 and h['m'][1]!=0:
                zeros.add(n)
        require(mismatch==mismatch_expected[role] and zeros==zeros_expected,'old negative controls '+role)
    print('旧方式10/25・初回32行の異常例を検出: 表示点不一致8件、回収率項目28行。')


def check_base_archive(path):
    """Compatibility replay of previously distributed, synthetic input/response pairs."""
    from zipfile import ZipFile
    require(hashlib.sha256(path.read_bytes()).hexdigest() ==
            '34ebb6ef630f5cd8f3c63628662848cfceaba9ad9acd5412bc42cbc928d55d03','wrong base archive')
    with ZipFile(path) as archive:
        def get(member):
            return json.loads(archive.read(member),parse_float=Decimal)
        cfg=load_json(ROOT/'config/r122_contract.json')
        original_cfg=get('config/r122_contract.json')
        for key in ('prompt_version','implementation_version'):
            original_cfg[key]=VERSION
        require(cfg==original_cfg, 'base policy changed')
        for kind in ('input','output'):
            member=f'schemas/{kind}_schema.json'
            current=load_json(ROOT/member)
            original=get(member)
            original['properties']['prompt_version']['const']=VERSION
            original['$id']=original['$id'].replace('r12-2:', 'r12-2-w1:')
            require(current==original,'schema drift '+kind)
        require(archive.read('schemas/source_registry_schema.json') ==
                (ROOT/'schemas/source_registry_schema.json').read_bytes(),'registry drift')
        inputs=sorted(n for n in archive.namelist() if n.startswith('validation/normal/') and n.endswith('_input.json'))
        require(len(inputs)==14,'base fixture count')
        for name in inputs:
            i=get(name)
            o=get(name.replace('_input.json','_output.json'))
            for key in ('race_id','snapshot_hash','ai_role','prompt_version','schema_version','role_quota','allocation_mode'):
                require(i[key]==o[key], 'fixture identity '+key)
            by_no={h['horse_no']:h for h in o['horses']}
            runners={r['horse_no']:r for r in i['runners']}
            require(len(by_no)==len(o['horses'])==i['N'] and by_no.keys()==runners.keys(),'all starters')
            registry=i['source_registry']
            for n,h in by_no.items():
                require(summarize_scores(h['scores']) ==
                        (h['observed_sum'],h['observed_cap'],h['total_score']), 'fixture scores')
                for ev in h['evidence']:
                    fact_refs=[fact['source_ref'] for fact in ev['facts']]
                    require(len(fact_refs)==len(set(fact_refs)) and set(fact_refs)==set(ev['source_refs']),'facts and refs')
                    individual=False
                    for fact in ev['facts']:
                        entry=registry[fact['source_ref']]
                        require(entry['race_id']==i['race_id'] and compact_equal(entry['value'],fact['value']), 'fact value')
                        scope=entry['scope']
                        applies=(n in entry['applicable_horse_nos'] if scope=='COHORT' else n in entry['horse_nos'])
                        require(scope=='RACE' or applies,'cross-horse reference')
                        individual |= applies and entry['dependency_role']=='SIGNAL' and entry['value'] is not None
                    require(individual, 'missing individual signal')
            c=[]
            for band in ('A','B','D'):
                order=o['band_ranks'][band]
                eligible={n for n,h in by_no.items() if h['eligibility']=='ELIGIBLE' and h['band']==band}
                require(len(order)==len(eligible) and set(order)==eligible, 'lost horse in band')
                backup=o['evidence_band_ranks'][band]
                require(len(backup)==len(eligible) and set(backup)==eligible, 'lost horse in backup')
                if i['selection_enabled']:
                    c.extend(order[:i['role_quota'][band]])
            require(o['public_candidates']==c and len(c)<=i['role_cap'],'band allocation')
            require({n for n,h in by_no.items() if h['public_candidate']}==set(c),'publication flag')
    print('PASS: original contract checked; all 14 synthetic role input/output pairs support the audited fields.')


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--compare-roundtrip',nargs=2,metavar=('FROZEN_JSON','EXPANDED_JSON'),
                        help='エンジニアが圧縮本文だけから復元したJSONを同一roleの凍結JSONと比較')
    parser.add_argument('--check-base', type=Path, help='10月19日エンジニア送付資料ZIPを指定して14組の合成事例も確認')
    args=parser.parse_args()
    if args.compare_roundtrip:
        left,right=(precise_json(Path(p)) for p in args.compare_roundtrip)
        check_roundtrip(left,right)
        print('PASS: all decoded fields and ordered references agree')
        return
    cfg=load_json(ROOT/'config/r122_contract.json')
    check_contract(cfg)
    legacy_negative_cases()
    if args.check_base:
        check_base_archive(args.check_base)
    data=load_json(FIXTURES/'market_inputs.json')
    outcomes=load_json(FIXTURES/'outcomes_for_audit_only.json')
    golden=load_json(FIXTURES/'expected.json')
    require(data['slots']==['計測前','21','12','9','6'],'slot order')
    summary=[]
    for race in data['races']:
        rows=race['runners']; n=len(rows)
        k=race['id']; cur=outcomes[k]
        require(len({h['horse'] for h in rows})==n,'duplicate horse')
        lows={h['horse'] for h in rows if h['rank']>=7}
        require(all(h['qualification']==0 for h in rows if h['rank']>=7),'old eligibility flags '+k)
        status,mode,smin,smax=allocate(market_signals(rows))
        # Chosen eight races have 11..18 runners and every base quota band is populated.
        c=7 if n>=16 else (6 if n>=14 else 5)
        quota=cfg['base_quota'][str(c)][mode] if mode else None
        if quota:
            require(all(have>=need for have,need in zip((6,min(n-6,4),max(0,n-10)),quota)), 'capacity adjustment required '+k)
        top3=set(cur['official_top3'])
        photographed=set(cur['visible_in_photos'])
        require(not photographed.intersection(lows),'photographed outsider '+k)
        record=[n,len(lows),sorted(lows&top3),len(photographed&top3),status,mode,smin,smax,quota]
        require(golden['races'][k]==record, 'race mismatch '+k)
        summary.append(record)
        print(k, 'N',n,'7人気以下',len(lows),'3着内',sorted(lows&top3),'写真にある3着以内',len(photographed&top3),status,mode,quota)
    require(len(summary)==8 and sum(r[0] for r in summary)==123 and sum(r[1] for r in summary)==75, 'weekend totals')
    require(sum(len(r[2]) for r in summary)==11 and sum(r[3] for r in summary)==12, 'observed results')
    require(sum(len(o['visible_in_photos']) for o in outcomes.values())==43,'visible cards')
    ky=next(r for r in data['races'] if r['id']=='2026-11-01_京都6R')
    hs={h['horse']:h for h in ky['runners']}
    for no,shown,correct in [(5,27,5),(2,22,20),(8,24,20)]:
        is_low,high,forced_zero,ceiling=old_score(hs[no])
        require(ceiling==correct and shown>ceiling and forced_zero,'old score '+str(no))
    require(old_score(hs[5])[:2]==(True,0) and 51+5==56,'low payout cap')
    require(not price_flag('1.43','4.7') and price_flag('1.28','2.0'),'both conditions')
    require(price_flag('1.5','2') is False and price_flag('1.49','3') is False and price_flag(None,'2') is None,'price boundary')
    edge=dict(hs[5],returns=[['110',30],['110',29],['90',30]])
    require(old_score(edge)[1:3]==(1,False),'inclusive thresholds N=30,rate=110; strictly below 90')
    require(old_score(dict(hs[5],returns=[['0',0],['0',35],['0',30]]))[2],'zero with samples')
    for no,sign in [(13,'RISING'),(9,'SHORTENING')]:
        row=hs[no]
        require(all(direction(row[f][3],row[f][4])==sign for f in ['win','place_min']), 'odds sign')
    require(not accelerated('8.6','9.6','12') and accelerated('1.9','1.8','1.5') and not accelerated('2','3','2.5') and accelerated(None,'2','1') is None,'three-slot direction')
    blank={k:None for k in CAPS}
    require(summarize_scores(blank)==(0,0,None),'missing all')
    require(summarize_scores(dict(blank,H3=0))==(0,12,None),'true zero')
    require(summarize_scores(CAPS)==(100,100,100),'complete')
    for bad in [dict(CAPS,V5=5),dict(CAPS,H1=True)]:
        try: summarize_scores(bad)
        except ValueError: pass
        else: raise ValueError('accepted invalid score')
    require(allocate([None,None,None,None,None,None,None])[:2]==('UNRESOLVED',None),'unknown mode')
    require(allocate([False,True,False,False,False,None,False])[:2]==('PROVISIONAL','MIXED'),'X6 mixed')
    require(allocate([True,True,False,False,False,None,False])[:2]==('PROVISIONAL','VOLATILE'),'X6 volatile')
    require(not compact_equal({'v': True},{'v':Decimal(1)}) and not compact_equal({'v':None},{}) and not compact_equal(['a','b'],['b','a']), 'roundtrip mutations')
    print('PASS: 8 races, 123 starters; offline checks only.')


if __name__=='__main__':
    main()
