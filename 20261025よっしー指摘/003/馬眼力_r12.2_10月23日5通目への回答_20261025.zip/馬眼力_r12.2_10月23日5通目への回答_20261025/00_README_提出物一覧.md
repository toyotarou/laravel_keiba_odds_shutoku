# 馬眼力 r12.2 — 10月23日5通目（4通目回答の確認結果）への提出物

2026年10月25日（日本時間）／豊田英之（実装担当）

## まず読むもの

| ファイル | だれ向け |
|---|---|
| `馬眼力_r12.2_10月25日の提出_20261025.html` | よっしーさん（スマホで読めます） |
| `02_10月23日5通目への対応表.md` | なるさん（3〜9章への対応・試験・非公開2レースの計画） |

## 中身

```
00_README_提出物一覧.md              これ
01_版とハッシュ.txt                  前回提出・今回（本番サーバで計算）
02_10月23日5通目への対応表.md        ご指摘の章ごとの対応（なるさん向け）
馬眼力_r12.2_10月25日の提出_20261025.html   よっしーさん向け

code/                                本番サーバに置いた版そのもの
  AiController.php                   app/Http/Controllers/Api/
  SummaryAiAnalysisCompensate.php    app/Console/Commands/

diff/
  AiController.前回提出から.diff                 前回提出（sha256 1e8f0fbf…）→ 今回
  AiController.3章_予約なし精算の除外だけ.diff    3章の修正だけ（10/25 18:40 に先に上げた版）
  SummaryAiAnalysisCompensate.前回提出から.diff  前回提出（sha256 721e55e6…）→ 今回

log/                                 本番サーバでの実行記録（外部AIへの送信0回・DBはロールバック）
  n5_racelock1.txt n5_racelock2.txt  発走時刻・発走済み・正本の欠落・送信直前の時刻（15件×2回）
  n5_job1.txt n5_job2.txt            予算（B-01〜B-20）・発走時刻（S-01〜S-10）ほか（101件×2回）
  n5_e2e.txt n5_wire.txt n5_publish.txt n5_read.txt n5_queue.txt
  n5_sha256.txt                      試験のあとの本番ファイルのハッシュ
```
