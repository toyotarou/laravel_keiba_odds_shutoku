# 馬眼力 r12.2 — 10月25日夜提出ZIPの再確認結果への提出物

2026年10月25日（日本時間）／豊田英之（実装担当）

| ファイル | だれ向け |
|---|---|
| `馬眼力_r12.2_10月25日夜2回目の提出_20261025.html` | よっしーさん（スマホで読めます） |
| `02_10月25日夜の再確認結果への対応表.md` | なるさん（7章 1〜3 と、新潟1R の記録） |

```
01_版とハッシュ.txt
code/   AiController.php・SummaryAiAnalysisCompensate.php（本番に置いた版）
diff/   AiController.前回提出から.diff・SummaryAiAnalysisCompensate.前回提出から.diff
log/    n7_commit.txt（公開の実COMMIT → 待っていたUPDATEの成功・8件）
        n7_legacy.txt（旧予想の材料待ち・8件）
        n7_sha.txt（本番のハッシュ）
```
