<?php
// 20261120 なる確認への対応（読むだけ。DBは最後に必ず取り消す。AIは疎通確認の1回だけ・数文字）
require '/var/www/horse_odds_finder/vendor/autoload.php';
$app = require '/var/www/horse_odds_finder/bootstrap/app.php';
$app->make(Illuminate\Contracts\Console\Kernel::class)->bootstrap();
use App\Http\Controllers\Api\AiController;
use App\Http\Controllers\Api\BaganrikiCandidateSelection as S;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Cache;

$tables = ['baganriki_snapshots', 'baganriki_ai_attempts', 'baganriki_publications', 'baganriki_validation_results',
           'baganriki_audit_events', 'baganriki_live_states', 'baganriki_race_runs', 'baganriki_acquisition_batches'];
$count = function () use ($tables) { $o = []; foreach ($tables as $t) { $o[] = DB::table($t)->count(); } return implode(' / ', $o); };
$before = $count();

echo "=== 1. 新しいキーで、1st のAIが実際に答えるか（数文字だけ） ===\n";
$model = trim((string) env('BAGANRIKI_PREDICTION_1ST_MODEL', '')) ?: 'claude-haiku-4-5';
try {
    $r = Http::timeout(30)->withHeaders([
        'x-api-key' => (string) config('services.anthropic.api_key'),
        'anthropic-version' => '2023-06-01',
        'content-type' => 'application/json',
    ])->post('https://api.anthropic.com/v1/messages', [
        'model' => $model, 'max_tokens' => 5,
        'messages' => [['role' => 'user', 'content' => '「はい」とだけ答えてください']],
    ]);
    $j = $r->json();
    echo '  送ったモデル : ' . $model . "\n";
    echo '  結果         : HTTP ' . $r->status() . "\n";
    if ($r->successful()) {
        echo '  答えたモデル : ' . ($j['model'] ?? '-') . "\n";
        echo '  答え         : ' . ($j['content'][0]['text'] ?? '-') . "\n";
        echo '  使った量     : 入力 ' . ($j['usage']['input_tokens'] ?? '-') . ' ／ 出力 ' . ($j['usage']['output_tokens'] ?? '-') . " トークン\n";
    } else {
        echo '  エラー       : ' . ($j['error']['type'] ?? '-') . ' ' . mb_substr((string) ($j['error']['message'] ?? ''), 0, 200) . "\n";
    }
} catch (\Throwable $e) {
    echo '  例外 : ' . mb_substr($e->getMessage(), 0, 200) . "\n";
}

echo "\n=== 2. 保存済みのAIの答えから、最終候補と画面の答えを今のプログラムで作り直す（11/14・15） ===\n";
$c = app(AiController::class);
$ppa = new ReflectionMethod(AiController::class, 'predictionPublishedAnswer');
$ppa->setAccessible(true);
$t = ['pub' => 0, 'cand_same' => 0, 'cand_diff' => [], 'ans_cached' => 0, 'ans_same' => 0, 'ans_diff' => [],
      'ans_cand_same' => 0, 'ans_cand_diff' => [], 'err' => []];
DB::beginTransaction();
try {
    foreach (['2026-11-14', '2026-11-15'] as $d) {
        foreach (DB::table('t_horse_odds_finder_races')->where('date', $d)->orderBy('basho')->orderBy('race')
                   ->get(['date', 'kaisuu', 'basho', 'day', 'race']) as $race) {
            $rid = AiController::buildPredictionRaceId($race->date, $race->kaisuu, $race->basho, $race->day, (int) $race->race);
            $snap = DB::table('baganriki_snapshots')->where('race_id', $rid)->where('generation', 0)->first();
            if ($snap === null) { continue; }
            $pub = DB::table('baganriki_publications')->where('snapshot_id', $snap->id)
                     ->orderByDesc('published_at')->orderByDesc('id')->first();
            if ($pub === null) { continue; }
            $t['pub']++;
            $name = substr($rid, 9);
            fwrite(STDERR, "\r\033[K  … {$rid}");
            $live = DB::table('baganriki_live_states')->where('snapshot_id', $snap->id)->first();
            $cancel = array_map('intval', (array) json_decode((string) ($live->cancellations ?? '[]'), true));
            $stored = array_column((array) json_decode((string) $pub->candidates, true), 'horse_no');
            // (a) 最終候補
            try {
                $active = array_values(array_diff(array_map('intval', (array) json_decode((string) $snap->frozen_nums, true)), $cancel));
                sort($active);
                $read = function ($role) use ($c, $snap) {
                    $a = $c->acceptedHorsesOf((int) $snap->id, $role);
                    $rk = (($a['ok'] ?? false) && ($a['complete'] ?? false) === true) ? $c->markResponseUsed((int) $snap->id, $role, $a) : null;
                    return [$a, $rk];
                };
                $o = S::submittedPublication($snap, $active, $read);
                $now = array_column((array) ($o['candidates'] ?? []), 'horse_no');
                if ($now === $stored) { $t['cand_same']++; } else { $t['cand_diff'][] = $name . ' 保存[' . implode(',', $stored) . ']→今[' . implode(',', $now) . ']'; }
            } catch (\Throwable $e) { $t['err'][] = $name . ' 候補:' . mb_substr($e->getMessage(), 0, 80); }
            // (b) 画面の答え
            try {
                $ans = $ppa->invoke($c, $snap, $pub, $cancel, $race->date, $race->kaisuu, $race->basho, $race->day, $race->race);
                $key = 'prediction_answer:v8:' . (int) $snap->id . ':' . $pub->publication_id . ':' . (int) ($live->state_revision ?? 0);
                $old = Cache::get($key);
                if ($old !== null) {
                    $t['ans_cached']++;
                    if (json_encode($old) === json_encode($ans)) { $t['ans_same']++; }
                    else {
                        $dk = [];
                        foreach (array_unique(array_merge(array_keys((array) $old), array_keys((array) $ans))) as $k) {
                            if (json_encode($old[$k] ?? null) !== json_encode($ans[$k] ?? null)) { $dk[] = $k; }
                        }
                        $t['ans_diff'][] = $name . '（違う項目：' . implode(',', $dk) . '）';
                    }
                }
                $enc = json_encode($ans, JSON_UNESCAPED_UNICODE);
                $miss = [];
                foreach ($stored as $h) { if (!preg_match('/"(horse_no|num|umaban)"\s*:\s*"?' . (int) $h . '"?[,}]/', $enc)) { $miss[] = $h; } }
                if ($miss === []) { $t['ans_cand_same']++; } else { $t['ans_cand_diff'][] = $name . ' 画面に無い馬番[' . implode(',', $miss) . ']'; }
            } catch (\Throwable $e) { $t['err'][] = $name . ' 画面:' . mb_substr($e->getMessage(), 0, 80); }
        }
    }
} finally {
    DB::rollBack();
}
fwrite(STDERR, "\r\033[K");
echo "  公開されたレース                         : {$t['pub']}\n";
echo "  最終候補が、保存済みの公開と同じ         : {$t['cand_same']}\n";
foreach ($t['cand_diff'] as $l) { echo "    × {$l}\n"; }
echo "  画面の答えに、公開した馬が全部入っている : {$t['ans_cand_same']}\n";
foreach ($t['ans_cand_diff'] as $l) { echo "    × {$l}\n"; }
echo "  分ける前に作って残っていた画面の答え     : {$t['ans_cached']} レース分 → 今作り直したものと完全に同じ {$t['ans_same']}\n";
foreach ($t['ans_diff'] as $l) { echo "    △ {$l}\n"; }
foreach ($t['err'] as $l) { echo "  ★うまくいかなかった {$l}\n"; }

$after = $count();
echo "\n=== 3. DBの件数（前と後が同じなら、何も残っていない） ===\n";
echo '  表 : ' . implode(' / ', array_map(fn($x) => str_replace('baganriki_', '', $x), $tables)) . "\n";
echo "  前 : {$before}\n";
echo "  後 : {$after}\n";
echo '  ' . ($before === $after ? '同じ（何も残っていません）' : '★違います') . "\n";
