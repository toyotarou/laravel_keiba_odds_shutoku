-- baganriki_snapshots --
CREATE TABLE `baganriki_snapshots` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `race_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `generation` int NOT NULL DEFAULT '0',
  `run_id` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `release_version` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `common_json` longtext COLLATE utf8mb4_unicode_ci COMMENT '両roleへ渡す共通JSONの原文',
  `input_json_1st` longtext COLLATE utf8mb4_unicode_ci,
  `input_json_2nd` longtext COLLATE utf8mb4_unicode_ci,
  `snapshot_hash` char(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '共通JSON本文のSHA-256',
  `frozen_nums` text COLLATE utf8mb4_unicode_ci COMMENT '凍結出走集合の馬番',
  `frozen_rank` text COLLATE utf8mb4_unicode_ci COMMENT '馬番=>凍結順位',
  `mode` varchar(16) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `mode_status` varchar(16) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `allocation_mode` varchar(16) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `mode_policy_id` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `display_rating` int DEFAULT NULL,
  `signals` text COLLATE utf8mb4_unicode_ci,
  `s_min` int DEFAULT NULL,
  `s_max` int DEFAULT NULL,
  `s0` int DEFAULT NULL,
  `target_count` int DEFAULT NULL,
  `quota_1st` text COLLATE utf8mb4_unicode_ci,
  `quota_2nd` text COLLATE utf8mb4_unicode_ci,
  `quota_adjustments` text COLLATE utf8mb4_unicode_ci,
  `collection_audit` longtext COLLATE utf8mb4_unicode_ci,
  `coverage` longtext COLLATE utf8mb4_unicode_ci,
  `anchor_at` datetime(6) DEFAULT NULL COMMENT '正本の発走時刻',
  `cutoff_at` datetime(6) DEFAULT NULL,
  `input_freeze_at` datetime(6) DEFAULT NULL,
  `frozen_at` datetime(6) DEFAULT NULL COMMENT '実際に保存した時刻。input_freeze_atとは別',
  `sales_close_at` datetime(6) DEFAULT NULL COMMENT '投票締切の正本。無ければ公開しない',
  `input_invalid_code` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `input_invalid_reason` text COLLATE utf8mb4_unicode_ci,
  `created_at` datetime(6) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_snap` (`race_id`,`generation`)
) ENGINE=InnoDB AUTO_INCREMENT=1993 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='r12.2 凍結入力。固定後は変えない';
-- baganriki_ai_attempts --
CREATE TABLE `baganriki_ai_attempts` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `snapshot_id` bigint unsigned NOT NULL,
  `role` varchar(8) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '1st / 2nd',
  `attempt_no` tinyint NOT NULL COMMENT '初回0・訂正1のみ',
  `token` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '内部専用。公開APIへ出さない',
  `status` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'RESERVED' COMMENT 'RESERVED/RECEIVED/FAILED',
  `reserved_at` datetime(6) DEFAULT NULL,
  `received_at` datetime(6) DEFAULT NULL,
  `complete` tinyint(1) NOT NULL DEFAULT '0',
  `raw_response` longtext COLLATE utf8mb4_unicode_ci COMMENT '原文のまま',
  `response_hash` char(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `failure_reason` text COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_attempt` (`snapshot_id`,`role`,`attempt_no`),
  UNIQUE KEY `uq_token` (`token`)
) ENGINE=InnoDB AUTO_INCREMENT=2702 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='r12.2 AI呼出枠。予約してから1回だけ送る';
-- baganriki_live_states --
CREATE TABLE `baganriki_live_states` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `snapshot_id` bigint unsigned NOT NULL,
  `cancellations` text COLLATE utf8mb4_unicode_ci COMMENT '累積の取消馬番。追加のみ',
  `active_count` int DEFAULT NULL COMMENT '集合矛盾時はNULL',
  `live_target_count` int DEFAULT NULL,
  `live_quota` text COLLATE utf8mb4_unicode_ci,
  `live_close` datetime(6) DEFAULT NULL COMMENT '締切の前倒し。延長はしない',
  `state_revision` bigint NOT NULL DEFAULT '0',
  `response_revision` bigint NOT NULL DEFAULT '0',
  `publication_revision` bigint NOT NULL DEFAULT '0',
  `latest_publication_id` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `updated_at` datetime(6) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_live` (`snapshot_id`)
) ENGINE=InnoDB AUTO_INCREMENT=849 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='r12.2 ライブ状態。競合の共通ロック行';
-- baganriki_audit_events --
CREATE TABLE `baganriki_audit_events` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `race_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `snapshot_id` bigint unsigned DEFAULT NULL,
  `kind` varchar(48) COLLATE utf8mb4_unicode_ci NOT NULL,
  `happened_at` datetime(6) NOT NULL,
  `old_revision` bigint DEFAULT NULL,
  `new_revision` bigint DEFAULT NULL,
  `diagnostics` longtext COLLATE utf8mb4_unicode_ci,
  `related_id` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `ix_race_time` (`race_id`,`happened_at`)
) ENGINE=InnoDB AUTO_INCREMENT=1658 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='r12.2 監査イベント';
-- baganriki_validation_results --
CREATE TABLE `baganriki_validation_results` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `attempt_id` bigint unsigned NOT NULL,
  `validator_version` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `normal_part` longtext COLLATE utf8mb4_unicode_ci,
  `diagnostics` longtext COLLATE utf8mb4_unicode_ci,
  `repair_scope` text COLLATE utf8mb4_unicode_ci,
  `field_sources` longtext COLLATE utf8mb4_unicode_ci,
  `rank_sources` longtext COLLATE utf8mb4_unicode_ci,
  `created_at` datetime(6) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_val` (`attempt_id`,`validator_version`)
) ENGINE=InnoDB AUTO_INCREMENT=3053 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='r12.2 応答の検証結果と局所回復';
-- baganriki_publications --
CREATE TABLE `baganriki_publications` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `publication_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `snapshot_id` bigint unsigned NOT NULL,
  `intent_id` bigint unsigned NOT NULL,
  `published_at` datetime(6) NOT NULL,
  `prediction_target_count` int DEFAULT NULL,
  `prediction_quota` text COLLATE utf8mb4_unicode_ci,
  `publication_target_count` int DEFAULT NULL,
  `publication_quota` text COLLATE utf8mb4_unicode_ci,
  `active_count` int DEFAULT NULL,
  `candidates` longtext COLLATE utf8mb4_unicode_ci,
  `evidence` longtext COLLATE utf8mb4_unicode_ci,
  `shortfalls` text COLLATE utf8mb4_unicode_ci,
  `used_state_revision` bigint DEFAULT NULL,
  `used_response_revision` bigint DEFAULT NULL,
  `public_proof_hash` text COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_pub_intent` (`intent_id`),
  KEY `ix_pub` (`publication_id`),
  KEY `ix_snap` (`snapshot_id`,`published_at`)
) ENGINE=InnoDB AUTO_INCREMENT=316 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='r12.2 公開履歴。追記型';
-- baganriki_publication_intents --
CREATE TABLE `baganriki_publication_intents` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `snapshot_id` bigint unsigned NOT NULL,
  `job_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `intent_hash` char(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `read_state_revision` bigint DEFAULT NULL,
  `read_response_revision` bigint DEFAULT NULL,
  `read_publication_revision` bigint DEFAULT NULL,
  `state` varchar(24) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'OPEN' COMMENT 'OPEN/PUBLISHED/STALE_INTENT',
  `publication_id` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` datetime(6) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_job` (`job_id`),
  UNIQUE KEY `uq_intent` (`snapshot_id`,`intent_hash`)
) ENGINE=InnoDB AUTO_INCREMENT=316 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='r12.2 公開intent。同じintentの再実行は同じ公開ID';
-- baganriki_race_runs --
CREATE TABLE `baganriki_race_runs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `run_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '処理の一意ID',
  `race_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `generation` int NOT NULL DEFAULT '0' COMMENT '固定入力の世代。期限延長のために増やさない',
  `run_kind` enum('PRODUCTION','REPLAY') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'PRODUCTION',
  `status` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'STARTED',
  `entry_count` int DEFAULT NULL,
  `acquired_count` int DEFAULT NULL,
  `frozen_count` int DEFAULT NULL,
  `active_count` int DEFAULT NULL,
  `invalid_code` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `invalid_reason` text COLLATE utf8mb4_unicode_ci,
  `release_version` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_run` (`run_id`),
  KEY `ix_race` (`race_id`,`run_kind`)
) ENGINE=InnoDB AUTO_INCREMENT=63 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='r12.2 レース単位の処理記録。snapshotを作れない入力不正でも残す';
-- baganriki_acquisition_batches --
CREATE TABLE `baganriki_acquisition_batches` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `race_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `slot` int NOT NULL COMMENT '21/18/15/12/9/6。3と0は取消監視のみ',
  `batch_id` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '同一応答バッチの一意ID',
  `slot_scheduled_at` datetime(6) DEFAULT NULL COMMENT '発走時刻からslot分を引いた予定時刻',
  `source_updated_at` datetime(6) DEFAULT NULL COMMENT '取得元の更新時刻。取れなければNULL',
  `request_started_at` datetime(6) DEFAULT NULL COMMENT '要求を開始した実サーバ時刻',
  `response_received_at` datetime(6) DEFAULT NULL COMMENT '受信し終えた実サーバ時刻（=observed_at）',
  `available_at` datetime(6) DEFAULT NULL COMMENT 'commit後に読めると確認した実時刻。予定で埋めない',
  `raw_payload` longtext COLLATE utf8mb4_unicode_ci COMMENT '原値のまま',
  `payload_hash` char(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '原ペイロードのSHA-256',
  `validation_result` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'ADOPTED / REJECTED',
  `rejection_reason` text COLLATE utf8mb4_unicode_ci,
  `committed` tinyint(1) NOT NULL DEFAULT '0' COMMENT '未確定の監査行は採用しない',
  `created_at` datetime(6) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_batch` (`batch_id`),
  KEY `ix_race_slot` (`race_id`,`slot`,`available_at`)
) ENGINE=InnoDB AUTO_INCREMENT=339 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='r12.2 取得監査。実時刻はここへ';
