# 馬眼力 r12.2 — 10月25日提出ZIPの確認結果への提出物

2026年10月25日（日本時間）／豊田英之（実装担当）

## まず読むもの

| ファイル | だれ向け |
|---|---|
| `馬眼力_r12.2_10月25日夜の提出_20261025.html` | よっしーさん（スマホで読めます） |
| `02_10月25日確認結果への対応表.md` | なるさん（8章 A〜D への対応と、旧来の予想の不具合の報告） |

## 中身

```
00_README_提出物一覧.md              これ
01_版とハッシュ.txt                  前回・途中・今回のハッシュと試験の対応
02_10月25日確認結果への対応表.md     なるさん向け
馬眼力_r12.2_10月25日夜の提出_20261025.html   よっしーさん向け

code/   AiController.php・SummaryAiAnalysisCompensate.php（本番に置いた版）
diff/   AiController.前回提出から.diff・SummaryAiAnalysisCompensate.前回提出から.diff
log/    n6_publish.txt（公開本体の競合 G-01〜G-05・85件）
        n6_budget.txt（予算の行・今日の集計・R122_USAGE の読取）
        n6_sha.txt（本番のハッシュ）
```
