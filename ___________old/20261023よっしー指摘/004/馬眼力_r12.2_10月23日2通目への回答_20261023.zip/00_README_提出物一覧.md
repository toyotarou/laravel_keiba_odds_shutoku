# 馬眼力 r12.2 — 10月23日提出物の確認結果（2通目）への提出

2026年10月23日（日本時間）／豊田英之（実装担当）

## まず読むもの

| ファイル | だれ向け |
|---|---|
| `馬眼力_r12.2_10月23日2通目への回答_20261023.html` | よっしーさん（スマホで読めます） |
| `02_10月23日2通目への対応表.md` | なるさん（3章〜8章と補足への対応） |

## 中身

```
00_README_提出物一覧.md           これ
01_版とハッシュ.txt               基準（前回提出）と今回のハッシュ・指示文のハッシュ・試験の件数
02_10月23日2通目への対応表.md     ご指摘の章ごとの対応（なるさん向け）
馬眼力_r12.2_10月23日2通目への回答_20261023.html   よっしーさん向け

code/        本番サーバに置いた版そのもの（今回変えた3本）
  AiController.php                 app/Http/Controllers/Api/
  SummaryAiAnalysisCompensate.php  app/Console/Commands/
  RepairKeibaStartTime.php         app/Console/Commands/（発走時刻の更新から新しい予想へ知らせる数行）

diff/        前回提出（10月23日 19:16）からの差分
  AiController.前回提出から.diff
  SummaryAiAnalysisCompensate.前回提出から.diff
  RepairKeibaStartTime.diff

log/         本番サーバでの実行記録（AIは呼んでいません。DBへの書き込みは全部ロールバック）
  response wire type read publish e2e queue acq onebuild job rawodds worker .txt
  compact.txt                       出典一覧の圧縮：元へ戻せること・トークン数
  reprocess_1st_*.json／.txt        18頭の保存原応答を最新版で再処理した結果（馬別）
  fixpolicy_compare_*.json／.txt    訂正方針 V1／V2 の診断別比較
  sha256.txt・sha256_command_final.txt   本番のファイルのハッシュ
```

## 試験の番号（今回追加）

| 記号 | 何を見ているか | ご指摘のどこ |
|---|---|---|
| S-01〜S-10 | 発走時刻の前倒し（オッズ取得なし・実状態へ書く前・repairStartTime の入口・延長しない） | 3章 |
| B-01〜B-08 | 送信前の予算制御 | 6章 |
