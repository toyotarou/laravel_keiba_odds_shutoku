# 馬眼力 r12.2 — 10月23日確認結果への提出物

2026年10月23日（日本時間）／豊田英之（実装担当）

## まず読むもの

| ファイル | だれ向け |
|---|---|
| `馬眼力_r12.2_10月23日の提出_20261023.html` | よっしーさん（スマホで読めます） |
| `02_10月23日ご指摘への対応表.md` | なるさん（3章〜7章への対応・試験・費用・2レースの計画） |

## 中身

```
00_README_提出物一覧.md              これ
01_版とハッシュ.txt                  基準hash・変更後hash（本番サーバで計算）
02_10月23日ご指摘への対応表.md       ご指摘の章ごとの対応（なるさん向け）
03_名称対応表.tsv                    名称の対応（識別子134件＋Jobクラス5件＋選択肢39件＋ImportKeibaOdds 4件＋常駐1件）
馬眼力_r12.2_10月23日の提出_20261023.html   よっしーさん向け

code/                                本番サーバに置いた版そのもの
  AiController.php                   app/Http/Controllers/Api/
  SummaryAiAnalysisCompensate.php    app/Console/Commands/
  ImportKeibaOdds.php                app/Console/Commands/（取消・締切の連携、記録の名前の直し）
  Jobs/Prediction*.php               app/Jobs/（5本）
  routes/api.php                     routes/
  systemd/                           常駐の中身と枠（root で置いたもの）

diff/
  AiController.010改名済みから.diff          010提出版を名称対応表で機械的に改名したもの → 今回（中身の変更だけが見えます）
  AiController.010提出版から.diff            010提出版 → 今回（改名も含む）
  AiController.011再精査10版から.diff        011再精査10版 → 今回（統合の照合用）
  SummaryAiAnalysisCompensate.010改名済みから.diff
  SummaryAiAnalysisCompensate.010提出版から.diff
  Jobs.010改名済みから.diff
  ImportKeibaOdds.diff

log/                                 本番サーバでの実行記録（AIは呼んでいません。DBへの書き込みは全部ロールバック）
  response.txt wire.txt type.txt read.txt publish.txt e2e.txt
  queue.txt acq.txt onebuild.txt job.txt rawodds.txt worker.txt
  rawodds_1回目_修正前.txt            139項目の1回目（135／139）。直す前の記録として分けて残します
  systemd.txt                        常駐の中身と枠
  md5.txt                            本番のファイルのハッシュ
  18頭_1st_*.txt / .json             10月23日 実測5回目の入力と原応答（3章の馬別診断の元）
```

## 試験の番号

| 記号 | 何を見ているか | ご指摘のどこ |
|---|---|---|
| L-01〜L-11、J-46b | 取得から実状態へ（取消・締切の前倒し・いまの頭数） | 5章B |
| C-01〜C-12 | 公開commit直前の取消・締切・版の競合 | 5章D |
| 011 audit10 の139項目 | 原オッズの読込（統合後の実装と本番MySQL） | 5章A |
| W-S1〜W-S8 | 実workerの受入（145秒の1stを含む） | 5章C |
