馬眼力 r11 組込用実装パッケージ

r10を再監査し、非選出理由の型、時刻精度、数値の往復、派生CONTEXTの扱いを修正しました。
今回再現した不具合は修正済みです。実DB・実AI・本番キュー・既存画面の接続は未検証です。
実行版r11、AI向け本文・Schema・marker・hash方式はr8契約を保持。markerをr11へ改名しないでください。

修正内容
・壊れた非選出理由で処理全体を止めず、表示欄の訂正へ限定。正常な穴根拠・順位を保持。
・秒以下7桁以上の時刻を切り捨てて受理しない。日時の対応形式と精度をPython/PHPで統一。
・入力の作成・保存でもJSON読込と同じ数値上限を適用。値を変換・丸め・削除して通さない。
・派生CONTEXTだけを個別馬の支持信号や既知採点にしない。別に正常な個別SIGNALがあれば残す。
・r10の同時保存、取消、締切、永続ワーカーの修正も保持。

実行
  python3 -m venv .venv
  .venv/bin/python -m pip install -r requirements-test.lock.txt
  .venv/bin/python verify.py
  .venv/bin/python cli.py < demo_replay_request.json
最後は架空データの再生で、保存・実AI呼出しを伴いません。
PHPはINSTALL.txtに従い、同梱6本を導入先の実PHPでも実行してください。
Python3.10以上、PHP8.0以上、proc_open、同一ホストの共有永続SQLiteが必要です。

同梱物
prompt_1st.txt / prompt_2nd.txt：AIへ渡すsystem本文。
engine.py / reference.py / adapter.py：入力・出典・採点・順位・穴枠・訂正・統合・取消。
journal.py / store.py：永続呼出枠、原応答、競合検査、公開履歴。
php/BaganrikiR11Bridge.php / RoleWorker.php / Timestamp.php：PHP接続・永続ワーカー・厳密な日時。
php/PublicView.php：現在の取消状態と正式予想の履歴を表示するDTO。
php/LaravelIntegration.example.php：独立roleジョブと固定公開intentの接続例。
INSTALL.txt / server_contract.txt：導入手順と実装契約。r11追加条件まで確認。
verify.py：189単体試験、異常応答304条件、標準Schemaの一括検証。
php_bridge_results.json：PHP-WASM8.5.10、模擬AI、Python、SQLiteによる6系列の結果。
IMPLEMENTATION_REPORT.txt：今回の修正と確認範囲。
runtime_contract.template.json：本番受入記録。ローカル合格だけでtrueに変えない。
SHA256SUMS.txt：配布内容の照合。audit/：修正前の失敗再現・差分・試験記録。

保持した仕様
確認済み個別根拠1系統で候補資格を維持。人気薄や低配当という理由だけの一律削除をしません。
C7混戦A/B/D=4/2/1、波乱=3/3/1。C6混戦・波乱=3/2/1。評価後の穴枠不足をAへ渡しません。
1st/2ndは独立、各roleは初回＋必要時の訂正1回。予約を永続保存してからAIを呼びます。
SDKの自動リトライは0。結果不明の予約を期限切れで再送せず、保存済み応答で縮退します。
全キューで同一ホストの同一永続DBを共有し、進行中のレースと旧履歴を保持します。
COLLECT_ONLY、未検証X6はUNKNOWN、購入推奨はfalseを維持。
試験合格は本番反映、予測精度改善、将来の全入力での不具合ゼロを保証するものではありません。
