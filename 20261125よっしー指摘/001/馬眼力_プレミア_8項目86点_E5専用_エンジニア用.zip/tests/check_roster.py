"""Offline cross-field fixtures for the premium E5 role reply, before merging both roles.

Usage: python r3_roster.py path/to/output_schema.json  (or path/to/engineering.zip)
Requires Python 3.10+ and jsonschema. The frozen fields and evidence placeholders in
these fixtures are synthetic. This checks roster, ranks and publication, not evidence
authenticity, E5 packet creation/provenance/calibration, post-cancellation merging or
live PHP. E5 rows here are projections of already validated frozen rows. Scores and
their declared totals are compared for every horse, including non-candidates.
"""
import argparse
from collections import Counter
from copy import deepcopy
from decimal import Decimal
from hashlib import sha256
import json
from pathlib import Path
from zipfile import ZipFile

from jsonschema import Draft202012Validator

BANDS = ('A', 'B', 'D')
CAPS = dict(H1=18, H2=15, H3=12, H4=9, H5=6, V1=12, V2=10, V5=4)
FAMILIES = ('ability', 'gap', 'win_place', 'market', 'similar_value')
BIBS = [18, 4, 15, 2, 7, 11, 6, 13, 1, 9, 14, 5, 12, 8, 17, 10, 16, 3]
# In the submitted allocation contract these correspond to MIXED 8, VOLATILE 12, MIXED 18.
QUOTAS = {8: ('MIXED', (2, 2, 0)), 12: ('VOLATILE', (2, 2, 1)), 18: ('MIXED', (3, 3, 1))}


def make_horse(no, band, index, is_partial, eligible):
    ref = f'h{no}_ability'
    group = f'h{no}_history'
    evidence = [dict(evidence_id=ref, family='ability', dependency_group=group,
                     source_refs=[ref], facts=[dict(source_ref=ref, value=18-index)],
                     observation='同条件の成績', interpretation='能力資料あり')] if eligible else []
    family = {k: dict(status='NO_SUPPORT', source_refs=[f'h{no}_{k}'],
                      evidence_ids=[], reason='資料を確認') for k in FAMILIES}
    if eligible:
        family['ability'].update(status='SUPPORTED', evidence_ids=[ref])
    scores = dict.fromkeys(CAPS, 0)
    scores['H1'] = 18-index if eligible else 0
    if is_partial:
        scores['V5'] = None
    known = sum(v for v in scores.values() if v is not None)
    return dict(horse_no=no, band=band, tier='B' if eligible else 'C',
                eligibility='ELIGIBLE' if eligible else 'NO_EVIDENCE', family_review=family,
                evidence=evidence, counterevidence=[], scores=scores, score_evidence={
                    k: dict(source_refs=[f'h{no}_{k}'] if v is not None else [],
                            reason='資料を確認' if v is not None else '資料不足') for k, v in scores.items()},
                score_status='partial' if is_partial else 'complete', total_score=None if is_partial else known,
                observed_sum=known, observed_cap=82 if is_partial else 86,
                rank_basis='NOT_RANKED', rank_reason='順位を照合',
                evidence_rank_evidence_ids=[ref] if eligible else [], evidence_rank_reason='根拠を照合',
                public_candidate=False, nonselect_reason=None, explanation='当該馬の資料を照合')


def add_independent_support(horse):
    """Two independent synthetic inputs: own ability history and a separate cohort sample."""
    no = horse['horse_no']
    ref_rate = f'h{no}_cohort_similar_top5_rate'
    ref_count = f'h{no}_cohort_similar_sample_count'
    evidence_id = f'h{no}_cohort_top5'
    refs = [ref_rate, ref_count]
    horse['evidence'].append(dict(
        evidence_id=evidence_id, family='similar_value', dependency_group=f'cohort_without_h{no}',
        source_refs=refs, facts=[dict(source_ref=ref_rate, value=42), dict(source_ref=ref_count, value=100)],
        observation='独立した類似条件で100頭中42頭が5着内', interpretation='類似条件の入着率が支持'))
    horse['family_review']['similar_value'].update(
        status='SUPPORTED', source_refs=refs, evidence_ids=[evidence_id], reason='比較可能な別集団の実測')
    horse['evidence_rank_evidence_ids'].append(evidence_id)
    horse['tier'] = 'A'
    # Keep the known score ordering and its H/V tiebreaks unchanged in this fixture.
    horse['scores']['H1'] -= 1
    horse['scores']['H4'] = 1
    horse['score_evidence']['H4'] = dict(source_refs=refs, reason='類似条件100頭の実測入着率')


def fixture(schema, n, role, partial, stopped, shortage, provisional=False, boundary_case=None):
    if provisional and stopped:
        raise ValueError("a stopped fixture cannot be provisional")
    mode, quotas = QUOTAS[n]
    quota = dict(zip(BANDS, quotas)); rq = quota.copy()
    if role == '2nd' and sum(quotas) > 5:
        rq['A'] = 5-rq['B']-rq['D']
    frozen = dict(roster={}, race_id=f'qa_R3_{n}', role=role,
                  selection=not stopped, quotas=rq if not stopped else None, e5_rows={})
    constants = schema['properties']
    header = dict(schema_version=constants['schema_version']['const'], prompt_version=constants['prompt_version']['const'],
                  race_id=frozen['race_id'], selection_enabled=not stopped,
                  mode='UNKNOWN' if (stopped or provisional) else mode,
                  mode_status='UNRESOLVED' if stopped else ('PROVISIONAL' if provisional else 'CONFIRMED'),
                  allocation_mode=None if stopped else mode,
                  mode_policy_id='X6_ONLY_UPPER_MODE_V1' if provisional else 'BASE_TRI_STATE_V1',
                  target_count=sum(quotas), quota=None if stopped else quota,
                  learning_stage='COLLECT_ONLY')
    rows = []
    groups = {b: [] for b in BANDS}
    for i, bib in enumerate(BIBS[:n]):
        band = 'A' if i < 6 else 'B' if i < 10 else 'D'
        frozen['roster'][bib] = band
        eligible = not (shortage and band == 'B' and i != 6)
        if eligible:
            groups[band].append(bib)
        rows.append(make_horse(bib, band, i, partial and i in (1, 6, 10), eligible))
        frozen['e5_rows'][bib] = dict(status='COMPARISON_READY', basis='RAW_UNCALIBRATED',
                                      E5=Decimal(50+i), p5_raw=Decimal(50+i)/100, p0_5=Decimal('0.30'))
    baseline = {b: (ids[::-1] if partial else ids.copy()) for b, ids in groups.items()}
    backups = {b: ids[::-1] for b, ids in groups.items()}
    if boundary_case:
        band, offset, tier_difference, status = boundary_case
        if stopped or not rq[band] or rq[band] >= len(baseline[band]):
            raise ValueError('fixture must have two adjacent boundary horses')
        pair = baseline[band][rq[band]-1:rq[band]+1]
        if tier_difference:
            add_independent_support(next(h for h in rows if h['horse_no']==pair[offset]))
        if status:
            # Projected status/values after preflight: LOW_SUPPORT has valid numbers,
            # UNAVAILABLE_INPUT has no numbers. Neither may participate in a swap.
            bib = pair[1-offset]
            frozen['e5_rows'][bib]['status'] = status
            if status == 'UNAVAILABLE_INPUT':
                frozen['e5_rows'][bib].update(basis='UNAVAILABLE', E5=None, p5_raw=None, p0_5=None)
    # Compute an actual digest of this synthetic freeze token. Production supplies its
    # own authoritative snapshot_hash; this is not a recreation of its serializer.
    # Both roles share the same common snapshot; role, role quota and cap are separate.
    freeze_token = dict(header=header, runners=list(frozen['roster'].items()), partial=partial, shortage=shortage,
                        e5_rows=frozen['e5_rows'], support_case=boundary_case)
    frozen['snapshot_hash'] = sha256(json.dumps(freeze_token, sort_keys=True, default=str).encode()).hexdigest()
    frozen['header'] = dict(header, snapshot_hash=frozen['snapshot_hash'], ai_role=role,
                            role_cap=0 if stopped else sum(rq.values()), role_quota=frozen['quotas'])
    # Explicit golden behavior for these fixtures: increasing rates with rank on score
    # fixtures, decreasing rates with rank on their reversed evidence fixtures.
    picks, reviews, published, shortfalls = deepcopy(baseline), {}, [], []
    for b in BANDS:
        order = baseline[b]; q = rq[b] if not stopped else 0
        inc = cha = None
        if stopped:
            decision = 'SELECTION_DISABLED'
        elif q == 0 or q >= len(order):
            decision = 'NO_BOUNDARY'
        else:
            inc, cha = order[q-1:q+1]
            decision = 'KEEP' if partial else 'SWAP'
            if boundary_case and b == boundary_case[0]:
                _, _, tier_difference, status = boundary_case
                if tier_difference:
                    decision = 'TIER_MISMATCH'
                elif status:
                    decision = 'E_UNAVAILABLE'
            if decision == 'SWAP':
                picks[b][q-1:q+1] = [cha, inc]
        reviews[b] = dict(incumbent=inc, challenger=cha, decision=decision)
        published.extend(picks[b][:q])
        if q > len(order):
            shortfalls.append(dict(band=b, requested=q, eligible=len(order), missing=q-len(order), reason='適格馬不足'))
    for h in rows:
        if h['eligibility'] == 'ELIGIBLE':
            h['rank_basis'] = 'EVIDENCE' if partial else 'SCORE'
        on = h['horse_no'] in published
        h['public_candidate'] = on
        code = 'SELECTION_DISABLED' if stopped else 'BAND_QUOTA' if h['eligibility'] == 'ELIGIBLE' else 'NO_EVIDENCE'
        h['nonselect_reason'] = None if on else dict(code=code, reason='選出条件を照合')
    result = dict(deepcopy(frozen['header']),
                  horses=rows[::2]+rows[1::2], band_ranks=baseline, evidence_band_ranks=backups,
                  selection_ranks=picks, expected_reviews=reviews, public_candidates=published,
                  shortfalls=shortfalls, validation_issues=[
                      dict(code='QA_RACE', severity='INFO', horse_no=None, field=None, reason='レース全体の確認'),
                      dict(code='QA_RUNNER', severity='INFO', horse_no=BIBS[0], field='scores', reason='該当馬を確認')])
    return frozen, result


def pair_decision(incumbent, challenger, rows):
    a, b = rows[incumbent['horse_no']], rows[challenger['horse_no']]
    if incumbent['tier'] != challenger['tier']:
        return 'TIER_MISMATCH'
    if a['status'] != 'COMPARISON_READY' or b['status'] != 'COMPARISON_READY':
        return 'E_UNAVAILABLE'
    if a['basis'] != b['basis']:
        return 'BASIS_MISMATCH'
    return 'SWAP' if b['E5'] > a['E5'] and b['p5_raw'] > b['p0_5'] else 'KEEP'


def check(frozen, reply):
    def need(value, issue):
        if not value:
            raise ValueError(issue)
    rows = reply['horses']; roster = frozen['roster']; indexed = {h['horse_no']: h for h in rows}
    for field, expected in frozen['header'].items():
        need(reply[field] == expected, 'frozen ' + field)
    need(all(issue['horse_no'] is None or (type(issue['horse_no']) is int and issue['horse_no'] in roster)
             for issue in reply['validation_issues']), 'issue horse')
    need(len(indexed)==len(rows) and indexed.keys()==roster.keys(), 'roster')
    need(all(h['band']==roster[h['horse_no']] for h in rows), 'band')
    for horse in rows:
        scores = horse['scores']
        known = {key: score for key,score in scores.items() if score is not None}
        need(set(scores)==set(CAPS) and all(type(v) is int and 0<=v<=CAPS[key] for key,v in known.items()),
             'score components')
        total = sum(known.values())
        complete = len(known)==len(CAPS)
        need(horse['observed_cap']==sum(CAPS[key] for key in known) and horse['observed_sum']==total,
             'observed score totals')
        need(horse['score_status']==('complete' if complete else 'partial') and
             horse['total_score']==(total if complete else None), 'total score')
    enabled = frozen['selection']; rq = frozen['quotas']
    need((reply['selection_enabled'], reply['role_quota'], reply['ai_role'])==(enabled, rq, frozen['role']), 'frozen role')
    need(reply['role_cap']==(sum(rq.values()) if enabled else 0), 'role cap')
    expected_public, expected_shortfalls = [], []
    for b in BANDS:
        members = {k for k in roster if roster[k]==b and indexed[k]['eligibility']=='ELIGIBLE'}
        base = reply['band_ranks'][b]; backup = reply['evidence_band_ranks'][b]
        for order in (base, backup):
            need(len(order)==len(members) and set(order)==members, 'rank membership')
        any_partial = any(indexed[k]['score_status']=='partial' for k in members)
        basis = 'EVIDENCE' if any_partial else 'SCORE'
        need(all(indexed[k]['rank_basis']==basis for k in members), 'rank basis')
        if any_partial:
            need(base == backup, 'evidence ordering')
        else:
            def score_key(no):
                scores = indexed[no]['scores']
                return (-sum(scores.values()), -sum(v for k,v in scores.items() if k.startswith('V')),
                        -sum(v for k,v in scores.items() if k.startswith('H')), no)
            need(base==sorted(members, key=score_key), 'score ordering')
        q = rq[b] if enabled else 0
        inc = cha = None; after = base.copy()
        if not enabled:
            decision = 'SELECTION_DISABLED'
        elif not q or len(base)<=q:
            decision = 'NO_BOUNDARY'
        else:
            inc, cha = base[q-1:q+1]
            decision = pair_decision(indexed[inc], indexed[cha], frozen['e5_rows'])
            if decision=='SWAP':
                after[q-1:q+1] = [cha, inc]
        need(reply['expected_reviews'][b]==dict(incumbent=inc, challenger=cha, decision=decision), 'boundary')
        need(reply['selection_ranks'][b]==after, 'final ranks')
        expected_public.extend(after[:q])
        if q > len(members):
            expected_shortfalls.append((b, q, len(members), q-len(members)))
    need(expected_public==reply['public_candidates'], 'public prefix')
    need(sorted(expected_shortfalls)==sorted((v['band'],v['requested'],v['eligible'],v['missing']) for v in reply['shortfalls']), 'shortfalls')
    for h in rows:
        flag = h['horse_no'] in expected_public; reason = h['nonselect_reason']
        need(h['public_candidate'] is flag and ((reason is None)==flag), 'public flag')
        if not flag:
            want = 'SELECTION_DISABLED' if not enabled else 'BAND_QUOTA' if h['eligibility']=='ELIGIBLE' else h['eligibility']
            need(reason['code']==want, 'reason')


def changes(reply):
    def replaced(tag, change):
        other=deepcopy(reply);change(other)
        return tag,other
    yield replaced('wrong race', lambda r: r.update(race_id='other_race'))
    yield replaced('wrong selection target', lambda r: r.update(target_count=4 if r['target_count']!=4 else 5))
    yield replaced('wrong score schema', lambda r: r.update(schema_version=r['schema_version']+'-stale'))
    yield replaced('wrong prompt version', lambda r: r.update(prompt_version=r['prompt_version']+'-stale'))
    yield replaced('wrong learning stage', lambda r: r.update(learning_stage='OTHER'))
    if reply['selection_enabled']:
        yield replaced('different overall quota with same total', lambda r: r.update(quota={
            **r['quota'], 'A': r['quota']['A']+1, 'B': r['quota']['B']-1}))
        if reply['quota'] != reply['role_quota']:
            yield replaced('second-role quota copied into overall quota', lambda r: r.update(quota=r['role_quota'].copy()))
        new_mode = 'FIRM' if reply['allocation_mode']!='FIRM' else 'MIXED'
        yield replaced('coherent wrong classification', lambda r: r.update(
            mode=new_mode, allocation_mode=new_mode, mode_status='CONFIRMED', mode_policy_id='BASE_TRI_STATE_V1'))
        if reply['mode_status']=='PROVISIONAL':
            yield replaced('provisional reported as confirmed', lambda r: r.update(
                mode=r['allocation_mode'], mode_status='CONFIRMED', mode_policy_id='BASE_TRI_STATE_V1'))
    yield replaced('wrong 64-character hash', lambda r: r.update(snapshot_hash='b'*64))
    yield replaced('out of range in issue', lambda r: r['validation_issues'][1].update(horse_no=19))
    missing_bibs = set(range(1, 19)) - {h['horse_no'] for h in reply['horses']}
    if missing_bibs:
        missing_bib = min(missing_bibs)
        yield replaced('legal bib absent from frozen roster in issue', lambda r: r['validation_issues'][1].update(horse_no=missing_bib))
        yield replaced('substitute legal non-runner for existing horse', lambda r: r['horses'][0].update(horse_no=missing_bib))
        yield replaced('legal non-runner in evidence ranking', lambda r: r['evidence_band_ranks']['A'].__setitem__(0,missing_bib))
        if reply['selection_enabled']:
            yield replaced('legal non-runner in published list',lambda r: r['public_candidates'].__setitem__(0,missing_bib))
    yield replaced('missing runner', lambda r: r['horses'].pop())
    yield replaced('duplicate runner', lambda r: r['horses'].append(deepcopy(r['horses'][0])))
    yield replaced('wrong frozen band', lambda r: r['horses'][0].update(band='B'))
    yield replaced('wrong role', lambda r: r.update(ai_role='2nd' if r['ai_role']=='1st' else '1st'))
    for field in ['band_ranks','evidence_band_ranks','selection_ranks']:
        yield replaced('duplicate across bands', lambda r: r[field]['A'].append(r[field]['B'][0]))
        yield replaced('missing ranked member', lambda r: r[field]['A'].pop())
    yield replaced('reordered full ranks', lambda r: r['band_ranks']['A'].reverse())
    yield replaced('wrong final order', lambda r: r['selection_ranks']['A'].reverse())
    if not reply['selection_enabled']:
        yield replaced('published on stop',lambda r: r['public_candidates'].append(r['band_ranks']['A'][0]))
        return
    yield replaced('flag only',lambda r: next(h for h in r['horses'] if h['public_candidate']).update(public_candidate=False,nonselect_reason=dict(code='BAND_QUOTA',reason='枠外')))
    yield replaced('prefix order', lambda r: r['public_candidates'].reverse())
    yield replaced('truncated published list',lambda r: r['public_candidates'].pop())
    yield replaced('edited role quota',lambda r: r.update(role_quota={**r['role_quota'],'A':0}))
    inc=reply['expected_reviews']['A']['incumbent']
    yield replaced('self challenger',lambda r: r['expected_reviews']['A'].update(challenger=inc))
    yield replaced('skipped challenger',lambda r: r['expected_reviews']['A'].update(challenger=r['band_ranks']['B'][0]))
    yield replaced('opposite decision',lambda r: r['expected_reviews']['A'].update(decision='KEEP' if r['expected_reviews']['A']['decision']=='SWAP' else 'SWAP'))
    if reply['shortfalls']:
        yield replaced('duplicate shortage',lambda r: r['shortfalls'].append(deepcopy(r['shortfalls'][0])))
        yield replaced('wrong shortage count',lambda r: r['shortfalls'][0].update(missing=7))
        yield replaced('unreported shortage',lambda r: r['shortfalls'].clear())
    if reply['ai_role']=='2nd' and reply['target_count']==7:
        # The package validates a role's outputs before any cross-role fill or active roster correction.
        fill=next(h['horse_no'] for h in reply['horses'] if h['eligibility']=='ELIGIBLE' and not h['public_candidate'])
        yield replaced('aggregate substituted into role',lambda r: r['public_candidates'].__setitem__(-1,fill))


def main():
    arg=argparse.ArgumentParser(description=__doc__);arg.add_argument('schema',type=Path)
    file=arg.parse_args().schema
    if file.suffix=='.zip':
        with ZipFile(file) as z:
            schema=json.loads(z.read('schemas/output_schema.json'))
    else:
        schema=json.loads(file.read_text(encoding='utf-8'))
    validator=Draft202012Validator(schema);stats=Counter()
    common_hashes = {}
    for n in QUOTAS:
        for role in ('1st','2nd'):
            for part in (False,True):
                for stopped, provisional in ((False, False), (True, False), (False, True)):
                    for shortage in (False,True):
                        frozen, reply=fixture(schema,n,role,part,stopped,shortage,provisional)
                        pair = (n,part,stopped,shortage,provisional)
                        if role == '1st':
                            common_hashes[pair] = frozen['snapshot_hash']
                        else:
                            assert frozen['snapshot_hash'] == common_hashes[pair], pair
                            stats['matching role-pair hashes'] += 1
                        validator.validate(reply);check(frozen,reply);stats['accepted fixtures']+=1
                        for label,test in changes(reply):
                            try:
                                check(frozen,test)
                            except ValueError:
                                stats['rejected mutated replies']+=1
                            else:
                                raise AssertionError((n,role,part,stopped,shortage,label))
    # Full role replies for the non-swap gates, independent of E5 packet preflight.
    def rejects(frozen, bad):
        try:
            check(frozen, bad)
        except ValueError:
            return
        raise AssertionError('accepted invalid reply')

    for role in ('1st','2nd'):
        for b in BANDS:
            for side in (0,1):
                for tier, status in ((True,None),(False,'LOW_SUPPORT'),(False,'UNAVAILABLE_INPUT'),
                                     (True,'LOW_SUPPORT'),(True,'UNAVAILABLE_INPUT')):
                    case = (b,side,tier,status)
                    f,r = fixture(schema,18,role,False,False,False,boundary_case=case)
                    validator.validate(r)
                    check(f,r)
                    stats['accepted gated boundary fixtures']+=1
                    q = r['role_quota'][b]
                    for wrong in ('SWAP','KEEP','E_UNAVAILABLE' if tier else 'TIER_MISMATCH'):
                        bad = deepcopy(r)
                        review = bad['expected_reviews'][b];review['decision'] = wrong
                        if wrong=='SWAP':
                            i,j=review['incumbent'],review['challenger']
                            bad['selection_ranks'][b][q-1:q+1]=[j,i]
                            bad['public_candidates'][bad['public_candidates'].index(i)]=j
                            horses={h['horse_no']:h for h in bad['horses']}
                            horses[i].update(public_candidate=False,nonselect_reason=dict(code='BAND_QUOTA',reason='枠外'))
                            horses[j].update(public_candidate=True,nonselect_reason=None)
                        validator.validate(bad)
                        rejects(f,bad)
                        stats['rejected erroneous boundary decisions']+=1
        for partial in (False,True):
            for stopped in (False,True):
                f,r = fixture(schema,18,role,partial,stopped,True)
                for horse in r['horses']:
                    for field in ('observed_sum','observed_cap','total_score'):
                        bad = deepcopy(r)
                        h = next(x for x in bad['horses'] if x['horse_no']==horse['horse_no'])
                        value = h[field]
                        h[field] = 0 if value is None else (value+1 if value<86 else value-1)
                        rejects(f,bad)
                        stats['rejected wrong score arithmetic']+=1
    # Distinct valid READY bases conflict with a single packet-wide calibration ID in
    # current input. Exercise this projection safeguard alone, never as a valid full packet.
    a,b = dict(horse_no=1,tier='B'),dict(horse_no=2,tier='B')
    for first,second in (('RAW_UNCALIBRATED','CALIBRATION_APPLIED'),('CALIBRATION_APPLIED','RAW_UNCALIBRATED')):
        projected = {1:dict(status='COMPARISON_READY',basis=first),2:dict(status='COMPARISON_READY',basis=second)}
        assert pair_decision(a,b,projected)=='BASIS_MISMATCH'
        stats['basis guard projections']+=1
    print(dict(stats))


if __name__=='__main__':
    main()
