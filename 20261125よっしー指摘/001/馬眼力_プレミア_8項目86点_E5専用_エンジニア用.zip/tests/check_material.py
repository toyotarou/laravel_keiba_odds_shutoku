"""Offline acceptance examples for known materials incorrectly declared missing.

Use: python tests/check_material.py schemas/output_schema.json
Checks H4 and V5 only, using a small projection of already authenticated sources.
It does not calculate AI scores, reimplement the production input verifier or run PHP.
"""
from copy import deepcopy
from datetime import datetime, timedelta, timezone
from hashlib import sha256
import json
import math
from pathlib import Path
import sys

from jsonschema import Draft202012Validator

try:
    from check_roster import fixture, check as check_roster
except ModuleNotFoundError:
    from r3_roster import fixture, check as check_roster


FREEZE = datetime(2026, 11, 15, 5, 54, 30, tzinfo=timezone.utc)
RACE = 'qa_R3_8'
SLOTS = {21, 18, 15, 12, 9, 6}


def source(ref, field, value, unit, *, members=(18,), scope='HORSE', group='course',
           slot=None, observed=None, available=None):
    return dict(source_ref=ref, field=field, value=value, unit=unit, source_kind='OBSERVED',
                race_id=RACE, scope=scope, horse_nos=list(members) if scope=='HORSE' else [],
                applicable_horse_nos=list(members) if scope=='COHORT' else [], dependency_key=group,
                slot_offset=slot, observed_at=observed or (FREEZE-timedelta(days=1)),
                available_at=available or FREEZE, computed_at=None)


def finite_number(value):
    return type(value) in (int, float) and math.isfinite(value)


def available_items(records, no, *, race_id, freeze_at):
    """One tested material path: accepted observed values; source ingestion is upstream."""
    rates, counts, lows, highs = set(), set(), set(), set()
    for row in records:
        if row['race_id'] != race_id or row['source_kind'] != 'OBSERVED':
            continue
        if not (row['observed_at'] <= row['available_at'] <= freeze_at):
            continue
        if row['scope'] == 'HORSE' and row['horse_nos'] == [no]:
            owners = (no,)
        elif row['scope'] == 'COHORT' and no in row['applicable_horse_nos']:
            owners = tuple(sorted(row['applicable_horse_nos']))
        else:
            continue
        key = (row['dependency_key'], row['scope'], owners, row['slot_offset'], row['observed_at'])
        field, value, unit = row['field'], row['value'], row['unit']
        if field in ('similar_top3_rate','similar_top5_rate') and unit == 'percent' and finite_number(value) and 0 <= value <= 100:
            rates.add(key)
        elif field == 'similar_sample_count' and unit == 'count' and type(value) is int and value > 0:
            counts.add(key)
        elif row['scope'] == 'HORSE' and row['slot_offset'] in SLOTS and unit == 'odds' and finite_number(value) and value > 0:
            if field == 'place_min':
                lows.add(row['slot_offset'])
            elif field == 'place_max':
                highs.add(row['slot_offset'])
    has_stats = bool(rates & counts)
    return {'H4':has_stats, 'V5':has_stats or bool(lows & highs)}


def disputed_nulls(available, scores, *, server_reconstruction=False):
    # Reconstructed points require original provenance. Materials alone cannot supply them.
    if server_reconstruction:
        return set()
    return {key for key in available if scores[key] is None and available[key]}


def run(schema):
    cases = 0
    def expect(actual, wanted):
        nonlocal cases
        assert actual == wanted, (actual, wanted)
        cases += 1

    rate = source('h18_similar_top3_rate','similar_top3_rate',0,'percent')
    count = source('h18_similar_sample_count','similar_sample_count',40,'count')
    lo = source('h18_place_min_6','place_min',2.1,'odds',slot=6)
    hi = source('h18_place_max_6','place_max',3.5,'odds',slot=6)
    modify = lambda row, **fields: dict(row,**fields)
    cohort_rate = modify(rate,scope='COHORT',horse_nos=[],applicable_horse_nos=[18,4])
    cohort_count = modify(count,scope='COHORT',horse_nos=[],applicable_horse_nos=[4,18])
    examples = [
        ([rate,count],True,True), ([modify(rate,field='similar_top5_rate',value=100),count],True,True),
        ([rate],False,False), ([count],False,False), ([rate,modify(count,value=0)],False,False),
        ([rate,modify(count,value=40.5)],False,False), ([rate,modify(count,value=True)],False,False),
        ([modify(rate,unit='ratio'),count],False,False), ([modify(rate,value=None),count],False,False),
        ([modify(rate,value=-1),count],False,False), ([modify(rate,value=101),count],False,False),
        ([rate,modify(count,horse_nos=[4])],False,False), ([cohort_rate,cohort_count],True,True),
        ([cohort_rate,modify(cohort_count,applicable_horse_nos=[18,5])],False,False),
        ([rate,cohort_count],False,False), ([rate,modify(count,dependency_key='other')],False,False),
        ([rate,modify(count,slot_offset=6)],False,False),
        ([rate,modify(count,observed_at=count['observed_at']-timedelta(microseconds=1))],False,False),
        ([rate,modify(count,available_at=FREEZE+timedelta(microseconds=1))],False,False),
        ([rate,modify(count,race_id='other')],False,False), ([lo,hi],False,True), ([lo],False,False),
        ([lo,modify(hi,slot_offset=9)],False,False), ([lo,modify(hi,horse_nos=[4])],False,False),
        ([lo,modify(hi,available_at=FREEZE+timedelta(microseconds=1))],False,False),
        ([rate,lo,hi],False,True), ([lo,rate,count],True,True), ([],False,False)]
    for records, h4, v5 in examples:
        known = available_items(records,18,race_id=RACE,freeze_at=FREEZE)
        expect(known, {'H4':h4, 'V5':v5})
        for value_h4, value_v5 in ((None,None),(None,0),(0,None),(3,1)):
            scores = {'H4':value_h4,'V5':value_v5}
            expected = {k for k, flag, v in [('H4',h4,value_h4),('V5',v5,value_v5)] if flag and v is None}
            expect(disputed_nulls(known,scores), expected)
    # A truly absent answer row cannot acquire an invented score from a complete source pair.
    for records in ([rate,count],[lo,hi],[]):
        fake_recovered = {'H4':None, 'V5':None}
        expect(disputed_nulls(available_items(records,18,race_id=RACE,freeze_at=FREEZE),fake_recovered,server_reconstruction=True),set())
        expect(fake_recovered,{'H4':None,'V5':None})

    # Roster checker concerns membership and order. This isolates why source-backed verification
    # is also necessary: an arithmetically consistent false partial can change a published list.
    v = Draft202012Validator(schema)
    for role in ('1st','2nd'):
        f, good = fixture(schema,8,role,False,False,False)
        assert f['race_id'] == RACE
        f['input_freeze_at'] = FREEZE
        f['example_sources'] = [rate, count]
        # Bind the added source projection and cutoff to both synthetic views. This is
        # a test hash, not an implementation of the production PHP snapshot serializer.
        payload = [f['snapshot_hash'], f['input_freeze_at'], f['example_sources']]
        digest = sha256(json.dumps(payload,sort_keys=True,default=lambda d:d.isoformat()).encode()).hexdigest()
        f['snapshot_hash'] = f['header']['snapshot_hash'] = good['snapshot_hash'] = digest
        material = available_items(f['example_sources'],18,race_id=f['race_id'],freeze_at=f['input_freeze_at'])
        selected = next(h for h in good['horses'] if h['horse_no']==18)
        refs=[rate['source_ref'],count['source_ref']]
        selected['family_review']['similar_value']['source_refs']=refs
        selected['score_evidence']['H4'] = {'source_refs':refs,'reason':'同条件40走で3着以内0回'}
        expect(v.is_valid(good),True)
        check_roster(f,good)
        bad = deepcopy(good);h=next(x for x in bad['horses'] if x['horse_no']==18)
        h['scores']['H4']=None
        h['score_evidence']['H4']={'source_refs':[rate['source_ref']],'reason':'類似成績の母数が不明'}
        h.update(score_status='partial',observed_cap=77,total_score=None)
        for horse in bad['horses']:
            if horse['band']=='A':
                horse['rank_basis']='EVIDENCE'
        order=bad['evidence_band_ranks']['A'];q=bad['role_quota']['A']
        bad['band_ranks']['A']=order.copy()
        bad['selection_ranks']['A']=order.copy()
        bad['expected_reviews']['A']=dict(incumbent=order[q-1],challenger=order[q],decision='KEEP')
        pub=[n for b in ('A','B','D') for n in bad['selection_ranks'][b][:bad['role_quota'][b]]]
        bad['public_candidates']=pub
        for horse in bad['horses']:
            on = horse['horse_no'] in pub
            horse.update(public_candidate=on,nonselect_reason=None if on else dict(code='BAND_QUOTA',reason='枠外'))
        expect(v.is_valid(bad),True)
        check_roster(f,bad)
        expect(good['public_candidates'] != pub,True)
        expect(disputed_nulls(material,selected['scores']),set())
        expect(disputed_nulls(material,h['scores']),{'H4'})
    print(f'{cases} frozen score-material checks passed')


if __name__=='__main__':
    run(json.loads(Path(sys.argv[1]).read_text(encoding='utf-8')))
